"""Shared operation entry points and non-destructive geometry tools.
Existing joint engines remain authoritative for their own geometry.
"""
import math
import bpy
from bpy.types import Operator, Panel, PropertyGroup
from bpy.props import PointerProperty, EnumProperty, FloatProperty, BoolProperty, StringProperty
from mathutils import Vector, Matrix
from . import ui, ball_joint as bj
from .hinge_maker import face_hinge as fh
from .hinge_maker.face_hinge_math import plan_ab_span, plan_shoulder_head
from .geometry_ops import volume, solid, stage, cut_checked, union_checked, intersect_volume
from .motion_math import plan_poses, pose_label, rotation_matrix

AXES=[('X','X',''),('Y','Y',''),('Z','Z','')]

def axis_vector(axis):
    return Vector(tuple(float(axis==a) for a in 'XYZ'))

def standalone_plan(context,s):
    span=plan_ab_span(a_width=s.a_width,b_width=s.b_width,gap=s.axial_gap,
        outer_diameter=s.outer_diameter,axle_diameter=s.axle_diameter,
        radial_clearance=s.radial_clearance,cap_wall=s.cap_wall,
        tip_clearance=s.shoulder_axial_clearance if s.shoulder_enabled else s.tip_clearance,
        min_radial_wall=s.radial_wall)
    shoulder=plan_shoulder_head(span,shoulder_diameter=s.shoulder_diameter,
        shoulder_thickness=s.shoulder_thickness,shoulder_radial_clearance=s.shoulder_radial_clearance,
        shoulder_axial_clearance=s.shoulder_axial_clearance,min_radial_wall=s.radial_wall) if s.shoulder_enabled else None
    return dict(mode='STRAIGHT',pivot=fh._center(context),axis=fh._axis(s),span=span,shoulder=shoulder,beams=[],faces={},angles=(),sweep_padding=0.)

def selected_meshes(context,n):
    selected=list(context.selected_objects); active=context.view_layer.objects.active
    if context.mode!='OBJECT' or len(selected)!=n or active not in selected or any(o.type!='MESH' for o in selected):
        raise ValueError(f'オブジェクトモードでメッシュを{n}個選択してください')
    return ([o for o in selected if o!=active]+[active])

def require_mesh(o):
    if o is None or o.type!='MESH': raise ValueError('対象メッシュを指定してください')
    return o

def restore_selection(context,selected,active):
    for o in list(context.selected_objects): o.select_set(False)
    for o in selected:
        try:
            if not o.hide_get(): o.select_set(True)
        except (ReferenceError,RuntimeError): pass
    try: context.view_layer.objects.active=active
    except (ReferenceError,RuntimeError,TypeError): pass

def add_cyl(plan,col,start,end,radius,name):
    return fh._add_cylinder_at(plan['span'],plan['pivot'],plan['axis'],start,end,radius,col,name)

def build_rotary(context,s,col,attach=False):
    p=standalone_plan(context,s); sp=p['span']; sh=p['shoulder']
    a=add_cyl(p,col,sp.a_outer,sp.a_inner,sp.outer_radius,'CJM_Rotary_A')
    b=add_cyl(p,col,sp.b_inner,sp.b_outer,sp.outer_radius,'CJM_Rotary_B')
    if attach:
        src_a=require_mesh(s.object_a); src_b=require_mesh(s.object_b)
        if src_a==src_b: raise ValueError('異なるA/Bを指定してください')
        aa=stage(context,src_a,col,'CJM_Rotary_A_Mounted'); bb=stage(context,src_b,col,'CJM_Rotary_B_Mounted')
        union_checked(aa,a); union_checked(bb,b); a,b=aa,bb
    cut_checked(a,add_cyl(p,col,sh.mouth_start if sh else sp.bore_start,sh.mouth_end if sh else sp.bore_end,sp.bore_radius,'CJM_bore'))
    if sh: cut_checked(a,add_cyl(p,col,sh.cavity_start,sh.cavity_end,sh.cavity_radius,'CJM_head_space'))
    union_checked(b,add_cyl(p,col,sh.shaft_start if sh else sp.shaft_min,sp.shaft_max,sp.axle_radius,'CJM_shaft'))
    if sh: union_checked(b,add_cyl(p,col,sh.head_start,sh.head_end,sh.head_radius,'CJM_head'))
    va,vb=solid(a),solid(b)
    if intersect_volume(context,a,b,col)>max(1e-15,min(va,vb)*1e-8): raise ValueError('A/Bが初期姿勢で重なっています')
    for o,side in ((a,'A'),(b,'B')):
        o['cjm_mechanism']='ROTARY';o['cjm_owner']=side;o['cjm_shoulder']=bool(sh)
    return a,b

def split_solid(context,source,col,plane,axis):
    original=stage(context,source,col,'CJM_split_source'); total=solid(original)
    u=axis_vector('Y' if abs(axis.x)>.9 else 'X'); v=axis.cross(u).normalized()
    u=v.cross(axis).normalized()
    context.view_layer.update()
    out=[]
    for positive,side in ((True,'A'),(False,'B')):
        part=stage(context,original,col,source.name+'_'+side)
        cutter=bj.create_body_receiver_halfspace(original,plane,axis,u,v,positive,col,'CJM_split_halfspace')
        try: bj.boolean_apply(part,cutter,'INTERSECT')
        finally: fh._remove(cutter)
        solid(part); bj.body_receiver_check_half_side(part,plane,axis,positive)
        part['cjm_split_source']=source.name;out.append(part)
    if abs(sum(volume(o) for o in out)-total)>max(1e-12,total*1e-5): raise ValueError('分割前後の体積が一致しません')
    fh._remove(original);return out

def inspect_motion(context,a,b,col,pivot,axes,poses):
    fixed=stage(context,a,col,'CJM_fixed'); moving=stage(context,b,col,'CJM_moving')
    va,vb=solid(fixed),solid(moving); tol=max(1e-15,min(va,vb)*1e-8)
    original=moving.matrix_world.copy(); hits=[]; peak=0.; peak_pose=None
    # Each pose is evaluated from the original world transform, never cumulatively.
    to_pivot=Matrix.Translation(pivot); from_pivot=Matrix.Translation(-pivot)
    for pose in poses:
        rot=rotation_matrix(Matrix, axes, pose)
        moving.matrix_world=to_pivot @ rot @ from_pivot @ original
        context.view_layer.update()
        overlap=intersect_volume(context,fixed,moving,col)
        if not math.isfinite(overlap) or overlap<0: raise ValueError('干渉体積を正しく計算できません')
        if overlap>peak: peak=overlap;peak_pose=pose
        if overlap>tol: hits.append(pose)
    return hits,peak,tol,peak_pose

class CJM_CommonSettings(PropertyGroup):
    split_target: PointerProperty(type=bpy.types.Object)
    split_axis: EnumProperty(name='分割面の法線',items=AXES,default='X')
    hide_split_source: BoolProperty(name='成功後に元を非表示',default=True)
    fixed: PointerProperty(type=bpy.types.Object)
    moving: PointerProperty(type=bpy.types.Object)
    motion_mode: EnumProperty(name='検査方式',items=[('SINGLE','単軸','1軸'),('DOUBLE','2軸','2軸の全角度組合せ'),('TRIPLE','3軸','3軸の全角度組合せ')],default='SINGLE')
    motion_axis: EnumProperty(name='回転軸',items=AXES,default='X')
    angle_min: FloatProperty(name='最小角（°）',default=-20,min=-180,max=180)
    angle_max: FloatProperty(name='最大角（°）',default=20,min=-180,max=180)
    angle_step: FloatProperty(name='角度刻み（°）',default=10,min=2,max=30)
    motion_axis_2: EnumProperty(name='第2回転軸',items=AXES,default='Y')
    angle_min_2: FloatProperty(name='最小角（°）',default=-20,min=-180,max=180)
    angle_max_2: FloatProperty(name='最大角（°）',default=20,min=-180,max=180)
    angle_step_2: FloatProperty(name='角度刻み（°）',default=10,min=2,max=30)
    motion_axis_3: EnumProperty(name='第3回転軸',items=AXES,default='Z')
    angle_min_3: FloatProperty(name='最小角（°）',default=0,min=-180,max=180)
    angle_max_3: FloatProperty(name='最大角（°）',default=0,min=-180,max=180)
    angle_step_3: FloatProperty(name='角度刻み（°）',default=10,min=2,max=30)
    status: StringProperty(default='未実行')

class CJM_OT_targets(Operator):
    bl_idname='cjm.register_targets';bl_label='選択中の本体を登録';bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        try:
            mode=context.scene.cjm_settings.mode
            if mode=='BALL':
                context.scene.ball_joint_settings.mount_target=selected_meshes(context,1)[0]
            elif mode=='HINGE':
                # Preserve the original capture operator, including CBDK validation/status.
                from .hinge_maker import HINGEMAKER_OT_capture_objects
                return HINGEMAKER_OT_capture_objects.execute(self,context)
            elif mode in ('ROTARY','TRUNNION'):
                a,b=selected_meshes(context,2)
                s=context.scene.face_hinge_settings
                s.object_a=a;s.object_b=b
                if mode=='ROTARY':
                    s.face_a=-1;s.face_b=-1;s.signature_a='';s.signature_b=''
            else: raise ValueError('機構を選択してください')
            return {'FINISHED'}
        except Exception as e: self.report({'ERROR'},str(e));return {'CANCELLED'}

class CJM_OT_rotary(Operator):
    bl_idname='cjm.generate_rotary';bl_label='回転ジョイント生成';bl_options={'REGISTER','UNDO'}
    attach: BoolProperty(default=False)
    def execute(self,context):
        if context.mode!='OBJECT' or context.scene.cjm_settings.mode!='ROTARY':
            self.report({'ERROR'},'回転ジョイント / オブジェクトモードで実行');return {'CANCELLED'}
        selected=tuple(context.selected_objects);active=context.view_layer.objects.active;col=None
        try:
            s=context.scene.face_hinge_settings
            col=fh._make_collection('CJM_Rotary_Result',context.scene)
            a,b=build_rotary(context,s,col,self.attach)
            fh._preview_clear()
            for o in list(context.selected_objects):o.select_set(False)
            a.select_set(True);b.select_set(True);context.view_layer.objects.active=b
            s.last_error='';return {'FINISHED'}
        except Exception as e:
            if col: fh._destroy_collection(col)
            restore_selection(context,selected,active)
            self.report({'ERROR'},str(e));return {'CANCELLED'}

class CJM_OT_common_capture(Operator):
    bl_idname='cjm.common_capture';bl_label='選択から登録';bl_options={'REGISTER','UNDO'}
    kind: StringProperty(default='SPLIT')
    def execute(self,context):
        try:
            s=context.scene.cjm_common
            if self.kind=='SPLIT':s.split_target=selected_meshes(context,1)[0]
            else:s.fixed,s.moving=selected_meshes(context,2)
            s.status='対象を登録しました';return {'FINISHED'}
        except Exception as e:self.report({'ERROR'},str(e));return {'CANCELLED'}

class CJM_OT_split(Operator):
    bl_idname='cjm.split_solid';bl_label='カーソル位置で任意分割';bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        if context.mode!='OBJECT': self.report({'ERROR'},'オブジェクトモードで実行');return {'CANCELLED'}
        s=context.scene.cjm_common; col=None;selected=tuple(context.selected_objects);active=context.view_layer.objects.active
        try:
            src=require_mesh(s.split_target);col=fh._make_collection('CJM_Split_Result',context.scene)
            a,b=split_solid(context,src,col,context.scene.cursor.location.copy(),axis_vector(s.split_axis))
            for o in list(context.selected_objects):o.select_set(False)
            a.select_set(True);b.select_set(True);context.view_layer.objects.active=b
            if s.hide_split_source:src.hide_set(True)
            s.status='分割成功（閉じた立体・体積一致）';return {'FINISHED'}
        except Exception as e:
            if col:fh._destroy_collection(col)
            restore_selection(context,selected,active);s.status='分割中止: '+str(e);self.report({'ERROR'},str(e));return {'CANCELLED'}

def motion_plan(s):
    n={'SINGLE':1,'DOUBLE':2,'TRIPLE':3}[s.motion_mode]
    specs=[]
    for suffix in ('','_2','_3')[:n]:
        specs.append(tuple(getattr(s,key+suffix) for key in ('motion_axis','angle_min','angle_max','angle_step')))
    return plan_poses(specs)

class CJM_OT_motion(Operator):
    bl_idname='cjm.check_motion';bl_label='指定角度を干渉検査'
    def execute(self,context):
        if context.mode!='OBJECT':self.report({'ERROR'},'オブジェクトモードで実行');return {'CANCELLED'}
        s=context.scene.cjm_common;col=None;selected=tuple(context.selected_objects);active=context.view_layer.objects.active
        try:
            a,b=require_mesh(s.fixed),require_mesh(s.moving)
            if a==b:raise ValueError('固定側と可動側は別の物体を指定')
            axes,poses=motion_plan(s)
            col=fh._make_collection('CJM_Motion_TEMP',context.scene)
            hits,peak,tol,peak_pose=inspect_motion(context,a,b,col,context.scene.cursor.location.copy(),axes,poses)
            s.status=(f'{len(poses)}姿勢中 {len(hits)}姿勢で体積干渉。最初 {pose_label(axes,hits[0])} / 最大 {pose_label(axes,peak_pose)}: {peak:.5g}' if hits else f'{len(poses)}姿勢で体積干渉なし（連続角度の保証なし）')
            self.report({'WARNING'} if hits else {'INFO'},s.status);return {'FINISHED'}
        except Exception as e:s.status='検査中止: '+str(e);self.report({'ERROR'},str(e));return {'CANCELLED'}
        finally:
            if col:fh._destroy_collection(col)
            restore_selection(context,selected,active)

class CJM_OT_mesh_diagnose(Operator):
    bl_idname='cjm.mesh_diagnose';bl_label='選択メッシュを診断'
    def execute(self,context):
        if context.mode!='OBJECT':self.report({'ERROR'},'オブジェクトモードで実行');return {'CANCELLED'}
        settings=context.scene.cjm_common;col=None
        try:
            sources=[o for o in context.selected_objects if o.type=='MESH']
            if not sources:raise ValueError('メッシュを選択してください')
            col=fh._make_collection('CJM_Diagnosis_TEMP',context.scene)
            summaries=[];bad_count=0
            for src in sources:
                obj=fh._make_stage(src,col,'Diagnosis',context.evaluated_depsgraph_get())
                n=bj.count_nonmanifold_edges(obj);islands=fh._mesh_components(obj.data)
                v=volume(obj) if n==0 else None
                valid=v is not None and v>0 and math.isfinite(v)
                bad_count+=not valid
                summaries.append(f'{src.name}: 非マニフォールド辺 {n}, 島 {islands}, '+('体積有効' if valid else '体積不正／未計算'))
            settings.status=' / '.join(summaries)
            self.report({'WARNING'} if bad_count else {'INFO'},settings.status[:180]);return {'FINISHED'}
        except Exception as e:settings.status='診断中止: '+str(e);self.report({'ERROR'},str(e));return {'CANCELLED'}
        finally:
            if col:fh._destroy_collection(col)

class VIEW3D_PT_cjm_rotary_solo(Panel):
    bl_idname='VIEW3D_PT_cjm_rotary_solo';bl_label='回転ジョイント・単体／直接取付'
    bl_space_type='VIEW_3D';bl_region_type='UI';bl_category=ui.CATEGORY;bl_parent_id=ui.ROOT
    @classmethod
    def poll(cls,context):return ui.visible(context,'ROTARY') and getattr(context.scene.cjm_settings,'rotary_section','FACE')!='FACE'
    def draw(self,context):
        l=self.layout;s=context.scene.face_hinge_settings;attach=context.scene.cjm_settings.rotary_section=='ATTACH'
        if attach:
            l.label(text='A=受け / B=軸側（アクティブ）');l.operator('cjm.register_targets',icon='EYEDROPPER');l.prop(s,'object_a');l.prop(s,'object_b');l.label(text='ナックルと本体を重ねて配置')
        l.label(text='3DカーソルをA/B間の軸中心に配置')
        for p in ('axis','reverse_axis','a_width','b_width','outer_diameter','axle_diameter','radial_clearance','axial_gap','cap_wall','radial_wall','shoulder_enabled'):
            ui.face_prop(l,s,p,**({'expand':True} if p=='axis' else {}))
        for p in (('shoulder_diameter','shoulder_thickness','shoulder_radial_clearance','shoulder_axial_clearance') if s.shoulder_enabled else ('tip_clearance',)):ui.face_prop(l,s,p)
        try:standalone_plan(context,s);l.label(text='寸法条件OK',icon='CHECKMARK')
        except Exception as e:l.label(text=str(e)[:100],icon='ERROR')
        l.prop(s,'live_enabled');r=l.row(align=True);r.operator('face_hinge.preview_parts',text='プレビュー');r.operator('face_hinge.clear_preview',text='削除')
        op=l.operator('cjm.generate_rotary',text='本体へ直接取付' if attach else '単体生成',icon='MOD_BOOLEAN');op.attach=attach
        l.label(text='元のモデルは保持・複製で加工')
        if attach:l.label(text='成功後は元A/Bを手動で非表示にしてください')

class VIEW3D_PT_cjm_common(Panel):
    bl_idname='VIEW3D_PT_cjm_common';bl_label='共通加工ツール'
    bl_space_type='VIEW_3D';bl_region_type='UI';bl_category=ui.CATEGORY;bl_parent_id=ui.ROOT;bl_options={'DEFAULT_CLOSED'}
    def draw(self,context):
        l=self.layout;s=context.scene.cjm_common
        b=l.box();b.label(text='任意分割（閉じた立体）',icon='MOD_BOOLEAN');b.prop(s,'split_target');b.operator('cjm.common_capture',text='選択中を登録').kind='SPLIT';b.prop(s,'split_axis',expand=True);b.label(text='分割面は3Dカーソルを通る');b.prop(s,'hide_split_source');b.operator('cjm.split_solid');b.label(text='ダボ付き球受け分割は旧機能を使用')
        b=l.box();b.label(text='可動域・サンプル干渉検査',icon='DRIVER_ROTATIONAL_DIFFERENCE')
        b.prop(s,'fixed',text='固定側 A');b.prop(s,'moving',text='可動側 B');b.operator('cjm.common_capture',text='選択中の2体を登録').kind='MOTION'
        b.label(text='アクティブ=B / カーソル=共通中心');b.prop(s,'motion_mode',expand=True)
        n={'SINGLE':1,'DOUBLE':2,'TRIPLE':3}[s.motion_mode]
        for i,suffix in enumerate(('','_2','_3')[:n],1):
            k=b.box();k.label(text=f'第{i}軸（ワールド固定）');k.prop(s,'motion_axis'+suffix,expand=True)
            for key in ('angle_min','angle_max','angle_step'):k.prop(s,key+suffix)
        b.label(text='順番に回転 / 0°を含む全組合せ')
        try:
            axes,poses=motion_plan(s);b.label(text=f'検査姿勢数: {len(poses)}',icon='CHECKMARK');b.operator('cjm.check_motion')
        except ValueError as exc:b.label(text=str(exc),icon='ERROR')
        b.label(text='離散姿勢の体積検査。連続保証なし')
        b=l.box();b.label(text='メッシュ診断（評価済み形状）');b.operator('cjm.mesh_diagnose');b.label(text='閉鎖性・島数・体積の簡易検査')
        for i in range(0,len(s.status),27):l.label(text=s.status[i:i+27])

CLASSES=(CJM_CommonSettings,CJM_OT_targets,CJM_OT_rotary,CJM_OT_common_capture,CJM_OT_split,CJM_OT_motion,CJM_OT_mesh_diagnose,VIEW3D_PT_cjm_rotary_solo,VIEW3D_PT_cjm_common)
