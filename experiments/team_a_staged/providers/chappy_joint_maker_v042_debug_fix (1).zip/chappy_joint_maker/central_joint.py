"""ABA+CBC: only B receives additions. A/C receive subtraction exclusively."""
from mathutils import Vector,Matrix
import bmesh
from math import radians
from . import central_math as cm
from .hinge_maker import face_hinge as fh
from .hinge_maker.face_hinge_math import sweep_angles,sweep_padding,rotate_xyz
from .geometry_ops import stage,solid,union_checked,intersect_volume
from . import ball_joint as bj
from . import shape_diagnostics as diag

def plan(s,j,index):
    if not j.pivot_set:raise ValueError('上下の軸中心を記憶してください')
    pivot=Vector(j.pivot);axis=fh._axis(type('Axis',(),dict(axis=s.axis,reverse_axis=j.reverse_axis))())
    sp=cm.span(j)
    # A/C face is checked for stale registration, but NEVER used to make a beam.
    outer='a' if index==0 else 'c'; inner='bu' if index==0 else 'bl'
    face=lambda obj,slot:fh._face_vertices(obj,getattr(s,'face_'+slot),getattr(s,'signature_'+slot))
    face(getattr(s,'object_'+outer),outer)
    center,normal,verts=face(s.object_b,inner)
    radial=center-pivot;radial-=axis*radial.dot(axis)
    if radial.length<sp.hub_radius*.3:raise ValueError('B取付面と軸中心の距離が不足しています')
    radial.normalize()
    start=center-normal*j.embed_depth;end=pivot+radial*sp.hub_radius*.65
    if (end-start).length<j.support_thickness*.25:raise ValueError('中央支持部が短すぎます')
    angles=sweep_angles(j.minimum_angle,j.maximum_angle,j.angle_step)
    step=max((b-a for a,b in zip(angles,angles[1:])),default=0.)
    reach=max((start-pivot).length,(end-pivot).length)+j.support_thickness
    pad=sweep_padding(reach,step,j.swing_clearance)
    return dict(pivot=pivot,axis=axis,span=sp,beam=dict(start=start,end=end,width=j.support_width,thickness=j.support_thickness,radial=radial),angles=angles,pad=pad,face=verts)

def separation(p,q):
    d=q['pivot']-p['pivot'];length=d.length
    if length<1e-8:raise ValueError('上下の軸中心を離してください')
    d.normalize()
    def extent(v):
        sp=v['span'];a=abs(v['axis'].dot(d));return a*sp.guard_end+(max(sp.slot_radius,sp.guard_radius))*(max(0.,1-a*a)**.5)
    gap=length-extent(p)-extent(q)
    if gap<=0:raise ValueError('上下のヒンジ加工領域が重なります')
    return gap

def cylinder(p,col,name,r,lo,hi):
    return fh._make_cylinder(name,p['pivot']+p['axis']*((lo+hi)/2),p['axis'],r,hi-lo,col)

def beam(p,col,name,pad=0,angle=0):
    b=p['beam'];axis=p['axis'];pivot=p['pivot']
    a=Vector(rotate_xyz(b['start'],pivot,axis,angle));z=Vector(rotate_xyz(b['end'],pivot,axis,angle))
    return fh._make_beam(name,a,z,axis,b['width']+2*pad,b['thickness']+2*pad,col)

def tolerance(v):return max(1e-12,v*1e-7)

def cut(context,target,cutter,col):
    # Skip disjoint cutters, and never accept an empty/invalid target.
    try:
        before=solid(target);overlap=intersect_volume(context,target,cutter,col)
        if overlap<=tolerance(before):return
        bj.boolean_apply(target,cutter,'DIFFERENCE');after=solid(target)
        if before-after<=tolerance(before):raise ValueError('逃げ加工で体積が減りませんでした')
    finally:fh._remove(cutter)

def require_guard(context,target,p,col,phase,side,component):
    """Both complete sleeves + end caps must survive. No added receiver arms."""
    sp=p['span'];eps=min(sp.guard_end-sp.bore_end,sp.slot_half)*1e-4
    for sign in (-1,1):
        lo,hi=sorted((sign*(sp.slot_half+eps),sign*sp.guard_end))
        guard=cylinder(p,col,'CJM_Bearing_Guard',sp.guard_radius,lo,hi)
        bore=cylinder(p,col,'CJM_Guard_Bore',sp.bore_radius,*sorted((0,sign*sp.bore_end)))
        try:
            bj.boolean_apply(guard,bore,'DIFFERENCE');v=solid(guard)
            overlap=intersect_volume(context,guard,target,col)
            diag.guard_failure(phase,side,component,sign,v,overlap,max(tolerance(v),v*1e-5))
        finally:fh._remove(bore);fh._remove(guard)

def hull_geometry(points):
    """Create a closed convex hull; discard all interior/unused input vertices."""
    bm=bmesh.new()
    try:
        verts=[bm.verts.new(v) for v in points]
        bmesh.ops.convex_hull(bm,input=verts,use_existing_faces=False)
        faces=list(bm.faces)
        if not faces:raise ValueError('中央本体の逃げ用包絡を作成できません')
        bmesh.ops.recalc_face_normals(bm,faces=faces)
        used=list(dict.fromkeys(v for f in faces for v in f.verts));indices={v:i for i,v in enumerate(used)}
        return [tuple(v.co) for v in used],[tuple(indices[v] for v in f.verts) for f in faces]
    finally:bm.free()


def body_envelope(points,p,j,col):
    # Only the original body, not the shaft, hub or bearing interfaces.
    # Convex envelope deliberately overbounds concave shapes. Guard checks
    # fail closed if conservative subtraction would damage a bearing.
    margin=cm.body_sweep_margin(points,p['pivot'],p['axis'],p['angles'],j.swing_clearance)
    vertices,faces=hull_geometry(cm.padded_points(points,margin))
    obj=fh._link_new_mesh('CJM_Body_Clearance',vertices,faces,col)
    solid(obj)
    return obj


def pose(p,angle,neutral):
    center=p['pivot']
    return Matrix.Translation(center)@Matrix.Rotation(radians(angle),4,p['axis'])@Matrix.Translation(-center)@neutral


def build(context,s,col,pairs):
    with diag.operation('入力メッシュの複製・検査'):
        out=[stage(context,o,col,'CJM_Central_'+k) for o,k in zip((s.object_a,s.object_b,s.object_c),'ABC')]
        a,b,c=out;islands=[fh._mesh_components(o.data) for o in out];original_vol=[solid(o) for o in out]
    # Freeze the original evaluated B in world coordinates before adding hardware.
    with diag.operation('中央本体の包絡',component='B'):
        body_points, _ = hull_geometry([b.matrix_world @ v.co for v in b.data.vertices])
    # Build B first: both supports, central hub, and one continuous coaxial pin per hinge.
    for index,(j,p) in enumerate(pairs):
        sp=p['span'];side=('UPPER','LOWER')[index]
        # Join beam to B; then central hub and continuous pin. All overlap positively.
        with diag.operation('支持腕結合',side,'B'):
            union_checked(b,beam(p,col,'CJM_B_Support'))
        with diag.operation('ナックル結合',side,'B'):
            union_checked(b,cylinder(p,col,'CJM_B_Hub',sp.hub_radius,-sp.hub_half,sp.hub_half))
        with diag.operation('ピン結合',side,'B'):
            union_checked(b,cylinder(p,col,'CJM_B_Twin_Pin',sp.pin_radius,-sp.pin_end,sp.pin_end))
    context.view_layer.update()
    # A/C: blind opposed bores and central hub slot. No unions on these objects.
    for index,((j,p),target) in enumerate(zip(pairs,(a,c))):
        sp=p['span'];side=('UPPER','LOWER')[index];component=('A','C')[index]
        with diag.operation('受け溝・止まり穴加工',side,component):
            cut(context,target,cylinder(p,col,'CJM_Central_Slot',sp.slot_radius,-sp.slot_half,sp.slot_half),col)
            for sign in (-1,1):
                cut(context,target,cylinder(p,col,'CJM_Blind_Bore',sp.bore_radius,*sorted((0,sign*sp.bore_end))),col)
        with diag.operation('受け初期検査',side,component):
            require_guard(context,target,p,col,'受け初期検査',side,component)
        with diag.operation('逃げカッター準備',side,component):
            probe=stage(context,b,col,'CJM_Central_Sweep');neutral=probe.matrix_world.copy()
            envelope=body_envelope(body_points,p,j,col);body_neutral=envelope.matrix_world.copy()
        try:
            for angle in p['angles']:
                with diag.operation('可動逃げ加工',side,component,angle):
                    rel=cm.relative_angle(index,angle)
                    # Original support relief plus padded body envelope and exact full-B sweep.
                    # B itself is never cut.
                    cut(context,target,beam(p,col,'CJM_Support_Relief',p['pad'],rel),col)
                    envelope.matrix_world=pose(p,rel,body_neutral)
                    probe.matrix_world=pose(p,rel,neutral)
                    context.view_layer.update()
                    # Do not remove the reusable envelope until all poses are cut.
                    before=solid(target)
                    if intersect_volume(context,target,envelope,col)>tolerance(before):
                        bj.boolean_apply(target,envelope,'DIFFERENCE')
                        if before-solid(target)<=tolerance(before):raise ValueError('中央本体の隙間加工に失敗しました')
                    context.view_layer.update()
                    overlap=intersect_volume(context,target,probe,col);before=solid(target)
                    if overlap>tolerance(before):
                        bj.boolean_apply(target,probe,'DIFFERENCE')
                        if before-solid(target)<=tolerance(before):raise ValueError('中央本体の逃げ加工に失敗しました')
            with diag.operation('逃げ加工後検査',side,component):
                require_guard(context,target,p,col,'逃げ加工後検査',side,component)
            # Recheck exact body and hardware at finer, independently sampled poses.
            for angle in cm.inspection_angles(j.minimum_angle,j.maximum_angle,j.angle_step):
                with diag.operation('可動姿勢検査',side,component,angle):
                    probe.matrix_world=pose(p,cm.relative_angle(index,angle),neutral)
                    context.view_layer.update()
                    overlap=intersect_volume(context,target,probe,col);limit=tolerance(min(solid(target),solid(probe)))
                    if overlap>limit:diag.fail('POSE_INTERFERENCE','可動姿勢検査','指定した可動姿勢に干渉が残っています',side=side,component=component,angle=angle,measured=overlap,threshold=limit,unit='体積（内部単位³）')
        finally:fh._remove(envelope);fh._remove(probe)
    for i,o in enumerate(out):
        n=fh._mesh_components(o.data)
        if n!=islands[i]:diag.fail('COMPONENT_CHANGED','最終接続検査','加工により部品の接続状態が変化しました',component='ABC'[i],measured=n,threshold=islands[i],unit='メッシュ島数')
        if i!=1:
            v=solid(o)
            if v>=original_vol[i]:diag.fail('NO_CUT','最終体積検査','A/Cの受け加工で体積が減少しませんでした',component='ABC'[i],measured=v,threshold=original_vol[i],unit='体積（内部単位³）')
    return tuple(out)
