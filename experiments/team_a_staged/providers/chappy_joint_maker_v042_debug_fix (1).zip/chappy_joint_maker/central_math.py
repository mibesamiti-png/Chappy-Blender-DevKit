"""Pure dimensions of a symmetric central-owned twin-pin hinge."""
from dataclasses import dataclass
from math import isfinite

@dataclass(frozen=True)
class Span:
    hub_radius: float
    hub_half: float
    bore_radius: float
    pin_radius: float
    slot_half: float
    bore_end: float
    pin_end: float
    guard_end: float
    guard_radius: float
    slot_radius: float

    def sides(self, start, end):
        return ((-end,-start),(start,end))

def span(j):
    values=[j.outer_diameter,j.axle_diameter,j.a_width,j.b_width,j.radial_clearance,j.axial_gap,j.cap_wall,j.radial_wall,j.tip_clearance,j.swing_clearance,j.support_width,j.support_thickness,j.embed_depth]
    if not all(isfinite(v) and v>0 for v in values):raise ValueError('中央支持方式は正の寸法・隙間を指定してください')
    r=j.outer_diameter/2; h=j.b_width/2; pin=j.axle_diameter/2; bore=pin+j.radial_clearance
    slot=h+j.axial_gap; end=slot+j.a_width; bore_end=end-j.cap_wall; pin_end=bore_end-j.tip_clearance
    if pin_end<=slot or r<=pin or r-bore<j.radial_wall:raise ValueError('ピン長・ナックル径・軸受け肉厚が不足しています')
    if j.support_width>j.b_width:raise ValueError('支持部の幅は中央ナックル長以下にしてください')
    return Span(r,h,bore,pin,slot,bore_end,pin_end,end,bore+j.radial_wall,r+j.swing_clearance)

def relative_angle(index,angle):
    # A fixed for upper, C fixed for lower: B moves in C's inverse local frame.
    return angle if index==0 else -angle


def body_sweep_margin(vertices, pivot, axis, angles, clearance):
    """World-space nearest-sample chord bound + requested isotropic clearance.

    The maximum perpendicular radius occurs at a vertex (convex norm).
    A cube of half-width margin contains the corresponding Euclidean ball.
    """
    from math import sqrt, sin, radians
    n=sqrt(sum(x*x for x in axis))
    if not isfinite(n) or n<=0 or not isfinite(clearance) or clearance<0:
        raise ValueError('中央本体の逃げ寸法が不正です')
    axis=tuple(x/n for x in axis);radius=0.;seen=False
    for v in vertices:
        d=tuple(x-y for x,y in zip(v,pivot));proj=sum(x*y for x,y in zip(d,axis))
        r=sqrt(sum((x-proj*a)**2 for x,a in zip(d,axis)))
        if not isfinite(r):raise ValueError('中央本体の座標が不正です')
        radius=max(radius,r);seen=True
    if not seen or not angles or not all(isfinite(a) for a in angles):raise ValueError('中央本体の逃げ計算が空です')
    gaps=[b-a for a,b in zip(angles,angles[1:])]
    if any(g<0 or g>30.000001 for g in gaps):raise ValueError('中央本体の角度刻みが不正です')
    step=max(gaps,default=0.)
    return clearance+2*radius*sin(radians(step)/4)


def padded_points(vertices, margin):
    """Vertices of convex hull Minkowski sum with a world-space cube."""
    from itertools import product
    if not isfinite(margin) or margin<0:raise ValueError('中央本体の逃げ隙間が不正です')
    offsets=tuple(product((-margin,margin),repeat=3)) if margin else ((0.,0.,0.),)
    return [tuple(x+d for x,d in zip(v,o)) for v in vertices for o in offsets]


def inspection_angles(lo, hi, step=5.):
    """Dense pairwise inspection, including halfway between generation poses."""
    from math import ceil
    if not all(isfinite(x) for x in (lo,hi,step)) or not -180<=lo<=hi<=180 or step<=0:
        raise ValueError('可動角範囲が不正です')
    a,b=min(0.,lo),max(0.,hi)
    n=max(1,min(360,ceil((b-a)/min(2.5,step/2))))
    return tuple(sorted({round(a+(b-a)*i/n,9) for i in range(n+1)}|{0.,lo,hi}))
