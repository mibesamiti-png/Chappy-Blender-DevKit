"""Reusable checked geometry operations for new CJM tools.
Legacy engines remain authoritative; no change to their algorithms.
"""
import math
from . import ball_joint as bj
from .hinge_maker import face_hinge as fh

def volume(obj):
    if not len(obj.data.polygons): return 0.
    v=fh._closed_mesh_volume(obj.data)
    if v is None: raise ValueError(f'{obj.name}: 閉じたメッシュではありません')
    return v*abs(obj.matrix_world.to_3x3().determinant())

def solid(obj):
    v=volume(obj)
    if not math.isfinite(v) or v<=0: raise ValueError(f'{obj.name}: 有効な立体ではありません')
    return v

def stage(context,source,col,name):
    o=fh._make_stage(source,col,name,context.evaluated_depsgraph_get()); o.name=name
    context.view_layer.update(); solid(o)
    return o

def cut_checked(target,cutter):
    before=solid(target); bj.boolean_apply(target,cutter,'DIFFERENCE'); after=solid(target)
    if before-after<=max(1e-15,before*1e-10): raise ValueError('穴加工で体積が減りませんでした')
    fh._remove(cutter)

def union_checked(target,part):
    before=solid(target); extra=solid(part); n=fh._mesh_components(target.data)
    bj.boolean_apply(target,part,'UNION'); after=solid(target)
    tol=max(1e-15,(before+extra)*1e-9)
    if after<=before+tol or before+extra-after<=tol or fh._mesh_components(target.data)>n:
        raise ValueError('結合部に十分な重なりがありません（または部品が完全に埋没）')
    fh._remove(part)

def intersect_volume(context,a,b,col):
    """Exact solver at a single pose; empty intersection is valid."""
    probe=stage(context,a,col,'CJM_intersection_probe')
    try:
        bj.boolean_apply(probe,b,'INTERSECT')
        return volume(probe)
    finally: fh._remove(probe)

