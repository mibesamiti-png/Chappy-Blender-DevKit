"""Read-only, serial-chain LIVE. Shared face-hinge wire geometry."""
import bpy
from mathutils import Matrix,Vector
from . import ui,double_math as dm,double_joint as dj
from .hinge_maker import face_hinge as fh
_HANDLE=None
COLORS=((.31,.66,.97,.94),(1.,.59,.25,.95),(.39,.85,.63,.94))
GAP=(.38,.94,.89,.76);FOCUS=(1.,.87,.16,1.);WARN=(1.,.25,.28,1.)

def groups(pairs,s,view):
    (up,pu),(lo,pl)=pairs
    angles=tuple(max(min(0.,j.minimum_angle),min(max(0.,j.maximum_angle),j.preview_angle)) for j in (up,lo))
    transforms=dm.transforms(Matrix,pu,pl,angles);out=[]
    def add(edges,owner,color,keys=(),joint=None):
        active=(joint==s.active_joint and (s.upper if joint=='UPPER' else s.lower).live_focus in keys)
        if view=='FOCUS' and not active and joint is not None:return
        t=transforms[owner];out.append(([(t@Vector(a),t@Vector(b)) for a,b in edges],FOCUS if active else color))
    if s.design=='CENTRAL':
        for index,(j,p) in enumerate(pairs):
            side=('UPPER','LOWER')[index];sp=p['span'];ax=p['axis'];pivot=p['pivot'];receiver=0 if index==0 else 2
            def cyl(owner,r,start,end,color,keys):add(fh._wire_cylinder(None,ax,r,start,end,pivot),owner,color,keys,side)
            cyl(1,sp.hub_radius,-sp.hub_half,sp.hub_half,COLORS[1],('outer_diameter','b_width'))
            cyl(1,sp.pin_radius,-sp.pin_end,sp.pin_end,COLORS[1],('axle_diameter','tip_clearance'))
            cyl(receiver,sp.slot_radius,-sp.slot_half,sp.slot_half,GAP,('outer_diameter','axial_gap','swing_clearance','b_width'))
            for lo,hi in sp.sides(sp.slot_half,sp.bore_end):cyl(receiver,sp.bore_radius,lo,hi,GAP,('radial_clearance','a_width','axle_diameter','cap_wall'))
            for lo,hi in sp.sides(sp.slot_half,sp.guard_end):cyl(receiver,sp.guard_radius,lo,hi,COLORS[receiver],('radial_wall','a_width','cap_wall','tip_clearance'))
            b=p['beam'];add(fh._wire_beam(b['start'],b['end'],ax,b['width'],b['thickness']),1,COLORS[1],('support_width','support_thickness','embed_depth','swing_clearance'),side)
            reach=sp.guard_end*1.2;add([(pivot-ax*reach,pivot+ax*reach)],1,FOCUS,('reverse_axis','minimum_angle','maximum_angle','angle_step','preview_angle'),side)
            if view=='DEBUG' or j.live_focus in ('minimum_angle','maximum_angle','preview_angle','angle_step','swing_clearance'):
                from .hinge_maker.face_hinge_math import rotate_xyz
                from .central_math import relative_angle
                start=pivot+b['radial']*sp.slot_radius*1.4
                pts=[Vector(rotate_xyz(start,pivot,ax,relative_angle(index,a))) for a in p['angles']]
                add(list(zip(pts,pts[1:])),receiver,FOCUS,('minimum_angle','maximum_angle','preview_angle','angle_step','swing_clearance'),side)
                if view=='DEBUG':
                    for angle in p['angles']:
                        aa=relative_angle(index,angle);a=Vector(rotate_xyz(b['start'],pivot,ax,aa));z=Vector(rotate_xyz(b['end'],pivot,ax,aa))
                        add(fh._wire_beam(a,z,ax,b['width']+2*p['pad'],b['thickness']+2*p['pad']),receiver,(*GAP[:3],.20),(),side)
        if view!='FOCUS':
            for i,o in enumerate((s.object_a,s.object_b,s.object_c)):
                add(fh._wire_bbox([o.matrix_world@Vector(v) for v in o.bound_box]),i,(*COLORS[i][:3],.35))
        return out
    for index,(settings,p) in enumerate(pairs):
        side=('UPPER','LOWER')[index];sp=p['span'];sh=p['shoulder'];ax=p['axis'];pivot=p['pivot']
        def cyl(owner,r,start,end,color,keys):add(fh._wire_cylinder(None,ax,r,start,end,pivot),owner,color,keys,side)
        cyl(index,sp.outer_radius,sp.a_outer,sp.a_inner,COLORS[index],('outer_diameter','a_width','radial_wall','cap_wall','axial_gap'))
        cyl(index+1,sp.outer_radius,sp.b_inner,sp.b_outer,COLORS[index+1],('outer_diameter','b_width','axial_gap'))
        cyl(index+1,sp.axle_radius,sh.shaft_start if sh else sp.shaft_min,sp.shaft_max,COLORS[index+1],('axle_diameter','tip_clearance'))
        cyl(index,sp.bore_radius,sh.mouth_start if sh else sp.bore_start,sh.mouth_end if sh else sp.bore_end,GAP,('radial_clearance','axle_diameter','cap_wall','radial_wall','tip_clearance'))
        if sh:
            cyl(index+1,sh.head_radius,sh.head_start,sh.head_end,COLORS[index+1],('shoulder_enabled','shoulder_diameter','shoulder_thickness'))
            cyl(index,sh.cavity_radius,sh.cavity_start,sh.cavity_end,GAP,('shoulder_radial_clearance','shoulder_axial_clearance','shoulder_enabled','radial_wall'))
        for b in p['beams']:
            owner=index+(b['owner']=='B');add(fh._wire_beam(b['start'],b['end'],ax,b['width'],b['thickness']),owner,COLORS[owner],('support_width','support_thickness','embed_depth','swing_clearance'),side)
        reach=max(sp.total_length,sp.outer_radius*2);add([(pivot-ax*reach,pivot+ax*reach)],index,FOCUS,('reverse_axis','minimum_angle','maximum_angle','angle_step','preview_angle'),side)
        if view=='DEBUG' or (side==s.active_joint and (s.upper if side=='UPPER' else s.lower).live_focus in ('minimum_angle','maximum_angle','preview_angle','angle_step')):
            from .hinge_maker.face_hinge_math import rotate_xyz
            radial=next(b['radial'] for b in p['beams'] if b['owner']=='B');start=pivot+radial*sp.outer_radius*1.5
            angles=[min(0.,settings.minimum_angle)+(max(0.,settings.maximum_angle)-min(0.,settings.minimum_angle))*i/32 for i in range(33)]
            pts=[Vector(rotate_xyz(start,pivot,ax,a)) for a in angles]
            add(list(zip(pts,pts[1:])),index,FOCUS,('minimum_angle','maximum_angle','angle_step','preview_angle'),side)
        if view=='DEBUG':
            for owner,(_,_,verts) in p['faces'].items():
                k=index+(owner=='B');add(list(zip(verts,verts[1:]+verts[:1])),k,COLORS[k],(),side)
    # Bounding boxes move with the chain; deliberately not actual solid collision geometry.
    if view!='FOCUS':
        for i,o in enumerate((s.object_a,s.object_b,s.object_c)):
            add(fh._wire_bbox([o.matrix_world@Vector(v) for v in o.bound_box]),i,(*COLORS[i][:3],.35))
    return out

def draw():
    c=bpy.context;s=getattr(getattr(c,'scene',None),'cjm_double',None)
    if not s or not s.live_enabled or not ui.visible(c,'DOUBLE'):return
    import gpu
    from gpu_extras.batch import batch_for_shader
    try:lines=groups(dj.plans(c,s),s,c.scene.cjm_settings.face_view)
    except (ValueError,RuntimeError,ReferenceError,AttributeError,TypeError):
        lines=[]
        for j in (s.upper,s.lower):
            if j.pivot_set:
                p=Vector(j.pivot);r=max(.2,min(j.outer_diameter,20.)/2);lines.append(([(p-Vector((r,0,0)),p+Vector((r,0,0))),(p-Vector((0,r,0)),p+Vector((0,r,0))),(p-Vector((0,0,r)),p+Vector((0,0,r)))],WARN))
    if not lines:return
    shader=gpu.shader.from_builtin('UNIFORM_COLOR');saved={k:getattr(gpu.state,k+'_get')() for k in ('blend','depth_test','line_width','depth_mask') if hasattr(gpu.state,k+'_get')}
    try:
        gpu.state.blend_set('ALPHA');gpu.state.depth_test_set('NONE')
        if 'depth_mask' in saved:gpu.state.depth_mask_set(False)
        for edges,color in lines:
            if not edges:continue
            gpu.state.line_width_set(2.5 if color in (FOCUS,WARN) else 1.3)
            batch=batch_for_shader(shader,'LINES',{'pos':[tuple(v) for edge in edges for v in edge]});shader.bind();shader.uniform_float('color',color);batch.draw(shader)
    finally:
        if 'depth_mask' in saved:gpu.state.depth_mask_set(saved['depth_mask'])
        gpu.state.line_width_set(saved.get('line_width',1.));gpu.state.depth_test_set(saved.get('depth_test','NONE'));gpu.state.blend_set(saved.get('blend','NONE'))

def install():
    global _HANDLE
    if _HANDLE is None:_HANDLE=bpy.types.SpaceView3D.draw_handler_add(draw,(),'WINDOW','POST_VIEW')
def uninstall():
    global _HANDLE
    try:
        if _HANDLE is not None:bpy.types.SpaceView3D.draw_handler_remove(_HANDLE,'WINDOW')
    finally:_HANDLE=None
