bl_info={'name':'Chappy Joint Maker [自作アドオン]','author':'OpenAI / Chappy','version':(0,4,2),'blender':(4,0,0),'location':'View3D > Sidebar > Joint Maker','description':'[自作アドオン] Ball Joint / Hinge / Face Hinge / 着脱・二重関節 統合UI','category':'自作アドオン'}
import bpy
from bpy.props import PointerProperty
from . import ui,ball_joint,hinge_maker
from .hinge_maker import face_hinge
from . import common_tools,debug_fixtures,swap_joint,swap_live,double_joint,double_live,constraints
ADDON_TAGS = ("自作アドオン",)

_registered=[]

def _safe(action):
    try: action()
    except Exception as exc: print('CJM cleanup:',exc)

def register():
    # Same RNA/Operator IDs deliberately preserved for old .blend compatibility.
    for name in ('cjm_settings','cjm_common','cjm_swap','cjm_double','ball_joint_settings','hinge_maker_settings','face_hinge_settings'):
        if hasattr(bpy.types.Scene,name):
            raise RuntimeError('旧 Ball Joint / Hinge Maker を無効化してから統合版を有効にしてください: '+name)
    try:
        for cls in (*ui.CLASSES,*common_tools.CLASSES,*swap_joint.CLASSES,*double_joint.CLASSES,*constraints.CLASSES):
            bpy.utils.register_class(cls); _registered.append(cls)
        bpy.types.Scene.cjm_settings=PointerProperty(type=ui.CJM_Settings)
        bpy.types.Scene.cjm_common=PointerProperty(type=common_tools.CJM_CommonSettings)
        bpy.types.Scene.cjm_swap=PointerProperty(type=swap_joint.CJM_SwapSettings)
        bpy.types.Scene.cjm_double=PointerProperty(type=double_joint.CJM_DoubleSettings)
        if debug_fixtures.reset_on_load not in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.append(debug_fixtures.reset_on_load)
        ui.load_icons()
        swap_live.install()
        double_live.install()
        ball_joint.register()
        hinge_maker.register()
        if hinge_maker._FACE_HINGE_REGISTER_ERROR:
            raise RuntimeError(hinge_maker._FACE_HINGE_REGISTER_ERROR)
    except Exception:
        unregister()
        raise

def unregister():
    if not _registered:
        return
    # Only unregister modules if their scene pointer belongs to this package.
    if hasattr(bpy.types.Scene,'face_hinge_settings') or hasattr(bpy.types.Scene,'hinge_maker_settings'):
        _safe(hinge_maker.unregister)
    if hasattr(bpy.types.Scene,'ball_joint_settings'):
        _safe(ball_joint.unregister)
    # Recover from a partial legacy registration without touching external classes.
    for module,classes in [(face_hinge,face_hinge._CLASSES),(hinge_maker,hinge_maker.classes),(ball_joint,ball_joint.classes)]:
        for cls in reversed(classes):
            if getattr(cls,'is_registered',False): _safe(lambda cls=cls:bpy.utils.unregister_class(cls))
    if debug_fixtures.reset_on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(debug_fixtures.reset_on_load)
    _safe(swap_live.uninstall)
    _safe(double_live.uninstall)
    _safe(ui.unload_icons)
    if hasattr(bpy.types.Scene,'cjm_double'): del bpy.types.Scene.cjm_double
    if hasattr(bpy.types.Scene,'cjm_swap'): del bpy.types.Scene.cjm_swap
    if hasattr(bpy.types.Scene,'cjm_common'): del bpy.types.Scene.cjm_common
    if hasattr(bpy.types.Scene,'cjm_settings'): del bpy.types.Scene.cjm_settings
    for cls in reversed(_registered): _safe(lambda cls=cls:bpy.utils.unregister_class(cls))
    _registered.clear()
