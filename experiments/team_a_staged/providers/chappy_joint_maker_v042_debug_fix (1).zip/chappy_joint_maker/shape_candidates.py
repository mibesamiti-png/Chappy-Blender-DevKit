"""Bounded, advisory-only hypotheses from a historical geometry failure.
No RNA writes, mesh operations, retries, or claim of geometric improvement.
"""
from math import isfinite
from struct import pack, unpack
import json
from types import SimpleNamespace as NS
from . import constraint_math as cm, central_math

# Only dimensions with existing lock UI. Do not shrink safety walls,
# desired motion angles, or pin-hole clearances. No opposite-side changes.
DIRECTIONS={
    'BEARING_INITIAL': ('受け初期検査',(('axle_diameter',-1),('a_width',-1))),
    'BEARING_AFTER_SWEEP': ('逃げ加工後検査',(('support_width',-1),('outer_diameter',-1),('swing_clearance',-1))),
    'POSE_INTERFERENCE': ('可動姿勢検査',(('swing_clearance',1),)),
}


def numerically_valid(v,options,extras):
    try:
        for r in cm.rules('central_pair',v,options):
            if r.deficit(v)>2e-6*max(1.,abs(r.minimum)):return False
        a,b,d=options['projection'];extent=0.
        for side in ('upper','lower'):
            local={k.split('.',1)[1]:x for k,x in v.items() if k.startswith(side+'.')}
            sp=central_math.span(NS(**{**extras[side],**local}))
            extent+=a*sp.guard_end+b*max(sp.guard_radius,sp.slot_radius)
        return d>extent
    except (ValueError,TypeError,OverflowError,AttributeError):return False

def propose(detail, original, options, bounds, policies, extras, *, fractions=(.05,.10), stronger=None):
    """At most six single-field trials; return at most three hypotheses.
    Numeric checks are necessary, not evidence that a new mesh is valid.
    """
    rule=DIRECTIONS.get(detail.code)
    p={'UPPER':'upper','LOWER':'lower'}.get(detail.side)
    if not rule or not p or detail.phase!=rule[0] or detail.component!=('A' if p=='upper' else 'C'):
        return []
    if detail.measured is None or detail.threshold is None or not detail.measured>detail.threshold>=0:
        return []
    if detail.code=='POSE_INTERFERENCE' and detail.angle is None:return []
    if not all(isfinite(x) for x in original.values()):return []
    if not numerically_valid(original,options,extras):return []
    out=[]
    for key,direction in rule[1]:
        k=p+'.'+key;old=original[k];policy=policies.get(k)
        if policy not in ('FREE','PREFERRED') or k not in bounds:continue
        lo,hi=bounds[k]
        if not all(isfinite(x) for x in (lo,hi)) or not lo<=old<=hi:continue
        if stronger is not None and key not in stronger:continue
        for fraction in fractions:
            # Match Blender float32 dimensions; reject rounding beyond bounds.
            try:x=unpack('f',pack('f',min(hi,max(lo,old*(1+direction*fraction)))))[0]
            except (OverflowError,ValueError):continue
            if not lo<=x<=hi or direction*(x-old)<=1e-7:continue
            if stronger is not None and direction*(x-stronger[key]['after'])<=1e-7:continue
            v={**original,k:x}
            if numerically_valid(v,options,extras):out.append(dict(side=detail.side,key=key,before=old,after=x,policy=policy))
    out.sort(key=lambda c:(c['policy']=='PREFERRED',abs(c['after']-c['before'])/c['before'],c['key'],c['after']))
    # One candidate per field, keeping the smallest admissible trial.
    unique={}
    for c in out:unique.setdefault(c['key'],c)
    return list(unique.values())[:3]


def inputs(context,s):
    from . import constraints as c
    if s.design!='CENTRAL' or not c.pair_ready(context):return None
    adj,protected=c.CONFIG['central'];original={};bounds={};policies={};extras={};opt={'projection':c.pair_projection(s)}
    floor=float(getattr(context.scene.cjm_settings,'constraint_clearance_floor',.01))
    for side,j in [('upper',s.upper),('lower',s.lower)]:
        opt[side]={'shoulder':False,'length':j.get('_cjm_length_central')}
        extras[side]={k:float(getattr(j,k)) for k in ('support_thickness','embed_depth','minimum_angle','maximum_angle','angle_step')}
        extras[side].update(pivot=list(j.pivot),reverse_axis=bool(j.reverse_axis))
        for k in (*adj,*protected):
            q=side+'.'+k;original[q]=float(getattr(j,k))
            if k not in adj:continue
            lo=float(j.bl_rna.properties[k].hard_min);hi=float(j.bl_rna.properties[k].hard_max)
            if k in c.DEFAULT_LOCKED:lo=min(hi,max(lo,min(floor,original[q]) if original[q]>0 else floor,cm.EPS))
            bounds[q]=(lo,hi);policies[q]=c.lock_state(j,k)
    return original,opt,bounds,policies,extras


def signature(data,s):
    # Numeric settings/registration fingerprint, not a geometry fingerprint.
    reg=[(getattr(s,'object_'+k).as_pointer() if getattr(s,'object_'+k) else 0) for k in 'abc']
    reg.extend((getattr(s,'face_'+k),getattr(s,'signature_'+k)) for k in ('a','bu','bl','c'))
    return json.dumps([s.design,s.axis,reg,data],sort_keys=True,allow_nan=False)


def capture(context,s,detail):
    if detail.code not in DIRECTIONS:return ''
    data=inputs(context,s)
    if data is None:return ''
    return json.dumps({'signature':signature(data,s),'diagnostic':detail.encode(),'candidates':propose(detail,*data)},ensure_ascii=False,allow_nan=False)


def display(context,s,detail):
    """Hide stale numeric advice. Geometry edits remain untracked; all advice historical."""
    if not s.last_shape_candidates:return None
    record=json.loads(s.last_shape_candidates);data=inputs(context,s)
    if data is None or record['diagnostic']!=detail.encode() or record['signature']!=signature(data,s):return None
    return record['candidates']


def expanded_propose(detail,data,keys):
    """One bounded stronger alternative per eligible initial field, same original."""
    initial={i['key']:i for i in propose(detail,*data)}
    if not keys or len(set(keys))!=len(keys) or any(k not in initial for k in keys):
        return []
    return propose(detail,*data,fractions=(.10,.20),stronger={k:initial[k] for k in keys})


def recompute(payload,detail,data):
    record=json.loads(payload)
    stage=record.get('stage','INITIAL')
    if stage=='INITIAL':return propose(detail,*data)
    if stage=='EXPANDED':return expanded_propose(detail,data,record.get('keys',[]))
    if stage=='PAIRED':return paired_propose(detail,data,record.get('keys',[]))
    if stage=='PAIR_EXCHANGED':return pair_exchanged_propose(detail,data,record.get('keys',[]),record.get('parent_index'),record.get('refined_index'))
    if stage=='PAIR_REFINED':return pair_refined_propose(detail,data,record.get('keys',[]),record.get('parent_index'))
    if stage=='REFINED':return refined_propose(detail,data,record.get('parent_stage'),record.get('keys',[]),record.get('parent_key'),record.get('history',[]))
    raise ValueError('不明な候補探索段階')


def expansion(payload,record,detail,data,s):
    """Historical local improvement authorizes a fresh trial, never an adoption."""
    old=json.loads(payload)
    if old.get('stage','INITIAL')!='INITIAL' or not record or record['status']!='DONE':return ''
    initial=propose(detail,*data);rows=record['rows']
    if not initial or old['candidates']!=initial or [r['item'] for r in rows]!=initial:return ''
    if any(r['result']['status']=='PASS' for r in rows):return ''
    keys=[r['item']['key'] for r in rows if r['result']['status']=='IMPROVED']
    items=expanded_propose(detail,data,keys)
    if not items:return ''
    return json.dumps({'signature':signature(data,s),'diagnostic':detail.encode(), 'stage':'EXPANDED','keys':keys,'candidates':items},ensure_ascii=False,allow_nan=False)


MAX_REFINEMENT_STEPS=4  # first midpoint plus at most three continuations
CONTINUE_FAILURES=frozenset(('IMPROVED','WORSE','UNCHANGED','MIXED'))


def refined_propose(detail,data,parent_stage,keys,parent_key,history=()):
    """Replay the bounded search path, not a proof of monotonic geometry."""
    if not isinstance(history,(list,tuple)) or len(history)>=MAX_REFINEMENT_STEPS or any(h not in ('PASS','FAIL') for h in history):return []
    if parent_stage=='INITIAL' and not keys:parents=propose(detail,*data)
    elif parent_stage=='EXPANDED':parents=expanded_propose(detail,data,keys)
    else:return []
    parent=next((i for i in parents if i['key']==parent_key),None)
    if parent is None or parent['before']<=0:return []
    old=parent['before'];failed=old
    for step in range(len(history)+1):
        end=parent['after'];target=(failed+end)/2
        fraction=abs(target-old)/old
        mid=next((i for i in propose(detail,*data,fractions=(fraction,)) if i['key']==parent_key),None)
        if mid is None or not min(failed,end)<mid['after']<max(failed,end):return []
        if step==len(history):return [parent,mid]
        if history[step]=='PASS':parent=mid
        else:failed=mid['after']
    return []


def refinement_depth(payload):
    old=json.loads(payload)
    return len(old.get('history',[]))+1 if old.get('stage')=='REFINED' else 0


def refinement(payload,record,detail,data,s):
    old=json.loads(payload);stage=old.get('stage','INITIAL')
    if not record or record['status']!='DONE':return ''
    if stage=='REFINED':
        history=old.get('history',[])
        source=record.get('source')
        if not isinstance(source,str) or not source or len(history)+1>=MAX_REFINEMENT_STEPS:return ''
        if history and old.get('history_source')!=source:return ''
        items=recompute(payload,detail,data);rows=record['rows']
        if len(items)!=2 or old['candidates']!=items or [r['item'] for r in rows]!=items or rows[0]['result']['status']!='PASS':return ''
        status=rows[1]['result']['status']
        if status!='PASS' and status not in CONTINUE_FAILURES:return ''
        history=[*history,'PASS' if status=='PASS' else 'FAIL']
        next_items=refined_propose(detail,data,old['parent_stage'],old.get('keys',[]),old['parent_key'],history)
        if not next_items:return ''
        return json.dumps({**old,'signature':signature(data,s),'diagnostic':detail.encode(),'history':history,'history_source':source,'candidates':next_items},ensure_ascii=False,allow_nan=False)
    if stage not in ('INITIAL','EXPANDED'):return '' 
    parents=recompute(payload,detail,data);rows=record['rows']
    if not parents or old['candidates']!=parents or [r['item'] for r in rows]!=parents:return ''
    passed=[i for i,r in enumerate(rows) if r['result']['status']=='PASS']
    if not passed:return ''
    # Same priority rule as ordinary comparison, independently recomputed.
    passed.sort(key=lambda i:(parents[i]['policy']=='PREFERRED',abs(parents[i]['after']-parents[i]['before'])/parents[i]['before'],i))
    keys=old.get('keys',[])
    for idx in passed:
        key=parents[idx]['key'];items=refined_propose(detail,data,stage,keys,key)
        if items:
            return json.dumps({'signature':signature(data,s),'diagnostic':detail.encode(),'stage':'REFINED','parent_stage':stage,'keys':keys,'parent_key':key,'candidates':items},ensure_ascii=False,allow_nan=False)
    return ''


def is_refined(payload):
    return bool(payload) and json.loads(payload).get('stage')=='REFINED'


def check_history_source(payload,source):
    old=json.loads(payload)
    if ((old.get('stage')=='REFINED' and old.get('history')) or old.get('stage') in ('PAIR_REFINED','PAIR_EXCHANGED')) and old.get('history_source')!=repr(source):
        raise ValueError('探索履歴の元メッシュが変化しました。通常生成からやり直してください')


# Pair hypotheses introduced in v0.3.7. Keep single records unchanged.
def components(item):
    return item['changes'] if 'changes' in item else [item]


def paired_propose(detail,data,keys):
    from itertools import combinations
    initial=propose(detail,*data)
    if not isinstance(keys,list) or not 2<=len(keys)<=3 or any(not isinstance(k,str) for k in keys):return []
    if len(set(keys))!=len(keys) or any(k not in [i['key'] for i in initial] for k in keys):return []
    original,options,bounds,policies,extras=data
    out=[]
    for a,b in combinations([i for i in initial if i['key'] in keys],2):
        v={**original, a['side'].lower()+'.'+a['key']:a['after'], b['side'].lower()+'.'+b['key']:b['after']}
        if numerically_valid(v,options,extras):out.append({'changes':[a,b]})
    def cost(item):
        changes=components(item)
        return (sum(i['policy']=='PREFERRED' for i in changes),sum(abs(i['after']-i['before'])/i['before'] for i in changes),tuple(i['key'] for i in changes))
    return sorted(out,key=cost)[:3]


def pairing(payload,record,detail,data,s):
    old=json.loads(payload)
    if old.get('stage','INITIAL')!='INITIAL' or not record or record['status']!='DONE':return ''
    initial=propose(detail,*data);rows=record['rows']
    if not initial or old['candidates']!=initial or [r['item'] for r in rows]!=initial:return ''
    if any(r['result']['status']=='PASS' for r in rows):return ''
    # Historical comparable failures only; unchanged/worse may still interact.
    keys=[r['item']['key'] for r in rows if r['result']['status'] in CONTINUE_FAILURES]
    items=paired_propose(detail,data,keys)
    if not items:return ''
    return json.dumps({'signature':signature(data,s),'diagnostic':detail.encode(),'stage':'PAIRED','keys':keys,'candidates':items},ensure_ascii=False,allow_nan=False)


def is_paired(payload):
    return bool(payload) and json.loads(payload).get('stage')=='PAIRED'


def pair_cost(item):
    changes=components(item)
    return (sum(c['policy']=='PREFERRED' for c in changes),
            sum(abs(c['after']-c['before'])/max(abs(c['before']),1e-15) for c in changes))


def pair_refined_propose(detail,data,keys,parent_index):
    """Replay one local step: incumbent plus at most two cheaper pair points.
    Each midpoint remains strictly between its original and passing endpoint.
    No extrapolation, no monotonicity assumption, no live dimension writes.
    """
    parents=paired_propose(detail,data,keys)
    if type(parent_index) is not int or not 0<=parent_index<len(parents):return []
    parent=parents[parent_index];changes=components(parent)
    original,options,bounds,policies,extras=data
    alternatives=[]
    for axes in ((0,1),(0,),(1,)):
        trial=[dict(c) for c in changes]
        for i in axes:
            c=trial[i];old,end=c['before'],c['after']
            try:mid=unpack('f',pack('f',old+(end-old)/2))[0]
            except (OverflowError,ValueError):break
            q=c['side'].lower()+'.'+c['key'];lo,hi=bounds[q]
            if not min(old,end)<mid<max(old,end) or not lo<=mid<=hi:break
            c['after']=mid
        else:
            item={'changes':trial}
            values={**original,**{c['side'].lower()+'.'+c['key']:c['after'] for c in trial}}
            if pair_cost(item)<pair_cost(parent) and numerically_valid(values,options,extras) and item not in alternatives:
                alternatives.append(item)
    alternatives.sort(key=pair_cost)
    return [parent,*alternatives[:2]] if alternatives else []


def pair_refinement(payload,record,detail,data,s):
    old=json.loads(payload)
    if old.get('stage')!='PAIRED' or not record or record['status']!='DONE':return ''
    source=record.get('source')
    if not isinstance(source,str) or not source:return ''
    parents=recompute(payload,detail,data);rows=record['rows']
    if not parents or old['candidates']!=parents or [r['item'] for r in rows]!=parents:return ''
    passed=sorted((i for i,r in enumerate(rows) if r['result']['status']=='PASS'),key=lambda i:(pair_cost(parents[i]),i))
    for index in passed:
        items=pair_refined_propose(detail,data,old['keys'],index)
        if items:
            return json.dumps({'signature':signature(data,s),'diagnostic':detail.encode(),'stage':'PAIR_REFINED','keys':old['keys'],'parent_index':index,'history_source':source,'candidates':items},ensure_ascii=False,allow_nan=False)
    return ''


def is_pair_refined(payload):
    return bool(payload) and json.loads(payload).get('stage')=='PAIR_REFINED'


MAX_EXCHANGE_FRACTION=.20


def pair_exchanged_propose(detail,data,keys,parent_index,refined_index):
    """One bounded exchange step; grow one FREE change by 25%, halve the other.
    Retain both original directions, both nonzero changes, and strictly lower cost.
    """
    parents=pair_refined_propose(detail,data,keys,parent_index)
    if type(refined_index) is not int or not 0<=refined_index<len(parents):return []
    parent=parents[refined_index];original,options,bounds,policies,extras=data
    alternatives=[]
    for grow in (0,1):
        trial=[dict(c) for c in components(parent)]
        if trial[grow]['policy']!='FREE':continue
        for i,c in enumerate(trial):
            old,end=c['before'],c['after'];q=c['side'].lower()+'.'+c['key'];lo,hi=bounds[q]
            if not isfinite(old) or old<=0:break
            try:x=unpack('f',pack('f',old+(end-old)*(1.25 if i==grow else .5)))[0]
            except (OverflowError,ValueError):break
            if not lo<=x<=hi or abs(x-old)>MAX_EXCHANGE_FRACTION*old:break
            if (x-old)*(end-old)<=0:break
            if not (abs(x-old)>abs(end-old) if i==grow else abs(x-old)<abs(end-old)):break
            c['after']=x
        else:
            item={'changes':trial};values={**original,**{c['side'].lower()+'.'+c['key']:c['after'] for c in trial}}
            if pair_cost(item)<pair_cost(parent) and numerically_valid(values,options,extras):alternatives.append(item)
    alternatives.sort(key=pair_cost)
    return [parent,*alternatives] if alternatives else []


def pair_exchange(payload,record,detail,data,s):
    old=json.loads(payload)
    if old.get('stage')!='PAIR_REFINED' or not record or record['status']!='DONE':return ''
    source=record.get('source')
    if not isinstance(source,str) or not source or old.get('history_source')!=source:return ''
    if old.get('signature')!=signature(data,s) or old.get('diagnostic')!=detail.encode():return ''
    parents=recompute(payload,detail,data);rows=record['rows']
    if not parents or old['candidates']!=parents or [r['item'] for r in rows]!=parents:return ''
    passed=[i for i,r in enumerate(rows) if r['result']['status']=='PASS']
    if not passed or 0 not in passed:return ''
    index=min(passed,key=lambda i:(pair_cost(parents[i]),i))
    items=pair_exchanged_propose(detail,data,old['keys'],old['parent_index'],index)
    if not items:return ''
    return json.dumps({'signature':signature(data,s),'diagnostic':detail.encode(),'stage':'PAIR_EXCHANGED','keys':old['keys'],'parent_index':old['parent_index'],'refined_index':index,'history_source':source,'candidates':items},ensure_ascii=False,allow_nan=False)


def is_pair_exchanged(payload):
    return bool(payload) and json.loads(payload).get('stage')=='PAIR_EXCHANGED'
