bl_info = {
    "name": "Ball Joint Maker",
    "author": "OpenAI / Chappy",
    "version": (0, 8, 9),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > Ball Joint",
    "description": "[自作アドオン] ボールジョイント生成 + 別タブの取付加工(A/B/C)。Cは本体受けの生成と任意の2分割を別々に行います。",
    "category": "自作アドオン",
}

# Classic single-file Blender addons do not have an official "tags" field
# equivalent to Blender Extension manifests, so keep an explicit tag constant
# and also show it in the addon UI/description.
ADDON_TAGS = ("自作アドオン",)

import bpy
from . import ui as _cjm_ui
try:
    from bpy.app.handlers import persistent as _persistent
except (ImportError, AttributeError):  # Standalone offline test stubs
    def _persistent(func):
        return func

import math
import bmesh

from mathutils import Matrix, Vector
from bpy.types import Operator, Panel, PropertyGroup
from bpy.props import (
    BoolProperty,
    EnumProperty,
    FloatProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)


# ============================================================
# v0.8.9 LIVE dimension guide (non-destructive: no bpy.ops/mesh changes)
# ============================================================

_BJ_LIVE_HANDLE = None
_BJ_LIVE_COLORS = {
    'background': (0.035, 0.06, 0.095, 0.92),
    'ball': (1.0, 0.62, 0.28, 0.95),
    'socket': (0.24, 0.63, 0.93, 0.92),
    'cavity': (0.24, 0.9, 0.75, 0.95),
    'focus': (1.0, 0.89, 0.25, 1.0),
    'error': (1.0, 0.22, 0.28, 1.0),
    'warn': (1.0, 0.48, 0.27, 1.0),
    'text': (0.98, 0.98, 0.99, 1.0),
    'muted': (0.70, 0.76, 0.83, 1.0),
}
_BJ_FOCUS_INFO = {
    'OVERVIEW': ('全体構造', '橙=ボール、青=受け外形、緑=球状の穴'),
    'GLOBAL_SCALE': ('全体倍率', '全ての部品・隙間が同じ倍率で変化'),
    'BALL_DIAMETER': ('ボール直径', '中央の橙色の球体（直径）'),
    'CLEARANCE': ('ボールと受けの隙間', '橙色の球面と緑の内面の半径方向の距離'),
    'WALL': ('ソケット肉厚', '緑の内面から青の外面までの片側厚み'),
    'OPENING': ('開口直径', '上部の入口幅。球状キャビティより小さくする'),
    'BALL_SHAFT_DIAMETER': ('ボール側の軸直径', '上側の棒の太さ。切り欠きOFF時は開口幅以下'),
    'BALL_SHAFT_LENGTH': ('ボール側の軸長さ', '球の上から伸びる棒の長さ'),
    'SOCKET_SHAFT_DIAMETER': ('受け側の軸直径', '受けの下から伸びる棒の太さ'),
    'SOCKET_SHAFT_LENGTH': ('受け側の軸長さ', '受けの下側の棒の長さ'),
    'MOTION_ANGLE': ('可動域の角度', '球中心から上へ向かう軸の傾き'),
    'MOTION_SHAFT_CLEARANCE': ('可動時の軸逃げ', '傾けた軸の外側に必要な余裕'),
    'MOTION_RETENTION': ('最低保持代', 'ボールが受け側から抜けないための保持量'),
    'DOWEL_DIAMETER': ('位置決めダボ径', '分割した受けの合わせ面に作るピン'),
    'DOWEL_LENGTH': ('位置決めダボ長さ', '分割面から突き出すピンの長さ'),
    'DOWEL_CLEARANCE': ('ダボ穴の隙間', 'ピンと穴の片側のクリアランス'),
    'OUTER_SHAPE': ('受け側の外形', '球形・円柱・立方体の外周の違い'),
    'SOCKET': ('受け側の有無', 'OFFではボールとボール側の軸だけを表示'),
    'MOUNT_CLEARANCE': ('取付クリアランス', 'ソケット外側と取付穴との片側の隙間'),
    'MOUNT_SHAFT': ('取付穴の受け側軸', 'ソケット側の軸を取付穴に含めるか'),
    'MOUNT_PATH': ('挿入経路', '本体へ差し込む方向と追加の穴あけ範囲'),
    'MOUNT_PATH_LENGTH': ('挿入経路長', '完成位置から外側へ延ばす距離'),
    'MOUNT_TARGET': ('取付先本体', 'A: クイック取付先、B: カッター適用先'),
    'MOUNT_CUTTER': ('再利用カッター', 'Bで作成または指定したカッター'),
    'BODY_CAVITY': ('本体側キャビティ', 'C: 本体内部へ球状空洞を削る'),
    'BODY_OPENING': ('本体側開口', 'C: 球の上へ伸びる開口カッター'),
    'BODY_DEPTH': ('本体側カッター長', 'C: 球中心から+Z側へ伸びる長さ'),
    'BODY_PLANE': ('本体の分割面', 'C: Bisectの法線方向を表示'),
    'BODY_OFFSET': ('分割位置オフセット', 'C: 分割面を法線方向へ動かす量'),
    'BODY_DOWEL': ('本体分割ダボ', 'C: 分割面に置く2本の丸ダボ'),
    'BODY_SHAFT': ('C側のボール軸', '橙=実際のボール/軸参考輪郭、緑=本体から削る空洞'),
}


def bj_live_diagnostics(settings, motion=None, dowel=None):
    """Pure planned-dimension checks: does not change geometry.

    Returns (focus, message, severity, actual, limit) tuples. A geometrical
    warning does not guarantee manufacturability or final Boolean integrity.
    """
    problems = []
    def add(key, message, severity='ERROR', actual=None, limit=None):
        problems.append((key, message, severity, actual, limit))
    ball_r = float(settings.ball_diameter) * 0.5
    if not settings.make_socket:
        return tuple(problems)
    inside_r = ball_r + float(settings.clearance)
    outside_r = inside_r + float(settings.wall_thickness)
    opening_r = float(settings.opening_diameter) * 0.5
    if opening_r >= inside_r - 1.e-8:
        add('OPENING', '開口径が内側キャビティ径以上です', actual=opening_r*2, limit=inside_r*2)
    if settings.make_shaft and not settings.make_motion_cut and settings.shaft_diameter*0.5 >= opening_r - 1.e-8:
        add('BALL_SHAFT_DIAMETER', '切り欠きOFFでは軸径を開口径より小さく', actual=float(settings.shaft_diameter), limit=float(settings.opening_diameter))
    if settings.wall_thickness <= 0:
        add('WALL', 'ソケット肉厚が0以下です', actual=float(settings.wall_thickness), limit=0)
    if settings.make_motion_cut and motion is not None:
        if not motion['feasible']:
            add('MOTION_SHAFT_CLEARANCE', '軸が球中心付近で干渉します')
        elif not motion['geometric_retained']:
            add('MOTION_ANGLE', '指定角度ではボールを保持できません', 'WARNING')
        elif not motion['safe_retained']:
            add('MOTION_RETENTION', '計算上の保持代が最低値に不足', 'WARNING',
                float(motion['retention_margin']), float(settings.motion_min_retention))
    if settings.make_dowels and dowel is not None and not dowel.get('ok', False):
        # The actual layout check is the generator's own function.
        add('DOWEL_DIAMETER', str(dowel.get('reason') or 'ダボ配置寸法が成立しません'))
    return tuple(problems)


def bj_live_motion_and_dowel(s):
    motion, dowel = None, None
    if not s.make_socket:
        return motion, dowel
    if s.make_motion_cut and s.motion_angle > 0.0001:
        try:
            motion = calc_motion_analysis(s)
        except (ValueError, RuntimeError, ArithmeticError):
            motion = None
    if s.make_dowels:
        try:
            R = s.ball_diameter * .5 + s.clearance
            outer = R + s.wall_thickness
            if s.dowel_style == 'PERIMETER':
                dowel = calc_perimeter_dowel_layout(s, R, outer)
            else:
                dowel = calc_safe_dowel_layout(s, R, outer)
        except (ValueError, RuntimeError, ArithmeticError):
            dowel = {'ok': False, 'reason': 'ダボ配置の計算に失敗しました'}
    return motion, dowel


def bj_live_tag_redraw(context=None):
    try:
        for screen in bpy.data.screens:
            for area in screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
    except (AttributeError, RuntimeError, ReferenceError):
        if context is not None and getattr(context, 'area', None):
            context.area.tag_redraw()


def bj_live_update_focus(key, view_mode=None):
    def changed(self, context):
        # Only a string assignment and redraw; never re-run a Boolean preview.
        self.live_focus = key
        if view_mode is not None:
            self.live_view_mode = view_mode
        bj_live_tag_redraw(context)
    return changed


def bj_live_update_toggle(self, context):
    bj_live_tag_redraw(context)


def bj_live_focus_prop(layout, s, prop, focus=None, view_mode=None, text=None):
    return _cjm_ui.focus_row(layout,s,prop,'ball',focus or _BJ_PROP_FOCUS.get(prop,'OVERVIEW'),view_mode or '',**({'text':text} if text is not None else {}))


_BJ_PROP_FOCUS = {
    'global_scale': 'GLOBAL_SCALE', 'ball_diameter': 'BALL_DIAMETER',
    'clearance': 'CLEARANCE', 'wall_thickness': 'WALL',
    'opening_diameter': 'OPENING', 'outer_shape': 'OUTER_SHAPE',
    'make_socket': 'SOCKET', 'shaft_diameter': 'BALL_SHAFT_DIAMETER',
    'shaft_length': 'BALL_SHAFT_LENGTH', 'make_shaft': 'BALL_SHAFT_DIAMETER',
    'make_socket_shaft': 'SOCKET_SHAFT_DIAMETER',
    'socket_shaft_diameter': 'SOCKET_SHAFT_DIAMETER',
    'socket_shaft_length': 'SOCKET_SHAFT_LENGTH',
    'motion_angle': 'MOTION_ANGLE',
    'motion_shaft_clearance': 'MOTION_SHAFT_CLEARANCE',
    'motion_min_retention': 'MOTION_RETENTION',
    'make_motion_cut': 'MOTION_ANGLE',
    'dowel_diameter': 'DOWEL_DIAMETER',
    'dowel_length': 'DOWEL_LENGTH',
    'dowel_clearance': 'DOWEL_CLEARANCE',
    'mount_clearance': 'MOUNT_CLEARANCE',
    'mount_include_socket_shaft': 'MOUNT_SHAFT',
    'mount_make_insertion_path': 'MOUNT_PATH',
    'mount_path_length': 'MOUNT_PATH_LENGTH',
    'mount_path_direction': 'MOUNT_PATH',
    'mount_target': 'MOUNT_TARGET',
    'mount_cutter': 'MOUNT_CUTTER',
    'body_receiver_cut_depth': 'BODY_DEPTH',
    'body_receiver_plane_axis': 'BODY_PLANE',
    'body_receiver_plane_offset': 'BODY_OFFSET',
    'body_receiver_dowel_spacing': 'BODY_DOWEL',
    'body_receiver_dowel_v_offset': 'BODY_DOWEL',
    'body_receiver_make_dowels': 'BODY_DOWEL',
}


def bj_live_focus_button(layout, text, focus, mode):
    op = layout.operator('ball_joint.live_focus', text=text, icon='VIEWZOOM')
    op.focus_key = focus
    op.view_mode = mode


def bj_live_install():
    global _BJ_LIVE_HANDLE
    if _BJ_LIVE_HANDLE is None:
        _BJ_LIVE_HANDLE = bpy.types.SpaceView3D.draw_handler_add(
            bj_live_draw, (), 'WINDOW', 'POST_PIXEL')
    bj_live_tag_redraw()


def bj_live_uninstall():
    global _BJ_LIVE_HANDLE
    if _BJ_LIVE_HANDLE is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_BJ_LIVE_HANDLE, 'WINDOW')
        _BJ_LIVE_HANDLE = None
    bj_live_tag_redraw()


def bj_live_draw():
    ctx = bpy.context
    if (getattr(ctx, 'region', None) is None or
            getattr(ctx.region, 'type', None) != 'WINDOW' or
            getattr(ctx, 'scene', None) is None or
            not hasattr(ctx.scene, 'ball_joint_settings')):
        return
    s = ctx.scene.ball_joint_settings
    if not s.live_guide_enabled or not _cjm_ui.engine_visible(ctx,"ball"):
        return
    # Keep plan calculation, 3D overlay, and 2D overlay independent. A bad
    # projection / stale deleted object must not hide the 2D repair guide.
    try:
        if s.live_view_mode == 'JOINT':
            motion, dowel = bj_live_motion_and_dowel(s)
            issues = bj_live_diagnostics(s, motion, dowel)
        else:
            issues = bj_live_mount_diagnostics(s)
    except (RuntimeError, ValueError, TypeError, AttributeError,
            ReferenceError, KeyError, ZeroDivisionError):
        issues = (('OVERVIEW', '寸法診断を取得できません', 'WARNING', None, None),)
    if s.live_world_enabled:
        try:
            bj_live_render_world_only(ctx, s, issues)
        except (RuntimeError, ValueError, TypeError, AttributeError,
                ReferenceError, KeyError, ZeroDivisionError, ImportError):
            pass
    try:
        if s.live_view_mode == 'JOINT':
            bj_live_render(ctx, s, issues)
        else:
            bj_live_render_mount(ctx, s, issues)
    except (RuntimeError, ValueError, TypeError, AttributeError,
            ReferenceError, KeyError, ZeroDivisionError, ImportError):
        pass


def bj_live_render_world_only(ctx, s, issues):
    """Project 3D hints independently from the 2D panel (read-only)."""
    import gpu
    from gpu_extras.batch import batch_for_shader
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    bad = {issue[0] for issue in issues if issue[2] == 'ERROR'}

    queued=[]
    def lines(points, color, thick=1.6):
        if len(points)>=2: queued.append((points,color,thick))
    def draw_lines(points,color,thick):
        gpu.state.line_width_set(thick)
        shader.bind()
        shader.uniform_float('color', color)
        batch_for_shader(shader, 'LINES', {'pos': points}).draw(shader)

    gpu.state.blend_set('ALPHA')
    try:
        if s.live_view_mode == 'JOINT':
            bj_live_draw_world(ctx, s, s.live_focus, bad, lines)
        else:
            bj_live_draw_mount_world(
                ctx, s, bj_live_mount_dimensions(s), s.live_focus, bad, lines)
        st=_cjm_ui.state(ctx.scene)
        if st and st.face_view=='FOCUS':
            marked=[item for item in queued if item[1] in (_BJ_LIVE_COLORS['focus'],_BJ_LIVE_COLORS['error'],_BJ_LIVE_COLORS['warn'])]
            if marked: queued=marked
        for item in queued: draw_lines(*item)
    finally:
        gpu.state.line_width_set(1.0)
        gpu.state.blend_set('NONE')


def bj_live_render(ctx, s, issues):
    import gpu
    import blf
    from gpu_extras.batch import batch_for_shader
    from math import cos, sin, pi

    region = ctx.region
    if region.width < 470 or region.height < 356:
        return
    C = _BJ_LIVE_COLORS
    focus = s.live_focus if s.live_focus in _BJ_FOCUS_INFO else 'OVERVIEW'
    bad = {item[0] for item in issues}
    title, detail = _BJ_FOCUS_INFO[focus]
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    x, y, width, height = 18, 24, min(468, region.width-38), 320

    def lines(points, color, thick=1.6):
        if len(points) < 2:
            return
        gpu.state.line_width_set(thick)
        shader.bind()
        shader.uniform_float('color', color)
        batch_for_shader(shader, 'LINES', {'pos': points}).draw(shader)

    def rect(rx,ry,w,h,color):
        shader.bind()
        shader.uniform_float('color', color)
        batch_for_shader(shader, 'TRIS', {'pos': [
            (rx,ry),(rx+w,ry),(rx+w,ry+h),
            (rx,ry),(rx+w,ry+h),(rx,ry+h)]}).draw(shader)

    def label(px,py,t,size=12,color=None):
        blf.position(0,px,py,0)
        blf.size(0,size)
        blf.color(0,*(color or C['text']))
        blf.draw(0,str(t))

    def ring(cx,cy,r,color,width_line=2):
        if r <= 0: return
        pts=[]
        for i in range(60):
            a=2*pi*i/60
            b=2*pi*(i+1)/60
            pts.extend(((cx+cos(a)*r,cy+sin(a)*r),
                        (cx+cos(b)*r,cy+sin(b)*r)))
        lines(pts,color,width_line)

    def outline(rx,ry,w,h,color,thick=2):
        lines([(rx,ry),(rx+w,ry), (rx+w,ry),(rx+w,ry+h),
               (rx+w,ry+h),(rx,ry+h), (rx,ry+h),(rx,ry)],color,thick)

    R = s.ball_diameter*.5*s.global_scale
    Ri = (s.ball_diameter*.5+s.clearance)*s.global_scale
    Ro = (s.ball_diameter*.5+s.clearance+s.wall_thickness)*s.global_scale
    opr = s.opening_diameter*.5*s.global_scale
    # Clamp display radius only; preserve actual values and diagnostic state.
    top = max(Ro if s.make_socket else R,
              R+s.shaft_length*s.global_scale if s.make_shaft else R)
    bottom = min(-Ro if s.make_socket else -R,
                 -Ro-s.socket_shaft_length*s.global_scale
                 if s.make_socket and s.make_socket_shaft else -R)
    radial = max(Ro if s.make_socket else R,
                 s.shaft_diameter*.5*s.global_scale if s.make_shaft else R)
    factor = min(78/max(radial,0.0001), 162/max(top-bottom,0.0001))
    # Correctly shift the local Z=0 origin if the shaft extends asymmetrically.
    cx = x+124
    cy = y+66-bottom*factor

    gpu.state.blend_set('ALPHA')
    try:
        rect(x,y,width,height,C['background'])
        rect(x,y+height-3,width,3,C['error'] if issues else C['cavity'])
        label(x+12,y+height-27,'Ball Joint Maker  |  LIVE 寸法ガイド',14)
        label(x+12,y+height-52,title,13,C['error'] if focus in bad else C['focus'])
        label(x+12,y+height-70,detail[:41],10,C['muted'])
        # The orange ball is the central solid, and inner cavity is green.
        ring(cx,cy,max(R*factor,1),C['error'] if 'BALL_DIAMETER' in bad else
             (C['focus'] if focus=='BALL_DIAMETER' else C['ball']),3 if focus=='BALL_DIAMETER' else 2)
        if s.make_socket:
            wall_color = C['error'] if 'WALL' in bad else (C['focus'] if focus in ('WALL','OUTER_SHAPE') else C['socket'])
            if s.outer_shape=='SPHERE':
                ring(cx,cy,max(Ro*factor,1),wall_color,3 if focus=='WALL' else 2)
            else:
                outline(cx-Ro*factor,cy-Ro*factor,2*Ro*factor,2*Ro*factor,wall_color)
            ring(cx,cy,max(Ri*factor,1),
                 C['focus'] if focus=='CLEARANCE' else C['cavity'],3 if focus=='CLEARANCE' else 2)
            lines([(cx+R*factor,cy),(cx+Ri*factor,cy)],
                  C['focus'] if focus=='CLEARANCE' else C['muted'],3 if focus=='CLEARANCE' else 1)
            # The real cutter removes a vertical cylinder starting at Z~0.
            # The lip of a spherical shell is at sqrt(Ro^2 - opening_radius^2).
            lip_z = ((max(0.0, Ro*Ro-opr*opr))**0.5
                     if s.outer_shape=='SPHERE' else Ro)
            z = cy+lip_z*factor
            oc = C['error'] if 'OPENING' in bad else (C['focus'] if focus in ('OPENING','BODY_OPENING') else C['cavity'])
            lines([(cx-opr*factor,cy),(cx-opr*factor,cy+Ro*factor),
                   (cx+opr*factor,cy),(cx+opr*factor,cy+Ro*factor)], oc,2)
            lines([(cx-opr*factor,z),(cx+opr*factor,z)],oc,4 if focus=='OPENING' or 'OPENING' in bad else 2)
            lines([(cx-opr*factor,z-4),(cx-opr*factor,z+4),
                   (cx+opr*factor,z-4),(cx+opr*factor,z+4)],oc,2)
            if focus=='MOTION_RETENTION' or 'MOTION_RETENTION' in bad or 'MOTION_ANGLE' in bad:
                retention_color = C['error'] if ('MOTION_RETENTION' in bad or 'MOTION_ANGLE' in bad) else C['focus']
                lines([(cx-opr*factor-7,z-5),(cx-opr*factor-7,z+8),
                       (cx+opr*factor+7,z-5),(cx+opr*factor+7,z+8)],retention_color,3)
            if focus=='WALL':
                lines([(cx+Ri*factor,cy-8),(cx+Ro*factor,cy-8)],C['focus'],4)
        if s.make_shaft:
            shaft_half=s.shaft_diameter*.5*s.global_scale*factor
            overlap=calc_ball_shaft_overlap(s.ball_diameter*.5, s.shaft_diameter*.5)
            y0=cy+(R-overlap*s.global_scale)*factor
            y1=cy+(R+s.shaft_length*s.global_scale)*factor
            clr=C['error'] if 'BALL_SHAFT_DIAMETER' in bad else (C['focus'] if focus in ('BALL_SHAFT_DIAMETER','BALL_SHAFT_LENGTH') else C['ball'])
            outline(cx-shaft_half,y0,shaft_half*2,max(4,y1-y0),clr,3 if focus in ('BALL_SHAFT_DIAMETER','BALL_SHAFT_LENGTH') else 2)
        if s.make_socket and s.make_socket_shaft:
            sr=s.socket_shaft_diameter*.5*s.global_scale*factor
            h=s.socket_shaft_length*s.global_scale*factor
            base=cy-Ro*factor
            col=C['focus'] if focus in ('SOCKET_SHAFT_DIAMETER','SOCKET_SHAFT_LENGTH') else C['socket']
            outline(cx-sr,base-h,2*sr,max(4,h),col,2)
        if s.make_socket and s.make_motion_cut:
            a=s.motion_angle
            length= max(35,min(92,s.shaft_length*s.global_scale*factor))
            col=C['error'] if any(k.startswith('MOTION') for k in bad) else (C['focus'] if focus.startswith('MOTION') else C['muted'])
            endx,endy=cx+math.sin(a)*length,cy+math.cos(a)*length
            lines([(cx,cy),(endx,endy)],col,3)
            if focus=='MOTION_SHAFT_CLEARANCE' or 'MOTION_SHAFT_CLEARANCE' in bad:
                offset=max(2,s.motion_shaft_clearance*s.global_scale*factor)
                lines([(cx+offset,cy),(endx+offset,endy)],
                      C['error'] if 'MOTION_SHAFT_CLEARANCE' in bad else C['focus'],3)
        if s.make_socket and s.make_dowels and (focus.startswith('DOWEL_') or any(k.startswith('DOWEL_') for k in bad)):
            # Illustrative pin and matching larger hole, NOT real dowel layout.
            pinx,piny=x+310,y+78
            pinr=max(2,s.dowel_diameter*.5*s.global_scale*factor)
            depth=max(10,min(32,s.dowel_length*s.global_scale*factor))
            extra=s.dowel_clearance*s.global_scale*factor
            col=C['error'] if 'DOWEL_DIAMETER' in bad else C['focus']
            outline(pinx-pinr-extra,piny-5,2*(pinr+extra),depth+10,C['cavity'])
            outline(pinx-pinr,piny,2*pinr,depth,col)
            label(pinx+18,piny+8,'DOWEL',10,C['muted'])
        # X/Z side dimensions. The values are actual effective lengths,
        # while the line weight and simplified sectional outlines are guides.
        half_d=R*factor
        hd_y=cy-12
        lines([(cx-half_d,hd_y),(cx+half_d,hd_y),
               (cx-half_d,hd_y-5),(cx-half_d,hd_y+5),
               (cx+half_d,hd_y-5),(cx+half_d,hd_y+5)],
              C['focus'] if focus=='BALL_DIAMETER' else C['ball'],1.5)
        dim_x=cx-94
        lines([(dim_x,cy-R*factor),(dim_x,cy+R*factor),
               (dim_x-5,cy-R*factor),(dim_x+5,cy-R*factor),
               (dim_x-5,cy+R*factor),(dim_x+5,cy+R*factor)],
              C['focus'] if focus=='BALL_DIAMETER' else C['ball'],1.5)
        label(x+10,y+64,f'XZ側面: 球幅={s.ball_diameter*s.global_scale:.3f}',10,C['muted'])
        label(x+10,y+48,f'球高={s.ball_diameter*s.global_scale:.3f} / Z方向',10,C['muted'])
        # Independent XY top section: radial gap is visible in both axes.
        top_cx,top_cy=x+396,y+86
        mini=26/max(Ro,R,1.e-8)
        ring(top_cx,top_cy,max(1,R*mini),C['ball'],1.5)
        if s.make_socket:
            ring(top_cx,top_cy,max(1,Ri*mini),C['cavity'],1.3)
            ring(top_cx,top_cy,max(1,Ro*mini),C['socket'],1.3)
        lines([(top_cx-29,top_cy),(top_cx+29,top_cy),
               (top_cx,top_cy-29),(top_cx,top_cy+29)],C['muted'],1)
        label(top_cx-27,top_cy-39,'XY上面',10,C['muted'])
        # Numerics represent actual settings (scaled units), not pixels.
        px=x+252
        scale=s.global_scale
        label(px,y+202,f'球径 XY/Z {s.ball_diameter*scale:.3f}',11,C['ball'])
        label(px,y+182,f'ボール軸長 {s.shaft_length*scale:.3f}' if s.make_shaft else 'ボール軸 OFF',11,C['text'])
        if s.make_socket:
            label(px,y+161,f'球側隙間 {s.clearance*scale:.3f}',11,C['cavity'])
            label(px,y+142,f'受け肉厚 {s.wall_thickness*scale:.3f}',11,C['socket'])
            label(px,y+123,f'開口径 {s.opening_diameter*scale:.3f}',11,C['text'])
        else:
            label(px,y+161,'受け側 OFF',11,C['muted'])
        if s.make_shaft:
            label(px,y+105,f'軸径 {s.shaft_diameter*scale:.3f}',11,C['text'])
        label(px,y+65,f'Z全高 {top-bottom:.3f}',11,C['text'])
        if s.make_motion_cut:
            label(px,y+48,f'軸逃げ {s.motion_shaft_clearance*scale:.3f}',10,C['focus'] if focus=='MOTION_SHAFT_CLEARANCE' else C['muted'])
            label(px,y+29,f'Scale x{scale:.3f}',10,C['muted'])
        else:
            label(px,y+48,f'Scale x{scale:.3f}',10,C['muted'])
        if issues:
            label(x+12,y+30,'要修正: '+issues[0][1][:38],11,C['error'] if issues[0][2]=='ERROR' else C['warn'])
            if len(issues)>1:
                label(x+12,y+17,f'ほか {len(issues)-1} 件の注意/エラー',10,C['error'])
        else:
            label(x+12,y+30,'黄色 = 注目箇所 / 赤 = 要修正箇所',11,C['muted'])
        label(x+12,y+7,'側面XZ / 上面XY：模式図。完成Booleanと印刷は別途確認',10,C['muted'])
    finally:
        gpu.state.line_width_set(1.0)
        gpu.state.blend_set('NONE')


def bj_live_draw_world(ctx, s, focus, bad, lines):
    """Draw actual-scale, reference-aligned 3D wire guides for ball and shafts.

    Three orthogonal great circles show the sphere's X/Y/Z extent, instead
    of the former XY-only ring. Shafts use two rim rings, four side rails and
    a centerline so their radius and longitudinal span remain recognizable
    at oblique views. This is an overlay and never changes a mesh.
    """
    if not getattr(ctx, 'space_data', None) or ctx.space_data.type != 'VIEW_3D':
        return
    if s.placement_mode == 'GUIDE' and not s.guide_object:
        return
    from bpy_extras.view3d_utils import location_3d_to_region_2d

    matrix = get_reference_matrix(ctx, s)
    rv = ctx.space_data.region_3d
    if rv is None:
        return
    scale = float(s.global_scale)
    C = _BJ_LIVE_COLORS

    def project(p):
        point = matrix @ Vector((p[0] * scale, p[1] * scale, p[2] * scale))
        pixel = location_3d_to_region_2d(ctx.region, rv, point)
        return None if pixel is None else (pixel.x, pixel.y)

    def segments(points, color, width=1.8, closed=False):
        if len(points) < 2:
            return
        endpoints = []
        prev = project(points[0])
        for point in points[1:] + (points[:1] if closed else []):
            current = project(point)
            if prev is not None and current is not None:
                endpoints.extend((prev, current))
            prev = current
        if endpoints:
            lines(endpoints, color, width)

    def line(p, q, color, width=1.8):
        segments([p, q], color, width)

    def circle(radius, color, width=1.8, z=0., plane='XY'):
        if radius <= 0:
            return
        points = []
        for i in range(48):
            angle = math.tau * i / 48
            a, b = radius * math.cos(angle), radius * math.sin(angle)
            if plane == 'XZ':
                points.append((a, 0., b + z))
            elif plane == 'YZ':
                points.append((0., a, b + z))
            else:
                points.append((a, b, z))
        segments(points, color, width, closed=True)

    def sphere(radius, color, width=1.8):
        # XY (equator) + XZ and YZ (the two vertical meridians).
        for plane in ('XY', 'XZ', 'YZ'):
            circle(radius, color, width, plane=plane)

    def cylinder(radius, bottom, top, color, width=1.8):
        if radius <= 0 or top <= bottom:
            return
        circle(radius, color, width, z=bottom)
        circle(radius, color, width, z=top)
        # Four generatrices show the full cylinder even when the centerline
        # projects to a very short segment in an end-on camera view.
        for a in (0., math.pi * .5, math.pi, math.pi * 1.5):
            x, y = radius * math.cos(a), radius * math.sin(a)
            line((x, y, bottom), (x, y, top), color, width)
        line((0., 0., bottom), (0., 0., top),
             C['focus'] if focus in ('BALL_SHAFT_LENGTH', 'SOCKET_SHAFT_LENGTH')
             else C['muted'], 1.4)

    def box(radius, color, width=1.8):
        for z in (-radius, radius):
            corners = [(x, y, z) for x, y in
                       ((-radius, -radius), (radius, -radius),
                        (radius, radius), (-radius, radius))]
            segments(corners, color, width, closed=True)
        for x in (-radius, radius):
            for y in (-radius, radius):
                line((x, y, -radius), (x, y, radius), color, width)

    R = float(s.ball_diameter) * .5
    Ri = R + float(s.clearance)
    Ro = Ri + float(s.wall_thickness)
    ball_color = C['focus'] if focus in ('BALL_DIAMETER', 'GLOBAL_SCALE') else C['ball']
    sphere(R, ball_color, 2.4 if focus == 'BALL_DIAMETER' else 1.9)

    if s.make_socket:
        cavity_color = C['focus'] if focus == 'CLEARANCE' else C['cavity']
        socket_color = (C['error'] if 'WALL' in bad else
                        C['focus'] if focus in ('WALL', 'OUTER_SHAPE') else C['socket'])
        sphere(Ri, cavity_color, 2.5 if focus == 'CLEARANCE' else 1.5)
        if s.outer_shape == 'SPHERE':
            sphere(Ro, socket_color, 2.4 if focus in ('WALL', 'OUTER_SHAPE') else 1.8)
        elif s.outer_shape == 'CYLINDER':
            cylinder(Ro, -Ro, Ro, socket_color)
        else:
            box(Ro, socket_color)

        if focus == 'OPENING' or 'OPENING' in bad:
            # Illustrative rim at the outer surface, not a boolean-cut mesh.
            opening = float(s.opening_diameter) * .5
            lip_z = (max(0., Ro * Ro - opening * opening) ** .5
                     if s.outer_shape == 'SPHERE' else Ro)
            circle(opening, C['error'] if 'OPENING' in bad else C['focus'],
                   3., z=lip_z)

    if s.make_shaft:
        shaft_r = float(s.shaft_diameter) * .5
        # Match create_joint_preview() shaft placement and union overlap.
        try:
            overlap = calc_ball_shaft_overlap(R, shaft_r)
        except (ValueError, ArithmeticError, RuntimeError):
            overlap = 0.
        base = R - overlap
        tip = R + float(s.shaft_length)
        shaft_color = (C['error'] if 'BALL_SHAFT_DIAMETER' in bad else
                       C['focus'] if focus in ('BALL_SHAFT_DIAMETER',
                                              'BALL_SHAFT_LENGTH', 'GLOBAL_SCALE')
                       else C['ball'])
        cylinder(shaft_r, base, tip, shaft_color,
                 2.8 if focus in ('BALL_SHAFT_DIAMETER', 'BALL_SHAFT_LENGTH') else 2.)

    if s.make_socket and s.make_socket_shaft:
        socket_r = float(s.socket_shaft_diameter) * .5
        try:
            overlap = calc_socket_shaft_overlap(
                s.outer_shape, Ro, socket_r, float(s.wall_thickness))
        except (ValueError, ArithmeticError, RuntimeError):
            overlap = 0.
        socket_color = (C['focus'] if focus in ('SOCKET_SHAFT_DIAMETER',
                                              'SOCKET_SHAFT_LENGTH', 'GLOBAL_SCALE')
                        else C['socket'])
        cylinder(socket_r, -Ro - float(s.socket_shaft_length),
                 -Ro + overlap, socket_color,
                 2.8 if focus in ('SOCKET_SHAFT_DIAMETER', 'SOCKET_SHAFT_LENGTH') else 2.)


# ============================================================
# v0.8.6 mount + body receiver live guides (no mesh mutations)
# ============================================================

def bj_live_mount_dimensions(s):
    """Build a dimension plan shared by A/B and C live viewers, in scene units.

    Values are unscaled until the final display step. A/B cutter construction
    follows create_mount_cutter; C follows create_body_receiver_void.
    """
    R=float(s.ball_diameter)*.5
    Ri=R+float(s.clearance)
    Ro=Ri+float(s.wall_thickness)
    mc=float(s.mount_clearance)
    return {
        'ball_radius':R, 'cavity_radius':Ri, 'socket_radius':Ro,
        'mount_radius':Ro+mc, 'opening_radius':float(s.opening_diameter)*.5,
        'cut_depth':float(body_receiver_cut_depth(s)),
        'path_length':float(s.mount_path_length) if s.mount_make_insertion_path else 0.,
        'path_sign':1 if s.mount_path_direction=='POS_Z' else -1,
        'socket_shaft_radius':float(s.socket_shaft_diameter)*.5+mc,
        'socket_shaft_length':float(s.socket_shaft_length),
        'effective_scale':float(s.global_scale),
    }


def bj_live_saved_cutter_bounds(s):
    """Read actual saved B-cutter bbox dimensions, NOT today's predicted plan.

    This deliberately avoids recomputing a stored cutter from the controls:
    users can move, scale or edit a reusable mesh after creation.
    """
    obj = getattr(s, 'mount_cutter', None)
    if obj is None or getattr(obj, 'type', None) != 'MESH':
        return None
    try:
        # Dimensions are for the saved object's current bounding box, not a
        # claim about its Boolean internal geometry.
        dims = obj.dimensions
        return (str(obj.name), abs(float(dims.x)),
                abs(float(dims.y)), abs(float(dims.z)))
    except (ReferenceError, AttributeError, TypeError, ValueError):
        return None


def bj_live_mount_diagnostics(s):
    """Pure/metadata-only warnings. Nothing here runs a Boolean."""
    mode=s.live_view_mode
    d=bj_live_mount_dimensions(s)
    found=[]
    def flag(k,message,sev='ERROR'):
        found.append((k,message,sev,None,None))
    target=getattr(s,'mount_target',None)
    if target is None or getattr(target,'type',None)!='MESH':
        flag('MOUNT_TARGET','取付先メッシュが未指定です','WARNING')
    if mode=='MOUNT':
        if not s.make_socket:
            flag('MOUNT_CLEARANCE','A/B取付には「受け側を作る」ONが必要です')
        if d['mount_radius']<=0:
            flag('MOUNT_CLEARANCE','取付穴の外形が成立しません')
        if s.live_focus=='MOUNT_CUTTER' and getattr(s,'mount_cutter',None) is None:
            flag('MOUNT_CUTTER','B: 再利用Cutterが未指定（作成前なら正常）','WARNING')
    else:
        if s.body_receiver_show_split_guides and s.body_receiver_make_dowels and s.body_receiver_dowel_spacing > 0:
            pin_rad=s.dowel_diameter*.5
            safe_spacing=2*(d['cavity_radius']+pin_rad+s.dowel_outer_margin)
            if s.body_receiver_dowel_spacing < safe_spacing-1e-8:
                flag('BODY_DOWEL',f'C: ダボ中心間隔は {safe_spacing*s.global_scale:.3f} 以上必要です')
        if d['opening_radius'] >= d['cavity_radius']-1e-8:
            flag('BODY_OPENING','C: 開口直径は内側キャビティより小さくしてください')
        if s.make_shaft and not s.make_motion_cut and s.shaft_diameter >= s.opening_diameter:
            flag('BALL_SHAFT_DIAMETER','C: ボール軸径は開口径より小さくしてください')
        if s.make_motion_cut and s.motion_cut_mode=='FLAT':
            try:
                cut=calc_body_receiver_flat_cut(s)
                if not cut['feasible']:
                    flag('MOTION_ANGLE','C: この軸径と傾きでは可動域が成立しません')
            except (ValueError,RuntimeError,ZeroDivisionError):
                flag('MOTION_ANGLE','C: 可動域の寸法計算に失敗しました')
    return tuple(found)


def bj_live_render_mount(ctx,s,issues):
    """Draw a true-to-dimension XZ cutter/void cross section.

    Target silhouette is conceptual (unknown model geometry). The world overlay
    separately uses the actual placement/target bbox when available.
    """
    import gpu
    import blf
    from gpu_extras.batch import batch_for_shader
    region=ctx.region
    if region.width<460 or region.height<335:
        return
    C=_BJ_LIVE_COLORS
    mode=s.live_view_mode
    focus=s.live_focus
    bad={r[0] for r in issues if r[2]=='ERROR'}
    scale=s.global_scale
    d=bj_live_mount_dimensions(s)
    x,y=18,20
    w=min(494,region.width-36)
    h=300
    shader=gpu.shader.from_builtin('UNIFORM_COLOR')
    def draw_lines(points,col,width=1.6):
        if len(points)<2:return
        gpu.state.line_width_set(width)
        shader.bind()
        shader.uniform_float('color',col)
        batch_for_shader(shader,'LINES',{'pos':points}).draw(shader)
    def panel_rect(px,py,ww,hh,col):
        shader.bind();shader.uniform_float('color',col)
        batch_for_shader(shader,'TRIS',{'pos':[(px,py),(px+ww,py),(px+ww,py+hh),
                     (px,py),(px+ww,py+hh),(px,py+hh)]}).draw(shader)
    def caption(px,py,msg,sz=11,col=None):
        blf.position(0,px,py,0);blf.size(0,sz);blf.color(0,*(col or C['text']));blf.draw(0,str(msg))
    def circle(cx,cy,r,col,width=1.8):
        if r<=0:return
        pts=[]
        for i in range(48):
            a=math.tau*i/48;b=math.tau*(i+1)/48
            pts.extend(((cx+math.cos(a)*r,cy+math.sin(a)*r),
                        (cx+math.cos(b)*r,cy+math.sin(b)*r)))
        draw_lines(pts,col,width)
    def rect_outline(x1,y1,x2,y2,col,lw=1.5):
        draw_lines([(x1,y1),(x2,y1),(x2,y1),(x2,y2),
                    (x2,y2),(x1,y2),(x1,y2),(x1,y1)],col,lw)
    is_body=(mode=='BODY')
    title='C. 本体受け' if is_body else 'A/B. 取付穴・再利用Cutter'
    # Layout uses a physical XZ plane; radius and axial extents share one factor.
    outer=d['cavity_radius'] if is_body else d['mount_radius']
    if is_body:
        lo=-outer
        shaft_top=(d['ball_radius']+float(s.shaft_length)) if s.make_shaft else d['ball_radius']
        hi=max(d['cut_depth'],outer,shaft_top)
    else:
        lo=-outer-(d['socket_shaft_length'] if s.make_socket_shaft and s.mount_include_socket_shaft else 0.)
        hi=outer
        if d['path_length']>0:
            if d['path_sign']>0:hi+=d['path_length']
            else:lo-=d['path_length']
    half=max(outer,d['socket_shaft_radius'] if not is_body and s.make_socket_shaft and s.mount_include_socket_shaft else 0.01)
    factor=min(78/max(half*scale,.0001),155/max((hi-lo)*scale,.0001))
    cx=x+119
    cy=y+40-lo*scale*factor
    def xx(v): return cx+v*scale*factor
    def zz(v): return cy+v*scale*factor
    def silhouette(r,z0=0.,shape='SPHERE',col=None,lw=2):
        if shape=='SPHERE':circle(cx,zz(z0),r*scale*factor,col or C['socket'],lw)
        else:rect_outline(xx(-r),zz(z0-r),xx(r),zz(z0+r),col or C['socket'],lw)
    gpu.state.blend_set('ALPHA')
    try:
        panel_rect(x,y,w,h,C['background'])
        panel_rect(x,y+h-3,w,3,C['error'] if bad else C['cavity'])
        caption(x+12,y+h-25,'Ball Joint Maker  |  LIVE 本体取付',14)
        caption(x+12,y+h-45,title,12,C['focus'])
        caption(x+12,y+h-61,'左: XZ断面寸法 / 本体枠は模式図',10,C['muted'])
        # Generic body shape: actual target mesh cannot be assumed cylindrical.
        body_r=outer*1.26
        rect_outline(xx(-body_r),zz(-body_r),xx(body_r),zz(body_r),
                     C['focus'] if focus=='MOUNT_TARGET' else C['muted'],1)
        if is_body:
            silhouette(d['cavity_radius'],col=C['error'] if 'BODY_CAVITY' in bad else C['cavity'])
            # Orange = male reference geometry, green = actual Boolean void.
            # The shaft shown below is NOT an additional C hole cutter.
            circle(cx,cy,d['ball_radius']*scale*factor,C['ball'],2)
            if s.make_shaft:
                shaft_r=float(s.shaft_diameter)*.5
                overlap=calc_ball_shaft_overlap(d['ball_radius'],shaft_r)
                shaft_lo=d['ball_radius']-overlap
                shaft_hi=d['ball_radius']+float(s.shaft_length)
                shaft_col=(C['error'] if 'BALL_SHAFT_DIAMETER' in bad else
                           C['focus'] if focus in ('BALL_SHAFT_DIAMETER','BALL_SHAFT_LENGTH','BODY_SHAFT') else C['ball'])
                rect_outline(xx(-shaft_r),zz(shaft_lo),xx(shaft_r),zz(shaft_hi),shaft_col,2.8)
                # Z direction and endpoint reference are explicitly visible.
                draw_lines([(xx(0),zz(d['ball_radius'])),(xx(0),zz(shaft_hi))],shaft_col,1.4)
            mouth=d['opening_radius']
            col=C['error'] if 'BODY_OPENING' in bad else C['focus'] if focus=='BODY_OPENING' else C['cavity']
            draw_lines([(xx(-mouth),zz(0)),(xx(-mouth),zz(d['cut_depth'])),
                        (xx(mouth),zz(0)),(xx(mouth),zz(d['cut_depth'])),
                        (xx(-mouth),zz(d['cut_depth'])),(xx(mouth),zz(d['cut_depth']))],col,2.4)
            if s.body_receiver_show_split_guides:
                # Representative split plane in a local XZ cut. Exact world orientation
                # (especially Y normals) is projected separately into the 3D viewport.
                offset=s.body_receiver_plane_offset
                pc=C['focus'] if focus in ('BODY_PLANE','BODY_OFFSET') else C['muted']
                if s.body_receiver_plane_axis.endswith('_Z'):
                    draw_lines([(xx(-body_r),zz(offset)),(xx(body_r),zz(offset))],pc,3)
                else:
                    draw_lines([(xx(offset),zz(-body_r)),(xx(offset),zz(body_r))],pc,3)
            caption(x+246,y+213,f'球径(XY/Z) {s.ball_diameter*scale:.3f}',11,C['ball'])
            caption(x+246,y+195,f'空洞径 {2*d["cavity_radius"]*scale:.3f}',11,C['cavity'])
            caption(x+246,y+177,f'開口径 {s.opening_diameter*scale:.3f}',11,col)
            caption(x+246,y+159,f'穴の深さ +Z {d["cut_depth"]*scale:.3f}',11,C['focus'] if focus=='BODY_DEPTH' else C['text'])
            if s.make_shaft:
                axis_col=C['error'] if 'BALL_SHAFT_DIAMETER' in bad else C['focus'] if focus in ('BALL_SHAFT_DIAMETER','BALL_SHAFT_LENGTH','BODY_SHAFT') else C['ball']
                caption(x+246,y+141,f'球側軸径 {s.shaft_diameter*scale:.3f}',11,axis_col)
                caption(x+246,y+123,f'球側軸長 {s.shaft_length*scale:.3f}',11,axis_col)
            else:
                caption(x+246,y+141,'球側軸 OFF',11,C['muted'])
            if s.body_receiver_show_split_guides:
                caption(x+246,y+105,f'分割面 {s.body_receiver_plane_axis}',10,pc)
                caption(x+246,y+87,f'面オフセット {offset*scale:.3f}',10,C['focus'] if focus=='BODY_OFFSET' else C['text'])
                if s.body_receiver_make_dowels:
                    dcol=C['error'] if 'BODY_DOWEL' in bad else C['focus'] if focus=='BODY_DOWEL' else C['muted']
                    spacer=s.body_receiver_dowel_spacing if s.body_receiver_dowel_spacing>0 else 2*(d['cavity_radius']+s.dowel_diameter*.5+s.dowel_outer_margin)
                    # Markers are symbolic; actual plane U/V positions are in 3D.
                    radius=max(2.,s.dowel_diameter*.5*scale*factor)
                    ux=min(62.,spacer*.5*scale*factor)
                    circle(cx-ux,zz(s.body_receiver_dowel_v_offset),radius,dcol,2.2)
                    circle(cx+ux,zz(s.body_receiver_dowel_v_offset),radius,dcol,2.2)
                    caption(x+246,y+69,f'ダボ間隔 {spacer*scale:.3f}',10,dcol)
                else:
                    caption(x+246,y+69,'C: 外殻・受け軸なし',10,C['muted'])
            caption(x+12,y+48,'橙=Ball参考形状 / 緑=本体から削る空洞',10,C['muted'])
        else:
            col=C['error'] if 'MOUNT_CLEARANCE' in bad else C['focus'] if focus=='MOUNT_CLEARANCE' else C['cavity']
            silhouette(d['mount_radius'],shape=s.outer_shape,col=col,lw=2.7)
            silhouette(d['socket_radius'],shape=s.outer_shape,col=C['socket'],lw=2)
            # End (POS_Z/NEG_Z) is shifted by path length in local coordinates.
            if d['path_length']>0:
                sign=d['path_sign'];end=sign*d['path_length']
                rr=d['mount_radius']
                pathcol=C['focus'] if focus in ('MOUNT_PATH','MOUNT_PATH_LENGTH') else C['cavity']
                draw_lines([(xx(-rr),zz(0)),(xx(-rr),zz(end)),
                            (xx(rr),zz(0)),(xx(rr),zz(end))],pathcol,2)
                silhouette(rr,z0=end,shape=s.outer_shape,col=pathcol,lw=1.6)
            if s.make_socket_shaft and s.mount_include_socket_shaft:
                shaft_r=d['socket_shaft_radius']
                start=-d['socket_radius']-d['socket_shaft_length']-max(.05,s.mount_clearance)
                end=-d['socket_radius']+max(.05,s.mount_clearance)
                sc=C['focus'] if focus=='MOUNT_SHAFT' else C['socket']
                rect_outline(xx(-shaft_r),zz(start),xx(shaft_r),zz(end),sc,2)
            caption(x+246,y+188,f'受け外径 {d["socket_radius"]*2*scale:.3f}',11,C['socket'])
            caption(x+246,y+166,f'取付穴径 {d["mount_radius"]*2*scale:.3f}',11,col)
            caption(x+246,y+144,f'片側隙間 {s.mount_clearance*scale:.3f}',11,C['focus'] if focus=='MOUNT_CLEARANCE' else C['text'])
            caption(x+246,y+122,f'挿入経路 {d["path_length"]*scale:.3f}',11,C['focus'] if focus.startswith('MOUNT_PATH') else C['text'])
            caption(x+246,y+100,f'方向 {"+Z" if d["path_sign"]>0 else "-Z"}',11,C['muted'])
            caption(x+246,y+83,'受け軸の穴: '+('含める' if s.make_socket_shaft and s.mount_include_socket_shaft else '含めない'),10,C['muted'])
            actual=bj_live_saved_cutter_bounds(s)
            if actual is not None:
                caption(x+246,y+221,'既存Cutter: '+actual[0][:16],10,C['focus'] if focus=='MOUNT_CUTTER' else C['muted'])
                caption(x+246,y+203,f'実BBox XYZ {actual[1]:.2f}/{actual[2]:.2f}/{actual[3]:.2f}',10,C['focus'])

            if s.mount_target is None:
                caption(x+246,y+66,'本体: 未指定',10,C['warn'])
            else:
                caption(x+246,y+66,'本体: '+s.mount_target.name[:18],10,C['text'])
        caption(x+12,y+29,'2D=設定予測 / 保存済みB Cutterは実BBox・3D枠を参照',10,C['muted'])
        if issues:
            err=next((z for z in issues if z[2]=='ERROR'), issues[0])
            caption(x+12,y+10,'要確認: '+err[1][:45],10,C['error'] if err[2]=='ERROR' else C['warn'])
        else:
            caption(x+12,y+10,'黄色=注目、赤=問題箇所 / 3D位置を併用して確認',10,C['muted'])
    finally:
        gpu.state.line_width_set(1)
        gpu.state.blend_set('NONE')


def bj_live_draw_mount_world(ctx,s,d,focus,bad,lines):
    """Actual-placement world guides, with live transformed target bbox and C split plane."""
    if not getattr(ctx,'space_data',None) or ctx.space_data.type!='VIEW_3D':return
    if s.placement_mode=='GUIDE' and not s.guide_object:return
    from bpy_extras.view3d_utils import location_3d_to_region_2d
    m=get_reference_matrix(ctx,s)
    rv=ctx.space_data.region_3d
    if rv is None:return
    def point(x,y,z):
        v=location_3d_to_region_2d(ctx.region,rv,m@Vector((x*s.global_scale,y*s.global_scale,z*s.global_scale)))
        return None if v is None else (v.x,v.y)
    def segment(p,q,col,thick=1.6):
        if p is not None and q is not None:lines([p,q],col,thick)
    def ring(radius, z, col, plane='XY'):
        if radius <= 0:
            return
        pts=[]
        for i in range(48):
            a=i*math.tau/48;b=(i+1)*math.tau/48
            if plane=='XZ':
                p=point(radius*math.cos(a),0,radius*math.sin(a)+z)
                q=point(radius*math.cos(b),0,radius*math.sin(b)+z)
            elif plane=='YZ':
                p=point(0,radius*math.cos(a),radius*math.sin(a)+z)
                q=point(0,radius*math.cos(b),radius*math.sin(b)+z)
            else:
                p=point(radius*math.cos(a),radius*math.sin(a),z)
                q=point(radius*math.cos(b),radius*math.sin(b),z)
            if p is not None and q is not None:
                pts.extend((p,q))
        if pts:
            lines(pts,col,2.2)
    C=_BJ_LIVE_COLORS
    r=(d['cavity_radius'] if s.live_view_mode=='BODY' else d['mount_radius'])
    if s.live_view_mode=='BODY':
        # C also needs a vertical sphere profile, not an XY-only circle.
        cavity_col=C['focus'] if focus=='BODY_CAVITY' else C['cavity']
        for plane in ('XY','XZ','YZ'):
            ring(r,0,cavity_col,plane)
            ring(d['ball_radius'],0,C['ball'],plane)
        if s.make_shaft:
            shaft_color=(C['error'] if 'BALL_SHAFT_DIAMETER' in bad else
                         C['focus'] if focus in ('BODY_SHAFT','BALL_SHAFT_DIAMETER','BALL_SHAFT_LENGTH') else C['ball'])
            rr=s.shaft_diameter*.5
            try:
                overlap=calc_ball_shaft_overlap(d['ball_radius'],rr)
            except (ValueError,ArithmeticError,RuntimeError):
                overlap=0.
            base=d['ball_radius']-overlap
            tip=d['ball_radius']+s.shaft_length
            ring(rr,base,shaft_color)
            ring(rr,tip,shaft_color)
            for angle in (0.,math.pi*.5,math.pi,math.pi*1.5):
                x0,y0=rr*math.cos(angle),rr*math.sin(angle)
                segment(point(x0,y0,base),point(x0,y0,tip),shaft_color,2)
            segment(point(0,0,base),point(0,0,tip),shaft_color,1.6)
        ring(d['opening_radius'],d['cut_depth'],C['error'] if 'BODY_OPENING' in bad else C['focus'])
        segment(point(0,0,0),point(0,0,d['cut_depth']),C['focus'],2)
        if s.body_receiver_show_split_guides:
            try:
                center,n,u,v=get_body_receiver_plane(ctx,s)
                radius=max(d['cavity_radius']*1.5,d['opening_radius']*1.5)*s.global_scale
                corners=[center+radius*(a*u+b*v) for a,b in [(-1,-1),(1,-1),(1,1),(-1,1)]]
                projected=[location_3d_to_region_2d(ctx.region,rv,p) for p in corners]
                for i in range(4):
                    a,b=projected[i],projected[(i+1)%4]
                    if a is not None and b is not None:lines([(a.x,a.y),(b.x,b.y)],C['focus'],2)
                if s.body_receiver_make_dowels:
                    pts,_,_,_,_,spacing=body_receiver_dowel_layout(ctx,s)
                    for world in pts:
                        p=location_3d_to_region_2d(ctx.region,rv,world)
                        if p is not None:
                            # A light cross marks exact 3D projected pin center.
                            color=C['error'] if 'BODY_DOWEL' in bad else C['focus']
                            lines([(p.x-5,p.y),(p.x+5,p.y),
                                   (p.x,p.y-5),(p.x,p.y+5)],color,2.2)
            except (ValueError, RuntimeError, ReferenceError):
                pass
    else:
        ring(r,0,C['focus'] if focus=='MOUNT_CLEARANCE' else C['cavity'])
        ring(d['socket_radius'],0,C['socket'])
        if d['path_length']>0:
            ring(r,d['path_sign']*d['path_length'],C['focus'])
            segment(point(0,0,0),point(0,0,d['path_sign']*d['path_length']),C['focus'],2)
        if s.make_socket_shaft and s.mount_include_socket_shaft:
            ring(d['socket_shaft_radius'],-d['socket_radius']-d['socket_shaft_length'],C['socket'])
    # A saved/reused B Cutter may have been moved after creation. Render its
    # current WORLD bounds; never pretend it remains at the live joint origin.
    if s.live_view_mode=='MOUNT':
        actual=getattr(s,'mount_cutter',None)
        if actual is not None and getattr(actual,'type',None)=='MESH':
            try:
                verts=[actual.matrix_world@Vector(v) for v in actual.bound_box]
                for i in range(len(verts)):
                    for j in range(i+1,len(verts)):
                        a0=actual.bound_box[i];b0=actual.bound_box[j]
                        if sum(abs(a-b)>1.e-7 for a,b in zip(a0,b0))!=1:continue
                        a=location_3d_to_region_2d(ctx.region,rv,verts[i]);b=location_3d_to_region_2d(ctx.region,rv,verts[j])
                        if a is not None and b is not None:lines([(a.x,a.y),(b.x,b.y)],C['focus'],2.6)
            except (ReferenceError,ValueError,RuntimeError,AttributeError):
                pass
    target=(getattr(s,'body_receiver_split_target',None)
            if s.live_view_mode=='BODY' and s.body_receiver_show_split_guides
            else getattr(s,'mount_target',None))
    if target is None or getattr(target,'type',None)!='MESH':return
    try:
        corners=[target.matrix_world@Vector(v) for v in target.bound_box]
        for i in range(len(corners)):
            for j in range(i+1,len(corners)):
                # Only connect original bbox edge pairs, never diagonals.
                u=target.bound_box[i];v=target.bound_box[j]
                if sum(abs(a-b)>1.e-7 for a,b in zip(u,v))!=1:continue
                a=location_3d_to_region_2d(ctx.region,rv,corners[i]);b=location_3d_to_region_2d(ctx.region,rv,corners[j])
                if a is not None and b is not None:
                    lines([(a.x,a.y),(b.x,b.y)],C['focus'] if focus=='MOUNT_TARGET' else C['muted'],1.5)
    except (ReferenceError,ValueError,RuntimeError,AttributeError):
        pass


class BALLJOINT_OT_live_focus(Operator):
    bl_idname = 'ball_joint.live_focus'
    bl_label = '注目箇所を表示'
    bl_description = 'この設定が作用する場所をLIVEガイドで強調します'
    focus_key: StringProperty(default='OVERVIEW')
    view_mode: StringProperty(default='')
    def execute(self, context):
        s=context.scene.ball_joint_settings
        s.live_guide_enabled=True
        s.live_focus=self.focus_key if self.focus_key in _BJ_FOCUS_INFO else 'OVERVIEW'
        if self.view_mode in {'JOINT', 'MOUNT', 'BODY'}:
            s.live_view_mode=self.view_mode
        bj_live_tag_redraw(context)
        return {'FINISHED'}


# ============================================================
# Helpers
# ============================================================

def ensure_object_mode():
    """
    Primitive-add and modifier-apply operators behave very differently in
    Edit Mode. In Edit Mode a new sphere/cube can be appended into the mesh
    currently being edited instead of becoming a new object, and
    modifier_apply can silently cancel.

    Ball Joint Maker always performs generation in Object Mode.
    """
    if bpy.context.mode == 'OBJECT':
        return False

    active = bpy.context.active_object

    if active is None:
        raise RuntimeError(
            "オブジェクトモードへ切り替えられません。"
        )

    try:
        bpy.ops.object.mode_set(
            mode='OBJECT'
        )
    except Exception as exc:
        raise RuntimeError(
            f"オブジェクトモードへの切替に失敗しました: {exc}"
        )

    return True


def set_active(obj):
    ensure_object_mode()
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj


def apply_scale(obj):
    set_active(obj)
    bpy.ops.object.transform_apply(
        location=False,
        rotation=False,
        scale=True,
    )


def move_to_collection(obj, collection):
    for c in list(obj.users_collection):
        c.objects.unlink(obj)
    collection.objects.link(obj)


def new_collection(name, parent):
    col = bpy.data.collections.new(name)
    parent.children.link(col)
    return col


def add_uv_sphere(name, radius, location, collection, segments, rings):
    ensure_object_mode()

    bpy.ops.mesh.primitive_uv_sphere_add(
        segments=segments,
        ring_count=rings,
        radius=radius,
        location=location,
    )
    obj = bpy.context.active_object
    obj.name = name
    move_to_collection(obj, collection)
    return obj


def add_cylinder(
    name,
    radius,
    depth,
    location,
    collection,
    vertices=64,
    rotation=(0.0, 0.0, 0.0),
):
    ensure_object_mode()

    bpy.ops.mesh.primitive_cylinder_add(
        vertices=vertices,
        radius=radius,
        depth=depth,
        location=location,
        rotation=rotation,
    )
    obj = bpy.context.active_object
    obj.name = name
    move_to_collection(obj, collection)
    return obj


def add_cone(
    name,
    radius1,
    radius2,
    depth,
    location,
    collection,
    vertices=96,
):
    ensure_object_mode()

    bpy.ops.mesh.primitive_cone_add(
        vertices=vertices,
        radius1=radius1,
        radius2=radius2,
        depth=depth,
        location=location,
    )
    obj = bpy.context.active_object
    obj.name = name
    move_to_collection(obj, collection)
    return obj


def add_box(name, dimensions, location, collection):
    ensure_object_mode()

    bpy.ops.mesh.primitive_cube_add(
        location=location,
    )
    obj = bpy.context.active_object
    obj.name = name
    obj.dimensions = dimensions
    move_to_collection(obj, collection)
    apply_scale(obj)
    return obj


def boolean_apply(target, cutter, operation):
    ensure_object_mode()
    set_active(target)

    mod = target.modifiers.new(
        name=f"BJ_{operation}",
        type='BOOLEAN',
    )
    mod.operation = operation
    mod.solver = 'EXACT'
    mod.object = cutter

    mod_name = mod.name

    try:
        result = bpy.ops.object.modifier_apply(
            modifier=mod_name,
        )

        if 'FINISHED' not in result:
            raise RuntimeError(
                f"modifier_apply returned {result}"
            )

        # If the modifier still exists, Blender did not really apply it.
        if target.modifiers.get(mod_name) is not None:
            raise RuntimeError(
                "Boolean modifier remained after apply"
            )

    except Exception as exc:
        existing = target.modifiers.get(
            mod_name
        )

        if existing is not None:
            try:
                target.modifiers.remove(
                    existing
                )
            except Exception:
                pass

        raise RuntimeError(
            f"Boolean {operation} failed on {target.name}: {exc}"
        )


def delete_object(obj):
    if obj and obj.name in bpy.data.objects:
        bpy.data.objects.remove(
            obj,
            do_unlink=True,
        )


def duplicate_object(obj, name, collection):
    dup = obj.copy()
    dup.data = obj.data.copy()
    dup.name = name
    collection.objects.link(dup)
    return dup


def mesh_result_looks_valid(obj, min_extent=1e-6):
    if (
        obj is None
        or obj.name not in bpy.data.objects
        or obj.type != 'MESH'
        or obj.data is None
    ):
        return False

    if (
        len(obj.data.vertices) < 4
        or len(obj.data.polygons) < 1
    ):
        return False

    dims = obj.dimensions

    if (
        not math.isfinite(dims.x)
        or not math.isfinite(dims.y)
        or not math.isfinite(dims.z)
    ):
        return False

    return dims.length > min_extent


def boolean_epsilon(reference_size):
    # Avoid exact symmetric vertex/edge-on-plane Boolean cases.
    return max(
        1e-5,
        min(
            0.002,
            abs(reference_size) * 0.0002,
        ),
    )


def mirror_mesh_across_axis(obj, axis):
    """
    Mirror mesh data across local X or Y and recalculate normals.
    Used to derive the opposite socket half from one known-good Boolean half.
    """
    if not obj or obj.type != 'MESH':
        raise RuntimeError("ミラー元がメッシュではありません。")

    if axis == 'X':
        mat = Matrix((
            (-1.0, 0.0, 0.0, 0.0),
            ( 0.0, 1.0, 0.0, 0.0),
            ( 0.0, 0.0, 1.0, 0.0),
            ( 0.0, 0.0, 0.0, 1.0),
        ))
    else:
        mat = Matrix((
            (1.0,  0.0, 0.0, 0.0),
            (0.0, -1.0, 0.0, 0.0),
            (0.0,  0.0, 1.0, 0.0),
            (0.0,  0.0, 0.0, 1.0),
        ))

    obj.data.transform(mat)
    obj.data.update()

    # Negative-determinant mirror reverses winding; recalc consistently.
    bm = bmesh.new()

    try:
        bm.from_mesh(obj.data)

        if bm.faces:
            bmesh.ops.reverse_faces(
                bm,
                faces=list(bm.faces),
            )

        bmesh.ops.recalc_face_normals(
            bm,
            faces=list(bm.faces),
        )

        bm.to_mesh(obj.data)
        obj.data.update()

    finally:
        bm.free()


def half_mesh_is_on_expected_side(
    obj,
    axis,
    positive_side,
    tolerance,
):
    """
    Stronger validation than "has polygons".
    A valid split half must not contain large geometry on the wrong side.
    This catches the exact failure where a Boolean returns a sphere-half
    plus a chunk of the box cutter in the same object.
    """
    if not mesh_result_looks_valid(obj):
        return False

    if not obj.data.vertices:
        return False

    coord_index = 0 if axis == 'X' else 1

    coords = [
        v.co[coord_index]
        for v in obj.data.vertices
    ]

    if positive_side:
        return min(coords) >= -tolerance

    return max(coords) <= tolerance




def count_nonmanifold_edges(obj):
    """
    Diagnostic only. Final joint parts should normally be closed solids.
    Returns -1 if the check itself cannot be completed.
    """
    if (
        not obj
        or obj.type != 'MESH'
        or not obj.data
    ):
        return -1

    bm = bmesh.new()

    try:
        bm.from_mesh(
            obj.data
        )

        return sum(
            1
            for edge in bm.edges
            if not edge.is_manifold
        )

    except Exception:
        return -1

    finally:
        bm.free()


def remove_temp_collection(temp_col):
    """
    Remove every temporary object first, then remove the collection.
    This prevents Boolean cutters from surviving a partial operation.
    """
    if not temp_col:
        return

    for obj in list(temp_col.objects):
        delete_object(obj)

    try:
        bpy.data.collections.remove(
            temp_col,
        )
    except Exception:
        pass


def remove_collection_tree(collection):
    """
    Transaction rollback helper.
    Remove every child collection and every generated object in this tree.
    """
    if not collection:
        return

    for child in list(collection.children):
        remove_collection_tree(
            child
        )

    for obj in list(collection.objects):
        delete_object(
            obj
        )

    try:
        bpy.data.collections.remove(
            collection,
        )
    except Exception:
        pass


def safe_collection_name(prefix):
    i = 1

    while bpy.data.collections.get(
        f"{prefix}_{i:03d}"
    ):
        i += 1

    return f"{prefix}_{i:03d}"


def safe_object_name(prefix):
    i = 1

    while bpy.data.objects.get(
        f"{prefix}_{i:03d}"
    ):
        i += 1

    return f"{prefix}_{i:03d}"


def get_reference_matrix(context, settings):
    """
    Geometry is generated around local origin first.
    This returns the final placement matrix without inheriting scale.
    """
    if (
        settings.placement_mode == 'GUIDE'
        and settings.guide_object
    ):
        mat = settings.guide_object.matrix_world.copy()
        loc, rot, _scale = mat.decompose()

        if settings.use_reference_rotation:
            return (
                Matrix.Translation(loc)
                @ rot.to_matrix().to_4x4()
            )

        return Matrix.Translation(loc)

    cursor = context.scene.cursor
    loc = cursor.location.copy()

    if settings.use_reference_rotation:
        rot = cursor.rotation_euler.to_quaternion()
        return (
            Matrix.Translation(loc)
            @ rot.to_matrix().to_4x4()
        )

    return Matrix.Translation(loc)


def transform_result_objects(objects, matrix):
    for obj in objects:
        if obj and obj.name in bpy.data.objects:
            obj.matrix_world = (
                matrix
                @ obj.matrix_world
            )


def uniform_scale_mesh_objects(objects, factor):
    """
    Scale finished mesh geometry uniformly around each object's local origin.

    This intentionally happens AFTER all booleans and BEFORE final placement.
    That keeps every proportion identical:
    ball, socket, cavity, clearance, dowels, openings and shafts all scale
    together without having separate scaling formulas that can drift apart.
    """
    factor = max(
        0.01,
        float(factor),
    )

    if abs(factor - 1.0) < 1e-9:
        return

    mat = Matrix.Scale(
        factor,
        4,
    )

    seen_meshes = set()

    for obj in objects:
        if (
            not obj
            or obj.name not in bpy.data.objects
            or obj.type != 'MESH'
            or not obj.data
        ):
            continue

        # Every generated output normally has unique mesh data, but guard
        # against accidental double-scaling if a mesh is ever shared.
        mesh_key = obj.data.as_pointer()

        if mesh_key in seen_meshes:
            continue

        obj.data.transform(
            mat
        )
        obj.data.update()
        seen_meshes.add(
            mesh_key
        )



def uniform_scale_preview_objects(objects, factor):
    """
    Preview uses multiple separate objects whose locations are offsets from the
    joint center. Scale both their mesh data AND those offsets.
    """
    factor = max(
        0.01,
        float(factor),
    )

    if abs(factor - 1.0) < 1e-9:
        return

    mat = Matrix.Scale(
        factor,
        4,
    )

    seen_meshes = set()

    for obj in objects:
        if (
            not obj
            or obj.name not in bpy.data.objects
            or obj.type != 'MESH'
            or not obj.data
        ):
            continue

        obj.location = (
            obj.location * factor
        )

        mesh_key = obj.data.as_pointer()

        if mesh_key in seen_meshes:
            continue

        obj.data.transform(
            mat
        )
        obj.data.update()

        seen_meshes.add(
            mesh_key
        )




PREVIEW_COLLECTION_NAME = "BallJoint_Preview"


def clear_joint_preview():
    collections=getattr(getattr(bpy,'data',None),'collections',None)
    if collections is None: return
    col = collections.get(PREVIEW_COLLECTION_NAME)

    if col is not None:
        remove_collection_tree(
            col
        )


def mark_preview_object(
    obj,
    display_type='WIRE',
):
    obj["ball_joint_preview"] = True
    obj.hide_render = True
    obj.show_in_front = True
    obj.display_type = display_type
    return obj


def create_joint_preview(
    context,
    settings,
):
    """
    Lightweight, non-destructive preview.

    No Boolean is applied here. Instead it shows:
      - ball and optional ball shaft
      - socket outside envelope
      - inner cavity envelope
      - opening guide
      - optional motion-cut guide
      - optional socket-side shaft
      - optional dowel-hole envelopes

    This keeps preview fast and prevents preview refreshes from creating the
    same Boolean failure modes as final generation.
    """
    ensure_object_mode()

    if (
        settings.placement_mode == 'GUIDE'
        and not settings.guide_object
    ):
        raise RuntimeError(
            "プレビュー用の仮原点オブジェクトが指定されていません。"
        )

    clear_joint_preview()

    col = new_collection(
        PREVIEW_COLLECTION_NAME,
        context.scene.collection,
    )

    created = []

    D = settings.ball_diameter
    R = D * 0.5
    Ri = R + settings.clearance
    Ro = Ri + settings.wall_thickness
    opening_r = settings.opening_diameter * 0.5
    center = Vector((0.0, 0.0, 0.0))

    try:
        # Ball
        ball = add_uv_sphere(
            "PREVIEW_Ball",
            R,
            center,
            col,
            min(settings.sphere_segments, 48),
            min(settings.sphere_rings, 24),
        )
        mark_preview_object(
            ball,
            'WIRE',
        )
        created.append(
            ball
        )

        if settings.make_shaft:
            shaft_r = (
                settings.shaft_diameter
                * 0.5
            )

            overlap = calc_ball_shaft_overlap(
                R,
                shaft_r,
            )

            shaft_depth = (
                settings.shaft_length
                + overlap
            )

            shaft_center = Vector((
                0.0,
                0.0,
                R
                + settings.shaft_length * 0.5
                - overlap * 0.5,
            ))

            shaft = add_cylinder(
                "PREVIEW_BallShaft",
                shaft_r,
                shaft_depth,
                shaft_center,
                col,
                vertices=32,
            )
            mark_preview_object(
                shaft,
                'WIRE',
            )
            created.append(
                shaft
            )

        # Ball-only preview mode.
        if not settings.make_socket:
            uniform_scale_preview_objects(
                created,
                settings.global_scale,
            )

            transform_result_objects(
                created,
                get_reference_matrix(
                    context,
                    settings,
                ),
            )

            return created

        # Socket outside envelope
        if settings.outer_shape == 'SPHERE':
            socket_outer = add_uv_sphere(
                "PREVIEW_SocketOuter",
                Ro,
                center,
                col,
                min(settings.sphere_segments, 48),
                min(settings.sphere_rings, 24),
            )
        elif settings.outer_shape == 'CYLINDER':
            socket_outer = add_cylinder(
                "PREVIEW_SocketOuter",
                Ro,
                Ro * 2.0,
                center,
                col,
                vertices=min(
                    max(48, settings.sphere_segments),
                    96,
                ),
            )
        else:
            socket_outer = add_box(
                "PREVIEW_SocketOuter",
                (
                    Ro * 2.0,
                    Ro * 2.0,
                    Ro * 2.0,
                ),
                center,
                col,
            )

        mark_preview_object(
            socket_outer,
            'WIRE',
        )
        created.append(
            socket_outer
        )

        if settings.preview_show_internal:
            # Inner cavity envelope
            inner = add_uv_sphere(
                "PREVIEW_InnerCavity",
                Ri,
                center,
                col,
                min(settings.sphere_segments, 40),
                min(settings.sphere_rings, 20),
            )
            mark_preview_object(
                inner,
                'WIRE',
            )
            created.append(
                inner
            )

            # Opening guide
            opening_depth = max(
                0.2,
                Ro * 1.15,
            )

            opening = add_cylinder(
                "PREVIEW_OpeningGuide",
                opening_r,
                opening_depth,
                Vector((
                    0.0,
                    0.0,
                    Ro * 0.575,
                )),
                col,
                vertices=40,
            )
            mark_preview_object(
                opening,
                'WIRE',
            )
            created.append(
                opening
            )

            # Optional motion-cut guide
            if (
                settings.make_motion_cut
                and settings.motion_angle > 0.0001
            ):
                motion = calc_motion_analysis(
                    settings
                )

                if settings.motion_cut_mode == 'FLAT':
                    if motion["needs_extra_cut"]:
                        preview_top = (
                            Ro * 1.35
                        )

                        flat_depth = max(
                            0.01,
                            preview_top
                            - motion["cut_z"],
                        )

                        flat_guide = add_box(
                            "PREVIEW_FlatCutRemoved",
                            (
                                Ro * 2.4,
                                Ro * 2.4,
                                flat_depth,
                            ),
                            Vector((
                                0.0,
                                0.0,
                                (
                                    preview_top
                                    + motion["cut_z"]
                                ) * 0.5,
                            )),
                            col,
                        )
                        mark_preview_object(
                            flat_guide,
                            'WIRE',
                        )
                        created.append(
                            flat_guide
                        )

                else:
                    depth = Ro * 1.4
                    bottom_radius = (
                        motion_swept_radius_at_height(
                            settings,
                            0.0,
                        )
                    )
                    top_radius = (
                        motion_swept_radius_at_height(
                            settings,
                            depth,
                        )
                    )

                    cone = add_cone(
                        "PREVIEW_MotionGuide",
                        bottom_radius,
                        top_radius,
                        depth,
                        Vector((
                            0.0,
                            0.0,
                            depth * 0.5,
                        )),
                        col,
                        vertices=48,
                    )
                    mark_preview_object(
                        cone,
                        'WIRE',
                    )
                    created.append(
                        cone
                    )

                # Show one extreme-position male shaft to make the requested
                # motion angle and the interference clearance visually obvious.
                if settings.make_shaft:
                    shaft_r = (
                        settings.shaft_diameter
                        * 0.5
                        + settings.motion_shaft_clearance
                    )

                    overlap = calc_ball_shaft_overlap(
                        R,
                        settings.shaft_diameter * 0.5,
                    )

                    shaft_depth = (
                        settings.shaft_length
                        + overlap
                    )

                    axial_center = (
                        R
                        + settings.shaft_length * 0.5
                        - overlap * 0.5
                    )

                    theta = settings.motion_angle

                    tilted_center = Vector((
                        axial_center * math.sin(theta),
                        0.0,
                        axial_center * math.cos(theta),
                    ))

                    tilted = add_cylinder(
                        "PREVIEW_TiltedShaftLimit",
                        shaft_r,
                        shaft_depth,
                        tilted_center,
                        col,
                        vertices=32,
                        rotation=(
                            0.0,
                            theta,
                            0.0,
                        ),
                    )
                    mark_preview_object(
                        tilted,
                        'WIRE',
                    )
                    created.append(
                        tilted
                    )

        if settings.make_socket_shaft:
            socket_shaft_r = (
                settings.socket_shaft_diameter
                * 0.5
            )

            overlap = calc_socket_shaft_overlap(
                settings.outer_shape,
                Ro,
                socket_shaft_r,
                settings.wall_thickness,
            )

            socket_shaft_depth = (
                settings.socket_shaft_length
                + overlap
            )

            socket_shaft_center = Vector((
                0.0,
                0.0,
                -Ro
                - settings.socket_shaft_length * 0.5
                + overlap * 0.5,
            ))

            ss = add_cylinder(
                "PREVIEW_SocketShaft",
                socket_shaft_r,
                socket_shaft_depth,
                socket_shaft_center,
                col,
                vertices=32,
            )
            mark_preview_object(
                ss,
                'WIRE',
            )
            created.append(
                ss
            )

        if (
            settings.make_dowels
            and settings.preview_show_dowels
        ):
            if settings.dowel_style == 'PERIMETER':
                layout = calc_perimeter_dowel_layout(
                    settings,
                    Ri,
                    Ro,
                )

                if layout["ok"]:
                    groove_width = (
                        settings.dowel_diameter
                        + settings.dowel_clearance * 2.0
                    )

                    specs = perimeter_bar_specs(
                        settings,
                        layout,
                        width=groove_width,
                        start_depth=0.0,
                        end_depth=layout["hole_depth"],
                    )

                    for idx, (dims, center_pos) in enumerate(
                        specs,
                        start=1,
                    ):
                        guide = add_box(
                            f"PREVIEW_PerimeterGroove_{idx}",
                            dims,
                            center_pos,
                            col,
                        )
                        mark_preview_object(
                            guide,
                            'WIRE',
                        )
                        created.append(
                            guide
                        )

            else:
                layout = calc_safe_dowel_layout(
                    settings,
                    Ri,
                    Ro,
                )

                if layout["ok"]:
                    center_radius = layout[
                        "center_radius"
                    ]
                    hole_depth = layout[
                        "hole_depth"
                    ]
                    hole_r = (
                        settings.dowel_diameter * 0.5
                        + settings.dowel_clearance
                    )

                    for idx, angle in enumerate(
                        dowel_angles(),
                        start=1,
                    ):
                        if settings.split_axis == 'X':
                            p = Vector((
                                0.0,
                                center_radius * math.cos(angle),
                                center_radius * math.sin(angle),
                            ))
                            c = p + Vector((
                                hole_depth * 0.5,
                                0.0,
                                0.0,
                            ))
                            rot = (
                                0.0,
                                math.radians(90.0),
                                0.0,
                            )
                        else:
                            p = Vector((
                                center_radius * math.cos(angle),
                                0.0,
                                center_radius * math.sin(angle),
                            ))
                            c = p + Vector((
                                0.0,
                                hole_depth * 0.5,
                                0.0,
                            ))
                            rot = (
                                math.radians(90.0),
                                0.0,
                                0.0,
                            )

                        guide = add_cylinder(
                            f"PREVIEW_DowelHole_{idx}",
                            hole_r,
                            hole_depth,
                            c,
                            col,
                            vertices=32,
                            rotation=rot,
                        )
                        mark_preview_object(
                            guide,
                            'WIRE',
                        )
                        created.append(
                            guide
                        )

        # Apply master scale after constructing the base-size preview,
        # exactly like final generation.
        uniform_scale_preview_objects(
            created,
            settings.global_scale,
        )

        transform_result_objects(
            created,
            get_reference_matrix(
                context,
                settings,
            ),
        )

        return created

    except Exception:
        clear_joint_preview()
        raise


def get_or_create_collection(name, parent):
    col = bpy.data.collections.get(name)

    if col is None:
        col = bpy.data.collections.new(name)

    # The datablock can exist while being unlinked from the current scene.
    if col.name not in parent.children:
        parent.children.link(
            col
        )

    return col


def create_mount_cutter(
    context,
    settings,
    *,
    name=None,
    placement_matrix=None,
    persistent=True,
):
    """
    Create the reusable cavity shape for installing the assembled socket unit.

    The cutter is the socket OUTER envelope enlarged by mount_clearance.
    Ball/ball-side shaft are intentionally excluded.

    If insertion-path mode is enabled, both the housing and the optional
    socket-side shaft are swept along local +/-Z.
    """
    R = settings.ball_diameter * 0.5
    Ri = R + settings.clearance
    Ro = Ri + settings.wall_thickness

    c = settings.mount_clearance
    mount_r = Ro + c

    if mount_r <= 0.0:
        raise RuntimeError(
            "取付クリアランス込みの外形寸法が不正です。"
        )

    if placement_matrix is None:
        placement_matrix = get_reference_matrix(
            context,
            settings,
        )

    if name is None:
        name = safe_object_name(
            "BJ_MountCutter"
        )

    result_col = get_or_create_collection(
        "BallJoint_MountCutters",
        context.scene.collection,
    )

    temp_col = new_collection(
        f"{name}_TEMP",
        context.scene.collection,
    )

    center = Vector((0.0, 0.0, 0.0))
    cutter = None

    # Keep these so insertion-path mode can sweep the shaft too.
    shaft_r = None
    shaft_depth = None
    shaft_center = None

    try:
        if settings.outer_shape == 'SPHERE':
            cutter = add_uv_sphere(
                name,
                mount_r,
                center,
                result_col,
                settings.sphere_segments,
                settings.sphere_rings,
            )
        elif settings.outer_shape == 'CYLINDER':
            cutter = add_cylinder(
                name,
                mount_r,
                mount_r * 2.0,
                center,
                result_col,
                vertices=max(
                    48,
                    settings.sphere_segments,
                ),
            )
        else:
            cutter = add_box(
                name,
                (
                    mount_r * 2.0,
                    mount_r * 2.0,
                    mount_r * 2.0,
                ),
                center,
                result_col,
            )

        # ----------------------------------------------------
        # Socket-side shaft cavity at final position
        # ----------------------------------------------------
        if (
            settings.make_socket_shaft
            and settings.mount_include_socket_shaft
        ):
            shaft_r = (
                settings.socket_shaft_diameter * 0.5
                + c
            )

            end_extra = max(
                0.05,
                c,
            )

            join_extra = max(
                0.05,
                c,
            )

            shaft_depth = (
                settings.socket_shaft_length
                + end_extra
                + join_extra
            )

            shaft_center = Vector((
                0.0,
                0.0,
                -Ro
                - settings.socket_shaft_length * 0.5
                + join_extra * 0.5
                - end_extra * 0.5,
            ))

            shaft = add_cylinder(
                f"{name}_SocketShaftPart",
                shaft_r,
                shaft_depth,
                shaft_center,
                temp_col,
                vertices=max(
                    32,
                    settings.sphere_segments,
                ),
            )

            boolean_apply(
                cutter,
                shaft,
                'UNION',
            )

            delete_object(
                shaft
            )

        # ----------------------------------------------------
        # Insertion path
        # ----------------------------------------------------
        if (
            settings.mount_make_insertion_path
            and settings.mount_path_length > 0.0
        ):
            path_len = settings.mount_path_length

            sign = (
                1.0
                if settings.mount_path_direction == 'POS_Z'
                else -1.0
            )

            sweep_eps = boolean_epsilon(
                mount_r
            )

            if settings.outer_shape == 'SPHERE':
                # First connect the start sphere to the future end sphere.
                # Give the cylinder tiny overlap at both ends; a tangent-only
                # union at z=0 can be unstable.
                path_depth = (
                    path_len
                    + sweep_eps * 2.0
                )

                path_center = Vector((
                    0.0,
                    0.0,
                    sign * path_len * 0.5,
                ))

                path = add_cylinder(
                    f"{name}_InsertionPath",
                    mount_r,
                    path_depth,
                    path_center,
                    temp_col,
                    vertices=max(
                        48,
                        settings.sphere_segments,
                    ),
                )

                boolean_apply(
                    cutter,
                    path,
                    'UNION',
                )

                delete_object(
                    path
                )

                # Only after the bridge exists, union the end sphere.
                end_center = Vector((
                    0.0,
                    0.0,
                    sign * path_len,
                ))

                end_cap = add_uv_sphere(
                    f"{name}_InsertionEndCap",
                    mount_r,
                    end_center,
                    temp_col,
                    settings.sphere_segments,
                    settings.sphere_rings,
                )

                boolean_apply(
                    cutter,
                    end_cap,
                    'UNION',
                )

                delete_object(
                    end_cap
                )

            elif settings.outer_shape == 'CYLINDER':
                # Sweeping a Z-axis cylinder along local Z simply extends it.
                path_depth = (
                    mount_r * 2.0
                    + path_len
                    + sweep_eps * 2.0
                )

                path_center = Vector((
                    0.0,
                    0.0,
                    sign * path_len * 0.5,
                ))

                path = add_cylinder(
                    f"{name}_InsertionPath",
                    mount_r,
                    path_depth,
                    path_center,
                    temp_col,
                    vertices=max(
                        48,
                        settings.sphere_segments,
                    ),
                )

                boolean_apply(
                    cutter,
                    path,
                    'UNION',
                )

                delete_object(
                    path
                )

            else:
                # Linear sweep of the cube housing.
                path_depth = (
                    mount_r * 2.0
                    + path_len
                    + sweep_eps * 2.0
                )

                path_center = Vector((
                    0.0,
                    0.0,
                    sign * path_len * 0.5,
                ))

                path = add_box(
                    f"{name}_InsertionPath",
                    (
                        mount_r * 2.0,
                        mount_r * 2.0,
                        path_depth,
                    ),
                    path_center,
                    temp_col,
                )

                boolean_apply(
                    cutter,
                    path,
                    'UNION',
                )

                delete_object(
                    path
                )

            # The whole assembled joint moves during insertion, including its
            # socket-side shaft. The old implementation swept only the housing.
            if (
                shaft_r is not None
                and shaft_depth is not None
                and shaft_center is not None
            ):
                shaft_sweep_depth = (
                    shaft_depth
                    + path_len
                    + sweep_eps * 2.0
                )

                shaft_sweep_center = (
                    shaft_center
                    + Vector((
                        0.0,
                        0.0,
                        sign * path_len * 0.5,
                    ))
                )

                shaft_sweep = add_cylinder(
                    f"{name}_SocketShaftInsertionPath",
                    shaft_r,
                    shaft_sweep_depth,
                    shaft_sweep_center,
                    temp_col,
                    vertices=max(
                        32,
                        settings.sphere_segments,
                    ),
                )

                boolean_apply(
                    cutter,
                    shaft_sweep,
                    'UNION',
                )

                delete_object(
                    shaft_sweep
                )

        uniform_scale_mesh_objects(
            [cutter],
            settings.global_scale,
        )

        cutter.matrix_world = (
            placement_matrix
            @ cutter.matrix_world
        )

        cutter["ball_joint_mount_cutter"] = True
        cutter["global_scale"] = settings.global_scale
        cutter["mount_outer_shape"] = settings.outer_shape
        cutter["mount_clearance"] = c
        cutter["mount_path_enabled"] = settings.mount_make_insertion_path
        cutter["mount_path_length"] = settings.mount_path_length
        cutter["persistent_cutter"] = bool(persistent)

        cutter.display_type = 'WIRE'
        cutter.show_in_front = True
        cutter.hide_render = True

        return cutter

    except Exception:
        delete_object(
            cutter
        )
        raise

    finally:
        remove_temp_collection(
            temp_col
        )


def apply_mount_cutter_to_target(
    target,
    cutter,
):
    if not target or target.type != 'MESH':
        raise RuntimeError("取付穴を開ける本体メッシュを指定してください。")

    if not cutter or cutter.type != 'MESH':
        raise RuntimeError("Mount Cutterメッシュを指定してください。")

    if target == cutter:
        raise RuntimeError("本体とMount Cutterは別オブジェクトにしてください。")

    boolean_apply(
        target,
        cutter,
        'DIFFERENCE',
    )


def calc_box_rise(ball_diameter, opening_diameter):
    """
    Previous box/hole problem:
    sphere initially touches a flat top plate, then moves upward.
    """
    D = ball_diameter
    d = opening_diameter

    if D <= 0:
        return 0.0

    if d >= D:
        return D * 0.5

    return (
        D - math.sqrt(
            max(0.0, D * D - d * d)
        )
    ) * 0.5


def calc_socket_lip_z(
    ball_radius,
    clearance,
    opening_radius,
):
    inner_radius = ball_radius + clearance

    if opening_radius >= inner_radius:
        return 0.0

    return math.sqrt(
        max(
            0.0,
            inner_radius * inner_radius
            - opening_radius * opening_radius,
        )
    )


def calc_socket_upward_play(
    ball_radius,
    clearance,
    opening_radius,
):
    """
    Ball center starts at socket center.
    Returns how far it can move +Z before touching
    the circular inner lip, ignoring motion-cut widening.
    """
    if opening_radius >= ball_radius:
        return float("inf")

    lip_z = calc_socket_lip_z(
        ball_radius,
        clearance,
        opening_radius,
    )

    ball_contact_z = math.sqrt(
        max(
            0.0,
            ball_radius * ball_radius
            - opening_radius * opening_radius,
        )
    )

    return max(
        0.0,
        lip_z - ball_contact_z,
    )


def motion_effective_shaft_radius(settings):
    """
    Radius of the male shaft envelope used for motion clearance.
    The shaft clearance is radial (one-sided).
    """
    shaft_r = (
        settings.shaft_diameter * 0.5
        if settings.make_shaft
        else 0.0
    )

    return max(
        0.0,
        shaft_r + settings.motion_shaft_clearance,
    )


def motion_swept_radius_at_height(
    settings,
    z,
    angle=None,
):
    """
    Radial envelope of a cylindrical male shaft swept to `angle`
    in all azimuth directions.

    For centerline tilt theta and effective shaft radius a:

        r(z) = z * tan(theta) + a / cos(theta)

    This is the exact infinite-cylinder cross-section envelope for z >= 0.
    It fixes the old cone whose radius incorrectly went to zero at the ball
    center even when the shaft itself had finite thickness.
    """
    if angle is None:
        angle = settings.motion_angle

    angle = max(
        0.0,
        min(
            math.radians(85.0),
            angle,
        ),
    )

    a = motion_effective_shaft_radius(
        settings
    )

    cos_a = max(
        1e-6,
        math.cos(angle),
    )

    return (
        max(0.0, z)
        * math.tan(angle)
        + a / cos_a
    )


def socket_base_void_radius_at_height(
    settings,
    z,
):
    """
    Radius already empty BEFORE the motion cut:
      spherical inner cavity UNION vertical opening cylinder.
    """
    R = settings.ball_diameter * 0.5
    Ri = R + settings.clearance
    opening_r = settings.opening_diameter * 0.5

    if 0.0 <= z <= Ri:
        cavity_r = math.sqrt(
            max(
                0.0,
                Ri * Ri - z * z,
            )
        )
    else:
        cavity_r = 0.0

    return max(
        opening_r,
        cavity_r,
    )


def calc_motion_analysis(
    settings,
    angle=None,
):
    """
    Shared analysis for both new motion modes.

    The base void radius decreases with height while the male-shaft sweep
    radius increases. Their first/unique crossing is:
      - FLAT mode: the horizontal cut height.
      - CONE mode: the narrowest retention-neck height.

    If the sweep remains inside the existing cavity/opening all the way to
    the socket top, no extra motion cut is needed.
    """
    R = settings.ball_diameter * 0.5
    Ri = R + settings.clearance
    Ro = Ri + settings.wall_thickness
    opening_r = settings.opening_diameter * 0.5

    if angle is None:
        angle = (
            settings.motion_angle
            if settings.make_motion_cut
            else 0.0
        )

    angle = max(
        0.0,
        min(
            math.radians(85.0),
            angle,
        ),
    )

    def diff(z):
        return (
            motion_swept_radius_at_height(
                settings,
                z,
                angle,
            )
            - socket_base_void_radius_at_height(
                settings,
                z,
            )
        )

    base_diff = diff(
        0.0
    )

    feasible = (
        base_diff <= 1e-9
    )

    # Normal opening lip height: where the spherical cavity contracts to the
    # vertical opening radius. Below this, the spherical cavity dominates.
    if opening_r < Ri:
        lip_z = math.sqrt(
            max(
                0.0,
                Ri * Ri
                - opening_r * opening_r,
            )
        )
    else:
        lip_z = 0.0

    if not feasible:
        cut_z = 0.0
        crossing = True

    elif diff(Ro) <= 0.0:
        cut_z = Ro
        crossing = False

    else:
        low = 0.0
        high = Ro

        for _ in range(64):
            mid = (
                low + high
            ) * 0.5

            if diff(mid) <= 0.0:
                low = mid
            else:
                high = mid

        cut_z = (
            low + high
        ) * 0.5
        crossing = True

    # The actual narrowest retaining neck:
    # - if the sweep crosses before the normal opening lip, the new cut/sweep
    #   itself becomes the neck;
    # - otherwise the existing opening remains the neck.
    if cut_z < lip_z:
        neck_z = cut_z
        neck_r = socket_base_void_radius_at_height(
            settings,
            cut_z,
        )
    else:
        neck_z = min(
            lip_z,
            Ro,
        )
        neck_r = opening_r

    retention_margin = (
        R - neck_r
    )

    geometric_retained = (
        retention_margin > 1e-9
    )

    safe_retained = (
        feasible
        and retention_margin
        >= settings.motion_min_retention
    )

    # Upward play until the physical ball first touches the controlling ring.
    if neck_r >= R:
        upward_play = float("inf")
    else:
        upward_play = max(
            0.0,
            neck_z
            - math.sqrt(
                max(
                    0.0,
                    R * R
                    - neck_r * neck_r,
                )
            ),
        )

    sweep_at_cut = motion_swept_radius_at_height(
        settings,
        cut_z,
        angle,
    )

    return {
        "feasible": feasible,
        "angle": angle,
        "cut_z": cut_z,
        "crossing": crossing,
        "needs_extra_cut": (
            feasible
            and cut_z < Ro - 1e-7
        ),
        "removed_height": max(
            0.0,
            Ro - cut_z,
        ),
        "shaft_sweep_radius_at_cut": sweep_at_cut,
        "base_void_radius_at_cut": socket_base_void_radius_at_height(
            settings,
            cut_z,
        ),
        "neck_z": neck_z,
        "neck_radius": neck_r,
        "retention_margin": retention_margin,
        "geometric_retained": geometric_retained,
        "safe_retained": safe_retained,
        "upward_play": upward_play,
        "lip_z": lip_z,
        "R": R,
        "Ri": Ri,
        "Ro": Ro,
        "opening_radius": opening_r,
    }


def max_safe_motion_angle(settings):
    """
    Largest centerline angle that still keeps `motion_min_retention`.
    This uses the same final geometry analysis as generation.
    """
    low = 0.0
    high = math.radians(
        85.0
    )

    base = calc_motion_analysis(
        settings,
        low,
    )

    if not base["safe_retained"]:
        return 0.0

    top = calc_motion_analysis(
        settings,
        high,
    )

    if top["safe_retained"]:
        return high

    for _ in range(56):
        mid = (
            low + high
        ) * 0.5

        result = calc_motion_analysis(
            settings,
            mid,
        )

        if result["safe_retained"]:
            low = mid
        else:
            high = mid

    return low


def motion_cut_angle(settings, inner_radius):
    """
    Backward-compatible helper retained for old callers.
    In v0.7+ the requested value is the shaft centerline angle itself;
    shaft thickness is handled as a radial sweep, not as an added angle.
    """
    if not settings.make_motion_cut:
        return 0.0

    return max(
        0.0,
        min(
            math.radians(85.0),
            settings.motion_angle,
        ),
    )


def estimated_effective_opening_radius(settings):
    """
    Radius of the controlling retention neck.
    For v0.7 motion modes this is calculated from the actual shaft sweep.
    """
    if not settings.make_motion_cut:
        return (
            settings.opening_diameter
            * 0.5
        )

    return calc_motion_analysis(
        settings
    )["neck_radius"]


def split_socket(
    source,
    split_axis,
    root_name,
    result_col,
    temp_col,
    outer_radius,
):
    """
    Robust symmetric split.

    Previous versions Booleaned L and R independently.
    On spherical hollow sockets Blender could produce:
      - R correctly
      - L as "half sphere + half cube" in one mesh

    The socket before dowels is intentionally symmetric across the split plane,
    so there is no reason to trust two independent Booleans.

    New method:
      1. Generate only the positive half (R / Front) with DIFFERENCE.
      2. Validate that NO substantial geometry exists on the wrong side.
      3. Duplicate that known-good half.
      4. Mirror the duplicate to create L / Back.
      5. Add dowels/holes afterward, so their intended asymmetry is preserved.

    This removes the unstable second split Boolean completely.
    """
    corners = [
        Vector(corner)
        for corner in source.bound_box
    ]

    min_x = min(v.x for v in corners)
    max_x = max(v.x for v in corners)
    min_y = min(v.y for v in corners)
    max_y = max(v.y for v in corners)
    min_z = min(v.z for v in corners)
    max_z = max(v.z for v in corners)

    margin = max(
        0.02,
        outer_radius * 0.01,
    )

    base_eps = max(
        0.00001,
        outer_radius * 0.00001,
    )

    retry_epsilons = (
        base_eps,
        base_eps * 5.0,
        base_eps * 20.0,
    )

    last_error = None

    def make_box(name, bmin, bmax):
        dims = (
            max(0.001, bmax.x - bmin.x),
            max(0.001, bmax.y - bmin.y),
            max(0.001, bmax.z - bmin.z),
        )

        center = (
            bmin + bmax
        ) * 0.5

        return add_box(
            name,
            dims,
            center,
            temp_col,
        )

    for attempt, eps in enumerate(
        retry_epsilons,
        start=1,
    ):
        positive = None
        negative = None
        cutter = None

        try:
            if split_axis == 'X':
                # Build only R (+X):
                # source - everything on the left through +eps.
                positive = duplicate_object(
                    source,
                    f"{root_name}_Socket_R",
                    result_col,
                )

                remove_min = Vector((
                    min_x - margin,
                    min_y - margin,
                    min_z - margin,
                ))
                remove_max = Vector((
                    +eps,
                    max_y + margin,
                    max_z + margin,
                ))

                cutter = make_box(
                    f"{root_name}_RemoveLeft_A{attempt}",
                    remove_min,
                    remove_max,
                )

            else:
                # Build only Front (+Y).
                positive = duplicate_object(
                    source,
                    f"{root_name}_Socket_Front",
                    result_col,
                )

                remove_min = Vector((
                    min_x - margin,
                    min_y - margin,
                    min_z - margin,
                ))
                remove_max = Vector((
                    max_x + margin,
                    +eps,
                    max_z + margin,
                ))

                cutter = make_box(
                    f"{root_name}_RemoveBack_A{attempt}",
                    remove_min,
                    remove_max,
                )

            boolean_apply(
                positive,
                cutter,
                'DIFFERENCE',
            )

            # Important: don't just check polygon count.
            # The exact reported corruption can still have lots of polygons.
            side_tolerance = max(
                eps * 2.0,
                outer_radius * 0.0005,
            )

            if not half_mesh_is_on_expected_side(
                positive,
                split_axis,
                True,
                side_tolerance,
            ):
                raise RuntimeError(
                    "正側半分に分割箱由来または反対側の異常ジオメトリを検出しました。"
                )

            # Create the other side by symmetry, not another Boolean.
            if split_axis == 'X':
                negative = duplicate_object(
                    positive,
                    f"{root_name}_Socket_L",
                    result_col,
                )
            else:
                negative = duplicate_object(
                    positive,
                    f"{root_name}_Socket_Back",
                    result_col,
                )

            mirror_mesh_across_axis(
                negative,
                split_axis,
            )

            if not half_mesh_is_on_expected_side(
                negative,
                split_axis,
                False,
                side_tolerance,
            ):
                raise RuntimeError(
                    "ミラー生成した負側半分の検証に失敗しました。"
                )

            # add_alignment_dowels() expects obj_a to be the negative side
            # and obj_b to be the positive side.
            return negative, positive

        except Exception as exc:
            last_error = exc

            delete_object(
                positive
            )
            delete_object(
                negative
            )

        finally:
            delete_object(
                cutter
            )

    raise RuntimeError(
        "ソケット正側の分割Booleanを3回試しましたが安定生成できませんでした。"
        f" 最終エラー: {last_error}"
    )


def calc_ball_shaft_overlap(
    ball_radius,
    shaft_radius,
):
    """
    Compute how far the ball-side shaft should penetrate into the ball.

    A fixed overlap such as 0.05 mm is not enough when ball/shaft diameter
    changes.  The shaft can technically touch the sphere only near its center
    while most of the shaft base remains outside, giving the visual/structural
    problem reported by the user.

    For normal shaft sizes, penetrate until the sphere cross-section is wider
    than the shaft base plus a small margin.  If the shaft is almost as wide
    as the ball, use a deep but bounded embed instead of demanding impossible
    full-base coverage.
    """
    if ball_radius <= 0.0:
        raise RuntimeError(
            "ボール半径が不正です。"
        )

    shaft_radius = max(
        0.0,
        shaft_radius,
    )

    tiny = boolean_epsilon(
        ball_radius
    )

    radial_margin = max(
        tiny * 4.0,
        min(
            max(0.02, shaft_radius * 0.10),
            ball_radius * 0.04,
        ),
    )

    # Full-base seating when practical.
    target_cross_radius = (
        shaft_radius
        + radial_margin
    )

    # Extremely thick stems cannot fit their whole circular base inside a
    # smaller sphere cross-section.  Still force a substantial embed.
    target_cross_radius = min(
        target_cross_radius,
        ball_radius * 0.94,
    )

    penetration = (
        ball_radius
        - math.sqrt(
            max(
                0.0,
                ball_radius * ball_radius
                - target_cross_radius * target_cross_radius,
            )
        )
    )

    minimum_embed = max(
        0.05,
        min(
            ball_radius * 0.08,
            max(0.05, shaft_radius * 0.30),
        ),
    )

    return min(
        ball_radius * 0.72,
        max(
            penetration + tiny * 2.0,
            minimum_embed,
        ),
    )


def calc_socket_shaft_overlap(
    outer_shape,
    outer_radius,
    shaft_radius,
    wall_thickness,
):
    """
    Guaranteed volumetric overlap for socket-side shaft union.
    """
    tiny = boolean_epsilon(
        outer_radius
    )

    if outer_shape in {'CUBE', 'CYLINDER'}:
        return max(
            tiny * 4.0,
            min(
                max(0.05, wall_thickness * 0.25),
                max(0.05, outer_radius * 0.25),
            ),
        )

    if shaft_radius >= outer_radius * 0.98:
        raise RuntimeError(
            "受け側の軸がソケット外径に対して太すぎます。"
            " 受け軸直径を小さくしてください。"
        )

    radial_margin = max(
        tiny * 4.0,
        min(
            wall_thickness * 0.08,
            outer_radius * 0.03,
        ),
    )

    required_cross_radius = min(
        outer_radius * 0.96,
        shaft_radius + radial_margin,
    )

    penetration = (
        outer_radius
        - math.sqrt(
            max(
                0.0,
                outer_radius * outer_radius
                - required_cross_radius * required_cross_radius,
            )
        )
    )

    return penetration + tiny * 2.0


def dowel_angles():
    return (
        math.radians(-52.0),
        math.radians(-128.0),
    )


def calc_safe_dowel_layout(
    settings,
    inner_radius,
    outer_radius,
):
    """
    Safe layout for legacy independent round dowels.

    SPHERE:
        Curved outer wall in every direction.

    CYLINDER:
        Cylinder axis is local Z. At the deepest point of a dowel hole,
        available width in the split-transverse direction shrinks according
        to the circular XY wall, while Z still has flat +/- outer_radius caps.

    CUBE:
        Flat walls in all directions.
    """
    pin_r = settings.dowel_diameter * 0.5
    margin = settings.dowel_outer_margin

    end_clear = max(
        0.20,
        settings.dowel_clearance * 1.5,
    )

    hole_depth = (
        settings.dowel_length
        + end_clear
    )

    angles = dowel_angles()

    def limits_for_pin_radius(test_pin_r):
        test_hole_r = (
            test_pin_r
            + settings.dowel_clearance
        )

        min_center_radius = (
            inner_radius
            + test_hole_r
            + margin
        )

        if settings.outer_shape == 'SPHERE':
            if hole_depth >= outer_radius:
                return None

            outer_radial_at_tip = math.sqrt(
                max(
                    0.0,
                    outer_radius * outer_radius
                    - hole_depth * hole_depth,
                )
            )

            max_center_radius = (
                outer_radial_at_tip
                - test_hole_r
                - margin
            )

            return {
                "min_center_radius": min_center_radius,
                "max_center_radius": max_center_radius,
                "outer_radial_at_tip": outer_radial_at_tip,
                "depth_ok": True,
            }

        if settings.outer_shape == 'CYLINDER':
            if hole_depth >= outer_radius:
                return None

            transverse_limit = (
                math.sqrt(
                    max(
                        0.0,
                        outer_radius * outer_radius
                        - hole_depth * hole_depth,
                    )
                )
                - test_hole_r
                - margin
            )

            z_limit = (
                outer_radius
                - test_hole_r
                - margin
            )

            if (
                transverse_limit <= 0.0
                or z_limit <= 0.0
            ):
                return None

            max_center_radius = float("inf")

            for angle in angles:
                transverse_component = abs(
                    math.cos(angle)
                )
                z_component = abs(
                    math.sin(angle)
                )

                if transverse_component > 1e-9:
                    max_center_radius = min(
                        max_center_radius,
                        transverse_limit
                        / transverse_component,
                    )

                if z_component > 1e-9:
                    max_center_radius = min(
                        max_center_radius,
                        z_limit
                        / z_component,
                    )

            return {
                "min_center_radius": min_center_radius,
                "max_center_radius": max_center_radius,
                "outer_radial_at_tip": transverse_limit,
                "depth_ok": True,
            }

        # CUBE
        if (
            hole_depth
            + margin
            >= outer_radius
        ):
            return None

        planar_limit = (
            outer_radius
            - test_hole_r
            - margin
        )

        if planar_limit <= 0.0:
            return None

        max_center_radius = float("inf")

        for angle in angles:
            c = abs(math.cos(angle))
            s = abs(math.sin(angle))

            if c > 1e-9:
                max_center_radius = min(
                    max_center_radius,
                    planar_limit / c,
                )

            if s > 1e-9:
                max_center_radius = min(
                    max_center_radius,
                    planar_limit / s,
                )

        return {
            "min_center_radius": min_center_radius,
            "max_center_radius": max_center_radius,
            "outer_radial_at_tip": planar_limit,
            "depth_ok": True,
        }

    limits = limits_for_pin_radius(
        pin_r
    )

    if limits is None:
        if settings.outer_shape == 'CUBE':
            reason = "ダボ穴が立方体外壁より深すぎます。"
        elif settings.outer_shape == 'CYLINDER':
            reason = "ダボ穴が円柱外壁を抜く可能性があります。"
        else:
            reason = "ダボ穴が球形外壁を抜く可能性があります。"

        return {
            "ok": False,
            "reason": reason,
            "max_diameter": 0.0,
            "shape_mode": settings.outer_shape,
        }

    min_center_radius = limits[
        "min_center_radius"
    ]
    max_center_radius = limits[
        "max_center_radius"
    ]

    low = 0.0
    high = max(
        0.001,
        outer_radius,
    )

    for _ in range(48):
        mid = (
            low + high
        ) * 0.5

        test = limits_for_pin_radius(
            mid
        )

        feasible = (
            test is not None
            and test["min_center_radius"]
            <= test["max_center_radius"]
        )

        if feasible:
            low = mid
        else:
            high = mid

    max_diameter = low * 2.0

    if min_center_radius > max_center_radius:
        shape_label = {
            'SPHERE': "球形",
            'CYLINDER': "円柱",
            'CUBE': "立方体",
        }.get(
            settings.outer_shape,
            "受け",
        )

        return {
            "ok": False,
            "reason": (
                f"ダボ穴が{shape_label}外壁または内側キャビティへ干渉します。"
            ),
            "max_diameter": max_diameter,
            "shape_mode": settings.outer_shape,
        }

    center_radius = (
        min_center_radius
        + max_center_radius
    ) * 0.5

    return {
        "ok": True,
        "center_radius": center_radius,
        "hole_depth": hole_depth,
        "end_clearance": end_clear,
        "max_diameter": max_diameter,
        "outer_radial_at_tip": limits[
            "outer_radial_at_tip"
        ],
        "shape_mode": settings.outer_shape,
    }


def calc_perimeter_dowel_layout(
    settings,
    inner_radius,
    outer_radius,
):
    """
    Layout for the new U-shaped perimeter alignment rib.

    The rib follows the outer wall on the split face:
      - two vertical side rails
      - one bottom rail
      - no top rail, so the ball opening/shaft area stays unobstructed

    It is supported on CYLINDER and CUBE sockets.
    """
    if settings.outer_shape == 'SPHERE':
        return {
            "ok": False,
            "reason": "外周リブ方式は円柱または立方体ソケットで使用してください。",
            "max_width": 0.0,
        }

    pin_width = settings.dowel_diameter
    clearance = settings.dowel_clearance
    margin = settings.dowel_outer_margin
    wall_offset = settings.perimeter_wall_offset

    # margin = safety minimum
    # wall_offset = intentional extra distance from the visible outside wall
    outer_keep = (
        margin
        + wall_offset
    )

    # For perimeter ribs, dowel_clearance is a literal ONE-SIDED
    # fitting clearance in every direction:
    #
    #   groove width  = rib width + 2 * clearance
    #   groove height = rib height + 2 * clearance
    #   groove depth  = rib depth + clearance
    #
    # Older builds used max(0.20, clearance * 1.5) for depth, which meant
    # changing small clearance values did not actually change the axial fit.
    end_clear = clearance

    hole_depth = (
        settings.dowel_length
        + end_clear
    )

    keepout_radius = max(
        inner_radius,
        settings.opening_diameter * 0.5,
    )

    def solve_for_width(test_width):
        groove_width = (
            test_width
            + clearance * 2.0
        )

        groove_half = groove_width * 0.5

        if settings.outer_shape == 'CYLINDER':
            if hole_depth >= outer_radius:
                return None

            transverse_outer = math.sqrt(
                max(
                    0.0,
                    outer_radius * outer_radius
                    - hole_depth * hole_depth,
                )
            )
        else:
            if (
                hole_depth
                + outer_keep
                >= outer_radius
            ):
                return None

            transverse_outer = outer_radius

        side_center = (
            transverse_outer
            - outer_keep
            - groove_half
        )

        bottom_center = (
            -outer_radius
            + outer_keep
            + groove_half
        )

        top_outer_limit = (
            outer_radius
            - outer_keep
        )

        if (
            settings.make_motion_cut
            and settings.motion_cut_mode == 'FLAT'
            and settings.motion_angle > 0.0001
        ):
            motion = calc_motion_analysis(
                settings
            )

            if (
                motion["feasible"]
                and motion["needs_extra_cut"]
            ):
                # Keep the same effective wall thickness above the rib
                # as we already keep at the side/bottom walls.
                #
                # v0.7.0-0.7.1 used only `margin` here, while side/bottom used
                # `outer_keep = margin + wall_offset`, which made the top
                # (red gap) visibly thinner than the side (blue gap).
                top_outer_limit = min(
                    top_outer_limit,
                    motion["cut_z"]
                    - outer_keep,
                )

        top_center = (
            top_outer_limit
            - groove_half
        )

        if (
            side_center <= 0.0
            or bottom_center >= 0.0
            or top_center <= bottom_center
        ):
            return None

        # Side rails must remain outside the spherical cavity/opening.
        side_inner_edge = (
            side_center
            - groove_half
        )

        # Bottom rail must remain below the spherical cavity.
        bottom_inner_edge = (
            abs(bottom_center)
            - groove_half
        )

        required_inner_clear = (
            keepout_radius
            + margin
        )

        if (
            side_inner_edge < required_inner_clear
            or bottom_inner_edge < (
                inner_radius + margin
            )
        ):
            return None

        return {
            "side_center": side_center,
            "bottom_center": bottom_center,
            "top_center": top_center,
            "hole_depth": hole_depth,
            "end_clearance": end_clear,
            "groove_width": groove_width,
            "transverse_outer_at_depth": transverse_outer,
            "outer_keep": outer_keep,
            "wall_offset": wall_offset,
            "fit_clearance": clearance,
            "axial_end_clearance": end_clear,
            "flat_top_keep": outer_keep,
        }

    current = solve_for_width(
        pin_width
    )

    low = 0.0
    high = max(
        0.001,
        settings.wall_thickness * 2.0,
        outer_radius,
    )

    for _ in range(48):
        mid = (
            low + high
        ) * 0.5

        if solve_for_width(mid) is not None:
            low = mid
        else:
            high = mid

    max_width = low

    if current is None:
        return {
            "ok": False,
            "reason": (
                "外周リブを配置できる肉厚がありません。"
                " リブ幅/長さ/外壁最低残しを小さくするか、ソケット肉厚を増やしてください。"
            ),
            "max_width": max_width,
            "outer_keep": outer_keep,
            "wall_offset": wall_offset,
            "fit_clearance": clearance,
            "axial_end_clearance": end_clear,
        }

    current.update({
        "ok": True,
        "max_width": max_width,
        "outer_keep": outer_keep,
        "wall_offset": wall_offset,
        "fit_clearance": clearance,
        "axial_end_clearance": end_clear,
        "flat_top_keep": outer_keep,
    })

    return current


def perimeter_bar_specs(
    settings,
    layout,
    *,
    width,
    start_depth,
    end_depth,
):
    """
    Return three box specs forming a U-shape on the split face.
    start_depth/end_depth are coordinates along +split axis.
    """
    side = layout["side_center"]
    bottom = layout["bottom_center"]
    top = layout["top_center"]

    axial_depth = (
        end_depth - start_depth
    )

    if axial_depth <= 0.0:
        raise RuntimeError(
            "外周リブの押し出し深さが不正です。"
        )

    axial_center = (
        start_depth + end_depth
    ) * 0.5

    side_height = (
        top - bottom + width
    )

    bottom_length = (
        side * 2.0 + width
    )

    specs = []

    if settings.split_axis == 'X':
        for y in (-side, side):
            specs.append((
                (
                    axial_depth,
                    width,
                    side_height,
                ),
                Vector((
                    axial_center,
                    y,
                    (top + bottom) * 0.5,
                )),
            ))

        specs.append((
            (
                axial_depth,
                bottom_length,
                width,
            ),
            Vector((
                axial_center,
                0.0,
                bottom,
            )),
        ))

    else:
        for x in (-side, side):
            specs.append((
                (
                    width,
                    axial_depth,
                    side_height,
                ),
                Vector((
                    x,
                    axial_center,
                    (top + bottom) * 0.5,
                )),
            ))

        specs.append((
            (
                bottom_length,
                axial_depth,
                width,
            ),
            Vector((
                0.0,
                axial_center,
                bottom,
            )),
        ))

    return specs


def add_perimeter_dowel(
    obj_a,
    obj_b,
    settings,
    root_name,
    temp_col,
    inner_radius,
    outer_radius,
):
    layout = calc_perimeter_dowel_layout(
        settings,
        inner_radius,
        outer_radius,
    )

    if not layout["ok"]:
        raise RuntimeError(
            layout["reason"]
        )

    pin_width = settings.dowel_diameter
    pin_len = settings.dowel_length
    pin_clear = settings.dowel_clearance

    embed = min(
        settings.wall_thickness * 0.35,
        pin_len * 0.45,
    )

    split_overlap = min(
        0.05,
        max(
            0.01,
            pin_len * 0.04,
        ),
    )

    # Male U-rib: embedded slightly into negative half, protrudes into positive.
    peg_specs = perimeter_bar_specs(
        settings,
        layout,
        width=pin_width,
        start_depth=-embed,
        end_depth=pin_len,
    )

    # Female U-groove: wider by clearance, blind into positive half.
    groove_width = (
        pin_width + pin_clear * 2.0
    )

    groove_specs = perimeter_bar_specs(
        settings,
        layout,
        width=groove_width,
        start_depth=-split_overlap,
        end_depth=layout["hole_depth"],
    )

    for idx, (dims, center) in enumerate(
        peg_specs,
        start=1,
    ):
        peg = add_box(
            f"{root_name}_PerimeterDowel_{idx}",
            dims,
            center,
            temp_col,
        )

        try:
            boolean_apply(
                obj_a,
                peg,
                'UNION',
            )
        finally:
            delete_object(
                peg
            )

    for idx, (dims, center) in enumerate(
        groove_specs,
        start=1,
    ):
        groove = add_box(
            f"{root_name}_PerimeterGroove_{idx}",
            dims,
            center,
            temp_col,
        )

        try:
            boolean_apply(
                obj_b,
                groove,
                'DIFFERENCE',
            )
        finally:
            delete_object(
                groove
            )


def add_alignment_dowels(
    obj_a,
    obj_b,
    settings,
    root_name,
    temp_col,
    inner_radius,
    outer_radius,
):
    if not settings.make_dowels:
        return

    if settings.dowel_style == 'PERIMETER':
        add_perimeter_dowel(
            obj_a,
            obj_b,
            settings,
            root_name,
            temp_col,
            inner_radius,
            outer_radius,
        )
        return

    layout = calc_safe_dowel_layout(
        settings,
        inner_radius,
        outer_radius,
    )

    if not layout["ok"]:
        raise RuntimeError(
            layout["reason"]
        )

    pin_r = settings.dowel_diameter * 0.5
    pin_len = settings.dowel_length
    pin_clear = settings.dowel_clearance

    center_radius = layout["center_radius"]
    hole_depth = layout["hole_depth"]

    # Keep dowels in lower solid area,
    # away from the motion opening.
    angles = dowel_angles()

    # Peg is embedded a little into part A and sticks into part B.
    embed = min(
        settings.wall_thickness * 0.35,
        pin_len * 0.45,
    )

    # Boolean cutters starting exactly on a coplanar split face can be flaky.
    # Give them a tiny overlap across the split plane.
    split_overlap = min(
        0.05,
        max(
            0.01,
            pin_len * 0.04,
        ),
    )

    for idx, angle in enumerate(
        angles,
        start=1,
    ):
        if settings.split_axis == 'X':
            p = Vector((
                0.0,
                center_radius * math.cos(angle),
                center_radius * math.sin(angle),
            ))

            peg_center = p + Vector((
                (pin_len - embed) * 0.5,
                0.0,
                0.0,
            ))

            # Blind hole only extends into +X mating half.
            hole_center = p + Vector((
                (hole_depth - split_overlap) * 0.5,
                0.0,
                0.0,
            ))

            rotation = (
                0.0,
                math.radians(90.0),
                0.0,
            )

        else:
            p = Vector((
                center_radius * math.cos(angle),
                0.0,
                center_radius * math.sin(angle),
            ))

            peg_center = p + Vector((
                0.0,
                (pin_len - embed) * 0.5,
                0.0,
            ))

            # Blind hole only extends into +Y mating half.
            hole_center = p + Vector((
                0.0,
                (hole_depth - split_overlap) * 0.5,
                0.0,
            ))

            rotation = (
                math.radians(90.0),
                0.0,
                0.0,
            )

        peg = add_cylinder(
            f"{root_name}_Dowel_{idx}",
            pin_r,
            pin_len + embed,
            peg_center,
            temp_col,
            vertices=48,
            rotation=rotation,
        )

        boolean_apply(
            obj_a,
            peg,
            'UNION',
        )
        delete_object(peg)

        hole = add_cylinder(
            f"{root_name}_DowelHole_{idx}",
            pin_r + pin_clear,
            hole_depth + split_overlap,
            hole_center,
            temp_col,
            vertices=48,
            rotation=rotation,
        )

        boolean_apply(
            obj_b,
            hole,
            'DIFFERENCE',
        )
        delete_object(hole)


# ============================================================
# Settings
# ============================================================

# ============================================================
# C. Body Receiver / 本体そのものを受け側にする
# ============================================================

BODY_RECEIVER_PREVIEW_COLLECTION = "BallJoint_BodyReceiverPreview"


def body_receiver_cut_depth(settings):
    """Local +Z cutter reach used by C mode.

    0 = automatic.  C mode has no socket outer shell, so the old socket
    wall thickness / outer radius cannot define the top of the opening.
    Use a local cutter reach based on the cavity and male shaft instead.
    """
    manual = max(0.0, float(settings.body_receiver_cut_depth))
    if manual > 1e-9:
        return manual

    R = settings.ball_diameter * 0.5
    Ri = R + settings.clearance
    shaft_part = settings.shaft_length if settings.make_shaft else 0.0

    return max(
        Ri * 2.8,
        Ri + shaft_part,
        settings.opening_diameter * 1.5,
        1.0,
    )


def calc_body_receiver_flat_cut(settings, cut_depth=None):
    """C-mode FLAT motion boundary without socket wall_thickness.

    The existing base void is sphere UNION vertical opening.  We search only
    inside the local receiver cutter depth.  Unlike the normal socket, C mode
    never uses outer_shape or wall_thickness.
    """
    if cut_depth is None:
        cut_depth = body_receiver_cut_depth(settings)

    cut_depth = max(1e-6, float(cut_depth))

    def diff(z):
        return (
            motion_swept_radius_at_height(settings, z)
            - socket_base_void_radius_at_height(settings, z)
        )

    if diff(0.0) > 1e-9:
        return {
            'feasible': False,
            'needs_extra_cut': True,
            'cut_z': 0.0,
        }

    if diff(cut_depth) <= 0.0:
        return {
            'feasible': True,
            'needs_extra_cut': False,
            'cut_z': cut_depth,
        }

    lo = 0.0
    hi = cut_depth

    for _ in range(64):
        mid = (lo + hi) * 0.5
        if diff(mid) <= 0.0:
            lo = mid
        else:
            hi = mid

    return {
        'feasible': True,
        'needs_extra_cut': True,
        'cut_z': (lo + hi) * 0.5,
    }


def get_body_receiver_plane(context, settings):
    """Return (plane_co_world, normal_world, u_world, v_world)."""
    placement = get_reference_matrix(context, settings)

    joint_x = Vector(placement.col[0].xyz).normalized()
    joint_y = Vector(placement.col[1].xyz).normalized()
    joint_z = Vector(placement.col[2].xyz).normalized()

    axis = settings.body_receiver_plane_axis

    if axis == 'LOCAL_X':
        normal = joint_x
    elif axis == 'LOCAL_Y':
        normal = joint_y
    elif axis == 'LOCAL_Z':
        normal = joint_z
    elif axis == 'WORLD_X':
        normal = Vector((1.0, 0.0, 0.0))
    elif axis == 'WORLD_Y':
        normal = Vector((0.0, 1.0, 0.0))
    else:
        normal = Vector((0.0, 0.0, 1.0))

    normal.normalize()

    plane_co = (
        placement.translation
        + normal
        * settings.body_receiver_plane_offset
        * settings.global_scale
    )

    # Stable axis inside the plane. Prefer something related to joint Z so
    # dowel left/right feels consistent when the guide is rotated.
    u = normal.cross(joint_z)
    if u.length < 1e-7:
        u = normal.cross(joint_x)
    if u.length < 1e-7:
        u = normal.cross(Vector((0.0, 1.0, 0.0)))
    if u.length < 1e-7:
        u = normal.cross(Vector((1.0, 0.0, 0.0)))

    u.normalize()
    v = normal.cross(u)

    if v.length < 1e-7:
        raise RuntimeError('C取付のBisect面内方向を計算できません。')

    v.normalize()
    return plane_co, normal, u, v


def body_receiver_oriented_matrix(location, z_axis, x_hint=None):
    z = Vector(z_axis).normalized()

    if x_hint is None:
        x_hint = Vector((1.0, 0.0, 0.0))

    x = Vector(x_hint)
    x = x - z * x.dot(z)

    if x.length < 1e-7:
        x = Vector((0.0, 1.0, 0.0))
        x = x - z * x.dot(z)

    x.normalize()
    y = z.cross(x).normalized()
    x = y.cross(z).normalized()

    return Matrix((
        (x.x, y.x, z.x, location.x),
        (x.y, y.y, z.y, location.y),
        (x.z, y.z, z.z, location.z),
        (0.0, 0.0, 0.0, 1.0),
    ))


def add_body_receiver_oriented_cylinder(
    name,
    radius,
    depth,
    location,
    axis,
    collection,
    vertices=48,
    x_hint=None,
):
    obj = add_cylinder(
        name,
        radius,
        depth,
        Vector((0.0, 0.0, 0.0)),
        collection,
        vertices=vertices,
    )
    obj.matrix_world = body_receiver_oriented_matrix(
        Vector(location),
        Vector(axis),
        x_hint,
    )
    return obj


def bake_evaluated_body_copy(context, source, name, collection):
    """Bake final evaluated appearance once; original object is untouched."""
    if source is None or source.type != 'MESH':
        raise RuntimeError('C. 本体受けの本体にはメッシュを指定してください。')

    depsgraph = context.evaluated_depsgraph_get()
    evaluated = source.evaluated_get(depsgraph)

    mesh = bpy.data.meshes.new_from_object(
        evaluated,
        preserve_all_data_layers=True,
        depsgraph=depsgraph,
    )

    if mesh is None or len(mesh.vertices) < 3:
        if mesh is not None:
            bpy.data.meshes.remove(mesh)
        raise RuntimeError('評価済み本体メッシュを作成できませんでした。')

    obj = bpy.data.objects.new(name, mesh)
    collection.objects.link(obj)
    obj.matrix_world = source.matrix_world.copy()
    obj['body_receiver_source'] = source.name
    obj['body_receiver_evaluated_copy'] = True
    return obj


def bisect_body_receiver_object(obj, plane_co_world, plane_no_world, keep_positive):
    """Bisect a mesh and cap the cut surface."""
    if obj is None or obj.type != 'MESH':
        raise RuntimeError('Bisect対象がメッシュではありません。')

    inv = obj.matrix_world.inverted()
    plane_co_local = inv @ Vector(plane_co_world)
    plane_no_local = (
        obj.matrix_world.to_3x3().transposed()
        @ Vector(plane_no_world)
    )

    if plane_no_local.length < 1e-9:
        raise RuntimeError('Bisect面の法線変換に失敗しました。')

    plane_no_local.normalize()
    bm = bmesh.new()

    try:
        bm.from_mesh(obj.data)
        geom = list(bm.verts) + list(bm.edges) + list(bm.faces)

        result = bmesh.ops.bisect_plane(
            bm,
            geom=geom,
            dist=1e-6,
            plane_co=plane_co_local,
            plane_no=plane_no_local,
            use_snap_center=False,
            clear_inner=bool(keep_positive),
            clear_outer=not bool(keep_positive),
        )

        cut_edges = [
            elem
            for elem in result.get('geom_cut', [])
            if (
                isinstance(elem, bmesh.types.BMEdge)
                and elem.is_valid
                and elem.is_boundary
            )
        ]

        if cut_edges:
            try:
                bmesh.ops.holes_fill(
                    bm,
                    edges=cut_edges,
                    sides=0,
                )
            except Exception:
                # Multiple disconnected intersections: fill loop-by-loop.
                pending = {e for e in cut_edges if e.is_valid}
                while pending:
                    seed = pending.pop()
                    island = {seed}
                    stack = [seed]
                    while stack:
                        edge = stack.pop()
                        for vert in edge.verts:
                            for other in vert.link_edges:
                                if other in pending and other.is_boundary:
                                    pending.remove(other)
                                    island.add(other)
                                    stack.append(other)
                    try:
                        bmesh.ops.holes_fill(
                            bm,
                            edges=list(island),
                            sides=0,
                        )
                    except Exception:
                        pass

        bm.normal_update()
        bm.to_mesh(obj.data)
        obj.data.update()

    finally:
        bm.free()


def create_body_receiver_void(context, settings, name, collection):
    """Create only the EMPTY volume cut directly from the body.

    No socket outer shape, no socket wall, no socket-side shaft.
    The specified body itself becomes the receiver wall.
    """
    R = settings.ball_diameter * 0.5
    Ri = R + settings.clearance
    opening_r = settings.opening_diameter * 0.5
    cut_depth = body_receiver_cut_depth(settings)

    if opening_r >= Ri:
        raise RuntimeError('C取付: 開口直径はボールキャビティ内径より小さくしてください。')

    cutter = None

    try:
        cutter = add_uv_sphere(
            name,
            Ri,
            Vector((0.0, 0.0, 0.0)),
            collection,
            settings.sphere_segments,
            settings.sphere_rings,
        )

        eps = boolean_epsilon(max(Ri, cut_depth))

        # Opening goes only toward local +Z from ball center.
        opening = add_cylinder(
            f'{name}_Opening_TEMP',
            opening_r,
            cut_depth + eps * 2.0,
            Vector((0.0, 0.0, cut_depth * 0.5)),
            collection,
            vertices=max(48, settings.sphere_segments),
        )

        try:
            boolean_apply(cutter, opening, 'UNION')
        finally:
            delete_object(opening)

        if settings.make_motion_cut and settings.motion_angle > 0.0001:
            if settings.motion_cut_mode == 'FLAT':
                flat = calc_body_receiver_flat_cut(settings, cut_depth)
                if not flat['feasible']:
                    raise RuntimeError('C取付: 現在の軸径/開口径では可動域切り欠きが成立しません。')

                if flat['needs_extra_cut']:
                    cut_z = flat['cut_z']
                    top_r = motion_swept_radius_at_height(settings, cut_depth)
                    local_half = max(
                        Ri * 1.35,
                        top_r + settings.motion_shaft_clearance,
                        opening_r * 1.35,
                    )
                    box_depth = max(eps * 2.0, cut_depth - cut_z + eps)
                    motion_part = add_box(
                        f'{name}_FlatMotion_TEMP',
                        (local_half * 2.0, local_half * 2.0, box_depth),
                        Vector((0.0, 0.0, (cut_depth + cut_z) * 0.5)),
                        collection,
                    )
                    try:
                        boolean_apply(cutter, motion_part, 'UNION')
                    finally:
                        delete_object(motion_part)

            else:
                r1 = motion_swept_radius_at_height(settings, 0.0)
                r2 = motion_swept_radius_at_height(settings, cut_depth)
                motion_part = add_cone(
                    f'{name}_ConeMotion_TEMP',
                    r1,
                    r2,
                    cut_depth + eps * 2.0,
                    Vector((0.0, 0.0, cut_depth * 0.5)),
                    collection,
                    vertices=max(64, settings.sphere_segments),
                )
                try:
                    boolean_apply(cutter, motion_part, 'UNION')
                finally:
                    delete_object(motion_part)

        uniform_scale_mesh_objects([cutter], settings.global_scale)
        cutter.matrix_world = get_reference_matrix(context, settings) @ cutter.matrix_world
        cutter['body_receiver_void'] = True
        return cutter

    except Exception:
        delete_object(cutter)
        raise


def create_body_receiver_ball(context, settings, name, collection):
    """Create male Ball (+shaft) only. Never Bisected in C mode."""
    R = settings.ball_diameter * 0.5
    shaft_r = settings.shaft_diameter * 0.5

    temp_col = new_collection(f'{name}_TEMP', context.scene.collection)
    ball = None

    try:
        ball = add_uv_sphere(
            name,
            R,
            Vector((0.0, 0.0, 0.0)),
            collection,
            settings.sphere_segments,
            settings.sphere_rings,
        )

        if settings.make_shaft:
            overlap = calc_ball_shaft_overlap(R, shaft_r)
            shaft_depth = settings.shaft_length + overlap
            shaft_center = Vector((
                0.0,
                0.0,
                R + settings.shaft_length * 0.5 - overlap * 0.5,
            ))
            shaft = add_cylinder(
                f'{name}_Shaft_TEMP',
                shaft_r,
                shaft_depth,
                shaft_center,
                temp_col,
                vertices=max(32, settings.sphere_segments),
            )
            try:
                boolean_apply(ball, shaft, 'UNION')
            finally:
                delete_object(shaft)

        uniform_scale_mesh_objects([ball], settings.global_scale)
        ball.matrix_world = get_reference_matrix(context, settings) @ ball.matrix_world
        ball['ball_joint_generated'] = True
        ball['part_type'] = 'BALL'
        ball['body_receiver_ball_uncut'] = True
        return ball

    except Exception:
        delete_object(ball)
        raise

    finally:
        remove_temp_collection(temp_col)


def body_receiver_dowel_layout(context, settings):
    plane_co, normal, u, v = get_body_receiver_plane(context, settings)

    Ri = (
        settings.ball_diameter * 0.5
        + settings.clearance
    ) * settings.global_scale

    pin_r = settings.dowel_diameter * 0.5 * settings.global_scale
    margin = settings.dowel_outer_margin * settings.global_scale

    # C mode has no socket outer radius.  Start outside the cavity itself and
    # keep the requested extra material between cavity and dowel.
    safe_radius = Ri + pin_r + margin

    requested = settings.body_receiver_dowel_spacing * settings.global_scale

    if requested <= 1e-9:
        spacing = safe_radius * 2.0
    else:
        spacing = requested
        if spacing * 0.5 < safe_radius:
            raise RuntimeError(
                'C取付: ダボ中心間隔が球キャビティに近すぎます。'
                f' 最低約 {safe_radius * 2.0:.3f} 必要です。'
            )

    base = (
        plane_co
        + v * settings.body_receiver_dowel_v_offset * settings.global_scale
    )

    return (
        [
            base - u * (spacing * 0.5),
            base + u * (spacing * 0.5),
        ],
        plane_co,
        normal,
        u,
        v,
        spacing,
    )


def add_body_receiver_dowels(context, part_a, part_b, settings, temp_col):
    if not settings.body_receiver_make_dowels:
        return []

    points, plane_co, normal, u, v, spacing = body_receiver_dowel_layout(
        context,
        settings,
    )

    pin_r = settings.dowel_diameter * 0.5 * settings.global_scale
    pin_len = settings.dowel_length * settings.global_scale
    clearance = settings.dowel_clearance * settings.global_scale

    if pin_r <= 0.0 or pin_len <= 0.0:
        raise RuntimeError('C取付: ダボ寸法が不正です。')

    # A keeps positive unless flip is on.  Peg goes from A toward B.
    a_positive = not settings.body_receiver_flip
    peg_dir = -normal if a_positive else normal

    embed = min(
        pin_len * 0.45,
        max(0.05 * settings.global_scale, pin_r * 0.8),
    )
    overlap = max(0.01 * settings.global_scale, min(pin_len * 0.05, 0.05 * settings.global_scale))

    for index, point in enumerate(points, start=1):
        total_peg_depth = pin_len + embed
        peg_center = point + peg_dir * ((pin_len - embed) * 0.5)

        peg = add_body_receiver_oriented_cylinder(
            f'BodyReceiver_DowelPeg_{index}',
            pin_r,
            total_peg_depth,
            peg_center,
            peg_dir,
            temp_col,
            vertices=max(32, settings.sphere_segments // 2),
            x_hint=u,
        )
        try:
            boolean_apply(part_a, peg, 'UNION')
        finally:
            delete_object(peg)

        hole_depth = pin_len + clearance + overlap
        hole_center = point + peg_dir * ((hole_depth - overlap) * 0.5)
        hole = add_body_receiver_oriented_cylinder(
            f'BodyReceiver_DowelHole_{index}',
            pin_r + clearance,
            hole_depth,
            hole_center,
            peg_dir,
            temp_col,
            vertices=max(32, settings.sphere_segments // 2),
            x_hint=u,
        )
        try:
            boolean_apply(part_b, hole, 'DIFFERENCE')
        finally:
            delete_object(hole)

    return [p.copy() for p in points]


def clear_body_receiver_preview():
    collections=getattr(getattr(bpy,'data',None),'collections',None)
    if collections is None: return
    col = collections.get(BODY_RECEIVER_PREVIEW_COLLECTION)
    if col is not None:
        remove_collection_tree(col)


def create_body_receiver_preview(context, settings):
    """Light preview: no target duplication, no Boolean."""
    is_split = settings.body_receiver_show_split_guides
    target = (settings.body_receiver_split_target if is_split
              else settings.mount_target)
    if target is None or target.type != 'MESH':
        raise RuntimeError('C取付プレビュー: 対象本体を指定してください。')

    clear_body_receiver_preview()
    col = new_collection(BODY_RECEIVER_PREVIEW_COLLECTION, context.scene.collection)

    if settings.body_receiver_show_split_guides:
        plane_co, normal, u, v = get_body_receiver_plane(context, settings)

    dims = target.dimensions
    size = max(
        dims.x,
        dims.y,
        dims.z,
        (settings.ball_diameter + settings.clearance * 2.0) * settings.global_scale * 2.5,
        1.0,
    ) * 1.15

    if settings.body_receiver_show_split_guides:
        plane = add_box(
            'BodyReceiver_Preview_BisectPlane',
            (size, size, max(0.01, size * 0.003)),
            Vector((0.0, 0.0, 0.0)),
            col,
        )
        plane.matrix_world = body_receiver_oriented_matrix(plane_co, normal, u)
        plane.display_type = 'WIRE'
        plane.show_in_front = True
        plane.hide_render = True

    if not is_split:
        placement = get_reference_matrix(context, settings)
        R = settings.ball_diameter * 0.5 * settings.global_scale
        Ri = (settings.ball_diameter * 0.5 + settings.clearance) * settings.global_scale

        ball = add_uv_sphere(
            'BodyReceiver_Preview_Ball',
            R,
            Vector((0.0, 0.0, 0.0)),
            col,
            max(24, settings.sphere_segments // 2),
            max(12, settings.sphere_rings // 2),
        )
        ball.matrix_world = placement @ ball.matrix_world
        ball.display_type = 'WIRE'
        ball.show_in_front = True
        ball.hide_render = True

        cavity = add_uv_sphere(
            'BodyReceiver_Preview_Cavity',
            Ri,
            Vector((0.0, 0.0, 0.0)),
            col,
            max(24, settings.sphere_segments // 2),
            max(12, settings.sphere_rings // 2),
        )
        cavity.matrix_world = placement @ cavity.matrix_world
        cavity.display_type = 'WIRE'
        cavity.show_in_front = True
        cavity.hide_render = True

    if settings.body_receiver_show_split_guides and settings.body_receiver_make_dowels:
        points, _, _, _, _, _ = body_receiver_dowel_layout(context, settings)
        pin_r = settings.dowel_diameter * 0.5 * settings.global_scale
        pin_len = max(0.01, settings.dowel_length * settings.global_scale)

        for index, point in enumerate(points, start=1):
            guide = add_body_receiver_oriented_cylinder(
                f'BodyReceiver_Preview_Dowel_{index}',
                pin_r,
                pin_len,
                point,
                normal,
                col,
                vertices=24,
                x_hint=u,
            )
            guide.display_type = 'WIRE'
            guide.show_in_front = True
            guide.hide_render = True

    return col


def body_receiver_check_closed(obj, label):
    """Refuse broken split results instead of silently reporting success."""
    if not mesh_result_looks_valid(obj):
        raise RuntimeError(f'{label}: 出力メッシュが空または寸法不正です。')
    bad = count_nonmanifold_edges(obj)
    if bad != 0:
        raise RuntimeError(
            f'{label}: 非マニフォールド辺が {bad} 件あります。'
            ' 切断面/空洞に不要な面が残った可能性があるため中断しました。'
        )


def create_body_receiver_halfspace(target, plane_co, normal, u, v,
                                   keep_positive, collection, name):
    """Finite closed half-space box containing the entire target half.

    Using BOOLEAN INTERSECT avoids the nested-loop holes_fill caps that could
    erroneously close the ball cavity when bisecting a hollow receiver.
    """
    corners = [target.matrix_world @ Vector(co) for co in target.bound_box]
    if not corners:
        raise RuntimeError('分割対象の境界を取得できませんでした。')
    rel = [p - plane_co for p in corners]
    margin = max(0.01, max(target.dimensions) * 0.1)
    half_x = max(abs(q.dot(u)) for q in rel) + margin
    half_y = max(abs(q.dot(v)) for q in rel) + margin
    # Start at the actual plane, not beyond it: A/B must meet at one seam.
    side_depth = max(abs(q.dot(normal)) for q in rel) + margin
    direction = 1.0 if keep_positive else -1.0
    center = plane_co + normal * (direction * side_depth * 0.5)
    box = add_box(
        name,
        (half_x * 2.0, half_y * 2.0, side_depth),
        Vector((0.0, 0.0, 0.0)),
        collection,
    )
    box.matrix_world = body_receiver_oriented_matrix(center, normal, u)
    return box


def body_receiver_check_half_side(obj, plane_co, normal, keep_positive):
    """Catch a Boolean result that retained geometry on the wrong side."""
    inv = obj.matrix_world
    tol = max(0.0001, max(obj.dimensions) * 0.0001)
    distances = [
        (inv @ vert.co - plane_co).dot(normal)
        for vert in obj.data.vertices
    ]
    if not distances:
        raise RuntimeError('分割結果に頂点がありません。')
    if keep_positive and min(distances) < -tol:
        raise RuntimeError('A/B分割に失敗：正側に負側の頂点が残っています。')
    if not keep_positive and max(distances) > tol:
        raise RuntimeError('A/B分割に失敗：負側に正側の頂点が残っています。')


def body_receiver_check_cavity_seam(obj, source, plane_co, normal):
    """Reject an accidental cap across the known spherical receiver cavity.

    A bisect + naive holes_fill can cover an inner ring with a giant polygon,
    leaving the original face over the ball cavity.  Exact INTERSECT generally
    avoids that topology, but check the cavity center on the seam explicitly.
    Only applies to receivers generated by this addon (metadata must exist).
    """
    center_value = source.get('body_receiver_cavity_center')
    radius = float(source.get('body_receiver_cavity_radius', 0.0))
    if center_value is None or radius <= 0.0:
        return
    center = Vector(center_value)
    signed = (center - plane_co).dot(normal)
    if abs(signed) >= radius * 0.8:
        # If the plane is close to the spherical rim there is no reliable
        # central opening to check; topological validation still runs.
        return
    seam_center = center - normal * signed
    eps = max(1e-4, radius * 0.002)
    inv = obj.matrix_world.inverted()
    origin_local = inv @ (seam_center - normal * (eps * 5.0))
    local_step = inv.to_3x3() @ (normal * (eps * 10.0))
    length = local_step.length
    if length <= 1e-12:
        raise RuntimeError('空洞の分割面検査: 座標変換が不正です。')
    hit, location, _, _ = obj.ray_cast(
        origin_local, local_step / length, distance=length,
    )
    if hit:
        world_hit = obj.matrix_world @ location
        if (world_hit - seam_center).length < eps * 4.0:
            raise RuntimeError(
                f'{obj.name}: 球キャビティ中心の分割面に不要な蓋状ポリゴンを検出しました。'
                ' 元の受けを残して分割を中止します。'
            )


def generate_body_receiver_mount(context, settings):
    """Create a complete, UNSPLIT body receiver and a separate ball.

    All cavity Booleans run on a single baked copy of the source.  Splitting
    happens only when the separate split operator is explicitly invoked.
    """
    target = settings.mount_target
    if target is None or target.type != 'MESH':
        raise RuntimeError('C取付: 本体メッシュを指定してください。')
    if settings.placement_mode == 'GUIDE' and not settings.guide_object:
        raise RuntimeError('C取付: 仮原点オブジェクトが指定されていません。')

    Ri = settings.ball_diameter * 0.5 + settings.clearance
    if settings.opening_diameter * 0.5 >= Ri:
        raise RuntimeError('C取付: 開口直径がキャビティ内径以上です。')
    if (settings.make_shaft and not settings.make_motion_cut
            and settings.shaft_diameter >= settings.opening_diameter):
        raise RuntimeError('C取付: ボール軸直径が開口径以上です。')
    if settings.make_motion_cut and settings.motion_angle > 0.0001:
        flat = calc_body_receiver_flat_cut(settings)
        if settings.motion_cut_mode == 'FLAT' and not flat['feasible']:
            raise RuntimeError('C取付: 可動域の自動フラット加工が成立しません。')

    root_name = safe_collection_name('BallJoint_BodyReceiver')
    result_col = new_collection(root_name, context.scene.collection)
    temp_col = new_collection(f'{root_name}_TEMP', result_col)
    try:
        receiver = bake_evaluated_body_copy(
            context, target, f'{target.name}_BodyReceiver', result_col,
        )
        polygon_count = len(receiver.data.polygons)
        void = create_body_receiver_void(
            context, settings, f'{root_name}_Void_TEMP', temp_col,
        )
        try:
            boolean_apply(receiver, void, 'DIFFERENCE')
        finally:
            delete_object(void)

        if not mesh_result_looks_valid(receiver):
            raise RuntimeError('本体受け生成後のメッシュが不正です。')

        ball = create_body_receiver_ball(
            context, settings, f'{root_name}_Ball', result_col,
        )
        for obj, part_type in ((receiver, 'BODY_RECEIVER'), (ball, 'BALL')):
            obj['ball_joint_generated'] = True
            obj['ball_joint_group'] = root_name
            obj['part_type'] = part_type
            obj['body_receiver_mode'] = True
            obj['body_receiver_source'] = target.name
            obj['global_scale'] = settings.global_scale
        # Store the cavity's reference so a later split can detect suspicious
        # seam closures even if the 3D cursor has moved.
        origin = get_reference_matrix(context, settings).translation
        receiver['body_receiver_cavity_center'] = tuple(origin)
        receiver['body_receiver_cavity_radius'] = Ri * settings.global_scale

        warnings = []
        for obj in (receiver, ball):
            bad = count_nonmanifold_edges(obj)
            obj['nonmanifold_edge_count'] = bad
            if bad != 0:
                warnings.append(f'{obj.name}: {bad}')
        remove_temp_collection(temp_col)
        settings.body_receiver_split_target = receiver
        if settings.body_receiver_hide_source:
            target.hide_set(True)
        set_active(receiver)
        return dict(receiver=receiver, ball=ball,
                    polygon_count=polygon_count, warnings=warnings)
    except Exception:
        remove_collection_tree(result_col)
        raise


def split_body_receiver_mount(context, settings):
    """Split a FINISHED receiver using EXACT solid intersections.

    The source remains intact. A/B are generated as independent closed solids
    instead of sealing nested bisect loops with arbitrary cap polygons.
    """
    target = settings.body_receiver_split_target
    if target is None or target.type != 'MESH':
        raise RuntimeError('分割する本体受けメッシュを指定してください。')
    if settings.placement_mode == 'GUIDE' and not settings.guide_object:
        raise RuntimeError('分割: 仮原点オブジェクトを指定してください。')
    body_receiver_check_closed(target, '分割元')
    plane_co, normal, u, v = get_body_receiver_plane(context, settings)
    a_positive = not settings.body_receiver_flip
    root_name = safe_collection_name('BallJoint_BodySplit')
    result_col = new_collection(root_name, context.scene.collection)
    temp_col = new_collection(f'{root_name}_TEMP', result_col)
    try:
        part_a = bake_evaluated_body_copy(
            context, target, f'{target.name}_A', result_col,
        )
        part_b = duplicate_object(part_a, f'{target.name}_B', result_col)
        for part, keep_positive, label in (
            (part_a, a_positive, 'A'), (part_b, not a_positive, 'B'),
        ):
            cutter = create_body_receiver_halfspace(
                target, plane_co, normal, u, v, keep_positive,
                temp_col, f'{root_name}_Halfspace_{label}',
            )
            try:
                boolean_apply(part, cutter, 'INTERSECT')
            finally:
                delete_object(cutter)
            body_receiver_check_closed(part, f'分割{label}')
            body_receiver_check_half_side(part, plane_co, normal, keep_positive)
            body_receiver_check_cavity_seam(part, target, plane_co, normal)

        dowel_points = add_body_receiver_dowels(
            context, part_a, part_b, settings, temp_col,
        )
        # Repeat after dowels: an invalid B seam must never pass as success.
        body_receiver_check_closed(part_a, 'ダボ加工後A')
        body_receiver_check_closed(part_b, 'ダボ加工後B')
        body_receiver_check_cavity_seam(part_a, target, plane_co, normal)
        body_receiver_check_cavity_seam(part_b, target, plane_co, normal)
        for obj, part_type in ((part_a, 'BODY_RECEIVER_A'),
                               (part_b, 'BODY_RECEIVER_B')):
            obj['ball_joint_generated'] = True
            obj['ball_joint_group'] = root_name
            obj['part_type'] = part_type
            obj['body_receiver_split_from'] = target.name
            obj['nonmanifold_edge_count'] = 0
            for idx, point in enumerate(dowel_points, start=1):
                obj[f'body_receiver_dowel_{idx}_x'] = point.x
                obj[f'body_receiver_dowel_{idx}_y'] = point.y
                obj[f'body_receiver_dowel_{idx}_z'] = point.z
        remove_temp_collection(temp_col)
        if settings.body_receiver_hide_source:
            target.hide_set(True)
        set_active(part_a)
        return dict(part_a=part_a, part_b=part_b, dowels=len(dowel_points))
    except Exception:
        remove_collection_tree(result_col)
        raise



class BALLJOINT_Settings(PropertyGroup):
    live_view_mode: EnumProperty(
        name="LIVE表示対象",
        items=[('JOINT', 'ジョイント', '球・受け・軸の断面'),
               ('MOUNT', '取付 A/B', '取付穴・ソケット外形・挿入経路'),
               ('BODY', '本体受け C', 'Cのキャビティ・開口・分割面')],
        default='JOINT', update=bj_live_update_toggle)
    live_guide_enabled: BoolProperty(
        name="LIVE 寸法ガイド",
        description="数値を動かした瞬間に軽量断面ガイドを更新。Booleanやオブジェクト作成は実行しません",
        default=False, options={'SKIP_SAVE'}, update=bj_live_update_toggle)
    live_world_enabled: BoolProperty(
        name="3D位置ガイドも表示",
        description="3Dカーソル/仮原点の位置に球・受けのガイド輪郭を重ねて表示",
        default=True, update=bj_live_update_toggle)
    live_focus: StringProperty(name="LIVE注目項目", default="OVERVIEW", update=bj_live_update_toggle)

    placement_mode: EnumProperty(
        name="生成基準",
        items=[
            (
                'CURSOR',
                "3Dカーソル",
                "3Dカーソルを仮原点として生成",
            ),
            (
                'GUIDE',
                "仮原点オブジェクト",
                "Empty等のオブジェクト位置・向きを仮原点として使用",
            ),
        ],
        default='CURSOR',
        update=bj_live_update_toggle,
    )

    guide_object: PointerProperty(
        name="仮原点",
        type=bpy.types.Object,
        update=bj_live_update_toggle,
    )

    use_reference_rotation: BoolProperty(
        name="基準の回転も使う",
        default=True,
        description="3Dカーソルまたは仮原点オブジェクトの向きへジョイントを合わせる",
        update=bj_live_update_toggle,
    )

    outer_shape: EnumProperty(
        name="受け外形",
        items=[
            (
                'SPHERE',
                "球形",
                "従来の球殻型ソケット",
            ),
            (
                'CYLINDER',
                "円柱",
                "外側を円柱にして立方体の角を削減。小型化しやすい",
            ),
            (
                'CUBE',
                "立方体",
                "外側を立方体にして平面を増やす。分割印刷や取り付けに便利",
            ),
        ],
        default='SPHERE',
        update=bj_live_update_focus("OUTER_SHAPE"),
    )

    global_scale: FloatProperty(
        name="全体倍率",
        description="完成したジョイント全体を比率そのままで一括拡大縮小します。1.0=100%、0.5=50%、2.0=200%",
        default=1.0,
        min=0.05,
        soft_min=0.1,
        soft_max=5.0,
        max=20.0,
        precision=3,
        update=bj_live_update_focus("GLOBAL_SCALE"),
    )

    ball_diameter: FloatProperty(
        name="ボール直径",
        description="球部分の直径",
        default=10.0,
        min=0.5,
        soft_max=100.0,
        unit='LENGTH',
        update=_cjm_ui.constraint_update('ball','ball_diameter',bj_live_update_focus("BALL_DIAMETER")),
    )

    clearance: FloatProperty(
        name="クリアランス",
        description="ボールとソケット内面の片側すき間",
        default=0.20,
        min=0.0,
        soft_max=2.0,
        unit='LENGTH',
        update=_cjm_ui.constraint_update('ball','clearance',bj_live_update_focus("CLEARANCE")),
    )

    wall_thickness: FloatProperty(
        name="ソケット肉厚",
        default=2.0,
        min=0.3,
        soft_max=10.0,
        unit='LENGTH',
        update=bj_live_update_focus("WALL"),
    )

    opening_diameter: FloatProperty(
        name="開口直径",
        description="上部の基本円形開口",
        default=7.5,
        min=0.2,
        soft_max=100.0,
        unit='LENGTH',
        update=_cjm_ui.constraint_update('ball','opening_diameter',bj_live_update_focus("OPENING")),
    )

    make_socket: BoolProperty(
        name="受け側を作る",
        description="OFFにすると通常生成/通常プレビューではBall側だけを作ります。C.本体受け生成には影響しません",
        default=True,
        update=_cjm_ui.constraint_update('ball','make_socket',bj_live_update_focus("SOCKET")),
    )

    make_shaft: BoolProperty(
        name="ボール側の軸を作る",
        default=True,
        update=_cjm_ui.constraint_update('ball','make_shaft',bj_live_update_focus("BALL_SHAFT_DIAMETER")),
    )

    shaft_diameter: FloatProperty(
        name="ボール軸直径",
        default=3.2,
        min=0.2,
        soft_max=30.0,
        unit='LENGTH',
        update=_cjm_ui.constraint_update('ball','shaft_diameter',bj_live_update_focus("BALL_SHAFT_DIAMETER")),
    )

    shaft_length: FloatProperty(
        name="ボール軸長さ",
        default=10.0,
        min=0.2,
        soft_max=100.0,
        unit='LENGTH',
        update=bj_live_update_focus("BALL_SHAFT_LENGTH"),
    )

    make_socket_shaft: BoolProperty(
        name="受け側の軸を作る",
        default=False,
        description="ソケット下側に接続用の円柱軸を追加。左右分割後は半円柱ずつになります",
        update=bj_live_update_focus("SOCKET_SHAFT_DIAMETER"),
    )

    socket_shaft_diameter: FloatProperty(
        name="受け軸直径",
        default=5.0,
        min=0.3,
        soft_max=50.0,
        unit='LENGTH',
        update=bj_live_update_focus("SOCKET_SHAFT_DIAMETER"),
    )

    socket_shaft_length: FloatProperty(
        name="受け軸長さ",
        default=8.0,
        min=0.3,
        soft_max=100.0,
        unit='LENGTH',
        update=bj_live_update_focus("SOCKET_SHAFT_LENGTH"),
    )

    make_motion_cut: BoolProperty(
        name="可動域切り欠きを作る",
        default=False,
        description="ボール軸が指定角度まで傾けられるよう、オス軸の太さ込みで逃げ形状を計算します",
        update=_cjm_ui.constraint_update('ball','make_motion_cut',bj_live_update_focus("MOTION_ANGLE")),
    )

    motion_cut_mode: EnumProperty(
        name="可動域方式",
        items=[
            (
                'FLAT',
                "自動フラット",
                "軸掃引が既存空洞に収まる限界高さを計算し、そこから上を水平に切り落とします",
            ),
            (
                'CONE',
                "円錐",
                "オス軸の太さを含む掃引包絡を円錐台状に切り抜きます",
            ),
        ],
        default='FLAT',
        update=bj_live_update_focus("MOTION_ANGLE"),
    )

    motion_angle: FloatProperty(
        name="最大傾き",
        description="ボール軸の中心線に対する目標最大傾き",
        default=math.radians(25.0),
        min=0.0,
        max=math.radians(70.0),
        subtype='ANGLE',
        update=bj_live_update_focus("MOTION_ANGLE"),
    )

    motion_shaft_clearance: FloatProperty(
        name="軸逃げクリアランス",
        description="可動時のオス軸外周に追加する片側の逃げ量",
        default=0.20,
        min=0.0,
        soft_max=2.0,
        unit='LENGTH',
        update=bj_live_update_focus("MOTION_SHAFT_CLEARANCE"),
    )

    motion_min_retention: FloatProperty(
        name="最低保持代",
        description="ボール半径に対して最低限残したい保持量。最大安全可動角の判定に使用",
        default=0.20,
        min=0.0,
        soft_max=2.0,
        unit='LENGTH',
        update=bj_live_update_focus("MOTION_RETENTION"),
    )

    split_axis: EnumProperty(
        name="分割方向",
        items=[
            (
                'X',
                "X分割（左右）",
                "X=0面で左右に分割",
            ),
            (
                'Y',
                "Y分割（前後）",
                "Y=0面で前後に分割",
            ),
        ],
        default='X',
        update=bj_live_update_focus('DOWEL_DIAMETER'),
    )

    make_dowels: BoolProperty(
        name="位置決めダボを作る",
        description="左右ソケットを接着するときの位置合わせ用",
        default=True,
        update=bj_live_update_focus("DOWEL_DIAMETER"),
    )

    dowel_style: EnumProperty(
        name="ダボ方式",
        items=[
            (
                'POINT',
                "独立ダボ",
                "従来の丸ピンを複数配置する方式",
            ),
            (
                'PERIMETER',
                "外周リブ",
                "分割面の外壁に沿ってU字状の連続ダボを作る方式。円柱/立方体向け",
            ),
        ],
        default='POINT',
        update=bj_live_update_focus('DOWEL_DIAMETER'),
    )

    dowel_diameter: FloatProperty(
        name="ダボ直径 / リブ幅",
        description="独立ダボではピン直径、外周リブではリブ幅。極細値も入力可能ですが、FDMではノズル幅/スライサー設定に注意",
        default=1.0,
        min=0.05,
        soft_min=0.10,
        soft_max=5.0,
        unit='LENGTH',
        update=bj_live_update_focus("DOWEL_DIAMETER"),
    )

    dowel_length: FloatProperty(
        name="ダボ長さ",
        default=1.2,
        min=0.3,
        soft_max=10.0,
        unit='LENGTH',
        update=bj_live_update_focus("DOWEL_LENGTH"),
    )

    dowel_clearance: FloatProperty(
        name="ダボ穴クリアランス",
        description="穴半径側へ追加するすき間",
        default=0.12,
        min=0.0,
        soft_max=1.0,
        unit='LENGTH',
        update=bj_live_update_focus("DOWEL_CLEARANCE"),
    )

    dowel_outer_margin: FloatProperty(
        name="ダボ外壁最低残し",
        description="ダボ/リブ穴と外側表面の間に最低限残す厚み。受け外形ごとに判定します",
        default=0.25,
        min=0.0,
        soft_max=2.0,
        unit='LENGTH',
        update=bj_live_update_focus('DOWEL_DIAMETER'),
    )

    perimeter_wall_offset: FloatProperty(
        name="外周リブ 外壁オフセット",
        description="外周リブ/溝を外壁からさらに内側へ離す距離。ダボ外壁最低残しに加算されます",
        default=0.40,
        min=0.0,
        soft_max=3.0,
        unit='LENGTH',
        update=bj_live_update_focus('DOWEL_DIAMETER'),
    )

    sphere_segments: IntProperty(
        name="球セグメント",
        default=64,
        min=16,
        max=256,
    )

    sphere_rings: IntProperty(
        name="球リング",
        default=32,
        min=8,
        max=128,
    )

    keep_whole_socket: BoolProperty(
        name="分割前ソケットも残す",
        default=False,
    )


    preview_show_internal: BoolProperty(
        name="内部ガイドも表示",
        description="プレビューで内側キャビティ・開口・可動域ガイドを表示",
        default=True,
    )

    preview_show_dowels: BoolProperty(
        name="ダボ位置も表示",
        description="プレビューでダボ穴の位置と大きさをワイヤー表示",
        default=True,
    )


    # --------------------------------------------------------
    # Mount Cutter / Quick Mount
    # --------------------------------------------------------

    mount_clearance: FloatProperty(
        name="取付クリアランス",
        description="完成したソケット外形と本体側取付穴の片側すき間",
        default=0.20,
        min=0.0,
        soft_max=3.0,
        unit='LENGTH',
        update=bj_live_update_focus("MOUNT_CLEARANCE", "MOUNT"),
    )

    mount_include_socket_shaft: BoolProperty(
        name="受け側軸も穴に含める",
        description="受け側の軸を作っている場合、その外形もMount Cutterへ含めます",
        default=True,
        update=bj_live_update_focus("MOUNT_SHAFT", "MOUNT"),
    )

    mount_make_insertion_path: BoolProperty(
        name="挿入経路も削る",
        description="完成位置だけでなく、そこへ差し込むまでの直線経路も取付穴にします",
        default=False,
        update=bj_live_update_focus("MOUNT_PATH", "MOUNT"),
    )

    mount_path_length: FloatProperty(
        name="挿入経路長",
        description="完成位置から外側へ追加で削る距離",
        default=10.0,
        min=0.0,
        soft_max=100.0,
        unit='LENGTH',
        update=bj_live_update_focus("MOUNT_PATH_LENGTH", "MOUNT"),
    )

    mount_path_direction: EnumProperty(
        name="挿入方向",
        items=[
            (
                'POS_Z',
                "+Z側から",
                "仮原点のローカル+Z方向へ挿入口を伸ばす",
            ),
            (
                'NEG_Z',
                "-Z側から",
                "仮原点のローカル-Z方向へ挿入口を伸ばす",
            ),
        ],
        default='POS_Z',
        update=bj_live_update_focus("MOUNT_PATH", "MOUNT"),
    )

    mount_target: PointerProperty(
        name="取付先本体",
        description="Mount Cutterで穴を開ける対象メッシュ",
        type=bpy.types.Object,
        update=bj_live_update_toggle,
    )

    mount_cutter: PointerProperty(
        name="Mount Cutter",
        description="再利用して穴を開けるMount Cutter",
        type=bpy.types.Object,
        update=bj_live_update_focus('MOUNT_CUTTER', 'MOUNT'),
    )

    mount_keep_cutter_after_apply: BoolProperty(
        name="適用後もカッターを残す",
        description="同じ穴形状を別モデルでも再利用できるようMount Cutterを残します",
        default=True,
    )


    # --------------------------------------------------------
    # C. Body Receiver / 本体そのものを受け側にする
    # --------------------------------------------------------

    body_receiver_split_target: PointerProperty(
        name="分割する受け本体",
        description="先に生成した未分割の本体受け（別の閉じたメッシュも指定可能）",
        type=bpy.types.Object,
        update=bj_live_update_toggle,
    )

    body_receiver_show_split_guides: BoolProperty(
        name="分割ガイドを表示",
        description="分割するときだけ分割面・ダボ位置をLIVEとプレビューに追加",
        default=False,
        update=bj_live_update_toggle,
    )

    body_receiver_hide_source: BoolProperty(
        name="成功後は元本体を非表示",
        description="元のメッシュは削除せず、生成結果を見やすくするため非表示にする",
        default=True,
    )

    body_receiver_plane_axis: EnumProperty(
        name="Bisect方向",
        items=[
            ('LOCAL_X', "Joint X", "ジョイント基準ローカルX法線で切断"),
            ('LOCAL_Y', "Joint Y", "ジョイント基準ローカルY法線で切断"),
            ('LOCAL_Z', "Joint Z", "ジョイント基準ローカルZ法線で切断"),
            ('WORLD_X', "World X", "ワールドX法線で切断"),
            ('WORLD_Y', "World Y", "ワールドY法線で切断"),
            ('WORLD_Z', "World Z", "ワールドZ法線で切断"),
        ],
        default='LOCAL_X',
        update=bj_live_update_focus("BODY_PLANE", "BODY"),
    )

    body_receiver_plane_offset: FloatProperty(
        name="分割位置オフセット",
        description="ジョイント中心からBisect面を法線方向へずらす量",
        default=0.0,
        soft_min=-20.0,
        soft_max=20.0,
        unit='LENGTH',
        update=bj_live_update_focus("BODY_OFFSET", "BODY"),
    )

    body_receiver_flip: BoolProperty(
        name="A/Bを反転",
        description="Bisectで残る側と凸ダボ側を入れ替えます",
        default=False,
        update=bj_live_update_focus("BODY_PLANE", "BODY"),
    )

    body_receiver_cut_depth: FloatProperty(
        name="開口/可動域カッター長",
        description="本体のローカル+Z側へ削る長さ。0でボール径/軸長から自動計算",
        default=0.0,
        min=0.0,
        soft_max=100.0,
        unit='LENGTH',
        update=bj_live_update_focus("BODY_DEPTH", "BODY"),
    )

    body_receiver_make_dowels: BoolProperty(
        name="切断面に丸ダボ2本",
        default=True,
        update=bj_live_update_focus("BODY_DOWEL", "BODY"),
    )

    body_receiver_dowel_spacing: FloatProperty(
        name="C取付 ダボ中心間隔",
        description="0で球キャビティ+最低残しから自動計算",
        default=0.0,
        min=0.0,
        soft_max=100.0,
        unit='LENGTH',
        update=bj_live_update_focus("BODY_DOWEL", "BODY"),
    )

    body_receiver_dowel_v_offset: FloatProperty(
        name="C取付 ダボ上下オフセット",
        description="Bisect面の中で2本のダボをまとめて上下へ移動",
        default=0.0,
        soft_min=-50.0,
        soft_max=50.0,
        unit='LENGTH',
        update=bj_live_update_focus("BODY_DOWEL", "BODY"),
    )


# ============================================================
# Operators
# ============================================================

class BALLJOINT_OT_set_guide_from_active(Operator):
    bl_idname = "ball_joint.set_guide_from_active"
    bl_label = "アクティブを仮原点に"
    bl_description = "現在のアクティブオブジェクトを仮原点として登録"

    def execute(self, context):
        obj = context.active_object

        if not obj:
            self.report(
                {'WARNING'},
                "アクティブオブジェクトがありません。",
            )
            return {'CANCELLED'}

        settings = context.scene.ball_joint_settings
        settings.guide_object = obj
        settings.placement_mode = 'GUIDE'

        return {'FINISHED'}


class BALLJOINT_OT_add_guide_empty(Operator):
    bl_idname = "ball_joint.add_guide_empty"
    bl_label = "仮原点Emptyを追加"
    bl_description = "3Dカーソル位置・向きにジョイント用Emptyを作成"

    def execute(self, context):
        cursor = context.scene.cursor

        empty = bpy.data.objects.new(
            "BJ_Guide",
            None,
        )
        context.scene.collection.objects.link(
            empty
        )

        empty.empty_display_type = 'ARROWS'

        settings = context.scene.ball_joint_settings
        empty.empty_display_size = max(
            0.05,
            settings.ball_diameter
            * settings.global_scale
            * 0.35,
        )

        empty.location = cursor.location
        empty.rotation_euler = cursor.rotation_euler

        settings.guide_object = empty
        settings.placement_mode = 'GUIDE'

        set_active(empty)

        return {'FINISHED'}


class BALLJOINT_OT_generate(Operator):
    bl_idname = "ball_joint.generate"
    bl_label = "ボールジョイント生成"
    bl_description = "設定した仮原点を中心にボール・分割ソケットを生成"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        try:
            switched_mode = ensure_object_mode()
        except Exception as exc:
            self.report(
                {'ERROR'},
                str(exc),
            )
            return {'CANCELLED'}

        s = context.scene.ball_joint_settings

        if switched_mode:
            self.report(
                {'INFO'},
                "Edit Mode等からObject Modeへ自動切替しました。",
            )

        D = s.ball_diameter
        R = D * 0.5

        clearance = s.clearance
        Ri = R + clearance
        wall = s.wall_thickness
        Ro = Ri + wall

        opening_d = s.opening_diameter
        opening_r = opening_d * 0.5

        shaft_r = s.shaft_diameter * 0.5

        # ----------------------------
        # Validation
        # ----------------------------

        if s.make_socket and opening_r >= Ri:
            self.report(
                {'ERROR'},
                "開口直径がソケット内径以上です。開口直径を小さくしてください。",
            )
            return {'CANCELLED'}

        if (
            s.make_socket
            and s.make_shaft
            and not s.make_motion_cut
            and shaft_r >= opening_r
        ):
            self.report(
                {'ERROR'},
                "可動域切り欠きを使わない場合、ボール軸直径は開口直径より小さくしてください。",
            )
            return {'CANCELLED'}

        if s.make_socket and wall <= 0:
            self.report(
                {'ERROR'},
                "ソケット肉厚が不正です。",
            )
            return {'CANCELLED'}

        if s.make_socket and s.make_dowels:
            if s.dowel_style == 'PERIMETER':
                dowel_layout = calc_perimeter_dowel_layout(
                    s,
                    Ri,
                    Ro,
                )

                if not dowel_layout["ok"]:
                    self.report(
                        {'ERROR'},
                        dowel_layout["reason"],
                    )
                    return {'CANCELLED'}

            else:
                dowel_layout = calc_safe_dowel_layout(
                    s,
                    Ri,
                    Ro,
                )

                if not dowel_layout["ok"]:
                    max_d = dowel_layout.get(
                        "max_diameter",
                        0.0,
                    )

                    if max_d > 0.0:
                        msg = (
                            f"{dowel_layout['reason']} "
                            f"現在条件の安全なダボ直径は約 {max_d:.3f} 以下です。"
                        )
                    else:
                        msg = (
                            f"{dowel_layout['reason']} "
                            "ダボ長さ・肉厚・クリアランスを見直してください。"
                        )

                    self.report(
                        {'ERROR'},
                        msg,
                    )
                    return {'CANCELLED'}

        if (
            s.make_socket
            and s.make_motion_cut
            and s.motion_angle > 0.0001
        ):
            motion_check = calc_motion_analysis(
                s
            )

            if not motion_check["feasible"]:
                self.report(
                    {'ERROR'},
                    "オス軸が太すぎてソケット中心側ですでに干渉します。",
                )
                return {'CANCELLED'}

            if not motion_check["geometric_retained"]:
                self.report(
                    {'WARNING'},
                    "現在の可動域ではボールを幾何学的に保持できません。",
                )

            elif not motion_check["safe_retained"]:
                self.report(
                    {'WARNING'},
                    (
                        "ボールは保持されますが、設定した最低保持代を下回っています。"
                    ),
                )

        if (
            s.placement_mode == 'GUIDE'
            and not s.guide_object
        ):
            self.report(
                {'ERROR'},
                "仮原点オブジェクトが指定されていません。",
            )
            return {'CANCELLED'}

        # ----------------------------
        # Collections
        # ----------------------------

        root_name = safe_collection_name("BallJoint")

        result_col = new_collection(
            root_name,
            context.scene.collection,
        )

        temp_col = new_collection(
            f"{root_name}_TEMP",
            result_col,
        )

        center = Vector((0.0, 0.0, 0.0))

        try:
            # ----------------------------
            # Ball
            # ----------------------------

            ball = add_uv_sphere(
                f"{root_name}_Ball",
                R,
                center,
                result_col,
                s.sphere_segments,
                s.sphere_rings,
            )

            if s.make_shaft:
                overlap = calc_ball_shaft_overlap(
                    R,
                    shaft_r,
                )

                shaft_depth = (
                    s.shaft_length + overlap
                )

                shaft_center = Vector((
                    0.0,
                    0.0,
                    R
                    + s.shaft_length * 0.5
                    - overlap * 0.5,
                ))

                shaft = add_cylinder(
                    f"{root_name}_BallShaft",
                    shaft_r,
                    shaft_depth,
                    shaft_center,
                    temp_col,
                    vertices=max(
                        32,
                        s.sphere_segments,
                    ),
                )

                boolean_apply(
                    ball,
                    shaft,
                    'UNION',
                )
                delete_object(shaft)

            # ----------------------------
            # Ball-only mode
            # ----------------------------

            if not s.make_socket:
                placement_matrix = get_reference_matrix(
                    context,
                    s,
                )

                uniform_scale_mesh_objects(
                    [ball],
                    s.global_scale,
                )

                transform_result_objects(
                    [ball],
                    placement_matrix,
                )

                world_center = placement_matrix.translation

                ball["ball_joint_generated"] = True
                ball["ball_joint_group"] = root_name
                ball["part_type"] = "BALL"
                ball["ball_diameter"] = D * s.global_scale
                ball["global_scale"] = s.global_scale
                ball["joint_center_x"] = world_center.x
                ball["joint_center_y"] = world_center.y
                ball["joint_center_z"] = world_center.z
                ball["socket_generated"] = False

                bad_edges = count_nonmanifold_edges(
                    ball
                )
                ball["nonmanifold_edge_count"] = bad_edges

                remove_temp_collection(
                    temp_col
                )

                set_active(
                    ball
                )

                if bad_edges > 0:
                    self.report(
                        {'WARNING'},
                        (
                            f"Ball側のみ生成完了: {root_name} / "
                            f"非マニフォールド辺 {bad_edges}"
                        ),
                    )
                else:
                    self.report(
                        {'INFO'},
                        f"Ball側のみ生成完了: {root_name}",
                    )

                return {'FINISHED'}

            # ----------------------------
            # Outer socket body
            # ----------------------------

            if s.outer_shape == 'SPHERE':
                outer = add_uv_sphere(
                    f"{root_name}_SocketWhole",
                    Ro,
                    center,
                    result_col,
                    s.sphere_segments,
                    s.sphere_rings,
                )

            elif s.outer_shape == 'CYLINDER':
                outer = add_cylinder(
                    f"{root_name}_SocketWhole",
                    Ro,
                    Ro * 2.0,
                    center,
                    result_col,
                    vertices=max(
                        48,
                        s.sphere_segments,
                    ),
                )

            else:
                outer = add_box(
                    f"{root_name}_SocketWhole",
                    (
                        Ro * 2.0,
                        Ro * 2.0,
                        Ro * 2.0,
                    ),
                    center,
                    result_col,
                )

            # Optional socket-side shaft first,
            # then cavity is subtracted so the inner sphere stays clean.
            if s.make_socket_shaft:
                socket_shaft_r = (
                    s.socket_shaft_diameter
                    * 0.5
                )

                overlap = calc_socket_shaft_overlap(
                    s.outer_shape,
                    Ro,
                    socket_shaft_r,
                    wall,
                )

                socket_shaft_depth = (
                    s.socket_shaft_length
                    + overlap
                )

                socket_shaft_center = Vector((
                    0.0,
                    0.0,
                    -Ro
                    - s.socket_shaft_length * 0.5
                    + overlap * 0.5,
                ))

                socket_shaft = add_cylinder(
                    f"{root_name}_SocketShaft",
                    socket_shaft_r,
                    socket_shaft_depth,
                    socket_shaft_center,
                    temp_col,
                    vertices=max(
                        32,
                        s.sphere_segments,
                    ),
                )

                try:
                    boolean_apply(
                        outer,
                        socket_shaft,
                        'UNION',
                    )
                except Exception as exc:
                    raise RuntimeError(
                        "受け側軸の結合Booleanに失敗しました。"
                        f" {exc}"
                    )
                finally:
                    delete_object(
                        socket_shaft
                    )

            # Inner spherical cavity.
            inner = add_uv_sphere(
                f"{root_name}_InnerCavity",
                Ri,
                center,
                temp_col,
                s.sphere_segments,
                s.sphere_rings,
            )

            boolean_apply(
                outer,
                inner,
                'DIFFERENCE',
            )
            delete_object(inner)

            # ----------------------------
            # Basic circular opening
            # ----------------------------

            cut_eps = boolean_epsilon(
                Ro
            )

            base_cutter_depth = (
                Ro * 2.4
            )

            cutter_depth = (
                base_cutter_depth
                + cut_eps * 2.0
            )

            # Bottom = -cut_eps, so it does not end exactly on the equator.
            cutter_center = Vector((
                0.0,
                0.0,
                base_cutter_depth * 0.5,
            ))

            opening_cutter = add_cylinder(
                f"{root_name}_OpeningCutter",
                opening_r,
                cutter_depth,
                cutter_center,
                temp_col,
                vertices=max(
                    48,
                    s.sphere_segments,
                ),
            )

            boolean_apply(
                outer,
                opening_cutter,
                'DIFFERENCE',
            )
            delete_object(
                opening_cutter
            )

            # ----------------------------
            # Motion clearance
            # ----------------------------

            if (
                s.make_motion_cut
                and s.motion_angle > 0.0001
            ):
                motion = calc_motion_analysis(
                    s
                )

                if not motion["feasible"]:
                    raise RuntimeError(
                        "オス軸の太さ/逃げ量がソケット中心の内球空間より大きく、"
                        "指定可動域を成立させられません。"
                    )

                motion_eps = boolean_epsilon(
                    Ro
                )

                if (
                    s.motion_cut_mode == 'FLAT'
                    and motion["needs_extra_cut"]
                ):
                    # User-requested flat truncation:
                    # remove everything above the exact height where the
                    # swept male shaft first stops fitting in the existing
                    # cavity/opening. This preserves the original cylinder/
                    # cube/sphere outer shape below the horizontal plane.
                    cut_bottom = (
                        motion["cut_z"]
                        - motion_eps
                    )

                    cut_top = (
                        Ro * 1.60
                        + motion_eps
                    )

                    cut_depth = max(
                        motion_eps * 2.0,
                        cut_top - cut_bottom,
                    )

                    flat_cutter = add_box(
                        f"{root_name}_MotionFlatCutter",
                        (
                            Ro * 2.8,
                            Ro * 2.8,
                            cut_depth,
                        ),
                        Vector((
                            0.0,
                            0.0,
                            (
                                cut_top
                                + cut_bottom
                            ) * 0.5,
                        )),
                        temp_col,
                    )

                    boolean_apply(
                        outer,
                        flat_cutter,
                        'DIFFERENCE',
                    )
                    delete_object(
                        flat_cutter
                    )

                elif s.motion_cut_mode == 'CONE':
                    # Improved cone/frustum:
                    # shaft thickness is a radial offset of the centerline
                    # sweep, so the cutter no longer collapses to radius zero
                    # at the ball center.
                    base_motion_depth = (
                        Ro * 2.6
                    )

                    motion_depth = (
                        base_motion_depth
                        + motion_eps * 2.0
                    )

                    bottom_radius = (
                        motion_swept_radius_at_height(
                            s,
                            0.0,
                        )
                    )

                    top_radius = (
                        motion_swept_radius_at_height(
                            s,
                            base_motion_depth
                            + motion_eps,
                        )
                    )

                    motion_center = Vector((
                        0.0,
                        0.0,
                        base_motion_depth * 0.5,
                    ))

                    motion_cutter = add_cone(
                        f"{root_name}_MotionCutter",
                        bottom_radius,
                        top_radius,
                        motion_depth,
                        motion_center,
                        temp_col,
                        vertices=max(
                            64,
                            s.sphere_segments,
                        ),
                    )

                    boolean_apply(
                        outer,
                        motion_cutter,
                        'DIFFERENCE',
                    )
                    delete_object(
                        motion_cutter
                    )

            # ----------------------------
            # Split
            # ----------------------------

            part_a, part_b = split_socket(
                outer,
                s.split_axis,
                root_name,
                result_col,
                temp_col,
                Ro,
            )

            # ----------------------------
            # Dowels
            # ----------------------------

            add_alignment_dowels(
                part_a,
                part_b,
                s,
                root_name,
                temp_col,
                Ri,
                Ro,
            )

            # ----------------------------
            # Keep/delete original socket
            # ----------------------------

            reference_socket = None

            if not s.keep_whole_socket:
                delete_object(outer)
            else:
                outer.hide_viewport = True
                outer.hide_render = True
                outer.name = (
                    f"{root_name}_SocketWhole_REFERENCE"
                )
                reference_socket = outer

            # ----------------------------
            # Placement using cursor/guide
            # ----------------------------

            placement_matrix = get_reference_matrix(
                context,
                s,
            )

            final_objects = [
                ball,
                part_a,
                part_b,
            ]

            if reference_socket:
                final_objects.append(
                    reference_socket
                )

            # Master scale is applied to the FINISHED geometry in one operation.
            # No individual dimension is recalculated, so nothing can be
            # accidentally scaled twice or omitted.
            uniform_scale_mesh_objects(
                final_objects,
                s.global_scale,
            )

            transform_result_objects(
                final_objects,
                placement_matrix,
            )

            # ----------------------------
            # Metadata
            # ----------------------------

            world_center = (
                placement_matrix.translation
            )

            for obj in (
                ball,
                part_a,
                part_b,
            ):
                obj["ball_joint_generated"] = True
                obj["ball_joint_group"] = root_name
                obj["ball_diameter"] = D
                obj["socket_clearance"] = clearance
                obj["opening_diameter"] = (
                    opening_d * s.global_scale
                )
                obj["ball_diameter"] = (
                    D * s.global_scale
                )
                obj["socket_clearance"] = (
                    clearance * s.global_scale
                )
                obj["global_scale"] = s.global_scale
                obj["outer_shape"] = s.outer_shape
                obj["split_axis"] = s.split_axis
                obj["joint_center_x"] = world_center.x
                obj["joint_center_y"] = world_center.y
                obj["joint_center_z"] = world_center.z

            ball["part_type"] = "BALL"
            ball["socket_generated"] = True
            part_a["part_type"] = "SOCKET_A"
            part_b["part_type"] = "SOCKET_B"

            topology_warnings = []

            for obj in (
                ball,
                part_a,
                part_b,
            ):
                bad_edges = count_nonmanifold_edges(
                    obj
                )

                obj["nonmanifold_edge_count"] = bad_edges

                if bad_edges > 0:
                    topology_warnings.append(
                        f"{obj.name}: {bad_edges}"
                    )

            if topology_warnings:
                self.report(
                    {'WARNING'},
                    (
                        "生成は完了しましたが非マニフォールド辺を検出: "
                        + ", ".join(topology_warnings)
                    ),
                )

            remove_temp_collection(
                temp_col
            )

            # Select generated ball.
            set_active(ball)

            # ----------------------------
            # Report
            # ----------------------------

            effective_r = (
                estimated_effective_opening_radius(
                    s
                )
            )

            if effective_r < R:
                play = calc_socket_upward_play(
                    R,
                    clearance,
                    effective_r,
                )

                self.report(
                    {'INFO'},
                    (
                        f"生成完了: {root_name} / "
                        f"保持あり / "
                        f"推定上方向遊び 約 {play * s.global_scale:.3f}"
                    ),
                )
            else:
                self.report(
                    {'WARNING'},
                    (
                        f"生成完了: {root_name} / "
                        "開口・可動切欠きが大きいため、保持が弱いか球が抜ける可能性があります。"
                    ),
                )

        except Exception as exc:
            # Roll back the entire generated collection.
            # This prevents InnerCavity / Split cutter / half-built socket
            # objects from being left in the scene after a failed Boolean.
            remove_collection_tree(
                result_col
            )

            self.report(
                {'ERROR'},
                f"生成を中止して後片付けしました: {exc}",
            )
            return {'CANCELLED'}

        return {'FINISHED'}




class BALLJOINT_OT_preview_update(Operator):
    bl_idname = "ball_joint.preview_update"
    bl_label = "プレビュー作成 / 更新"
    bl_description = "現在の設定をワイヤー表示でプレビュー。最終生成物には影響しません"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        try:
            objects = create_joint_preview(
                context,
                context.scene.ball_joint_settings,
            )
        except Exception as exc:
            self.report(
                {'ERROR'},
                f"プレビュー生成失敗: {exc}",
            )
            return {'CANCELLED'}

        self.report(
            {'INFO'},
            f"プレビュー更新: {len(objects)} オブジェクト",
        )
        return {'FINISHED'}


class BALLJOINT_OT_preview_clear(Operator):
    bl_idname = "ball_joint.preview_clear"
    bl_label = "プレビュー削除"
    bl_description = "Ball Joint Makerのプレビューだけを削除"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        clear_joint_preview()

        self.report(
            {'INFO'},
            "プレビューを削除しました。",
        )
        return {'FINISHED'}

class BALLJOINT_OT_set_mount_target(Operator):
    bl_idname = "ball_joint.set_mount_target"
    bl_label = "アクティブを取付先に"
    bl_description = "現在のアクティブメッシュを取付穴を開ける本体として設定"

    def execute(self, context):
        obj = context.active_object

        if not obj or obj.type != 'MESH':
            self.report(
                {'WARNING'},
                "取付先にするメッシュを選択してください。",
            )
            return {'CANCELLED'}

        context.scene.ball_joint_settings.mount_target = obj
        return {'FINISHED'}


class BALLJOINT_OT_set_mount_cutter(Operator):
    bl_idname = "ball_joint.set_mount_cutter"
    bl_label = "アクティブをカッターに"
    bl_description = "現在のアクティブメッシュをMount Cutterとして設定"

    def execute(self, context):
        obj = context.active_object

        if not obj or obj.type != 'MESH':
            self.report(
                {'WARNING'},
                "Mount Cutterにするメッシュを選択してください。",
            )
            return {'CANCELLED'}

        context.scene.ball_joint_settings.mount_cutter = obj
        return {'FINISHED'}


class BALLJOINT_OT_create_mount_cutter(Operator):
    bl_idname = "ball_joint.create_mount_cutter"
    bl_label = "Mount Cutter作成"
    bl_description = "現在のジョイント設定から再利用可能な取付穴用カッターを生成"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        try:
            ensure_object_mode()
        except Exception as exc:
            self.report(
                {'ERROR'},
                str(exc),
            )
            return {'CANCELLED'}

        s = context.scene.ball_joint_settings

        if (
            s.placement_mode == 'GUIDE'
            and not s.guide_object
        ):
            self.report(
                {'ERROR'},
                "仮原点オブジェクトが指定されていません。",
            )
            return {'CANCELLED'}

        try:
            cutter = create_mount_cutter(
                context,
                s,
                name=safe_object_name("BallJoint_MountCutter"),
                persistent=True,
            )
        except Exception as exc:
            self.report(
                {'ERROR'},
                f"Mount Cutter生成失敗: {exc}",
            )
            return {'CANCELLED'}

        s.mount_cutter = cutter
        set_active(cutter)

        self.report(
            {'INFO'},
            "Mount Cutterを生成しました。移動・複製して何度でも再利用できます。",
        )
        return {'FINISHED'}


class BALLJOINT_OT_apply_mount_cutter(Operator):
    bl_idname = "ball_joint.apply_mount_cutter"
    bl_label = "Mount Cutter適用"
    bl_description = "指定した本体からMount Cutter形状をBooleanで削る"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        try:
            ensure_object_mode()
        except Exception as exc:
            self.report(
                {'ERROR'},
                str(exc),
            )
            return {'CANCELLED'}

        s = context.scene.ball_joint_settings
        target = s.mount_target
        cutter = s.mount_cutter

        try:
            apply_mount_cutter_to_target(
                target,
                cutter,
            )
        except Exception as exc:
            self.report(
                {'ERROR'},
                f"取付穴生成失敗: {exc}",
            )
            return {'CANCELLED'}

        if not s.mount_keep_cutter_after_apply:
            delete_object(cutter)
            s.mount_cutter = None

        if target and target.name in bpy.data.objects:
            set_active(target)

        self.report(
            {'INFO'},
            "取付穴を生成しました。",
        )
        return {'FINISHED'}


class BALLJOINT_OT_quick_mount(Operator):
    bl_idname = "ball_joint.quick_mount"
    bl_label = "クイック取付"
    bl_description = "ジョイントを生成し、同じ位置・向きのMount Cutterで取付先に穴を一発生成"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        try:
            ensure_object_mode()
        except Exception as exc:
            self.report(
                {'ERROR'},
                str(exc),
            )
            return {'CANCELLED'}

        s = context.scene.ball_joint_settings

        if not s.make_socket:
            self.report(
                {'ERROR'},
                "A. クイック取付では受け側が必要です。「受け側を作る」をONにしてください。",
            )
            return {'CANCELLED'}

        target = s.mount_target

        if not target:
            obj = context.active_object

            if obj and obj.type == 'MESH':
                target = obj
                s.mount_target = obj

        if not target or target.type != 'MESH':
            self.report(
                {'ERROR'},
                "先に取付先本体を設定してください。",
            )
            return {'CANCELLED'}

        if (
            s.placement_mode == 'GUIDE'
            and not s.guide_object
        ):
            self.report(
                {'ERROR'},
                "仮原点オブジェクトが指定されていません。",
            )
            return {'CANCELLED'}

        # Preserve the exact placement before the normal generate operator
        # changes selection/active object.
        placement_matrix = get_reference_matrix(
            context,
            s,
        )

        # 1) Generate the actual joint using the same settings.
        result = bpy.ops.ball_joint.generate()

        if 'FINISHED' not in result:
            self.report(
                {'ERROR'},
                "ジョイント生成に失敗したため取付穴は作りませんでした。",
            )
            return {'CANCELLED'}

        # 2) Create an internal temporary cutter at precisely the same pose.
        cutter = None

        try:
            cutter = create_mount_cutter(
                context,
                s,
                name=safe_object_name("BallJoint_QuickMountCutter"),
                placement_matrix=placement_matrix,
                persistent=False,
            )

            # 3) Cut the target.
            apply_mount_cutter_to_target(
                target,
                cutter,
            )

        except Exception as exc:
            self.report(
                {'ERROR'},
                (
                    "ジョイント本体は生成されましたが、"
                    f"取付穴生成に失敗しました: {exc}"
                ),
            )
            return {'CANCELLED'}

        finally:
            # Quick Mount never leaves its internal cutter behind.
            delete_object(cutter)

        if target and target.name in bpy.data.objects:
            target.select_set(True)

        self.report(
            {'INFO'},
            "クイック取付完了: ジョイント生成 + 取付穴Boolean",
        )
        return {'FINISHED'}


class BALLJOINT_OT_body_receiver_preview(Operator):
    bl_idname = "ball_joint.body_receiver_preview"
    bl_label = "C取付プレビュー"
    bl_description = "本体を複製せず、Ball/キャビティを表示。任意で分割面・ダボ位置も表示"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        s = context.scene.ball_joint_settings

        try:
            ensure_object_mode()
            create_body_receiver_preview(context, s)
        except Exception as exc:
            clear_body_receiver_preview()
            self.report({'ERROR'}, f"C取付プレビュー失敗: {exc}")
            return {'CANCELLED'}

        self.report({'INFO'}, "C取付プレビュー更新: 本体コピー/Booleanはまだ実行していません。")
        return {'FINISHED'}


class BALLJOINT_OT_body_receiver_preview_clear(Operator):
    bl_idname = "ball_joint.body_receiver_preview_clear"
    bl_label = "C取付プレビュー削除"

    def execute(self, context):
        clear_body_receiver_preview()
        return {'FINISHED'}


class BALLJOINT_OT_body_receiver_generate(Operator):
    bl_idname = "ball_joint.body_receiver_generate"
    bl_label = "C. 未分割の本体受けを生成"
    bl_description = "元本体を保持し、評価済みコピーに球キャビティを一括加工します。分割は別操作です"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        s = context.scene.ball_joint_settings

        try:
            ensure_object_mode()
            clear_body_receiver_preview()
            result = generate_body_receiver_mount(context, s)
        except Exception as exc:
            self.report({'ERROR'}, f"C. 本体受け生成失敗: {exc}")
            return {'CANCELLED'}

        faces = result['polygon_count']
        warnings = result['warnings']

        if faces >= 500000:
            self.report(
                {'WARNING'},
                f"C取付完了 / 評価済み本体 {faces:,} faces。Booleanは重くなる場合があります。",
            )
        elif warnings:
            self.report(
                {'WARNING'},
                "C取付完了。ただし非マニフォールド辺を検出: " + ", ".join(warnings),
            )
        else:
            self.report(
                {'INFO'},
                "C取付完了: 未分割の本体受け + Ball を生成。元本体は保持しました。",
            )

        return {'FINISHED'}


class BALLJOINT_OT_set_body_receiver_split_target(Operator):
    bl_idname = "ball_joint.set_body_receiver_split_target"
    bl_label = "アクティブを分割対象に"
    bl_description = "現在のアクティブな受けメッシュを分割対象に登録します"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            self.report({'ERROR'}, '分割対象はメッシュにしてください。')
            return {'CANCELLED'}
        context.scene.ball_joint_settings.body_receiver_split_target = obj
        self.report({'INFO'}, f'分割対象: {obj.name}')
        return {'FINISHED'}


class BALLJOINT_OT_body_receiver_split(Operator):
    bl_idname = "ball_joint.body_receiver_split"
    bl_label = "本体受けをA/Bに分割"
    bl_description = "既存の未分割受けを残し、正確な半空間BooleanでA/Bへ分割します"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.ball_joint_settings
        try:
            ensure_object_mode()
            result = split_body_receiver_mount(context, settings)
        except Exception as exc:
            self.report({'ERROR'}, f'本体受け分割失敗: {exc}')
            return {'CANCELLED'}
        self.report({'INFO'},
                    f'本体受け分割完了: A/B、ダボ {result["dowels"]} 本。元受けは保持。')
        return {'FINISHED'}


class BALLJOINT_OT_select_generated(Operator):
    bl_idname = "ball_joint.select_generated"
    bl_label = "生成パーツを選択"
    bl_description = "Ball Joint Makerで生成された全パーツを選択"

    def execute(self, context):
        bpy.ops.object.select_all(
            action='DESELECT'
        )

        count = 0
        active = None

        for obj in context.scene.objects:
            if obj.get(
                "ball_joint_generated",
                False,
            ):
                obj.select_set(True)
                count += 1

                if active is None:
                    active = obj

        if active:
            context.view_layer.objects.active = active

        self.report(
            {'INFO'},
            f"{count} パーツを選択しました。",
        )

        return {'FINISHED'}


# ============================================================
# UI
# ============================================================

class VIEW3D_PT_ball_joint_maker(Panel):
    bl_label = "Ball Joint Maker"
    bl_idname = "VIEW3D_PT_ball_joint_maker"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Joint Maker"

    bl_parent_id = "VIEW3D_PT_cjm_root"

    @classmethod
    def poll(cls, context):
        return _cjm_ui.visible(context,"BALL","GENERATE")

    def draw(self, context):
        layout = self.layout
        s = context.scene.ball_joint_settings

        if context.mode != 'OBJECT':
            warn = layout.box()
            warn.alert = True
            warn.label(
                text="現在 Object Mode ではありません",
                icon='ERROR',
            )
            warn.label(
                text="生成時に自動で Object Mode へ切り替えます",
            )

        col = layout.column()
        col.scale_y = 1.45
        col.operator(
            BALLJOINT_OT_generate.bl_idname,
            text="ボールジョイント生成",
            icon='OUTLINER_OB_MESH',
        )

        layout.operator(
            BALLJOINT_OT_select_generated.bl_idname,
            text="生成パーツを選択",
            icon='RESTRICT_SELECT_OFF',
        )

        info = layout.box()
        info.label(
            text=f"v0.8.9 / 全体倍率 {s.global_scale:.3f}x",
            icon='INFO',
        )
        info.label(
            text="タグ: 自作アドオン",
            icon='BOOKMARKS',
        )
        info.label(
            text="本体取付: 上部の「本体取付・分割」",
            icon='MOD_BOOLEAN',
        )


class VIEW3D_PT_ball_joint_size(Panel):
    bl_label = "全体サイズ"
    bl_idname = "VIEW3D_PT_ball_joint_size"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Joint Maker"
    bl_parent_id = "VIEW3D_PT_ball_joint_maker"

    @classmethod
    def poll(cls, context):
        return _cjm_ui.visible(context,"BALL","GENERATE")

    def draw(self, context):
        layout = self.layout
        s = context.scene.ball_joint_settings

        bj_live_focus_prop(layout, s, "global_scale")

        layout.label(
            text=(
                "実効ボール直径: "
                f"{s.ball_diameter * s.global_scale:.3f}"
            ),
            icon='DRIVER_DISTANCE',
        )

        layout.label(
            text="全パーツ・穴・ダボ・隙間を同じ比率で変更",
            icon='INFO',
        )



class VIEW3D_PT_ball_joint_preview(Panel):
    bl_label = "プレビュー"
    bl_idname = "VIEW3D_PT_ball_joint_preview"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Joint Maker"
    bl_parent_id = "VIEW3D_PT_ball_joint_maker"

    @classmethod
    def poll(cls, context):
        return _cjm_ui.visible(context,"BALL","GENERATE")

    def draw(self, context):
        layout = self.layout
        s = context.scene.ball_joint_settings

        row = layout.row(
            align=True
        )

        row.operator(
            BALLJOINT_OT_preview_update.bl_idname,
            text="作成 / 更新",
            icon='HIDE_OFF',
        )

        row.operator(
            BALLJOINT_OT_preview_clear.bl_idname,
            text="削除",
            icon='TRASH',
        )

        box = layout.box()
        box.label(text="LIVE 寸法ガイド", icon='DRIVER_DISTANCE')
        box.prop(s, 'live_guide_enabled', text="数値変更で自動更新")
        if s.live_guide_enabled:
            box.prop(s, 'live_world_enabled')
            box.prop(s, 'live_view_mode', expand=True)
            box.operator('ball_joint.live_focus', text="全体を表示", icon='ZOOM_ALL').focus_key = 'OVERVIEW'
            current = _BJ_FOCUS_INFO.get(s.live_focus, _BJ_FOCUS_INFO['OVERVIEW'])
            box.label(text="注目: " + current[0])
            motion, dowel = bj_live_motion_and_dowel(s)
            issues = bj_live_diagnostics(s, motion, dowel)
            for issue in issues[:3]:
                row = box.row()
                row.alert = True
                row.label(text=issue[1][:57], icon='ERROR')
            if len(issues)>3:
                box.label(text=f"ほか {len(issues)-3} 件", icon='INFO')
        box.label(text="模式図は自動。メッシュは作成/更新で再生成", icon='INFO')

        layout.prop(
            s,
            "preview_show_internal",
        )
        layout.prop(
            s,
            "preview_show_dowels",
        )

        if bpy.data.collections.get(
            PREVIEW_COLLECTION_NAME
        ):
            layout.label(
                text="プレビュー表示中",
                icon='CHECKMARK',
            )
        else:
            layout.label(
                text="プレビューなし",
                icon='HIDE_ON',
            )

        layout.label(
            text="完成メッシュの更新には「作成 / 更新」が必要",
            icon='INFO',
        )

class VIEW3D_PT_ball_joint_placement(Panel):
    bl_label = "仮原点 / 生成基準"
    bl_idname = "VIEW3D_PT_ball_joint_placement"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Joint Maker"
    bl_parent_id = "VIEW3D_PT_ball_joint_maker"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _cjm_ui.visible(context,"BALL","GENERATE")

    def draw(self, context):
        layout = self.layout
        s = context.scene.ball_joint_settings

        layout.prop(
            s,
            "placement_mode",
            expand=True,
        )

        if s.placement_mode == 'GUIDE':
            layout.prop(
                s,
                "guide_object",
                text="仮原点",
            )

            row = layout.row(
                align=True
            )
            row.operator(
                BALLJOINT_OT_set_guide_from_active.bl_idname,
                text="アクティブを設定",
                icon='EYEDROPPER',
            )
            row.operator(
                BALLJOINT_OT_add_guide_empty.bl_idname,
                text="Empty追加",
                icon='EMPTY_ARROWS',
            )
        else:
            layout.operator(
                BALLJOINT_OT_add_guide_empty.bl_idname,
                text="カーソル位置に仮原点Empty",
                icon='EMPTY_ARROWS',
            )

        layout.prop(
            s,
            "use_reference_rotation",
        )


class VIEW3D_PT_ball_joint_ball(Panel):
    bl_label = "ボール側"
    bl_idname = "VIEW3D_PT_ball_joint_ball"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Joint Maker"
    bl_parent_id = "VIEW3D_PT_ball_joint_maker"

    @classmethod
    def poll(cls, context):
        return _cjm_ui.visible(context,"BALL","GENERATE")

    def draw(self, context):
        layout = self.layout
        s = context.scene.ball_joint_settings

        bj_live_focus_prop(layout, s, "ball_diameter")
        bj_live_focus_prop(layout, s, "make_shaft")

        if s.make_shaft:
            bj_live_focus_prop(layout, s, 'shaft_diameter')
            bj_live_focus_prop(layout, s, 'shaft_length')

            embed = calc_ball_shaft_overlap(
                s.ball_diameter * 0.5,
                s.shaft_diameter * 0.5,
            )

            layout.label(
                text=(
                    "自動埋込深さ: "
                    f"{embed * s.global_scale:.3f}"
                ),
                icon='DRIVER_DISTANCE',
            )


class VIEW3D_PT_ball_joint_socket(Panel):
    bl_label = "受け側"
    bl_idname = "VIEW3D_PT_ball_joint_socket"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Joint Maker"
    bl_parent_id = "VIEW3D_PT_ball_joint_maker"

    @classmethod
    def poll(cls, context):
        return _cjm_ui.visible(context,"BALL","GENERATE")

    def draw(self, context):
        layout = self.layout
        s = context.scene.ball_joint_settings

        bj_live_focus_prop(layout, s, "make_socket")

        if not s.make_socket:
            note = layout.box()
            note.label(
                text="通常生成はBall側のみになります",
                icon='INFO',
            )
            note.label(
                text="C. 本体受け分割はこの設定に関係なく使用できます",
            )
            return

        bj_live_focus_prop(layout, s, "outer_shape")
        bj_live_focus_prop(layout, s, "clearance")
        bj_live_focus_prop(layout, s, "wall_thickness")
        bj_live_focus_prop(layout, s, "opening_diameter")
        bj_live_focus_prop(layout, s, "make_socket_shaft")

        if s.make_socket_shaft:
            bj_live_focus_prop(layout, s, 'socket_shaft_diameter')
            bj_live_focus_prop(layout, s, 'socket_shaft_length')

        if s.outer_shape == 'CYLINDER':
            note = layout.box()
            note.label(
                text="円柱型: 立方体の角を削って省スペース化",
                icon='MESH_CYLINDER',
            )
            note.label(
                text="外周リブダボとの組み合わせがおすすめ",
            )


class VIEW3D_PT_ball_joint_motion(Panel):
    bl_label = "可動域"
    bl_idname = "VIEW3D_PT_ball_joint_motion"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Joint Maker"
    bl_parent_id = "VIEW3D_PT_ball_joint_maker"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _cjm_ui.visible(context,"BALL","GENERATE")

    def draw(self, context):
        layout = self.layout
        s = context.scene.ball_joint_settings

        bj_live_focus_prop(layout, s, "make_motion_cut")

        if not s.make_motion_cut:
            return

        layout.prop(
            s,
            "motion_cut_mode",
            expand=True,
        )
        bj_live_focus_prop(layout, s, "motion_angle")
        bj_live_focus_prop(layout, s, "motion_shaft_clearance")
        bj_live_focus_prop(layout, s, "motion_min_retention")

        motion = calc_motion_analysis(
            s
        )

        result = layout.box()
        result.label(
            text="可動域 / 保持 計算",
            icon='DRIVER',
        )

        if not motion["feasible"]:
            warn = result.row()
            warn.alert = True
            warn.label(
                text="軸が中心側ですでに干渉: 条件を成立できません",
                icon='ERROR',
            )
            return

        scale = s.global_scale

        if s.motion_cut_mode == 'FLAT':
            result.label(
                text=(
                    "自動切断高さ: "
                    f"{motion['cut_z'] * scale:.3f}"
                ),
            )
            result.label(
                text=(
                    "上部除去量: "
                    f"{motion['removed_height'] * scale:.3f}"
                ),
            )

            if not motion["needs_extra_cut"]:
                result.label(
                    text="既存の球キャビティ/開口だけで可動可能",
                    icon='CHECKMARK',
                )
        else:
            result.label(
                text=(
                    "保持ネック高さ: "
                    f"{motion['neck_z'] * scale:.3f}"
                ),
            )
            result.label(
                text="円錐台はオス軸の太さ込みで生成",
                icon='INFO',
            )

        result.label(
            text=(
                "軸掃引半径 @ 境界: "
                f"{motion['shaft_sweep_radius_at_cut'] * scale:.3f}"
            ),
        )
        result.label(
            text=(
                "保持ネック半径: "
                f"{motion['neck_radius'] * scale:.3f}"
            ),
        )
        result.label(
            text=(
                "ボール保持代: "
                f"{motion['retention_margin'] * scale:.3f}"
            ),
        )

        if math.isfinite(
            motion["upward_play"]
        ):
            result.label(
                text=(
                    "推定上方向遊び: "
                    f"{motion['upward_play'] * scale:.3f}"
                ),
            )
        else:
            result.label(
                text="推定上方向遊び: 保持なし",
            )

        safe_angle = max_safe_motion_angle(
            s
        )

        result.label(
            text=(
                "最大安全可動角: "
                f"{math.degrees(safe_angle):.1f}°"
            ),
        )

        if motion["safe_retained"]:
            ok = result.row()
            ok.label(
                text="軸干渉なし / 最低保持代を確保",
                icon='CHECKMARK',
            )

        elif motion["geometric_retained"]:
            warn = result.row()
            warn.alert = True
            warn.label(
                text="保持あり。ただし最低保持代を下回っています",
                icon='ERROR',
            )

        else:
            warn = result.row()
            warn.alert = True
            warn.label(
                text="ボールが抜ける形状です",
                icon='UNLOCKED',
            )

        if (
            motion["cut_z"]
            < motion["R"]
        ):
            note = result.row()
            note.alert = True
            note.label(
                text="切断境界がボール中心側へ深く入っています",
                icon='INFO',
            )


class VIEW3D_PT_ball_joint_split(Panel):
    bl_label = "分割 / 接着位置合わせ"
    bl_idname = "VIEW3D_PT_ball_joint_split"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Joint Maker"
    bl_parent_id = "VIEW3D_PT_ball_joint_maker"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _cjm_ui.visible(context,"BALL","GENERATE")

    def draw(self, context):
        layout = self.layout
        s = context.scene.ball_joint_settings

        layout.prop(
            s,
            "split_axis",
            expand=True,
        )
        layout.prop(
            s,
            "make_dowels",
        )

        if s.make_dowels:
            layout.prop(
                s,
                "dowel_style",
                expand=True,
            )
            bj_live_focus_prop(layout, s, "dowel_diameter")
            bj_live_focus_prop(layout, s, "dowel_length")
            bj_live_focus_prop(layout, s, "dowel_clearance")

            if s.dowel_style == 'PERIMETER':
                layout.label(
                    text="リブ: 全方向の片側クリアランスとして適用",
                    icon='DRIVER_DISTANCE',
                )

            layout.prop(
                s,
                "dowel_outer_margin",
            )

            if s.dowel_style == 'PERIMETER':
                layout.prop(
                    s,
                    "perimeter_wall_offset",
                )

                total_keep = (
                    s.dowel_outer_margin
                    + s.perimeter_wall_offset
                ) * s.global_scale

                layout.label(
                    text=(
                        "外壁からの実効残し: "
                        f"{total_keep:.3f}"
                    ),
                    icon='DRIVER_DISTANCE',
                )

            Ri = (
                s.ball_diameter * 0.5
                + s.clearance
            )
            Ro = (
                Ri
                + s.wall_thickness
            )

            if s.dowel_style == 'PERIMETER':
                ring_layout = calc_perimeter_dowel_layout(
                    s,
                    Ri,
                    Ro,
                )

                layout.label(
                    text="外周リブ: 左右の外壁に沿うU字ダボ",
                    icon='MOD_SOLIDIFY',
                )
                if (
                    s.dowel_diameter * s.global_scale
                    < 0.30
                ):
                    thin = layout.row()
                    thin.alert = True
                    thin.label(
                        text="0.30mm未満: スライサーで消える可能性あり",
                        icon='ERROR',
                    )
                layout.label(
                    text="オフセットを増やすほど外側に厚い壁を残します",
                    icon='INFO',
                )

                if s.outer_shape == 'SPHERE':
                    warn = layout.row()
                    warn.alert = True
                    warn.label(
                        text="外周リブは円柱 / 立方体で使用",
                        icon='ERROR',
                    )
                elif ring_layout["ok"]:
                    layout.label(
                        text=(
                            "安全判定: OK / "
                            f"最大リブ幅 約 {ring_layout['max_width'] * s.global_scale:.3f}"
                        ),
                        icon='CHECKMARK',
                    )
                    layout.label(
                        text=(
                            "リブ片側クリアランス: "
                            f"{ring_layout['fit_clearance'] * s.global_scale:.3f}"
                        ),
                    )
                    layout.label(
                        text=(
                            "奥行き終端クリアランス: "
                            f"{ring_layout['axial_end_clearance'] * s.global_scale:.3f}"
                        ),
                    )

                    if (
                        s.make_motion_cut
                        and s.motion_cut_mode == 'FLAT'
                        and s.motion_angle > 0.0001
                    ):
                        layout.label(
                            text=(
                                "フラット面との実効残し: "
                                f"{ring_layout['flat_top_keep'] * s.global_scale:.3f}"
                            ),
                            icon='DRIVER_DISTANCE',
                        )
                else:
                    warn = layout.row()
                    warn.alert = True
                    warn.label(
                        text=ring_layout["reason"],
                        icon='ERROR',
                    )

            else:
                dowel_layout = calc_safe_dowel_layout(
                    s,
                    Ri,
                    Ro,
                )

                max_d = dowel_layout.get(
                    "max_diameter",
                    0.0,
                )

                if s.outer_shape == 'CUBE':
                    layout.label(
                        text="安全判定: 立方体外壁基準",
                        icon='CUBE',
                    )
                elif s.outer_shape == 'CYLINDER':
                    layout.label(
                        text="安全判定: 円柱外壁基準",
                        icon='MESH_CYLINDER',
                    )
                else:
                    layout.label(
                        text="安全判定: 球面外壁基準",
                        icon='MESH_UVSPHERE',
                    )

                if dowel_layout["ok"]:
                    layout.label(
                        text=(
                            "安全判定: OK / "
                            f"最大径 約 {max_d * s.global_scale:.3f}"
                        ),
                        icon='CHECKMARK',
                    )
                else:
                    warn = layout.row()
                    warn.alert = True
                    warn.label(
                        text=(
                            "外壁干渉の可能性 / "
                            f"最大径 約 {max_d * s.global_scale:.3f}"
                        ),
                        icon='ERROR',
                    )

        layout.prop(
            s,
            "keep_whole_socket",
        )


class VIEW3D_PT_ball_joint_info(Panel):
    bl_label = "計算 / メッシュ品質"
    bl_idname = "VIEW3D_PT_ball_joint_info"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Joint Maker"
    bl_parent_id = "VIEW3D_PT_ball_joint_maker"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _cjm_ui.visible(context,"BALL","GENERATE")

    def draw(self, context):
        layout = self.layout
        s = context.scene.ball_joint_settings

        box = layout.box()
        box.label(
            text="計算",
            icon='DRIVER',
        )

        D = s.ball_diameter
        d = s.opening_diameter
        R = D * 0.5

        h = calc_box_rise(
            D,
            d,
        )

        box.label(
            text=f"参考 h（箱の穴式）: {h * s.global_scale:.3f}",
        )

        if s.make_motion_cut:
            motion = calc_motion_analysis(
                s
            )

            if motion["geometric_retained"]:
                box.label(
                    text="推定保持: あり",
                    icon='LOCKED',
                )

                if math.isfinite(
                    motion["upward_play"]
                ):
                    box.label(
                        text=(
                            "推定上方向遊び: "
                            f"{motion['upward_play'] * s.global_scale:.3f}"
                        ),
                    )

                box.label(
                    text=(
                        "保持代: "
                        f"{motion['retention_margin'] * s.global_scale:.3f}"
                    ),
                )

            else:
                warn = box.row()
                warn.alert = True
                warn.label(
                    text="推定保持: なし",
                    icon='UNLOCKED',
                )

        else:
            effective_r = (
                estimated_effective_opening_radius(
                    s
                )
            )

            if effective_r < R:
                play = calc_socket_upward_play(
                    R,
                    s.clearance,
                    effective_r,
                )

                box.label(
                    text="推定保持: あり",
                    icon='LOCKED',
                )

                if math.isfinite(play):
                    box.label(
                        text=(
                            "推定上方向遊び: "
                            f"{play * s.global_scale:.3f}"
                        ),
                    )
            else:
                warn = box.row()
                warn.alert = True
                warn.label(
                    text="推定保持: 要確認",
                    icon='UNLOCKED',
                )

        box = layout.box()
        box.label(
            text="メッシュ品質",
            icon='MESH_DATA',
        )
        box.prop(
            s,
            "sphere_segments",
        )
        box.prop(
            s,
            "sphere_rings",
        )


class VIEW3D_PT_ball_joint_mount(Panel):
    bl_label = "Joint Mount / 本体取付"
    bl_idname = "VIEW3D_PT_ball_joint_mount"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Joint Maker"
    bl_options = {'DEFAULT_CLOSED'}

    bl_parent_id = "VIEW3D_PT_cjm_root"

    @classmethod
    def poll(cls, context):
        return _cjm_ui.visible(context,"BALL","MOUNT")

    def draw(self, context):
        layout = self.layout
        s = context.scene.ball_joint_settings

        layout.label(
            text="本体への取り付け・任意分割を行います。",
            icon='MOD_BOOLEAN',
        )
        layout.label(
            text="A/Bは従来方式、Cは本体そのものを受け側にします。",
            icon='INFO',
        )
        live = layout.box()
        live.label(text="LIVE 取付寸法ガイド", icon='DRIVER_DISTANCE')
        live.prop(s, "live_guide_enabled", text="LIVE表示を有効にする")
        if s.live_guide_enabled:
            live.prop(s, "live_view_mode", expand=True)
            live.prop(s, "live_world_enabled", text="3D位置にも重ねる")
            live.label(text="黄色: 注目 / 赤: 寸法・対象の要確認", icon='INFO')


class VIEW3D_PT_ball_joint_mount_common(Panel):
    bl_label = "取付設定"
    bl_idname = "VIEW3D_PT_ball_joint_mount_common"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Joint Maker"
    bl_parent_id = "VIEW3D_PT_ball_joint_mount"

    @classmethod
    def poll(cls, context):
        return _cjm_ui.visible(context,"BALL","MOUNT")

    def draw(self, context):
        layout = self.layout
        s = context.scene.ball_joint_settings

        layout.label(
            text=f"全体倍率: {s.global_scale:.3f}x",
            icon='FULLSCREEN_ENTER',
        )
        bj_live_focus_prop(layout, s, "mount_clearance", view_mode='MOUNT')

        if s.make_socket_shaft:
            bj_live_focus_prop(layout, s, "mount_include_socket_shaft", view_mode='MOUNT')

        bj_live_focus_prop(layout, s, "mount_make_insertion_path", view_mode='MOUNT')

        if s.mount_make_insertion_path:
            bj_live_focus_prop(layout, s, "mount_path_length", view_mode='MOUNT')
            bj_live_focus_prop(layout, s, "mount_path_direction", view_mode='MOUNT')


class VIEW3D_PT_ball_joint_mount_quick(Panel):
    bl_label = "A. クイック取付"
    bl_idname = "VIEW3D_PT_ball_joint_mount_quick"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Joint Maker"
    bl_parent_id = "VIEW3D_PT_ball_joint_mount"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _cjm_ui.visible(context,"BALL","MOUNT")

    def draw(self, context):
        layout = self.layout
        s = context.scene.ball_joint_settings

        bj_live_focus_button(layout, '取付位置をLIVE表示', 'MOUNT_TARGET', 'MOUNT')
        step = layout.box()
        step.label(
            text="1. 本体を選択 → 取付先に設定",
            icon='RESTRICT_SELECT_OFF',
        )
        step.label(
            text="2. 3Dカーソル/仮原点でジョイント位置と向きを決定",
            icon='PIVOT_CURSOR',
        )
        step.label(
            text="3. 下のボタンでジョイント生成 + 穴あけ",
            icon='MOD_BOOLEAN',
        )

        bj_live_focus_prop(layout, s, "mount_target", view_mode='MOUNT', text="取付先本体")
        layout.operator(
            BALLJOINT_OT_set_mount_target.bl_idname,
            text="アクティブを取付先に",
            icon='EYEDROPPER',
        )

        col = layout.column()
        col.scale_y = 1.3
        col.operator(
            BALLJOINT_OT_quick_mount.bl_idname,
            text="ジョイント生成 + 穴を一発作成",
            icon='MOD_BOOLEAN',
        )


class VIEW3D_PT_ball_joint_mount_reuse(Panel):
    bl_label = "B. 再利用 Mount Cutter"
    bl_idname = "VIEW3D_PT_ball_joint_mount_reuse"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Joint Maker"
    bl_parent_id = "VIEW3D_PT_ball_joint_mount"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _cjm_ui.visible(context,"BALL","MOUNT")

    def draw(self, context):
        layout = self.layout
        s = context.scene.ball_joint_settings

        bj_live_focus_button(layout, '既存Cutterの実BBoxをLIVE表示', 'MOUNT_CUTTER', 'MOUNT')
        layout.label(text='2Dは現在設定の予測 / 3Dは保存済み実BBox', icon='INFO')
        help_box = layout.box()
        help_box.label(
            text="Cutterを作る → 好きな位置へ移動/複製 → 本体へ適用",
            icon='DUPLICATE',
        )
        help_box.label(
            text="同じジョイント穴を何度でも使い回せます。",
        )

        row = layout.row(
            align=True
        )
        row.operator(
            BALLJOINT_OT_create_mount_cutter.bl_idname,
            text="Cutter作成",
            icon='ADD',
        )
        row.operator(
            BALLJOINT_OT_set_mount_cutter.bl_idname,
            text="アクティブを指定",
            icon='EYEDROPPER',
        )

        bj_live_focus_prop(layout, s, "mount_cutter", view_mode='MOUNT', text="Cutter")
        bj_live_focus_prop(layout, s, "mount_target", view_mode='MOUNT', text="適用先")
        layout.prop(
            s,
            "mount_keep_cutter_after_apply",
        )

        col = layout.column()
        col.scale_y = 1.2
        col.operator(
            BALLJOINT_OT_apply_mount_cutter.bl_idname,
            text="Mount Cutterを適用",
            icon='MOD_BOOLEAN',
        )

        note = layout.box()
        note.label(
            text="Cutter = ソケット外形 + 取付クリアランス",
            icon='INFO',
        )
        note.label(
            text="ボール/ボール軸は可動部なので穴型に含めません",
        )


class VIEW3D_PT_ball_joint_mount_body_receiver(Panel):
    bl_label = "C. 本体受け生成"
    bl_idname = "VIEW3D_PT_ball_joint_mount_body_receiver"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Joint Maker"
    bl_parent_id = "VIEW3D_PT_ball_joint_mount"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _cjm_ui.visible(context,"BALL","MOUNT")

    def draw(self, context):
        layout = self.layout
        s = context.scene.ball_joint_settings

        bj_live_focus_button(layout, '本体受け C をLIVE表示', 'BODY_CAVITY', 'BODY')
        bj_live_focus_button(layout, 'Ball/軸の位置も確認', 'BODY_SHAFT', 'BODY')
        intro = layout.box()
        intro.label(text="本体そのものをソケット壁として使います", icon='MESH_UVSPHERE')
        intro.label(text="Cでは受け外形 / ソケット肉厚 / 受け側軸を生成しません")
        intro.label(text="元本体は保持。未分割の受けを出力します", icon='LOCKED')

        target = layout.box()
        target.label(text="本体 / 位置", icon='OBJECT_DATA')
        bj_live_focus_prop(target, s, "mount_target", "MOUNT_TARGET", "BODY", "受け側にする本体")
        target.operator(
            BALLJOINT_OT_set_mount_target.bl_idname,
            text="アクティブを本体に",
            icon='EYEDROPPER',
        )
        target.prop(s, "placement_mode", expand=True)

        if s.placement_mode == 'GUIDE':
            target.prop(s, "guide_object", text="仮原点")
            row = target.row(align=True)
            row.operator(
                BALLJOINT_OT_set_guide_from_active.bl_idname,
                text="アクティブを仮原点に",
                icon='EYEDROPPER',
            )
            row.operator(
                BALLJOINT_OT_add_guide_empty.bl_idname,
                text="Empty追加",
                icon='EMPTY_AXIS',
            )

        target.prop(s, "use_reference_rotation")

        ball = layout.box()
        ball.label(text="Ball / 本体側キャビティ", icon='MESH_UVSPHERE')
        bj_live_focus_prop(ball, s, 'global_scale', focus='GLOBAL_SCALE', view_mode='BODY')
        bj_live_focus_prop(ball, s, "ball_diameter", "BALL_DIAMETER", "BODY")
        bj_live_focus_prop(ball, s, "clearance", "CLEARANCE", "BODY")
        bj_live_focus_prop(ball, s, "opening_diameter", "BODY_OPENING", "BODY")
        bj_live_focus_prop(ball, s, 'make_shaft', focus='BALL_SHAFT_DIAMETER', view_mode='BODY')

        if s.make_shaft:
            bj_live_focus_prop(ball, s, "shaft_diameter", "BALL_SHAFT_DIAMETER", "BODY")
            bj_live_focus_prop(ball, s, "shaft_length", "BALL_SHAFT_LENGTH", "BODY")

        motion = layout.box()
        motion.label(text="開口 / 可動域", icon='ORIENTATION_NORMAL')
        bj_live_focus_prop(motion, s, "body_receiver_cut_depth", "BODY_DEPTH", "BODY")

        auto_depth = body_receiver_cut_depth(s) * s.global_scale
        if s.body_receiver_cut_depth <= 1e-9:
            motion.label(text=f"自動カッター長: {auto_depth:.3f}", icon='DRIVER_DISTANCE')

        bj_live_focus_prop(motion, s, 'make_motion_cut', focus='MOTION_ANGLE', view_mode='BODY')
        if s.make_motion_cut:
            motion.prop(s, "motion_cut_mode", expand=True)
            bj_live_focus_prop(motion, s, "motion_angle", "MOTION_ANGLE", "BODY")
            bj_live_focus_prop(motion, s, "motion_shaft_clearance", "MOTION_SHAFT_CLEARANCE", "BODY")

            if s.motion_cut_mode == 'FLAT':
                try:
                    flat = calc_body_receiver_flat_cut(s)
                    if flat['feasible']:
                        motion.label(
                            text=f"C用フラット開始高さ: {flat['cut_z'] * s.global_scale:.3f}",
                            icon='DRIVER_DISTANCE',
                        )
                    else:
                        row = motion.row()
                        row.alert = True
                        row.label(text="この軸径/開口径では可動域が成立しません", icon='ERROR')
                except Exception as exc:
                    row = motion.row()
                    row.alert = True
                    row.label(text=str(exc), icon='ERROR')

        layout.prop(s, "body_receiver_hide_source")

        preview = layout.row(align=True)
        preview.operator(
            BALLJOINT_OT_body_receiver_preview.bl_idname,
            text="プレビュー",
            icon='HIDE_OFF',
        )
        preview.operator(
            BALLJOINT_OT_body_receiver_preview_clear.bl_idname,
            text="削除",
            icon='X',
        )

        col = layout.column()
        col.scale_y = 1.35
        col.operator(
            BALLJOINT_OT_body_receiver_generate.bl_idname,
            text="未分割の本体受けを生成",
            icon='MOD_BOOLEAN',
        )

        result = layout.box()
        result.label(text="出力: BodyReceiver / Ball", icon='OUTLINER_COLLECTION')
        result.label(text="分割は下の任意分割パネルで実行")
        result.label(text="500,000 faces以上は生成完了時に高負荷警告", icon='INFO')



class VIEW3D_PT_ball_joint_mount_body_split(Panel):
    bl_label = "C-2. 本体受けの任意分割"
    bl_idname = "VIEW3D_PT_ball_joint_mount_body_split"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Joint Maker"
    bl_parent_id = "VIEW3D_PT_ball_joint_mount_body_receiver"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        return _cjm_ui.visible(context,"BALL","MOUNT")

    def draw(self, context):
        layout = self.layout
        s = context.scene.ball_joint_settings
        intro = layout.box()
        intro.label(text="完成済みの受けを必要なときだけ分割します", icon='MOD_BOOLEAN')
        intro.label(text="元の受けは残し、A/Bを別メッシュとして出力")
        intro.label(text="空洞を作り直さず、閉じた立体同士の交差で分割")

        source = layout.box()
        source.prop(s, 'body_receiver_split_target', text='分割する受け')
        source.operator(BALLJOINT_OT_set_body_receiver_split_target.bl_idname,
                        text='アクティブを分割対象に', icon='EYEDROPPER')
        source.prop(s, 'body_receiver_hide_source')
        source.prop(s, 'body_receiver_show_split_guides')
        if s.body_receiver_show_split_guides:
            bj_live_focus_button(source, '分割面をLIVE表示', 'BODY_PLANE', 'BODY')
            row = source.row(align=True)
            row.operator(BALLJOINT_OT_body_receiver_preview.bl_idname,
                         text='分割プレビュー', icon='HIDE_OFF')
            row.operator(BALLJOINT_OT_body_receiver_preview_clear.bl_idname,
                         text='消去', icon='X')

        split = layout.box()
        bj_live_focus_prop(split, s, 'body_receiver_plane_axis', 'BODY_PLANE', 'BODY')
        bj_live_focus_prop(split, s, 'body_receiver_plane_offset', 'BODY_OFFSET', 'BODY')
        split.prop(s, 'body_receiver_flip')

        dowel = layout.box()
        bj_live_focus_prop(dowel, s, 'body_receiver_make_dowels', focus='BODY_DOWEL', view_mode='BODY')
        if s.body_receiver_make_dowels:
            bj_live_focus_prop(dowel, s, 'dowel_diameter', focus='DOWEL_DIAMETER', view_mode='BODY', text='丸ダボ直径')
            bj_live_focus_prop(dowel, s, 'dowel_length', focus='DOWEL_LENGTH', view_mode='BODY', text='ダボ長さ')
            bj_live_focus_prop(dowel, s, 'dowel_clearance', focus='DOWEL_CLEARANCE', view_mode='BODY', text='穴クリアランス')
            dowel.prop(s, 'dowel_outer_margin', text='キャビティからの最低残し')
            bj_live_focus_prop(dowel, s, 'body_receiver_dowel_spacing', 'BODY_DOWEL', 'BODY')
            bj_live_focus_prop(dowel, s, 'body_receiver_dowel_v_offset', 'BODY_DOWEL', 'BODY')
            try:
                _, _, _, _, _, spacing = body_receiver_dowel_layout(context, s)
                dowel.label(text=f'実効中心間隔: {spacing:.3f}', icon='DRIVER_DISTANCE')
            except Exception as exc:
                row = dowel.row()
                row.alert = True
                row.label(text=str(exc), icon='ERROR')

        layout.operator(BALLJOINT_OT_body_receiver_split.bl_idname,
                        text='本体受けをA/Bに分割', icon='MOD_BOOLEAN')
        layout.label(text='出力: BodyReceiver_A / B（元受けを保持）',
                     icon='OUTLINER_COLLECTION')


# ============================================================
# Register
# ============================================================

classes = (
    BALLJOINT_Settings,
    BALLJOINT_OT_set_guide_from_active,
    BALLJOINT_OT_add_guide_empty,
    BALLJOINT_OT_generate,
    BALLJOINT_OT_live_focus,
    BALLJOINT_OT_preview_update,
    BALLJOINT_OT_preview_clear,
    BALLJOINT_OT_set_mount_target,
    BALLJOINT_OT_set_mount_cutter,
    BALLJOINT_OT_create_mount_cutter,
    BALLJOINT_OT_apply_mount_cutter,
    BALLJOINT_OT_quick_mount,
    BALLJOINT_OT_body_receiver_preview,
    BALLJOINT_OT_body_receiver_preview_clear,
    BALLJOINT_OT_body_receiver_generate,
    BALLJOINT_OT_set_body_receiver_split_target,
    BALLJOINT_OT_body_receiver_split,
    BALLJOINT_OT_select_generated,
    VIEW3D_PT_ball_joint_maker,
    VIEW3D_PT_ball_joint_size,
    VIEW3D_PT_ball_joint_preview,
    VIEW3D_PT_ball_joint_placement,
    VIEW3D_PT_ball_joint_ball,
    VIEW3D_PT_ball_joint_socket,
    VIEW3D_PT_ball_joint_motion,
    VIEW3D_PT_ball_joint_split,
    VIEW3D_PT_ball_joint_info,
    VIEW3D_PT_ball_joint_mount,
    VIEW3D_PT_ball_joint_mount_common,
    VIEW3D_PT_ball_joint_mount_quick,
    VIEW3D_PT_ball_joint_mount_reuse,
    VIEW3D_PT_ball_joint_mount_body_receiver,
    VIEW3D_PT_ball_joint_mount_body_split,
)


def _bj_reset_live_on_open():
    """LIVE overlay is session UI, not a .blend scene setting to restore."""
    for scene in getattr(getattr(bpy, 'data', None), 'scenes', ()):
        settings = getattr(scene, 'ball_joint_settings', None)
        if settings is None:
            continue
        try:
            settings.live_guide_enabled = False
        except (AttributeError, ReferenceError, RuntimeError):
            continue
    bj_live_tag_redraw()


@_persistent
def _bj_live_load_post(_dummy):
    _bj_reset_live_on_open()


def _bj_register_load_handler():
    handlers = getattr(getattr(getattr(bpy, 'app', None), 'handlers', None),
                       'load_post', None)
    if handlers is not None and _bj_live_load_post not in handlers:
        handlers.append(_bj_live_load_post)


def _bj_unregister_load_handler():
    handlers = getattr(getattr(getattr(bpy, 'app', None), 'handlers', None),
                       'load_post', None)
    if handlers is not None and _bj_live_load_post in handlers:
        handlers.remove(_bj_live_load_post)


def register():
    if hasattr(
        bpy.types.Scene,
        "ball_joint_settings",
    ):
        raise RuntimeError(
            "別バージョンの Ball Joint Maker が既に有効です。"
            "古い ball_joint_maker_v*.py を無効化してから、この版だけを有効にしてください。"
        )

    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.ball_joint_settings = PointerProperty(
        type=BALLJOINT_Settings
    )
    _bj_register_load_handler()
    _bj_reset_live_on_open()
    bj_live_install()


def unregister():
    _bj_unregister_load_handler()
    bj_live_uninstall()
    clear_joint_preview()
    clear_body_receiver_preview()

    if hasattr(
        bpy.types.Scene,
        "ball_joint_settings",
    ):
        del bpy.types.Scene.ball_joint_settings

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
