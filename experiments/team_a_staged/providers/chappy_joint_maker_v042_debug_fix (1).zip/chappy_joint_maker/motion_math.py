"""Bounded multi-axis pose planning, independent of bpy."""
from itertools import product
from math import prod, radians
from .hinge_maker.face_hinge_math import sweep_angles

SINGLE_LIMIT=91
MULTI_LIMIT=225

def plan_poses(specs):
    """World-fixed axes, applied in specified order, all sampled combinations.
    Includes neutral and transfer range on each axis (same semantics as v0.1.1).
    Reject oversized jobs before allocating the Cartesian product.
    """
    specs=tuple(specs)
    if not 1<=len(specs)<=3: raise ValueError('1～3軸を指定してください')
    axes=tuple(s[0] for s in specs)
    if any(a not in ('X','Y','Z') for a in axes) or len(set(axes))!=len(axes):
        raise ValueError('異なるX/Y/Z軸を指定してください')
    samples=[sweep_angles(lo,hi,step) for _,lo,hi,step in specs]
    count=prod(map(len,samples));limit=SINGLE_LIMIT if len(axes)==1 else MULTI_LIMIT
    if count>limit: raise ValueError(f'{count}姿勢は上限{limit}を超えます。刻みを大きくしてください')
    return axes,tuple(product(*samples))

def rotation_matrix(matrix_type,axes,pose):
    """Column vectors; world-axis rotations applied first-to-last."""
    if len(axes)!=len(pose): raise ValueError('軸と角度の数が一致しません')
    result=matrix_type.Identity(4)
    for axis,angle in zip(axes,pose):
        result=matrix_type.Rotation(radians(angle),4,axis) @ result
    return result

def pose_label(axes,pose):
    return ' / '.join(f'{axis}{angle:g}°' for axis,angle in zip(axes,pose))
