"""Pure chain transforms and conservative separation checks."""
from math import sqrt, isfinite

def validate_registration(root):
    """Shared gate for generation and the legacy paired dimension planner."""
    objects=[root.object_a,root.object_b,root.object_c]
    if any(o is None or o.type!='MESH' or not o.data for o in objects) or len({o.as_pointer() for o in objects})!=3:
        raise ValueError('異なる3個のメッシュ A/B/C を登録してください')
    if root.face_bu==root.face_bl:
        raise ValueError('中央Bの上側と下側は異なる面を指定してください')


def dot(a,b): return sum(x*y for x,y in zip(a,b))
def sub(a,b): return tuple(x-y for x,y in zip(a,b))
def norm(v): return sqrt(dot(v,v))
def unit(v):
    n=norm(v)
    if not isfinite(n) or n<1e-8: raise ValueError('上下の軸中心を離してください')
    return tuple(x/n for x in v)

def interval(plan,direction,origin):
    """Conservative projection of all new knuckles and support beams."""
    p=dot(sub(plan['pivot'],origin),direction); a=dot(plan['axis'],direction); s=plan['span']
    r=s.outer_radius*sqrt(max(0.,1-a*a))
    axial=[p+a*s.a_outer,p+a*s.b_outer]
    lo,hi=min(axial)-r,max(axial)+r
    for beam in plan['beams']:
        ends=[dot(sub(beam[k],origin),direction) for k in ('start','end')]
        pad=sqrt(beam['width']**2+beam['thickness']**2)/2
        lo=min(lo,min(ends)-pad);hi=max(hi,max(ends)+pad)
    return lo,hi

def separation(upper,lower):
    origin=upper['pivot']; direction=unit(sub(lower['pivot'],origin))
    u=interval(upper,direction,origin);l=interval(lower,direction,origin)
    if u[1]>=l[0]-1e-6:
        raise ValueError('上下の新規加工領域が重なる可能性があります。軸間隔・支持部寸法を見直してください')
    return l[0]-u[1]

def transforms(Matrix,upper,lower,angles):
    """World-space neutral frames: A unchanged; B rotates about upper;
    C first rotates about lower in neutral coordinates, then follows B."""
    from math import radians
    def turn(p,angle):
        c=p['pivot'];return Matrix.Translation(c) @ Matrix.Rotation(radians(angle),4,p['axis']) @ Matrix.Translation(-c)
    b=turn(upper,angles[0]);return Matrix.Identity(4),b,b@turn(lower,angles[1])

def samples(lo,hi):
    if not all(isfinite(x) for x in (lo,hi)) or not -180<=lo<=hi<=180:raise ValueError('可動角範囲が不正です')
    return tuple(sorted({0.,lo,hi,(lo+hi)/2}))
