# Chappy Joint Maker v0.1.0 — 統合UI試作版

## 導入
1. 作業中の .blend を別名保存する。
2. プリファレンス > アドオンで旧 Ball Joint Maker と Hinge Maker + Face Hinge を無効化（必要ならアンインストール）。両方の旧版と本版を同時に有効にしない。
3. Blender を再起動し、ZIPを「ディスクからインストール」、Chappy Joint Maker を有効にする。
4. 3Dビューの N > Joint Maker を開く。

## 機構の選択
- ボールジョイント: 単体生成 / 本体取付・分割。旧 Ball Joint v0.8.9 の本体受け生成、任意分割、クイック取付等を保持。
- 回転ジョイント: Face Hinge v0.2.5 の A-B 支持腕。肩付き軸（抜け止め頭）は既存のON/OFFを保持。
- 通常ヒンジ: Hinge Maker v0.5.16 の ABA/BAB、止まり穴等を保持。
- 側面直付け軸: Face Hinge TRUNNION。A=外側受け、B=未分割ソケット、3Dカーソル=軸中心。面登録不要。

## 寸法ガイド
左の寸法アイコン: 上部の断面説明図を切替。3D LIVEはONにしない。数値変更でも既存の注目コールバックに連動。右の目アイコン: 対応する設定を選び、3D LIVEをONにする。上の「寸法説明図」をOFFにすると図を隠せる。機構選択時は旧LIVEを消し、寸法値は維持。球と受け、軸と頭、穴とすき間などを描き分けた109枚のPNG（切替用・OFF時の差分を含む）。図は固定の模式図で、入力数値に応じた実寸変形ではない。Blenderの標準パネルを使用。

## 3D LIVE
起動時OFF。全体／注目／デバッグを共通選択できる。各エンジンの既存描画を使い、注目では該当グループを優先、デバッグでは従来の詳細描画（面指定ヒンジの角度両端も含む）を残す。厳密に選択部位だけを抽出するわけではない。赤い診断は維持。通常ヒンジの詳細表示モードなど旧設定も残す。実モデルの形状を変えない。

## 互換性と限界
- 生成エンジン、既存オペレータIDとScene設定名を維持。旧版との同時有効化を拒否。旧 .blend の設定互換は実機で要確認。
- 回転ジョイントと側面直付け軸は同じFace Hinge設定を共有（元実装と同じ）。
- 統合UIを先行。取付エンジンの完全共通化、新規の独立肩付き軸生成や共通分割ツール、全機構の厳密な可動干渉検査は今回未追加。旧機能の移植優先。
- Blender実機UI、GPU、Boolean、スライサー・実印刷は未検証。3D LIVEは形状予測であり製造保証ではない。

最新版 v0.1.6: README_v016.md / DEBUG_CHECKLIST_v016.md を参照。

最新版 v0.2.4: README_v024.md / DEBUG_CHECKLIST_v024.md を参照。

最新版 v0.3.8: README_v038.md / DEBUG_CHECKLIST_v038.md を参照。

最新版 v0.3.9: README_v039.md / DEBUG_CHECKLIST_v039.md を参照。

最新版 v0.4.0: README_v040.md / DEBUG_CHECKLIST_v040.md を参照。

最新版 v0.4.1: README_v041.md / DEBUG_CHECKLIST_v041.md を参照。

最新版 v0.4.2: README_v042.md / DEBUG_CHECKLIST_v042.md を参照。
