"""Explicit one- or two-dimension adoption, after fresh isolated verification. No mesh commit."""
import hashlib
from math import isfinite
from struct import pack
from . import shape_trials as trials, shape_comparison as comparison


def mesh_digest(mesh):
    h=hashlib.sha256()
    def add(fmt,*values):h.update(pack('<'+fmt,*values))
    add('QQQ',len(mesh.vertices),len(mesh.edges),len(mesh.polygons))
    for v in mesh.vertices:add('3d',*v.co)
    for e in mesh.edges:add('2Q',*e.vertices)
    for p in mesh.polygons:
        add('Q',len(p.vertices))
        for v in p.vertices:add('Q',v)
    return h.hexdigest()


def source_signature(context,s):
    """Raw and evaluated geometry used by planning and staging; not all scene state."""
    dg=context.evaluated_depsgraph_get();result=[]
    for o in (s.object_a,s.object_b,s.object_c):
        if o is None or o.type!='MESH':raise ValueError('元メッシュがありません')
        ev=o.evaluated_get(dg);mesh=ev.to_mesh()
        try:
            if mesh is None:raise ValueError('評価済みメッシュがありません')
            result.append((o.as_pointer(),tuple(x for row in o.matrix_world for x in row),mesh_digest(o.data),mesh_digest(mesh)))
        finally:ev.to_mesh_clear()
    return tuple(result)


def passing_item(payload,advice,items,index,*,allow_pair=False):
    record=comparison.display(payload,advice)
    if not record or record['status']!='DONE' or not 0<=index<len(items):raise ValueError('完了した比較結果が必要です')
    rows=record['rows']
    if len(rows)!=len(items) or any(r['item']!=i for r,i in zip(rows,items)) or rows[index]['result']['status']!='PASS':
        raise ValueError('生成時検査を通過した候補のみ適用できます')
    if "changes" in items[index]:
        if not allow_pair:raise ValueError("連動候補には明示的な一括適用が必要です")
        changes=items[index]["changes"]
        if len(changes)!=2 or changes[0]["side"]!=changes[1]["side"] or changes[0]["key"]==changes[1]["key"]:
            raise ValueError("同じ側の異なる2寸法が必要です")
    return items[index]


def verify(expected,base,trial,attempt,check):
    check();original=attempt(base);check()
    if original.status!='FAILED' or original.diagnostic is None or not trials.matches(expected,original.diagnostic):
        raise ValueError('元の失敗を再現できません：'+original.message)
    result=attempt(trial);check()
    if result.status!='PASS':raise ValueError('候補の再検証失敗：'+result.message)


def commit(read,write,restore,finish,original,key,value):
    return commit_many(read,write,restore,finish,original,{key:value})


def commit_many(read,write,restore,finish,original,changes):
    """One logical transaction; caller suspends RNA constraint callbacks.
    Intermediate writes are checked, never independently accepted.
    """
    if not 1<=len(changes)<=2 or any(k not in original or not isfinite(v) or v==original[k] for k,v in changes.items()):
        raise ValueError('適用寸法が無効です')
    if read()!=original:raise RuntimeError('適用直前に寸法が変化しました')
    expected=dict(original)
    try:
        for key,value in changes.items():
            write(key,value);expected[key]=value
            if read()!=expected:raise ValueError('丸め・予定外の寸法変更を検出')
        finish()
        if read()!=expected:raise ValueError('適用後に寸法が変化しました')
    except Exception as e:
        try:remaining=restore(original)
        except Exception as rollback:raise RuntimeError('復元未完了：'+str(rollback)) from e
        if remaining or read()!=original:raise RuntimeError('復元未完了：'+', '.join(remaining or [])) from e
        raise
