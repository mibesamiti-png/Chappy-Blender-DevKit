"""Live dimension overlay: lightweight, non-destructive, no Boolean on edit.

Blender 4.0+ VIEW_3D POST_PIXEL handler. Installed only in Blender by register().
The colored schematic is intentionally not a preview of the Boolean output.
"""
import bpy
from .. import ui as _cjm_ui
import blf
import gpu
from gpu_extras.batch import batch_for_shader

from .live_guide_math import FOCUS_INFO, make_guide_plan, numeric_focus_value
from .dimension_diagnostics import (inspect_dimensions, DimensionIssue,
                                    focus_from_error)
from .live_wire_math import make_wire_plan, cylinder_edges

_HANDLE = None
_3D_ERROR_REPORTED = False
_BLUE = (.23, .62, .89, .88)
_ORANGE = (.98, .61, .27, .88)
_YELLOW = (1.0, .90, .30, 1.0)
_DARK = (.04, .07, .10, .90)
_LIGHT = (.96, .97, .98, 1.0)
_MUTED = (.67, .75, .83, 1.0)
_TEAL = (.31, .91, .75, .92)
_RED = (1., .27, .31, 1.)


def tag_redraw(context=None):
    """Refresh guide without changing the object graph or rebuilding a preview."""
    try:
        for screen in bpy.data.screens:
            for area in screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
    except (AttributeError, RuntimeError, ReferenceError):
        if context and getattr(context, 'area', None):
            context.area.tag_redraw()


def install():
    global _HANDLE
    if _HANDLE is None:
        _HANDLE = bpy.types.SpaceView3D.draw_handler_add(_draw, (), 'WINDOW', 'POST_PIXEL')
    tag_redraw()


def uninstall():
    global _HANDLE
    if _HANDLE is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_HANDLE, 'WINDOW')
        _HANDLE = None
    tag_redraw()


def _rect(shader, x, y, w, h, color):
    batch = batch_for_shader(shader, 'TRIS', {'pos': ((x, y), (x+w, y), (x+w, y+h),
                                                     (x, y), (x+w, y+h), (x, y+h))})
    shader.bind()
    shader.uniform_float('color', color)
    batch.draw(shader)


def _lines(shader, points, color, width=1.5):
    if len(points) < 2:
        return
    gpu.state.line_width_set(width)
    shader.bind()
    shader.uniform_float('color', color)
    batch_for_shader(shader, 'LINES', {'pos': points}).draw(shader)


def _text(x, y, content, size=12, color=_LIGHT):
    if not content:
        return
    font = 0
    blf.position(font, x, y, 0)
    blf.size(font, size)
    blf.color(font, *color)
    blf.draw(font, str(content))


def _draw():
    context = bpy.context
    if (getattr(context, 'region', None) is None or
            getattr(context.region, 'type', '') != 'WINDOW' or
            getattr(context, 'scene', None) is None or
            not hasattr(context.scene, 'hinge_maker_settings')):
        return
    s = context.scene.hinge_maker_settings
    if not s.guide_enabled or not _cjm_ui.engine_visible(context,"hinge"):
        return
    # Lightweight planning ONLY: failed bores must not erase the whole guide.
    error = None
    plan = None
    issues = ()
    try:
        from . import resolved_hinge_geometry, _blind_bore_plan
        specs, axle, total = resolved_hinge_geometry(s)
        issues = inspect_dimensions(s, specs, axle)
        holes = ()
        if (s.hinge_style == 'INTEGRATED_AXLE' and s.axle_end_mode == 'BLIND'):
            try:
                holes = _blind_bore_plan(s, specs, axle, total)
            except (ValueError, RuntimeError) as exc:
                error = str(exc)
                if not any(i.focus == 'CAP_WALL' for i in issues):
                    issues += (DimensionIssue(focus_from_error(error), error),)
        plan = make_guide_plan(
            specs, axle, total, blind_bores=holes,
            end_mode=s.axle_end_mode, hinge_style=s.hinge_style,
            allow_incomplete=True, tip_clearance=s.axle_tip_clearance)
    except (RuntimeError, ValueError, TypeError, ZeroDivisionError) as exc:
        error = str(exc)
        issues = inspect_dimensions(s)
        issues += (DimensionIssue(focus_from_error(error), error),)
        # Approximate fallback is labelled as a diagram, not real geometry.
        # Preserve a visible guide even with impossible total/gap ratios.
        try:
            total = max(float(s.total_length), .1)
            gap = max(0., float(s.knuckle_gap))
            side = max(.1, (total - 2 * gap) / 3)
            center_length = side
            approx_total = side * 2 + center_length + 2 * gap
            owners = ('A', 'B', 'A') if s.layout_mode=='ABA' else ('B', 'A', 'B')
            specs = ((owners[0], -approx_total/2+side/2, side,'Left'),
                     (owners[1], 0., center_length,'Center'),
                     (owners[2], approx_total/2-side/2,side,'Right'))
            plan = make_guide_plan(specs,None,approx_total,
                                   hinge_style='THROUGH_PIN',allow_incomplete=True)
        except (RuntimeError, ValueError, TypeError, ZeroDivisionError):
            pass
    try:
        _render(context, s, plan, error, issues)
    except (RuntimeError, ValueError, TypeError, AttributeError):
        # Never let a drawing problem interfere with Blender or hinge creation.
        pass


def _render(context, s, plan, error, issues=()):
    global _3D_ERROR_REPORTED
    rw = context.region.width
    rh = context.region.height
    if rw < 430 or rh < 270:
        return
    width = min(420, rw - 36)
    height = 233 if issues or error else 205
    x = 20
    y = min(rh - height - 24, 78)
    focus = s.guide_focus if s.guide_focus in FOCUS_INFO else 'OVERVIEW'
    title, explanation = FOCUS_INFO[focus]
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    gpu.state.blend_set('ALPHA')
    try:
        # Draw real-cursor guides behind the explanatory card, not over text.
        failed = {issue.focus for issue in issues}
        if plan is not None and s.guide_scene_enabled:
            try:
                _render_world_positions(shader, context, s, plan, focus, failed)
            except Exception as exc:
                # The 3D overlay is optional. It must never blank the 2D
                # diagnostic card or interrupt mesh generation. Only print
                # once to avoid flooding the console on every redraw frame.
                if not _3D_ERROR_REPORTED:
                    print(f"Hinge Maker: 3D guide skipped: {exc}")
                    _3D_ERROR_REPORTED = True
        _rect(shader, x, y, width, height, _DARK)
        _rect(shader, x, y+height-3, width, 3, _RED if issues or error else _TEAL)
        _text(x+14, y+height-25, 'Hinge Maker  |  LIVE 寸法ガイド', 13, _LIGHT)
        _text(x+14, y+height-47, title, 13,
              _RED if focus in failed else _YELLOW)
        value = numeric_focus_value(focus, s, plan.total if plan else None)
        _text(x+width-105, y+height-47, value, 12,
              _RED if focus in failed else _YELLOW)
        _text(x+14, y+height-65, explanation[:60], 10, _MUTED)
        if plan is not None:
            _render_schematic(shader, s, plan, focus, x+24, y+63,
                              width-48, 76, failed)
        if issues:
            _text(x+14, y+43, '要修正: '+issues[0].message[:49], 11, _RED)
            if len(issues) > 1:
                _text(x+14, y+27, f'他に {len(issues)-1} 件の寸法警告（右側の設定欄に表示）', 10, _RED)
        elif error:
            _text(x+14, y+43, '要修正: '+error[:50], 11, _RED)
        else:
            _text(x+14, y+39, '青=A / 橙=B / 黄色=注目箇所', 10, _MUTED)
        _text(x+14, y+8, '赤=寸法の要修正箇所 | 模式図・Boolean/スライス非検証', 10, _MUTED)

    finally:
        gpu.state.line_width_set(1.0)
        gpu.state.blend_set('NONE')


def _render_schematic(shader, s, plan, focus, left, base, width, height, failed=()):
    # Exact projected axial positions; radial bands are illustrative only.
    scale = width / max(plan.right-plan.left, 1e-7)
    xx = lambda z: left + (z-plan.left)*scale
    cy = base + height*0.48
    h = 43
    by_owner = {'A': _BLUE, 'B': _ORANGE}
    for segment in plan.segments:
        px, w = xx(segment.start), max(.75, (segment.end-segment.start)*scale)
        _rect(shader, px, cy-h/2, w, h, by_owner[segment.owner])
        _text(px+max(1, w/2-6), cy+7, segment.owner, 11)
    # Red regions persist even when the focused setting is a different one.
    if 'CAP_WALL' in failed:
        for index in (0, 2):
            seg = plan.segments[index]
            marker_len = max(3, min(18, (seg.end-seg.start)*scale*.28))
            start_x = xx(seg.start) if index==0 else xx(seg.end)-marker_len
            _rect(shader, start_x, cy-h/2-4, marker_len, h+8, (.95,.12,.20,.65))
    if 'SIDE_LENGTH' in failed or 'TOTAL_LENGTH' in failed:
        for index in (0,2):
            seg = plan.segments[index]
            _lines(shader, [(xx(seg.start),cy-h/2-6),(xx(seg.end),cy-h/2-6)],_RED,3.5)
    if 'CENTER_LENGTH' in failed or 'AXLE_LENGTH' in failed:
        seg = plan.segments[1]
        _lines(shader,[(xx(seg.start),cy+h/2+6),(xx(seg.end),cy+h/2+6)],_RED,3.5)
    # Axial clearances (two bands between colored knuckles).
    for a, b in plan.gaps:
        _rect(shader, xx(a), cy-h/2-7, max(1, xx(b)-xx(a)), h+14,
              _RED if 'KNUCKLE_GAP' in failed else (_YELLOW if focus == 'KNUCKLE_GAP' else (.8,.8,.8,.17)))
    # Bore / shaft are drawn over colored solids for clarity. The central
    # barrel is *never* drawn as hollow in INTEGRATED_AXLE mode.
    if (focus in ('FACE_CLEARANCE', 'BODY_RELIEF') or 'FACE_CLEARANCE' in failed) and s.make_body_relief:
        from .end_geometry import resolve_face_clearance
        try:
            fc = resolve_face_clearance(s.knuckle_gap, s.face_clearance_follow_gap,
                                        s.face_clearance)
        except ValueError:
            # Still draw out-of-range face clearance in red, not blank.
            fc = s.knuckle_gap if s.face_clearance_follow_gap else s.face_clearance
        for i, seg in enumerate(plan.segments):
            dist = fc if focus == 'FACE_CLEARANCE' else 0
            radial = min(14, max(2, s.body_relief_clearance / max(s.outer_diameter, .001) * 42))
            z0 = max(plan.left, seg.start-dist)
            z1 = min(plan.right, seg.end+dist)
            padding = radial if focus == 'BODY_RELIEF' else 2
            _lines(shader, [(xx(z0), cy-h/2-padding), (xx(z1), cy-h/2-padding),
                            (xx(z0), cy+h/2+padding), (xx(z1), cy+h/2+padding)],
                           _RED if 'FACE_CLEARANCE' in failed else _TEAL, 2.5)
    hole_h = 10 + min(12, max(0, 2*s.pin_clearance/max(s.pin_diameter, 0.01) * 10))
    for a, b in plan.bores:
        _rect(shader, xx(a), cy-hole_h/2, max(.5, xx(b)-xx(a)), hole_h,
              (.045,.075,.105,.92))
    if plan.axle:
        az, bz = plan.axle
        shaft_h = max(4, hole_h - 2*max(2, s.pin_clearance/max(s.pin_diameter,.01)*12))
        _rect(shader, xx(az), cy-shaft_h/2, max(.5, xx(bz)-xx(az)), shaft_h,
              _YELLOW if focus in ('AXLE_LENGTH','PIN_DIAMETER') else _ORANGE)
    if focus in ('PIN_CLEARANCE','PIN_DIAMETER','RADIAL_WALL') or 'RADIAL_WALL' in failed:
        # Vertical marker clearly shows radial (not axial) clearance.
        ax = plan.bores[0] if plan.bores else (plan.left, plan.right)
        marker_x = (xx(ax[0]) + xx(ax[1]))*.5
        _lines(shader, [(marker_x, cy-hole_h/2), (marker_x, cy-hole_h*.2),
                        (marker_x-5, cy-hole_h/2), (marker_x+5, cy-hole_h/2)],
                       _RED if 'RADIAL_WALL' in failed else _YELLOW, 2.5)
    if focus in ('AXLE_TIP','CAP_WALL'):
        portions = plan.tips if focus == 'AXLE_TIP' else plan.caps
        for a, b in portions:
            _rect(shader, xx(a), cy-h/2-12, max(1, xx(b)-xx(a)), 5, _YELLOW)
            _lines(shader, [(xx(a),cy-h/2-16),(xx(a),cy+h/2+4),
                            (xx(b),cy-h/2-16),(xx(b),cy+h/2+4)],_YELLOW,2)
    if focus == 'SIDE_LENGTH':
        for seg in (plan.segments[0], plan.segments[2]):
            _lines(shader,[(xx(seg.start),cy+h/2+10),(xx(seg.end),cy+h/2+10)],
                   _RED if 'SIDE_LENGTH' in failed else _YELLOW,3)
    if focus == 'CENTER_LENGTH':
        seg=plan.segments[1]
        _lines(shader, [(xx(seg.start),cy-h/2-12),(xx(seg.end),cy-h/2-12)], _YELLOW, 3)
    if focus == 'TOTAL_LENGTH':
        _lines(shader,[(xx(plan.left),cy-h/2-13),(xx(plan.right),cy-h/2-13)],_YELLOW,3)
    if focus == 'DIAMETER':
        seg=plan.segments[1]
        px=xx((seg.start+seg.end)*.5)
        _lines(shader,[(px,cy-h/2),(px,cy+h/2)],_YELLOW,3)
    if focus.startswith('BRIDGE_'):
        seg=plan.segments[1]
        px=xx((seg.start+seg.end)*.5)
        _rect(shader, px-8,cy+h/2-3,16,18,_TEAL)
        _rect(shader,px-35,cy+h/2+15,70,8,_MUTED)
        if focus == 'BRIDGE_REACH':
            _lines(shader,[(px+25,cy+h/2),(px+25,cy+h/2+23)],_YELLOW,3)
        else:
            _lines(shader,[(px-10,cy+h/2+16),(px+10,cy+h/2+16)],_YELLOW,3)


def _render_world_positions(shader, context, s, plan, focus, failed=()):
    """Project planned 3D cylinder edges around the real 3D cursor and axis.

    Wire annotations are nondestructive and follow the dimension plan; they
    are NOT actual Boolean output, true body surfaces or a slicer check.
    """
    from mathutils import Vector
    from bpy_extras.view3d_utils import location_3d_to_region_2d
    from . import get_axis_world

    area = getattr(context, 'area', None)
    space = getattr(context, 'space_data', None)
    if (area is None or area.type != 'VIEW_3D' or
            space is None or space.type != 'VIEW_3D'):
        return
    rv3d = getattr(space, 'region_3d', None)
    if rv3d is None:
        return
    center = context.scene.cursor.location
    axis = get_axis_world(context, s)
    reference = Vector((1, 0, 0))
    if abs(axis.dot(reference)) > .90:
        reference = Vector((0, 1, 0))
    u = (reference - axis * axis.dot(reference)).normalized()
    v = axis.cross(u).normalized()

    def project(z, x=0.0, y=0.0):
        world = center + axis * z + u * x + v * y
        point = location_3d_to_region_2d(context.region, rv3d, world)
        return None if point is None else (float(point.x), float(point.y))

    def line3(p0, p1, color, thickness=1.6):
        a, b = project(*p0), project(*p1)
        if a is not None and b is not None:
            _lines(shader, (a, b), color, thickness)

    def ring(z, radius, color, thickness=1.6, segments=28):
        if radius <= 0:
            return
        from math import pi, cos, sin
        pairs = []
        for i in range(segments):
            t1, t2 = 2*pi*i/segments, 2*pi*(i+1)/segments
            a = project(z, radius*cos(t1), radius*sin(t1))
            b = project(z, radius*cos(t2), radius*sin(t2))
            if a is not None and b is not None:
                pairs.extend((a, b))
        if pairs:
            _lines(shader, pairs, color, thickness)

    def label(z, radius, message, color):
        p = project(z, radius, 0)
        if p is not None:
            _text(p[0]+6, p[1]+6, message, 11, color)

    mode = getattr(s, 'guide_3d_mode', 'ALL')
    st=_cjm_ui.state(context.scene)
    if st and st.face_view=='DEBUG': mode='CLEARANCE' if focus in ('BODY_RELIEF','FACE_CLEARANCE') else 'ALL'
    elif st and st.face_view=='FOCUS':
        mode={'PIN_DIAMETER':'AXLE','AXLE_LENGTH':'AXLE','AXLE_TIP':'AXLE','PIN_CLEARANCE':'CLEARANCE','RADIAL_WALL':'CLEARANCE','CAP_WALL':'BORE','KNUCKLE_GAP':'KNUCKLE','DIAMETER':'KNUCKLE','SIDE_LENGTH':'KNUCKLE','CENTER_LENGTH':'KNUCKLE','TOTAL_LENGTH':'KNUCKLE','BODY_RELIEF':'CLEARANCE','FACE_CLEARANCE':'CLEARANCE'}.get(focus,mode)
    cylinders, markers = make_wire_plan(plan, s, mode=mode, focus=focus, failed=failed)
    if st and st.face_view=='FOCUS':
        warnings_c, warnings_m=make_wire_plan(plan,s,mode='ERRORS',focus=focus,failed=failed)
        cylinders=tuple(dict.fromkeys((*cylinders,*warnings_c)))
        markers=tuple(dict.fromkeys((*markers,*warnings_m)))
    out_r = s.outer_diameter * .5
    shaft_r = s.pin_diameter * .5
    hole_r = shaft_r + s.pin_clearance

    # Draw cutter/hole envelopes before the solid axis so the latter remains
    # visually distinguishable. These are projected outlines, not depth-tested
    # geometry; the user can hide groups with the mode selector.
    order = {'RELIEF':0, 'KNUCKLE':1, 'BORE':2, 'AXLE':3}
    for item in sorted(cylinders, key=lambda item: order[item.kind]):
        color = (_RED if item.warning else
                 _TEAL if item.focus == focus and focus != 'OVERVIEW' else
                 _BLUE if item.kind == 'KNUCKLE' and item.owner == 'A' else
                 _ORANGE if item.kind == 'KNUCKLE' and item.owner == 'B' else
                 (.43, .86, 1., .82) if item.kind == 'BORE' else
                 (.42, .91, .73, .43) if item.kind == 'RELIEF' else
                 _ORANGE)
        width = 3.0 if item.warning or item.focus == focus else 1.45
        pairs = []
        for a, b in cylinder_edges(item):
            pa, pb = project(*a), project(*b)
            if pa is not None and pb is not None:
                pairs.extend((pa, pb))
        if pairs:
            _lines(shader, pairs, color, width)

    for item in markers:
        if item.kind == 'RADIAL':
            if mode != 'CLEARANCE' and focus not in ('PIN_CLEARANCE', 'RADIAL_WALL') and not item.warning:
                continue
            color = _RED if item.warning or 'RADIAL_WALL' in failed else _YELLOW
            for sign in (-1,1):
                line3((item.start, shaft_r*sign, 0),
                      (item.start, hole_r*sign, 0), color, 2.5)
            continue
        if item.kind in ('GAP', 'FACE'):
            color = _RED if item.warning else (_YELLOW if focus == item.focus else _TEAL)
            line3((item.start, item.radius, 0),
                  (item.end, item.radius, 0), color, 3.2)
            line3((item.start, item.radius*.94, 0),
                  (item.start, item.radius*1.06, 0), color, 1.8)
            line3((item.end, item.radius*.94, 0),
                  (item.end, item.radius*1.06, 0), color, 1.8)
        elif item.kind in ('TIP','CAP'):
            color = _RED if item.warning else _YELLOW if focus == item.focus else _TEAL
            line3((item.start, item.radius, 0),
                  (item.end, item.radius, 0), color, 2.5)
            # End circles reveal the actual axial depth of blind bores and
            # remaining external cap material.
            if mode != 'ALL' or focus == item.focus or item.warning:
                ring(item.start, item.radius, color)
                ring(item.end, item.radius, color)

    # Avoid a cloud of labels in 'all' mode while retaining the vital axle
    # diameter / shaft length and one hole diameter. No guessed mm unit.
    if mode not in ('ERRORS',):
        shaft = next((c for c in cylinders if c.kind == 'AXLE'), None)
        hole = next((c for c in cylinders if c.kind == 'BORE'), None)
        if shaft is not None and mode in ('ALL', 'AXLE', 'CLEARANCE'):
            label((shaft.start+shaft.end)*.5, shaft.radius,
                  f'軸 Ø{s.pin_diameter:.2f} / L{shaft.end-shaft.start:.2f}',
                  _RED if shaft.warning else _YELLOW)
        if hole is not None and mode in ('ALL', 'BORE', 'CLEARANCE'):
            label((hole.start+hole.end)*.5, hole.radius,
                  f'穴 Ø{s.pin_diameter+2*s.pin_clearance:.2f}',
                  _RED if hole.warning else (.43, .86, 1., 1.))
        if mode in ('CLEARANCE', 'KNUCKLE') or focus == 'KNUCKLE_GAP':
            for a, b in plan.gaps:
                label((a+b)*.5, out_r*1.18,
                      f'隙間 {b-a:.2f}', _RED if 'KNUCKLE_GAP' in failed else _YELLOW)
        if mode in ('BORE', 'CLEARANCE') and plan.caps:
            for a,b in plan.caps:
                label((a+b)*.5, out_r*.84, f'壁 {b-a:.2f}',
                      _RED if 'CAP_WALL' in failed else _YELLOW)
