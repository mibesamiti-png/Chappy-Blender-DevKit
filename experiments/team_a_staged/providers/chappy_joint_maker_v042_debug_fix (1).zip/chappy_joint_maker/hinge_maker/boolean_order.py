"""Trusted, bpy-independent Hinge Maker Boolean ordering contract (v0.5.3).

For integrated axles, the shaft must be unioned to its owning body *last*.
Passing it as an early Union would allow the subsequent relief Difference
for the opposing barrel to erase the shaft tips (observed in v0.5.2).
"""

def ordered_boolean_operations(unions, differences, late_unions=()):
    """Return immutable (source, operation) pairs in the mechanical order.

    1. Union owning barrel(s) and support bridges into the body
    2. Difference opposing barrel relief and axle/pin hole cutters
    3. Union the integrated axle onto its centre owner, if present

    This function is used by APPLY, preview baking and MODIFIER waiting.
    """
    unions = tuple(unions)
    differences = tuple(differences)
    late_unions = tuple(late_unions)
    early_ids = {id(x) for x in unions + differences}
    if any(x is None for x in unions + differences + late_unions):
        raise ValueError('Booleanの参照元にNoneは使用できません')
    if any(id(x) in early_ids for x in late_unions):
        raise ValueError('中央一体軸はDifference前の処理に含められません')
    if len({id(x) for x in late_unions}) != len(late_unions):
        raise ValueError('中央一体軸が二重指定されています')
    return (tuple((source, 'UNION') for source in unions) +
            tuple((source, 'DIFFERENCE') for source in differences) +
            tuple((source, 'UNION') for source in late_unions))
