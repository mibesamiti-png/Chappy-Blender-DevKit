"""Pure lightweight *planned dimension* diagnostics. No Blender operations.

These measurements inspect the parameterized cylinder plan, not actual
post-Boolean wall thickness or slicer output. Never treat warnings as a
physical or print-in-place guarantee.
"""
from dataclasses import dataclass
from math import isfinite


@dataclass(frozen=True)
class DimensionIssue:
    focus: str
    message: str
    actual: float | None = None
    required: float | None = None
    side: str = ''


def inspect_dimensions(settings, specs=None, axle=None):
    issues = []
    gap = float(settings.knuckle_gap)
    tip = float(settings.axle_tip_clearance)
    outer_r = float(settings.outer_diameter) / 2
    hole_r = float(settings.pin_diameter) / 2 + float(settings.pin_clearance)
    remaining_radial = outer_r - hole_r
    radial_min = float(getattr(settings, 'minimum_radial_wall', 0.4))
    if not all(isfinite(v) for v in (gap, tip, outer_r, hole_r, radial_min)):
        return (DimensionIssue('OVERVIEW', '寸法に非数値があります'),)
    if outer_r <= 0 or hole_r <= 0:
        issues.append(DimensionIssue('PIN_DIAMETER', '外径または軸径が不正です'))
    elif remaining_radial + 1e-8 < radial_min:
        issues.append(DimensionIssue('RADIAL_WALL',
                          f'穴周囲の肉厚 {remaining_radial:.3f} / 最低 {radial_min:.3f}（不足 {radial_min-remaining_radial:.3f}）',
                          remaining_radial, radial_min))
    if settings.hinge_style == 'INTEGRATED_AXLE':
        if gap <= 0:
            issues.append(DimensionIssue('KNUCKLE_GAP', 'ナックル間クリアランスは0より大きくしてください', gap, 0.0))
        if float(settings.pin_clearance) <= 0:
            issues.append(DimensionIssue('PIN_CLEARANCE', '一体造形の軸穴クリアランスは0より大きくしてください'))
    if getattr(settings,'make_body_relief',False):
        face = gap if settings.face_clearance_follow_gap else float(settings.face_clearance)
        if face > gap + 1.e-8:
            issues.append(DimensionIssue('FACE_CLEARANCE',
                       f'端面逃げ {face:.3f} がナックル間隙 {gap:.3f} を超えています', face,gap))
    if specs is None:
        return tuple(issues)
    lengths = [float(s[2]) for s in specs]
    if any(x <= 0 for x in lengths):
        issues.append(DimensionIssue('SIDE_LENGTH' if lengths[0] <= 0 else 'CENTER_LENGTH',
                                     'ナックル長が0以下です'))
        return tuple(issues)
    if settings.hinge_style == 'INTEGRATED_AXLE' and settings.axle_end_mode == 'BLIND' and axle is not None:
        left_outer = float(specs[0][1]) - lengths[0]/2
        right_outer = float(specs[2][1]) + lengths[2]/2
        walls = (float(axle.start) - tip - left_outer,
                 right_outer - float(axle.end) - tip)
        minimum = float(settings.minimum_cap_wall)
        for label, wall in zip(('左', '右'), walls):
            if wall + 1e-8 < minimum:
                issues.append(DimensionIssue('CAP_WALL',
                            f'{label}の閉鎖壁厚 {wall:.3f} / 最低 {minimum:.3f}（不足 {minimum-wall:.3f}）',
                            wall, minimum, label))
    return tuple(issues)


def focus_from_error(message):
    """Fallback red focus when the planner itself cannot return geometry."""
    if any(v in message for v in ('閉鎖壁', '止まり穴', '穴底')):
        return 'CAP_WALL'
    if any(v in message for v in ('軸穴', '軸径', '外径')):
        return 'RADIAL_WALL'
    if any(v in message for v in ('端面逃げ', '本体逃げ')):
        return 'FACE_CLEARANCE'
    if any(v in message for v in ('ナックル間', '全長', '配分')):
        return 'TOTAL_LENGTH'
    if any(v in message for v in ('一体軸', '軸長', '軸が')):
        return 'AXLE_LENGTH'
    return 'OVERVIEW'
