"""Hinge Maker v0.5.4: bpy-independent print-in-place end geometry contracts.

All distances are along the local hinge axis, in Blender length units.
These plans are dimension checks, *not* evidence of slicer/toolpath separation.
"""
from dataclasses import dataclass
from math import isfinite


@dataclass(frozen=True)
class BoreInterval:
    label: str
    start: float
    end: float
    cap_wall: float

    @property
    def length(self):
        return self.end - self.start

    @property
    def center(self):
        return (self.start + self.end) * .5


@dataclass(frozen=True)
class TrimPlan:
    specs: tuple
    axle_start: float
    axle_end: float
    total_length: float
    side_length: float


def plan_trim_knuckles(*, layout, center_length, axle_length,
                       knuckle_gap, tip_clearance, min_side_length=0.10):
    """Shaft-first design; the nominal hinge length is an *output*.

    Open-hole A/B outer faces finish ``tip_clearance`` beyond shaft tips.
    The center barrel stays the user's requested length, and the two side
    barrels are equal. Applies equally to ABA and BAB center owners.
    """
    vals = (center_length, axle_length, knuckle_gap, tip_clearance, min_side_length)
    if not all(isfinite(v) for v in vals):
        raise ValueError('軸基準寸法に非数値があります')
    if layout not in ('ABA', 'BAB'):
        raise ValueError('ABA/BAB以外の配置です')
    if center_length <= 0 or axle_length <= 0 or knuckle_gap < 0 or tip_clearance < 0 or min_side_length <= 0:
        raise ValueError('中央長/軸長/隙間の値が不正です')
    side_length = (axle_length - center_length) * .5 - knuckle_gap + tip_clearance
    overlap = side_length - tip_clearance
    if side_length < min_side_length or overlap <= 1.e-5:
        raise ValueError('B一体軸が左右ナックル内に十分届きません。軸長を伸ばすか中央長/隙間を小さくしてください')
    total = center_length + 2 * (knuckle_gap + side_length)
    left_center = -total * .5 + side_length * .5
    right_center = total * .5 - side_length * .5
    owners = ('A', 'B', 'A') if layout == 'ABA' else ('B', 'A', 'B')
    specs = ((owners[0], left_center, side_length, 'Left'),
             (owners[1], 0.0, center_length, 'Center'),
             (owners[2], right_center, side_length, 'Right'))
    left_tip, right_tip = -axle_length * .5, axle_length * .5
    assert abs((left_center-side_length*.5)-(left_tip-tip_clearance)) < 1.e-8
    assert abs((right_center+side_length*.5)-(right_tip+tip_clearance)) < 1.e-8
    return TrimPlan(specs, left_tip, right_tip, total, side_length)


def plan_blind_bores(specs, *, axle_start, axle_end, tip_clearance,
                     min_cap_wall, opening_extension=0.02):
    """Create left/right *separate*, bounded cutter intervals.

    Each bore starts at its knuckle's inner face (with slight harmless
    overshoot into the empty gap) and terminates at axle tip plus axial
    tip-clearance. The central barrel is NOT a cutter target.
    """
    if len(specs) != 3:
        raise ValueError('3ナックルが必要です')
    vals = (axle_start, axle_end, tip_clearance, min_cap_wall, opening_extension)
    if not all(isfinite(v) for v in vals) or axle_start >= axle_end or tip_clearance < 0 or min_cap_wall <= 0 or opening_extension < 0:
        raise ValueError('止まり穴の寸法が不正です')
    left, central, right = specs
    l_center, l_len = float(left[1]), float(left[2])
    m_center, m_len = float(central[1]), float(central[2])
    r_center, r_len = float(right[1]), float(right[2])
    if not (l_center < m_center < r_center and min(l_len, m_len, r_len) > 0):
        raise ValueError('ナックルの並びが不正です')
    left_outer = l_center - l_len * .5
    left_inner = l_center + l_len * .5
    right_inner = r_center - r_len * .5
    right_outer = r_center + r_len * .5
    if left_inner >= m_center - m_len*.5 or right_inner <= m_center + m_len*.5:
        raise ValueError('止まり穴には左右のナックル隙間が必要です')
    l_bottom = axle_start - tip_clearance
    r_bottom = axle_end + tip_clearance
    l_wall = l_bottom - left_outer
    r_wall = right_outer - r_bottom
    if l_wall < min_cap_wall or r_wall < min_cap_wall:
        raise ValueError(
            f'外側の閉鎖壁厚が不足: 左{l_wall:.3f} 右{r_wall:.3f} '
            f'（必要{min_cap_wall:.3f}）。軸長/先端隙間を短くするかAを長くしてください'
        )
    l_end = left_inner + opening_extension
    r_start = right_inner - opening_extension
    if l_bottom >= l_end or r_start >= r_bottom:
        raise ValueError('軸がナックルに届かず止まり穴を作れません')
    return (BoreInterval('Left', l_bottom, l_end, l_wall),
            BoreInterval('Right', r_start, r_bottom, r_wall))


def resolve_face_clearance(knuckle_gap, follow_gap, face_clearance):
    if not all(isfinite(v) for v in (knuckle_gap, face_clearance)):
        raise ValueError('端面クリアランスに非数値があります')
    if knuckle_gap < 0 or face_clearance < 0:
        raise ValueError('端面クリアランスは0以上にしてください')
    c = knuckle_gap if follow_gap else face_clearance
    if c > knuckle_gap + 1.e-8:
        raise ValueError('端面逃げがナックル間クリアランスを超えています。自分側のナックルまで削るため値を下げてください')
    return min(c, knuckle_gap)


def print_clearance_warnings(*, knuckle_gap, radial_clearance, tip_clearance,
                             face_clearance, min_trial_gap=0.3):
    """Hints only: 0.3 is an adjustable trial threshold, not a safe guarantee."""
    vals = {'ナックル間': knuckle_gap, '軸穴片側': radial_clearance,
            '軸先端': tip_clearance, '端面逃げ': face_clearance}
    return tuple(f'{key}={value:.3f} (<試験目安{min_trial_gap:.2f})'
                 for key, value in vals.items() if value < min_trial_gap)
