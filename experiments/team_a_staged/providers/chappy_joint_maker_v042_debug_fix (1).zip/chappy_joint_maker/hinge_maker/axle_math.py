"""Pure geometric planning for Hinge Maker integral axle length (v0.5.3).

No bpy dependency. All axial coordinates share a local hinge axis with its
origin at the user cursor, and all spans are in Blender length units.
"""
from dataclasses import dataclass
from math import isfinite


@dataclass(frozen=True)
class AxleSpan:
    start: float
    end: float
    center: float
    length: float
    left_side_center: float
    right_side_center: float
    capped: bool


def plan_integrated_axle(specs, *, total_length, pin_end_extra,
                         follow_side_centers=True, prevent_overrun=True,
                         end_margin=0.10):
    """Plan an integrated axle against actual left/right knuckle intervals.

    Follow=True: tips stop at centers of side knuckles, for ABA this is the
    middle of each A barrel. When Follow=False, the legacy oversized span is
    used, optionally clipped before the *outer faces* of the side knuckles.
    """
    if len(specs) != 3:
        raise ValueError('3つのナックル指定が必要です')
    a, middle, b = specs
    if not all(len(s) >= 3 for s in specs):
        raise ValueError('ナックルの長さ情報がありません')
    values = [float(a[1]), float(a[2]), float(middle[1]), float(middle[2]),
              float(b[1]), float(b[2]), float(total_length),
              float(pin_end_extra), float(end_margin)]
    if not all(isfinite(v) for v in values):
        raise ValueError('軸長計算に非数値が含まれています')
    z_left, len_left = float(a[1]), float(a[2])
    z_mid, len_mid = float(middle[1]), float(middle[2])
    z_right, len_right = float(b[1]), float(b[2])
    if not (z_left < z_mid < z_right and len_left > 0 and len_mid > 0
            and len_right > 0 and total_length > 0 and pin_end_extra >= 0
            and end_margin >= 0):
        raise ValueError('ナックル配置/軸長設定が不正です')
    outer_left = z_left - len_left / 2
    outer_right = z_right + len_right / 2
    # Keep a practical inward tip margin but never beyond either side center.
    safe_margin = min(end_margin, len_left * 0.45, len_right * 0.45)
    safe_left = outer_left + safe_margin
    safe_right = outer_right - safe_margin
    if follow_side_centers:
        start, end = z_left, z_right
    else:
        start = -total_length / 2 - pin_end_extra
        end = total_length / 2 + pin_end_extra
    capped = False
    if prevent_overrun:
        clamped_start = max(start, safe_left)
        clamped_end = min(end, safe_right)
        capped = (clamped_start != start or clamped_end != end)
        start, end = clamped_start, clamped_end
    if not (start < end):
        raise ValueError('安全範囲内で軸長を確保できません')
    # The integrated axle must reach into the two side barrels, not stop in
    # central barrel or in the clearance gap.
    mid_left_outer = z_mid - len_mid / 2
    mid_right_outer = z_mid + len_mid / 2
    if start >= mid_left_outer or end <= mid_right_outer:
        raise ValueError('軸が左右ナックルへ届きません')
    return AxleSpan(start, end, (start + end) / 2, end - start,
                    z_left, z_right, capped)
