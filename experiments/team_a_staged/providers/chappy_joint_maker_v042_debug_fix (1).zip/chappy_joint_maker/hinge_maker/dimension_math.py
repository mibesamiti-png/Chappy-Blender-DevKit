"""Pure, Blender-independent coupled lengths for Hinge Maker v0.5.6.

For a symmetric A-B-A/B-A-B hinge, usable = 2*side + center.
Auto uses the legacy 3-equal / center-ratio allocation. Manual stores a
reference ratio and scales it whenever total length or knuckle gap changes.
Do not silently clamp an invalid edit: report it to the guide/validation.
"""
from math import isfinite


def usable_length(total_length, gap):
    if not all(isfinite(float(v)) for v in (total_length, gap)):
        raise ValueError('ヒンジ寸法に非数値があります')
    usable = float(total_length) - 2 * float(gap)
    if usable <= 0:
        raise ValueError('全長に対してナックル間クリアランスが大きすぎます')
    return usable


def auto_lengths(total_length, gap, mode, center_ratio):
    usable = usable_length(total_length, gap)
    ratio = 1.0 if mode == 'EQUAL' else float(center_ratio)
    if not isfinite(ratio) or ratio <= 0:
        raise ValueError('中央長さ倍率が正しくありません')
    side = usable / (2.0 + ratio)
    return side, side * ratio


def manual_lengths(total_length, gap, reference_usable, reference_side, reference_center):
    usable = usable_length(total_length, gap)
    values = [float(reference_usable), float(reference_side), float(reference_center)]
    if not all(isfinite(v) for v in values) or values[0] <= 0:
        raise ValueError('個別寸法の保存値が不正です。配分をリセットしてください')
    if abs((2 * values[1] + values[2]) - values[0]) > 1e-5 * max(1,values[0]):
        raise ValueError('個別寸法が全長と一致しません。配分をリセットしてください')
    scale = usable / values[0]
    return values[1] * scale, values[2] * scale


def edit_side(total_length, gap, new_side):
    usable = usable_length(total_length, gap)
    side = float(new_side)
    if not isfinite(side):
        raise ValueError('A/B寸法に非数値があります')
    return usable, side, usable - 2 * side


def edit_center(total_length, gap, new_center):
    usable = usable_length(total_length, gap)
    center = float(new_center)
    if not isfinite(center):
        raise ValueError('A/B寸法に非数値があります')
    return usable, (usable - center) / 2, center


def trim_side_length(center_length, axle_length, gap, tip_clearance):
    return (float(axle_length) - float(center_length)) / 2 - float(gap) + float(tip_clearance)


def trim_axle_from_side(center_length, side_length, gap, tip_clearance):
    return float(center_length) + 2 * (float(side_length) + float(gap) - float(tip_clearance))


def minimum_total_for_blind_cap(*, gap, center_ratio, tip_clearance, min_cap_wall):
    """Only valid for AUTO + axle ending at each side center (not arbitrary oversize)."""
    ratio = float(center_ratio)
    if not isfinite(ratio) or ratio <= 0:
        raise ValueError('倍率が不正です')
    min_side = 2 * (float(min_cap_wall) + float(tip_clearance))
    return 2 * float(gap) + min_side * (2 + ratio)
