"""Bpy-independent dimensions for the non-destructive Hinge Maker live guide.

Values come from the same resolved_hinge_geometry planning as the generator.
The guide is an illustration, not a Boolean simulation or slicer clearance proof.
"""
from dataclasses import dataclass
from math import isfinite


FOCUS_INFO = {
    'OVERVIEW': ('全体の構造', '水色=左右側、オレンジ=中央側。軸と穴の関係を表示'),
    'TOTAL_LENGTH': ('ヒンジ全長', '両外端の距離。方式Bでは軸長から自動計算'),
    'KNUCKLE_GAP': ('ナックル間', '左右のA/Bナックル端面間の軸方向すき間'),
    'PIN_CLEARANCE': ('軸と穴のすき間', '軸の半径方向の片側すき間。穴径=軸径+2×設定値'),
    'FACE_CLEARANCE': ('本体の端面逃げ', '相手ナックルを避けるBooleanの軸方向の延長量'),
    'BODY_RELIEF': ('本体の外周逃げ', '相手ナックル外周と本体ポケットの半径方向のすき間'),
    'AXLE_TIP': ('軸先端のすき間', '止まり穴では穴底まで、方式BではAの外端までの距離'),
    'CAP_WALL': ('止まり穴の外壁', '左右Aの外端に残る閉鎖壁の厚み'),
    'AXLE_LENGTH': ('一体軸の全長', '中央軸の左右先端位置とAの長さへの追従'),
    'SIDE_LENGTH': ('左右ナックルの長さ', '左右のナックル各1個の軸方向の長さ（全長と連動）'),
    'RADIAL_WALL': ('軸穴の外周肉厚', 'ナックル外側から穴の壁までの半径方向の肉厚'),
    'CENTER_LENGTH': ('中央ナックル長', '中央の円筒の長さ。方式Bは固定寸法'),
    'DIAMETER': ('ヒンジ外径', '全ナックルの外径（軸の太さとは別）'),
    'PIN_DIAMETER': ('中央軸の直径', 'Bの一体軸／独立ピンの直径'),
    'BRIDGE_EMBED': ('本体への食い込み', 'ナックルと本体をつなぐブリッジの接続深さ'),
    'BRIDGE_WIDTH': ('接続ブリッジの幅', '接続ブリッジの幅の比率'),
    'BRIDGE_REACH': ('接続距離の上限', '本体が遠すぎる場合に生成を中断する上限'),
    'LAYOUT': ('左右と中央の所属', 'ABAかBABかでA/Bの担当箇所が入れ替わる'),
}


@dataclass(frozen=True)
class GuideSegment:
    owner: str
    label: str
    start: float
    end: float


@dataclass(frozen=True)
class GuidePlan:
    segments: tuple
    gaps: tuple
    bores: tuple
    axle: tuple | None
    tips: tuple
    caps: tuple
    total: float
    left: float
    right: float
    axis_origin: float


def make_guide_plan(specs, axle_span, total_length, *, blind_bores=(),
                    end_mode='BLIND', hinge_style='INTEGRATED_AXLE',
                    allow_incomplete=False, tip_clearance=0.0):
    """Project real generator axial intervals into a stable illustration plan.

    Axial dimensions are exact input plans; radial dimensions are illustrated
    separately in the drawing. No meshes, context, modifiers or transforms.
    """
    if len(specs) != 3 or total_length <= 0 or not isfinite(total_length):
        raise ValueError('ガイドに必要な3ナックル寸法がありません')
    segments = tuple(GuideSegment(str(owner), str(label), float(z) - float(length) / 2,
                                  float(z) + float(length) / 2)
                     for owner, z, length, label in specs)
    if any(not (isfinite(s.start) and isfinite(s.end) and s.start < s.end)
           for s in segments):
        raise ValueError('ナックルの座標が不正です')
    if not all(segments[i].end < segments[i + 1].start or
               (allow_incomplete and segments[i].end <= segments[i+1].start)
               for i in range(2)):
        raise ValueError('ナックル間に正の隙間がありません')
    gaps = tuple((segments[i].end, segments[i + 1].start) for i in range(2))
    left, right = segments[0].start, segments[-1].end
    axle = None if axle_span is None else (float(axle_span.start), float(axle_span.end))
    if axle is not None and not (left <= axle[0] < axle[1] <= right):
        # Early display of inconsistent settings rather than a false diagram.
        raise ValueError('一体軸がナックル端面の外側にあります')
    if hinge_style == 'INTEGRATED_AXLE' and end_mode == 'BLIND' and axle is not None:
        if len(blind_bores) != 2 and not allow_incomplete:
            raise ValueError('止まり穴の左右区間が不足しています')
        if len(blind_bores) == 2:
            bores = tuple((float(item.start), float(item.end)) for item in blind_bores)
        else:
            # Display-only clipping: preserve an explanatory drawing even
            # when the actual blind-bore planner refuses negative wall depth.
            l_bottom = max(left, min(segments[0].end, axle[0]-tip_clearance))
            r_bottom = min(right, max(segments[2].start, axle[1]+tip_clearance))
            bores = ((l_bottom, segments[0].end), (segments[2].start, r_bottom))
        tips = ((min(bores[0][0], axle[0]), max(bores[0][0], axle[0])),
                (min(axle[1], bores[1][1]), max(axle[1], bores[1][1])))
        caps = ((left, bores[0][0]), (bores[1][1], right))
    elif hinge_style == 'INTEGRATED_AXLE' and axle is not None:
        bores = ((segments[0].start, segments[0].end),
                 (segments[2].start, segments[2].end))
        tips = ((left, axle[0]), (axle[1], right))
        caps = ()
    else:
        bores = tuple((s.start, s.end) for s in segments)
        tips = ()
        caps = ()
    if any(not (isfinite(a) and isfinite(b) and a <= b) for a, b in (*bores, *tips, *caps)):
        raise ValueError('穴/先端の区間が不正です')
    return GuidePlan(segments, gaps, bores, axle, tips, caps,
                     float(total_length), left, right, 0.0)


def numeric_focus_value(focus, settings, total_length=None):
    """Return a label (never mm without a known scene unit configuration)."""
    prop = {
        'TOTAL_LENGTH': 'total_length', 'KNUCKLE_GAP': 'knuckle_gap',
        'SIDE_LENGTH': 'side_length_edit', 'RADIAL_WALL': 'minimum_radial_wall',
        'PIN_CLEARANCE': 'pin_clearance', 'BODY_RELIEF': 'body_relief_clearance',
        'AXLE_TIP': 'axle_tip_clearance', 'CAP_WALL': 'minimum_cap_wall',
        'AXLE_LENGTH': 'trim_axle_length', 'CENTER_LENGTH': 'center_length_edit',
        'DIAMETER': 'outer_diameter', 'PIN_DIAMETER': 'pin_diameter',
        'BRIDGE_EMBED': 'bridge_embed', 'BRIDGE_WIDTH': 'bridge_width_ratio',
        'BRIDGE_REACH': 'bridge_max_reach',
    }.get(focus)
    if focus == 'FACE_CLEARANCE':
        return f'{float(settings.knuckle_gap if settings.face_clearance_follow_gap else settings.face_clearance):.3f}'
    if focus == 'TOTAL_LENGTH' and total_length is not None:
        return f'{total_length:.3f}'
    if focus == 'RADIAL_WALL':
        return f'{(settings.outer_diameter-settings.pin_diameter)*.5-settings.pin_clearance:.3f}'
    if focus == 'AXLE_LENGTH' and settings.axle_end_mode == 'BLIND':
        return '自動追従'
    if prop is None:
        return ''
    return f'{float(getattr(settings, prop)):.3f}'
