"""Face Hinge Maker v0.2.5 — opt-in experimental face-anchored print-in-place hinge.

Integrated into Hinge Maker as a collapsible child panel. Originals stay unchanged;
confirmed output is evaluated working copies. No claims of guaranteed real sweep,
mechanical strength, slicer separation, or arbitrary mesh compatibility.
"""

import math
import bpy
from .. import ui as _cjm_ui
import bmesh
from mathutils import Matrix, Vector
from bpy.props import (BoolProperty, EnumProperty, FloatProperty,
                       IntProperty, PointerProperty, StringProperty)
from bpy.types import Operator, Panel, PropertyGroup
from .face_hinge_math import plan_ab_span, plan_shoulder_head, sweep_angles, sweep_padding, rotate_xyz, plan_trunnion, guide_arrow_segments, guide_axis_segments

try:
    from bpy.app.handlers import persistent
except ImportError:
    persistent = lambda f: f

_PREVIEW_NAME = 'FaceHinge_V020_Preview'
_OLD_PREVIEW_NAMES = ('FaceHinge_V011_Preview', 'FaceHinge_V010_Preview')
_LIVE_3D = None
_LIVE_2D = None
_COL_A = (0.31, 0.66, 0.97, 0.94)
_COL_B = (1.00, 0.59, 0.25, 0.95)
_COL_GAP = (0.38, 0.94, 0.89, 0.76)
_COL_WARN = (1.00, 0.25, 0.28, 1.00)
_COL_AXIS = (1.00, 0.87, 0.16, 1.00)
_COL_AXIS_POS = (0.37, 1.00, 0.51, 1.00)
_COL_AXIS_NEG = (1.00, 0.48, 0.72, 1.00)


def _redraw(context=None):
    screen = getattr(context, 'screen', None) or getattr(bpy.context, 'screen', None)
    if screen:
        for area in screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()


def _update(self, context):
    _redraw(context)


def _update_shoulder_enabled(self, context):
    # When opting in, the larger captive head needs a sound outer A wall.
    # Make the actual changed outer diameter visible to the user instead of
    # silently creating a barrel that disagrees with the UI value.
    if self.shoulder_enabled and not _cjm_ui.constraint_active(context,"face"):
        needed = (self.shoulder_diameter +
                  2.0 * (self.shoulder_radial_clearance + self.radial_wall))
        if self.outer_diameter < needed:
            self.outer_diameter = round(needed + 0.01, 4)
    _cjm_ui.face_changed('shoulder_enabled')(self,context)
    _redraw(context)


def _axis(settings):
    vec = {
        'X': (1, 0, 0), 'Y': (0, 1, 0), 'Z': (0, 0, 1),
    }[settings.axis]
    result = Vector(vec)
    if settings.reverse_axis:
        result.negate()
    return result


def _center(context):
    return context.scene.cursor.location.copy()


def _face_vertices(obj, face_index, signature):
    if obj is None or obj.type != 'MESH' or obj.data is None:
        raise ValueError('記憶した対象がメッシュではありません')
    if not 0 <= face_index < len(obj.data.polygons):
        raise ValueError('記憶した面がなくなりました。もう一度登録してください')
    poly = obj.data.polygons[face_index]
    indices = tuple(int(x) for x in poly.vertices)
    if ','.join(map(str, indices)) != signature:
        raise ValueError('面の頂点構成が変わりました。もう一度登録してください')
    coords = [obj.matrix_world @ obj.data.vertices[i].co for i in indices]
    if len(coords) < 3 or poly.area <= 1e-10:
        raise ValueError('面積がない面は登録できません')
    # A local polygon centroid is sufficient for an attachment point; use
    # inverse transpose for a nonuniformly-scaled face normal.
    center = sum(coords, Vector((0.0, 0.0, 0.0))) / len(coords)
    normal = (obj.matrix_world.inverted_safe().transposed().to_3x3() @ poly.normal).normalized()
    if normal.length < 1e-9:
        raise ValueError('面の法線が不正です')
    return center, normal, coords


def _face(settings, side):
    return _face_vertices(getattr(settings, f'object_{side.lower()}'),
                          getattr(settings, f'face_{side.lower()}'),
                          getattr(settings, f'signature_{side.lower()}'))


def trunnion_bounds(context, settings):
    """Plan a direct-mounted twin axle on B and matching bores in A.

    Only object pointers are required here; no remembered face indices. This
    matches an existing U-shaped A receiver and a B socket body.
    """
    a, b = settings.object_a, settings.object_b
    if a is None or b is None or a == b:
        raise ValueError('異なる2つのメッシュを指定（A=受け / B=ソケット）してください')
    if a.type != 'MESH' or b.type != 'MESH' or not a.data or not b.data:
        raise ValueError('A/Bはメッシュオブジェクトにしてください')
    pivot, axis = _center(context), _axis(settings)
    # The B mesh bounds are taken from actual original vertices, not a mirrored
    # assumed cube. This supports modestly asymmetric sockets.
    if not b.data.vertices:
        raise ValueError('Bソケットが空のメッシュです')
    projections = [float((b.matrix_world @ v.co - pivot).dot(axis))
                   for v in b.data.vertices]
    return min(projections), max(projections)

def _trunnion_plan(context, settings):
    lo,hi=trunnion_bounds(context,settings)
    b=settings.object_b
    pivot,axis=_center(context),_axis(settings)
    span = plan_trunnion(socket_min=lo, socket_max=hi,
                         axle_diameter=settings.axle_diameter,
                         radial_clearance=settings.radial_clearance,
                         pin_projection=settings.pin_projection,
                         pin_embed=settings.pin_embed,
                         tip_clearance=settings.tip_clearance,
                         axial_gap=settings.axial_gap)
    # Bounds are only used for a translucent/wire *preview*, never the Boolean.
    corners = [b.matrix_world @ Vector(v) for v in b.bound_box]
    return dict(mode='TRUNNION', pivot=pivot, axis=axis, trunnion=span,
                bbox_corners=corners)


def _plan(context, settings):
    st=_cjm_ui.state(context.scene)
    if st and st.mode=='ROTARY' and getattr(st,'rotary_section','FACE')!='FACE':
        from ..common_tools import standalone_plan
        return standalone_plan(context,settings)
    if settings.mode == 'TRUNNION':
        return _trunnion_plan(context, settings)
    a = _face(settings, 'A')
    b = _face(settings, 'B')
    if settings.object_a == settings.object_b:
        raise ValueError('A/Bは異なる2つのメッシュにしてください')
    pivot, axis = _center(context), _axis(settings)
    span = plan_ab_span(a_width=settings.a_width, b_width=settings.b_width,
                     gap=settings.axial_gap, outer_diameter=settings.outer_diameter,
                     axle_diameter=settings.axle_diameter,
                     radial_clearance=settings.radial_clearance,
                     cap_wall=settings.cap_wall,
                     tip_clearance=(settings.shoulder_axial_clearance
                                    if settings.shoulder_enabled else settings.tip_clearance),
                     min_radial_wall=settings.radial_wall)
    angles = sweep_angles(settings.minimum_angle, settings.maximum_angle,
                          settings.angle_step)
    shoulder = (plan_shoulder_head(span,
                  shoulder_diameter=settings.shoulder_diameter,
                  shoulder_thickness=settings.shoulder_thickness,
                  shoulder_radial_clearance=settings.shoulder_radial_clearance,
                  shoulder_axial_clearance=settings.shoulder_axial_clearance,
                  min_radial_wall=settings.radial_wall)
                if settings.shoulder_enabled else None)
    result = dict(mode='STRAIGHT', pivot=pivot, axis=axis, span=span,
                  shoulder=shoulder, angles=angles, faces={'A':a, 'B':b})
    beams = []
    for owner, data, offsets, width in (
        ('A', a, (span.a_center,), min(settings.support_width, settings.a_width*0.85)),
        ('B', b, (span.b_center,), min(settings.support_width, settings.b_width*0.85))):
        center, normal, _ = data
        radial = center - pivot
        radial -= axis*radial.dot(axis)
        if radial.length < 1e-7:
            radial = normal - axis*normal.dot(axis)
        if radial.length < 1e-7:
            raise ValueError(f'{owner}面から軸への接続方向を決定できません')
        radial.normalize()
        if (center - pivot).length < span.outer_radius*0.30:
            raise ValueError(f'{owner}取付面がヒンジ軸へ近すぎます')
        for offset in offsets:
            beam_start = center - normal*settings.embed_depth
            # End overlaps the knuckle; avoids point-contact-only UNION.
            beam_end = pivot + axis*offset + radial*(span.outer_radius*0.65)
            if (beam_end-beam_start).length < settings.support_thickness*.25:
                raise ValueError(f'{owner}支持部が短すぎます')
            beams.append(dict(owner=owner, start=beam_start,
                              end=beam_end, width=width,
                              thickness=settings.support_thickness,
                              radial=radial, offset=offset))
    result['beams'] = beams
    reach = max((p-pivot).length for beam in beams if beam['owner']=='B'
                for p in (beam['start'], beam['end'])) + settings.support_thickness
    actual_step = max((v-u for u,v in zip(angles, angles[1:])), default=0.)
    result['sweep_padding'] = sweep_padding(reach, actual_step, settings.swing_clearance)
    return result


def _make_collection(name, scene):
    col = bpy.data.collections.new(name)
    scene.collection.children.link(col)
    return col


def _destroy_collection(col):
    if col is None:
        return
    for obj in list(col.objects):
        _remove(obj)
    bpy.data.collections.remove(col)


def _preview_clear():
    # Blender may expose _RestrictData while enabling/disabling add-ons.
    # Do not abort unregister when scene collections are unavailable.
    collections = getattr(getattr(bpy, 'data', None), 'collections', None)
    if collections is None:
        return
    for col in list(collections):
        if any(col.name == name or col.name.startswith(name + '.')
               for name in (_PREVIEW_NAME, *_OLD_PREVIEW_NAMES)):
            _destroy_collection(col)


def _link_new_mesh(name, vertices, faces, collection):
    mesh = bpy.data.meshes.new(name + '_mesh')
    mesh.from_pydata([tuple(v) for v in vertices], [], faces)
    mesh.update()
    if not mesh.polygons:
        bpy.data.meshes.remove(mesh)
        raise RuntimeError('空のメッシュが生成されました')
    obj = bpy.data.objects.new(name, mesh)
    collection.objects.link(obj)
    return obj


def _make_beam(name, start, end, axis, width, thickness, collection):
    start, end, axis = Vector(start), Vector(end), Vector(axis).normalized()
    direction = (end-start).normalized()
    side = axis.cross(direction)
    if side.length < 1e-7:
        side = direction.cross(Vector((1,0,0)))
        if side.length < 1e-7:
            side = direction.cross(Vector((0,1,0)))
    side.normalize()
    across = direction.cross(side).normalized()
    # Offsets are constant at both ends -> planar convex side quads.
    corners = (-across*width/2-side*thickness/2,
               across*width/2-side*thickness/2,
               across*width/2+side*thickness/2,
               -across*width/2+side*thickness/2)
    vertices = [start+p for p in corners] + [end+p for p in corners]
    return _link_new_mesh(name, vertices,
                          [(0,1,2,3), (7,6,5,4),
                           (4,5,1,0), (5,6,2,1),
                           (6,7,3,2), (7,4,0,3)], collection)


def _make_cylinder(name, center, axis, radius, depth, collection, segments=48):
    if radius <= 0 or depth <= 0:
        raise ValueError('円柱の寸法が不正です')
    axis = Vector(axis).normalized()
    x = axis.cross(Vector((0,0,1)))
    if x.length < 1e-7:
        x = axis.cross(Vector((0,1,0)))
    x.normalize()
    y = axis.cross(x).normalized()
    center = Vector(center)
    vertices = []
    for offset in (-depth/2, depth/2):
        for i in range(segments):
            angle = 2*math.pi*i/segments
            vertices.append(center + axis*offset + radius*(x*math.cos(angle)+y*math.sin(angle)))
    faces = [tuple(reversed(range(segments))), tuple(range(segments,segments*2))]
    faces.extend((i,(i+1)%segments,(i+1)%segments+segments,i+segments)
                 for i in range(segments))
    return _link_new_mesh(name, vertices, faces, collection)


def _boolean(target, cutter, operation):
    if not target or not cutter:
        raise RuntimeError('Boolean対象またはカッターがありません')
    for obj in bpy.context.selected_objects:
        obj.select_set(False)
    target.hide_set(False)
    target.select_set(True)
    bpy.context.view_layer.objects.active = target
    modifier = target.modifiers.new('FaceHinge_' + operation, 'BOOLEAN')
    modifier.operation = operation
    modifier.solver = 'EXACT'
    modifier.object = cutter
    try:
        bpy.ops.object.modifier_apply(modifier=modifier.name)
    except Exception as exc:
        if target.modifiers.get(modifier.name) is not None:
            target.modifiers.remove(modifier)
        raise RuntimeError(f'{target.name}: {operation} に失敗: {exc}') from exc
    if len(target.data.polygons) == 0:
        raise RuntimeError(f'{target.name}: {operation} で全形状が消えました')


def _mesh_components(mesh):
    """Count connected mesh islands; used only as a relative safety gate."""
    count = len(mesh.vertices)
    if count == 0:
        return 0
    parent = list(range(count))
    def root(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i
    for e in mesh.edges:
        a, b = e.vertices
        a, b = root(int(a)), root(int(b))
        if a != b:
            parent[b] = a
    return len({root(i) for i in range(count)})


def _closed_mesh_volume(mesh):
    """Unsigned volume of a closed receiver mesh; None for open geometry."""
    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        if not bm.faces or any(not edge.is_manifold for edge in bm.edges):
            return None
        return float(bm.calc_volume(signed=False))
    finally:
        bm.free()


def _make_stage(original, col, label, depsgraph):
    evaluated = original.evaluated_get(depsgraph)
    mesh = bpy.data.meshes.new_from_object(evaluated, depsgraph=depsgraph)
    if mesh is None or len(mesh.polygons) == 0:
        raise RuntimeError(f'{label}の評価済みメッシュが空です')
    obj = bpy.data.objects.new(f'FaceHinge_{label}_PRINT', mesh)
    obj.matrix_world = original.matrix_world.copy()
    col.objects.link(obj)
    return obj


def _remove(obj):
    """Idempotent cleanup, including RNA references already invalidated by Blender.

    In v0.1 the sampled Boolean path removed the cutter in _diff and then
    attempted to remove the same object in a finally block. On Blender, even
    reading `obj.name` after bpy.data.objects.remove raises ReferenceError.
    """
    if obj is None:
        return
    try:
        name = obj.name
        live = bpy.data.objects.get(name)
        if live is None or live != obj:
            return
        mesh = obj.data if obj.type == 'MESH' else None
        bpy.data.objects.remove(obj, do_unlink=True)
    except (ReferenceError, RuntimeError):
        return
    if mesh is not None and mesh.users == 0:
        bpy.data.meshes.remove(mesh)


def _union(target, cutter):
    _boolean(target, cutter, 'UNION')
    _remove(cutter)


def _diff(target, cutter):
    _boolean(target, cutter, 'DIFFERENCE')
    _remove(cutter)


def _add_cylinder_at(span, pivot, axis, start, end, radius, collection, label):
    center = pivot + axis*((start+end)/2)
    return _make_cylinder(label, center, axis, radius, end-start, collection)


def _make_parts(plan, settings, col, *, preview=False):
    """Create annotation geometry; does not modify source objects."""
    pivot, axis, span = plan['pivot'], plan['axis'], plan['span']
    parts = {'A': [], 'B': []}
    for beam in plan['beams']:
        obj = _make_beam(f'FH_{beam["owner"]}_Support', beam['start'], beam['end'],
                         axis, beam['width'], beam['thickness'], col)
        parts[beam['owner']].append((obj, beam))
    barrels = {'A': [], 'B': []}
    for tag, start, end, owner in (
        ('A',span.a_outer,span.a_inner,'A'),
        ('B',span.b_inner,span.b_outer,'B')):
        obj = _add_cylinder_at(span,pivot,axis,start,end,span.outer_radius,col,f'FH_{owner}_Barrel_{tag}')
        barrels[owner].append(obj)
    if preview:
        # Show the single A bore and the B-integrated axle as read-only wire
        # cylinders. These are preview annotations, not exported solid parts.
        shoulder = plan.get('shoulder')
        if shoulder is not None:
            bore = _add_cylinder_at(span,pivot,axis,shoulder.mouth_start,shoulder.mouth_end,
                                    span.bore_radius,col,'FH_A_Narrow_Entry_Preview')
            chamber = _add_cylinder_at(span,pivot,axis,shoulder.cavity_start,shoulder.cavity_end,
                                       shoulder.cavity_radius,col,'FH_A_Head_Chamber_Preview')
            axle = _add_cylinder_at(span,pivot,axis,shoulder.shaft_start,span.shaft_max,
                                    span.axle_radius,col,'FH_B_Axle_Preview')
            head = _add_cylinder_at(span,pivot,axis,shoulder.head_start,shoulder.head_end,
                                    shoulder.head_radius,col,'FH_B_Shoulder_Head_Preview')
            extra = [chamber,head]
            chamber.color = _COL_GAP
            head.color = _COL_B
        else:
            bore = _add_cylinder_at(span,pivot,axis,span.bore_start,span.bore_end,
                                    span.bore_radius,col,'FH_A_Bore_Preview')
            axle = _add_cylinder_at(span,pivot,axis,span.shaft_min,span.shaft_max,
                                    span.axle_radius,col,'FH_B_Axle_Preview')
            extra = []
        for obj in [o for side in ('A','B') for o,_ in parts[side]] + barrels['A'] + barrels['B'] + [bore,axle] + extra:
            obj.display_type = 'WIRE'
            obj.show_in_front = True
            obj.hide_render = True
        bore.color = _COL_GAP
        axle.color = _COL_B
    return parts, barrels


def _trunnion_cylinders(plan, col, *, preview=False):
    """Create side pins (B) and bore cutters (A), without touching source A/B."""
    pivot, axis, sp = plan['pivot'], plan['axis'], plan['trunnion']
    items = []
    for side, pin_start, pin_end, bore_start, bore_end in (
        ('Left', sp.left_pin_outer, sp.left_pin_inner,
         sp.left_bore_outer, sp.left_bore_inner),
        ('Right', sp.right_pin_inner, sp.right_pin_outer,
         sp.right_bore_inner, sp.right_bore_outer)):
        pin = _add_cylinder_at(None, pivot, axis, pin_start, pin_end,
                               sp.pin_radius, col, f'FH_B_Trunnion_{side}')
        bore = _add_cylinder_at(None, pivot, axis, bore_start, bore_end,
                                sp.bore_radius, col, f'FH_A_Bore_{side}')
        items.append((pin, bore, side))
        if preview:
            for obj, color in ((pin, _COL_B), (bore, _COL_GAP)):
                obj.display_type = 'WIRE'
                obj.show_in_front = True
                obj.hide_render = True
                obj.color = color
    return items


def _build_trunnion_real(context, settings, plan, col):
    """B gets solid coaxial side pins; A gets matching Boolean bores.

    No support beams are added, and no imported/registered source mesh is
    modified. The existing A object must already have two receiving walls.
    The socket's own ball joint is not rebuilt or altered internally.
    """
    dg = context.evaluated_depsgraph_get()
    target_a = _make_stage(settings.object_a, col, 'A', dg)
    target_b = _make_stage(settings.object_b, col, 'B', dg)
    original_islands = {
        'A': _mesh_components(target_a.data),
        'B': _mesh_components(target_b.data),
    }
    pairs = _trunnion_cylinders(plan, col)
    # Receiver bores first, before joining the B pins. Never drill the pin or
    # socket by accident: cutter target is strictly the copied A receiver.
    for pin, bore, side in pairs:
        before_volume = _closed_mesh_volume(target_a.data)
        _diff(target_a, bore)
        after_volume = _closed_mesh_volume(target_a.data)
        if before_volume is not None and after_volume is not None:
            removed = before_volume - after_volume
            if removed <= max(1e-9, before_volume*1e-10):
                raise RuntimeError(
                    f'A側{side}の受け穴が実際には加工されませんでした。'
                    'Aの壁位置・軸突出長・カーソル軸を確認してください')
    for pin, bore, side in pairs:
        _union(target_b, pin)
    for owner, target in (('A',target_a),('B',target_b)):
        islands = _mesh_components(target.data)
        if islands > original_islands[owner]:
            raise RuntimeError(
                f'{owner}の接続失敗（独立メッシュ島 {original_islands[owner]}→{islands}）。'
                'カーソル位置・B側面の厚み・軸突出長を確認してください')
        target['face_hinge_maker'] = True
        target['face_hinge_mode'] = 'TRUNNION'
        target['face_hinge_owner'] = owner
        target['face_hinge_original_name'] = getattr(settings, 'object_'+owner.lower()).name
        target['face_hinge_no_collision_guarantee'] = True
    return target_a, target_b


def _sweep_a_arm(arm, plan, settings, col):
    """Boolean sampled expanded B beam on A *support only*, not original body.

    Each cutter is conservative: thickness and width get additional pad for
    the maximum movement between neighboring angle samples. This is an
    approximation; mesh/BVH and printer clearance still require real checks.
    """
    pad = plan['sweep_padding']
    pivot, axis = plan['pivot'], plan['axis']
    for beam in plan['beams']:
        if beam['owner'] != 'B':
            continue
        for angle in plan['angles']:
            start = Vector(rotate_xyz(beam['start'], pivot, axis, angle))
            end = Vector(rotate_xyz(beam['end'], pivot, axis, angle))
            cutter = _make_beam('FH_Swept_B_Cutter', start, end, axis,
                                beam['width'] + 2*pad,
                                beam['thickness'] + 2*pad, col)
            # Difference and cleanup must be one transaction. The old path
            # called _diff (which deleted the cutter), then deleted it again.
            try:
                _boolean(arm, cutter, 'DIFFERENCE')
            finally:
                _remove(cutter)


def _build_real(context, settings, plan, col):
    axis,pivot,span = plan['axis'],plan['pivot'],plan['span']
    depsgraph = context.evaluated_depsgraph_get()
    target_a = _make_stage(settings.object_a, col, 'A', depsgraph)
    target_b = _make_stage(settings.object_b, col, 'B', depsgraph)
    original_islands = {'A': _mesh_components(target_a.data), 'B': _mesh_components(target_b.data)}
    parts, barrels = _make_parts(plan, settings, col)
    # Sweep comes before A arms are united to A's body. This is intentional:
    # original body/other-body collisions are not in v0.1 scope.
    for obj,_ in parts['A']:
        _sweep_a_arm(obj, plan, settings, col)
    for obj,_ in parts['A']:
        _union(target_a, obj)
    for obj,_ in parts['B']:
        _union(target_b, obj)
    for obj in barrels['A']:
        _union(target_a, obj)
    for obj in barrels['B']:
        _union(target_b, obj)
    # Single A blind bore, opening toward B across the axial gap.
    # Only A receives the Difference; source A/B are preserved as copies.
    shoulder = plan.get('shoulder')
    if shoulder is not None:
        # First cut the narrow entry, then enlarge only the *internal* end.
        # The opening stays smaller than the captured head, so pulling the
        # shaft toward B cannot extract the head through the A entrance.
        cutter = _add_cylinder_at(span,pivot,axis,shoulder.mouth_start,shoulder.mouth_end,
                                  span.bore_radius,col,'FH_A_Blind_Bore')
    else:
        cutter = _add_cylinder_at(span,pivot,axis,span.bore_start,span.bore_end,
                                  span.bore_radius,col,'FH_A_Blind_Bore')
    _diff(target_a, cutter)
    if shoulder is not None:
        # On watertight targets, confirm the *internal* counterbore actually
        # removes material; a failed cut must not pass as a successful capture.
        before_cavity = _closed_mesh_volume(target_a.data)
        head_cutter = _add_cylinder_at(span,pivot,axis,
                                       shoulder.cavity_start,shoulder.cavity_end,
                                       shoulder.cavity_radius,col,'FH_A_Head_Chamber')
        _diff(target_a, head_cutter)
        after_cavity = _closed_mesh_volume(target_a.data)
        if before_cavity is not None and after_cavity is not None:
            removed = before_cavity - after_cavity
            if removed <= max(1e-9, before_cavity * 1e-10):
                raise RuntimeError('A側の返し頭収納空間が加工できませんでした。'
                                   'ナックル寸法・軸位置を確認してください')
    # All B additions happen after drilling A; never cut B's axle or head.
    shaft_start = shoulder.shaft_start if shoulder is not None else span.shaft_min
    axle = _add_cylinder_at(span,pivot,axis,shaft_start,span.shaft_max,
                            span.axle_radius,col,'FH_B_Integrated_Axle')
    _union(target_b, axle)
    if shoulder is not None:
        retainer = _add_cylinder_at(span,pivot,axis,
                                    shoulder.head_start,shoulder.head_end,
                                    shoulder.head_radius,col,'FH_B_Captured_Shoulder_Head')
        _union(target_b, retainer)
    for owner, target in (('A',target_a),('B',target_b)):
        actual_islands = _mesh_components(target.data)
        if actual_islands > original_islands[owner]:
            raise RuntimeError(
                f'{owner}の接続に失敗: 独立メッシュ島が '
                f'{original_islands[owner]}→{actual_islands} に増加。'
                '取付面・支持腕の厚み・埋め込み深さを見直してください')
        target['face_hinge_maker'] = True
        target['face_hinge_mode'] = 'STRAIGHT_AB'
        target['face_hinge_shoulder_head'] = bool(plan.get('shoulder'))
        target['face_hinge_owner'] = owner
        target['face_hinge_min_angle'] = settings.minimum_angle
        target['face_hinge_max_angle'] = settings.maximum_angle
        target['face_hinge_sweep_approximation'] = True
        target['face_hinge_original_name'] = getattr(settings, 'object_'+owner.lower()).name
    return target_a,target_b


def _circle_segments(center, axis, radius, num=48):
    axis=Vector(axis).normalized()
    x=axis.cross(Vector((0,0,1)))
    if x.length < 1e-7: x=axis.cross(Vector((0,1,0)))
    x.normalize();y=axis.cross(x).normalized()
    return [Vector(center) + radius*(x*math.cos(2*math.pi*i/num)+y*math.sin(2*math.pi*i/num))
            for i in range(num)]


def _wire_cylinder(center, axis, radius, start, end, pivot):
    segs=[]
    points=[]
    for offset in (start,end):
        circle = _circle_segments(pivot+axis*offset,axis,radius,32)
        points.extend(circle)
        segs.extend((circle[i],circle[(i+1)%len(circle)]) for i in range(len(circle)))
    for i in range(0,32,4):
        segs.append((points[i],points[32+i]))
    return segs


def _wire_beam(start,end,axis,width,thickness):
    direction=(Vector(end)-Vector(start)).normalized()
    axis=Vector(axis)
    side=axis.cross(direction)
    if side.length < 1e-7:
        side=direction.cross(Vector((1,0,0)))
        if side.length < 1e-7: side=direction.cross(Vector((0,1,0)))
    side.normalize();across=direction.cross(side).normalized()
    offsets=[-across*width/2-side*thickness/2,
             across*width/2-side*thickness/2,
             across*width/2+side*thickness/2,
             -across*width/2+side*thickness/2]
    v=[Vector(start)+x for x in offsets]+[Vector(end)+x for x in offsets]
    edges=[(0,1),(1,2),(2,3),(3,0),(4,5),(5,6),(6,7),(7,4),
           (0,4),(1,5),(2,6),(3,7)]
    return [(v[i],v[j]) for i,j in edges]


def _wire_bbox(corners):
    # Blender Object.bound_box uses this stable 0..7 corner ordering.
    edges=((0,1),(1,2),(2,3),(3,0),
           (4,5),(5,6),(6,7),(7,4),
           (0,4),(1,5),(2,6),(3,7))
    return [(corners[i],corners[j]) for i,j in edges]


def _trunnion_guide_edges(plan, settings):
    pivot, axis, sp = plan['pivot'], plan['axis'], plan['trunnion']
    items=[]
    for pin_a, pin_b, bore_a, bore_b in (
        (sp.left_pin_outer,sp.left_pin_inner,sp.left_bore_outer,sp.left_bore_inner),
        (sp.right_pin_inner,sp.right_pin_outer,sp.right_bore_inner,sp.right_bore_outer)):
        items.append((_wire_cylinder(None,axis,sp.pin_radius,pin_a,pin_b,pivot),_COL_B))
        items.append((_wire_cylinder(None,axis,sp.bore_radius,bore_a,bore_b,pivot),_COL_GAP))
    items.append(([(pivot+axis*(sp.left_pin_outer-.4),
                    pivot+axis*(sp.right_pin_outer+.4))],_COL_B))
    corners = plan['bbox_corners']
    items.append((_wire_bbox(corners), _COL_B))
    # Actual B object is NEVER rotated. The rotated bounding box is a guide,
    # not a model/collision test.
    try:
        transformed=[Vector(rotate_xyz(p,pivot,axis,settings.preview_angle))
                     for p in corners]
        items.append((_wire_bbox(transformed),(1.0,.82,.22,.75)))
    except Exception:
        pass
    return items


def _axis_debug_lines(settings, context, plan=None):
    """Always-visible, read-only direction marks; works without a valid plan.

    Cursor translation sets the axis *position*. The world-axis setting
    (possibly reversed) alone sets its *direction*. No face normal or cursor
    rotation is consulted in TRUNNION mode.
    """
    pivot = _center(context)
    axis = _axis(settings)
    extent = max(2., float(settings.axle_diameter)*1.6)
    if plan and plan.get('mode') == 'TRUNNION':
        sp = plan['trunnion']
        extent = max(extent, abs(sp.left_pin_outer), abs(sp.right_pin_outer)) + max(.3, sp.pin_radius*.6)
    elif plan and plan.get('mode') == 'STRAIGHT':
        sp = plan['span']
        extent = max(extent, abs(sp.a_outer), abs(sp.b_outer)) + max(.3, sp.axle_radius*.6)
    else:
        extent = max(extent, float(settings.pin_projection)+float(settings.pin_embed))
    head = min(max(.14, settings.axle_diameter*.17), .55)
    g = guide_axis_segments(pivot, axis, extent, head)
    lines = [(g['center_line'], _COL_AXIS),
             (g['negative_arrow'], _COL_AXIS_NEG),
             (g['positive_arrow'], _COL_AXIS_POS)]
    r = max(.16, min(settings.axle_diameter*.24, .5))
    ring = _circle_segments(pivot, axis, r, 24)
    lines.append(([(ring[i], ring[(i+1)%len(ring)]) for i in range(len(ring))], _COL_AXIS))
    # Trunnion mount vectors start at B's axial surface, not the cursor. This
    # makes an incorrect side or axis immediately visible in the viewport.
    if plan and plan.get('mode') == 'TRUNNION':
        sp = plan['trunnion']
        pairs = ((sp.left_surface, sp.left_pin_outer, _COL_AXIS_NEG),
                 (sp.right_surface, sp.right_pin_outer, _COL_AXIS_POS))
        for start, end, color in pairs:
            p = pivot + axis*start
            q = pivot + axis*end
            lines.append((guide_arrow_segments(p, q, head), color))
            # A-side bore centers and pin surface circles are already in the
            # regular wire. Emphasize their entrance positions in X-ray mode.
            circle = _circle_segments(p, axis, sp.pin_radius*1.08, 24)
            lines.append(([(circle[i], circle[(i+1)%len(circle)]) for i in range(len(circle))], color))
    elif plan and plan.get('mode') == 'STRAIGHT':
        # Connection vectors are meaningful only for the face-support mode.
        for owner, (center, normal, _verts) in plan['faces'].items():
            end = pivot + axis*(center-pivot).dot(axis)
            if (end-center).length > 1e-7:
                lines.append((guide_arrow_segments(center, end, head),
                              _COL_A if owner == 'A' else _COL_B))
    elif settings.mode == 'STRAIGHT':
        # Show *partial* face→cursor information even if _plan() failed,
        # rather than hiding all direction diagnostics behind a red circle.
        for owner in ('A', 'B'):
            try:
                center, normal, _ = _face(settings, owner)
            except (ValueError, AttributeError, TypeError, ReferenceError):
                continue
            end = pivot + axis*(center-pivot).dot(axis)
            if (end-center).length > 1e-7:
                lines.append((guide_arrow_segments(center, end, head),
                              _COL_A if owner == 'A' else _COL_B))
    return lines


def _guide_edges(plan, settings, *, debug=True):
    if plan.get('mode') == 'TRUNNION':
        return _trunnion_guide_edges(plan, settings)
    pivot,axis,span=plan['pivot'],plan['axis'],plan['span']
    out=[]
    for start,end,owner in ((span.a_outer,span.a_inner,'A'),
                             (span.b_inner,span.b_outer,'B')):
        out.append((_wire_cylinder(None,axis,span.outer_radius,start,end,pivot),
                    _COL_A if owner=='A' else _COL_B))
    shoulder = plan.get('shoulder')
    if shoulder is not None:
        out.append((_wire_cylinder(None,axis,span.axle_radius,
                                   shoulder.shaft_start,span.shaft_max,pivot),_COL_B))
        out.append((_wire_cylinder(None,axis,span.bore_radius,
                                   shoulder.mouth_start,shoulder.mouth_end,pivot),_COL_GAP))
        out.append((_wire_cylinder(None,axis,shoulder.head_radius,
                                   shoulder.head_start,shoulder.head_end,pivot),_COL_B))
        out.append((_wire_cylinder(None,axis,shoulder.cavity_radius,
                                   shoulder.cavity_start,shoulder.cavity_end,pivot),_COL_GAP))
    else:
        out.append((_wire_cylinder(None,axis,span.axle_radius,span.shaft_min,span.shaft_max,pivot),_COL_B))
        out.append((_wire_cylinder(None,axis,span.bore_radius,
                                   span.bore_start,span.bore_end,pivot),_COL_GAP))
    for beam in plan['beams']:
        out.append((_wire_beam(beam['start'],beam['end'],axis,
                               beam['width'],beam['thickness']),
                    _COL_A if beam['owner']=='A' else _COL_B))
        if beam['owner']=='B':
            for angle in ((settings.minimum_angle,settings.maximum_angle,settings.preview_angle)
                          if debug else (settings.preview_angle,)):
                p=Vector(rotate_xyz(beam['start'],pivot,axis,angle))
                q=Vector(rotate_xyz(beam['end'],pivot,axis,angle))
                color=_COL_WARN if settings.minimum_angle>settings.maximum_angle else (1,.82,.22,.60)
                out.append((_wire_beam(p,q,axis,beam['width'],beam['thickness']),color))
    for owner,(_,_,verts) in plan['faces'].items():
        out.append(([(verts[i],verts[(i+1)%len(verts)]) for i in range(len(verts))],
                    _COL_A if owner=='A' else _COL_B))
    return out


def _draw_3d():
    from gpu_extras.batch import batch_for_shader
    import gpu
    c=bpy.context
    if not getattr(c,'scene',None): return
    s=getattr(c.scene,'face_hinge_settings',None)
    if not s or not s.live_enabled or not _cjm_ui.engine_visible(c,"face"): return
    plan = None
    try:
        plan = _plan(c,s)
        st=_cjm_ui.state(c.scene)
        lines = _guide_edges(plan,s,debug=not st or st.face_view=='DEBUG')
        if st and st.face_view == 'FOCUS':
            focus=st.face_focus
            wanted=(_COL_B,_COL_GAP) if ('clearance' in focus or 'gap' in focus or 'wall' in focus) else (_COL_B,) if focus in ('axle_diameter','pin_projection','pin_embed','shoulder_diameter','shoulder_thickness') else (_COL_A,_COL_B,_COL_GAP,(1,.82,.22,.60),(1.0,.82,.22,.75))
            lines=[(edges,col) for edges,col in lines if col in wanted or col==_COL_WARN]

    except Exception:
        # Old A→pivot plan can fail with coincident points. Still draw the
        # direction guide independently, not just a red error marker.
        try:
            point=_center(c)
            axis=_axis(s)
            radius=max(.25,min(20.,float(s.outer_diameter)/2.))
            cir=_circle_segments(point,axis,radius,32)
            lines=[([(cir[i],cir[(i+1)%len(cir)]) for i in range(len(cir))],_COL_WARN),
                   ([(point-axis*radius*1.6,point+axis*radius*1.6)],_COL_WARN)]
        except Exception:
            lines=[]
    try:
        # Axis gizmo is an X-ray overlay: the actual cursor often sits INSIDE
        # the socket, and a depth-tested line would otherwise be invisible.
        axis_lines = _axis_debug_lines(s,c,plan)
    except (ValueError,TypeError,AttributeError,ReferenceError,RuntimeError):
        axis_lines = []
    if not lines and not axis_lines:
        return
    shader=gpu.shader.from_builtin('UNIFORM_COLOR')
    gpu.state.blend_set('ALPHA')
    try:
        for group, depth, width in ((lines,'LESS_EQUAL',2.0),
                                    (axis_lines,'NONE',2.8)):
            gpu.state.depth_test_set(depth)
            gpu.state.line_width_set(width)
            for edges,color in group:
                points=[tuple(p) for a,b in edges for p in (a,b)]
                if not points: continue
                batch=batch_for_shader(shader,'LINES',{'pos':points})
                shader.bind();shader.uniform_float('color',color);batch.draw(shader)
    finally:
        gpu.state.line_width_set(1.0)
        gpu.state.blend_set('NONE')
        gpu.state.depth_test_set('NONE')


def _draw_2d():
    import blf
    c=bpy.context
    if not getattr(c,'scene',None) or not getattr(c,'region',None): return
    s=getattr(c.scene,'face_hinge_settings',None)
    if not s or not s.live_enabled or not _cjm_ui.engine_visible(c,"face"):return
    font=0
    st=_cjm_ui.state(c.scene)
    if st and st.mode=='ROTARY' and getattr(st,'rotary_section','FACE')!='FACE':
        lines=['回転ジョイント LIVE | 単体／直接取付',f'軸方向: {s.axis} / 軸径 {s.axle_diameter:.2f} / 穴径 {s.axle_diameter+2*s.radial_clearance:.2f}']
    elif s.mode == 'TRUNNION':
        lines=['Face Hinge LIVE | 現在: ソケット側面へ直付け軸（トラニオン）',
               f'軸方向: ワールド{s.axis}{" (反転)" if s.reverse_axis else ""} | 黄=軸線 / 緑=＋向き / 桃=－向き',
               f'B左右ピン→A受け穴 | 軸径 {s.axle_diameter:.2f} / 穴径 {s.axle_diameter+2*s.radial_clearance:.2f}',
               f'突出 {s.pin_projection:.2f} / 埋込 {s.pin_embed:.2f} / 角度表示 {s.preview_angle:.1f}°',
               '※ カーソルの回転は使用しません。球・本体の衝突は未検査']
    else:
        lines=['Face Hinge LIVE | 現在: 面から支持腕（A-B / 各1ナックル）',
               f'軸方向: ワールド{s.axis}{" (反転)" if s.reverse_axis else ""} | 黄=軸線 / 緑=＋向き / 桃=－向き',
               f'角度: {s.minimum_angle:.1f}° ～ {s.maximum_angle:.1f}°  現在 {s.preview_angle:.1f}°',
               f'軸径 {s.axle_diameter:.2f} / 穴径 {s.axle_diameter+2*s.radial_clearance:.2f} / 隙間 {s.axial_gap:.2f}']
    try:
        _plan(c,s)
    except Exception as exc:
        lines.append('要修正: '+str(exc)[:90])
        if s.mode == 'STRAIGHT' and (not st or getattr(st,'rotary_section','FACE')=='FACE'):
            lines.append('※ 側面にピンを直接付けるなら「作成方式→ソケット側面へ直付け軸」に変更')
    width=c.region.width
    for i,line in enumerate(lines):
        blf.size(font,12)
        blf.position(font,max(12,width-530),c.region.height-33-i*18,0)
        if line.startswith('要修正'):
            blf.color(font,*_COL_WARN)
        else:
            blf.color(font,.95,.96,.98,1)
        blf.draw(font,line)


def _install_overlay():
    global _LIVE_3D,_LIVE_2D
    if _LIVE_3D is None:
        _LIVE_3D=bpy.types.SpaceView3D.draw_handler_add(_draw_3d, (), 'WINDOW', 'POST_VIEW')
    if _LIVE_2D is None:
        _LIVE_2D=bpy.types.SpaceView3D.draw_handler_add(_draw_2d, (), 'WINDOW', 'POST_PIXEL')


def _uninstall_overlay():
    global _LIVE_3D,_LIVE_2D
    for handle in (_LIVE_3D,_LIVE_2D):
        if handle is not None:
            bpy.types.SpaceView3D.draw_handler_remove(handle,'WINDOW')
    _LIVE_3D=_LIVE_2D=None


class FACEHINGE_Settings(PropertyGroup):
    mode: EnumProperty(
        name='作成方式',
        items=[('STRAIGHT','面から支持腕（A-B）','A/Bそれぞれ1本の支持腕と1個のナックルを作る'),
               ('TRUNNION','ソケット側面へ直付け軸','Bの左右側面に一体軸、Aの受けに軸穴を加工')],
        default='STRAIGHT',update=_update)
    object_a: PointerProperty(type=bpy.types.Object)
    object_b: PointerProperty(type=bpy.types.Object)
    face_a: IntProperty(default=-1)
    face_b: IntProperty(default=-1)
    signature_a: StringProperty(default='')
    signature_b: StringProperty(default='')
    axis: EnumProperty(name='軸方向',items=[('X','X',''),('Y','Y',''),('Z','Z','')],default='X',update=_cjm_ui.face_changed('axis'))
    reverse_axis: BoolProperty(name='軸の向きを反転',default=False,update=_cjm_ui.face_changed('reverse_axis'))
    outer_diameter: FloatProperty(name='ナックル外径',default=4.0,min=.2,update=_cjm_ui.constraint_update('face','outer_diameter',_cjm_ui.face_changed('outer_diameter')))
    axle_diameter: FloatProperty(name='一体軸径',default=2.0,min=.1,update=_cjm_ui.constraint_update('face','axle_diameter',_cjm_ui.face_changed('axle_diameter')))
    shoulder_enabled: BoolProperty(name='肩付き軸（抜け止め頭）',default=False,update=_cjm_ui.constraint_update('face','shoulder_enabled',_update_shoulder_enabled))
    shoulder_diameter: FloatProperty(name='返し頭の直径',default=3.4,min=.2,update=_cjm_ui.constraint_update('face','shoulder_diameter',_cjm_ui.face_changed('shoulder_diameter')))
    shoulder_thickness: FloatProperty(name='返し頭の厚み',default=.5,min=.05,update=_cjm_ui.constraint_update('face','shoulder_thickness',_cjm_ui.face_changed('shoulder_thickness')))
    shoulder_radial_clearance: FloatProperty(name='頭の半径方向隙間',default=.4,min=.01,update=_cjm_ui.constraint_update('face','shoulder_radial_clearance',_cjm_ui.face_changed('shoulder_radial_clearance')))
    shoulder_axial_clearance: FloatProperty(name='頭の軸方向隙間（片側）',default=.35,min=.01,update=_cjm_ui.constraint_update('face','shoulder_axial_clearance',_cjm_ui.face_changed('shoulder_axial_clearance')))
    radial_clearance: FloatProperty(name='軸穴クリアランス（片側）',default=.4,min=0,update=_cjm_ui.constraint_update('face','radial_clearance',_cjm_ui.face_changed('radial_clearance')))
    axial_gap: FloatProperty(name='ナックル間クリアランス',default=.4,min=0,update=_cjm_ui.constraint_update('face','axial_gap',_cjm_ui.face_changed('axial_gap')))
    a_width: FloatProperty(name='Aナックル長',default=2.5,min=.1,update=_cjm_ui.constraint_update('face','a_width',_cjm_ui.face_changed('a_width')))
    b_width: FloatProperty(name='Bナックル長',default=3.,min=.1,update=_cjm_ui.constraint_update('face','b_width',_cjm_ui.face_changed('b_width')))
    radial_wall: FloatProperty(name='最低外周肉厚',default=.35,min=0,update=_cjm_ui.constraint_update('face','radial_wall',_cjm_ui.face_changed('radial_wall')))
    cap_wall: FloatProperty(name='最低閉鎖壁厚',default=.8,min=0,update=_cjm_ui.constraint_update('face','cap_wall',_cjm_ui.face_changed('cap_wall')))
    tip_clearance: FloatProperty(name='軸先端クリアランス',default=.4,min=0,update=_cjm_ui.constraint_update('face','tip_clearance',_cjm_ui.face_changed('tip_clearance')))
    pin_projection: FloatProperty(name='側面からの軸突出長',default=2.5,min=.1,update=_cjm_ui.constraint_update('face','pin_projection',_cjm_ui.face_changed('pin_projection')))
    pin_embed: FloatProperty(name='軸の本体埋め込み長',default=.5,min=.05,update=_cjm_ui.constraint_update('face','pin_embed',_cjm_ui.face_changed('pin_embed')))
    support_width: FloatProperty(name='支持腕の幅',default=1.8,min=.15,update=_cjm_ui.face_changed('support_width'))
    support_thickness: FloatProperty(name='支持腕の厚み',default=2.2,min=.15,update=_cjm_ui.face_changed('support_thickness'))
    embed_depth: FloatProperty(name='本体への埋め込み深さ',default=.5,min=0.01,update=_cjm_ui.face_changed('embed_depth'))
    minimum_angle: FloatProperty(name='最小角',default=-20,min=-180,max=180,update=_cjm_ui.face_changed('minimum_angle'))
    maximum_angle: FloatProperty(name='最大角',default=20,min=-180,max=180,update=_cjm_ui.face_changed('maximum_angle'))
    angle_step: FloatProperty(name='Booleanサンプル間隔',default=5.,min=.5,max=30.,update=_cjm_ui.face_changed('angle_step'))
    swing_clearance: FloatProperty(name='回転逃げクリアランス',default=.4,min=0,update=_cjm_ui.face_changed('swing_clearance'))
    preview_angle: FloatProperty(name='表示角度',default=0.,min=-180,max=180,update=_cjm_ui.face_changed('preview_angle'))
    live_enabled: BoolProperty(name='3Dライブガイドを表示',default=False,update=_update)
    hide_originals: BoolProperty(name='生成後に元A/Bを非表示',default=True)
    last_error: StringProperty(default='')


class FACEHINGE_OT_assign_pair(Operator):
    bl_idname='face_hinge.assign_pair'
    bl_label='選択した2体をA/Bに登録'
    bl_description='オブジェクトモードで2体を選択。アクティブ=Bソケット、もう一方=A外側受け'
    bl_options={'REGISTER','UNDO'}

    def execute(self,context):
        if context.mode != 'OBJECT':
            self.report({'ERROR'},'Object Modeで2つのメッシュを選択してください')
            return {'CANCELLED'}
        selected=[o for o in context.selected_objects if o.type == 'MESH']
        active=context.view_layer.objects.active
        if len(context.selected_objects)!=2 or len(selected)!=2 or active not in selected:
            self.report({'ERROR'},'メッシュ2体だけ選択し、Bソケットをアクティブにしてください')
            return {'CANCELLED'}
        other=next(o for o in selected if o != active)
        s=context.scene.face_hinge_settings
        s.object_a=other
        s.object_b=active
        self.report({'INFO'},f'A受け: {other.name} / Bソケット: {active.name}')
        _redraw(context)
        return {'FINISHED'}


class FACEHINGE_OT_capture(Operator):
    bl_idname='face_hinge.capture_face'
    bl_label='選択面を記憶'
    bl_description='編集モードで選択した1面を指定側へ記憶。A/B別々に登録できます'
    bl_options={'REGISTER','UNDO'}
    side: EnumProperty(items=[('A','A',''),('B','B','')])

    def execute(self,context):
        obj=context.edit_object
        if context.mode!='EDIT_MESH' or obj is None or obj.type!='MESH':
            self.report({'ERROR'},'メッシュの編集モードで面を1つ選択してください')
            return {'CANCELLED'}
        bm=bmesh.from_edit_mesh(obj.data)
        bm.faces.ensure_lookup_table()
        bm.faces.index_update()
        bm.verts.index_update()
        faces=[f for f in bm.faces if f.select and not f.hide]
        if len(faces)!=1:
            self.report({'ERROR'},f'ちょうど1面を選択してください（現在 {len(faces)}面）')
            return {'CANCELLED'}
        face=faces[0]
        signature=','.join(str(v.index) for v in face.verts)
        s=context.scene.face_hinge_settings
        setattr(s,f'object_{self.side.lower()}',obj)
        setattr(s,f'face_{self.side.lower()}',face.index)
        setattr(s,f'signature_{self.side.lower()}',signature)
        self.report({'INFO'},f'{self.side}面を記憶: {obj.name} / Face {face.index}')
        _redraw(context)
        return {'FINISHED'}


class FACEHINGE_OT_preview(Operator):
    bl_idname='face_hinge.preview_parts'
    bl_label='支持部プレビュー'
    bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        s=context.scene.face_hinge_settings
        if context.mode!='OBJECT':
            self.report({'ERROR'},'生成プレビューはObject Modeで実行してください')
            return {'CANCELLED'}
        col=None
        try:
            plan=_plan(context,s)
            _preview_clear()
            col=_make_collection(_PREVIEW_NAME,context.scene)
            if s.mode == 'TRUNNION':
                _trunnion_cylinders(plan,col,preview=True)
            else:
                _make_parts(plan,s,col,preview=True)
            s.live_enabled=True
        except Exception as exc:
            if col: _destroy_collection(col)
            self.report({'ERROR'},f'プレビュー失敗: {exc}')
            return {'CANCELLED'}
        self.report({'INFO'},'ワイヤーのプレビューを作成しました。元A/Bは未変更です')
        return {'FINISHED'}


class FACEHINGE_OT_clear(Operator):
    bl_idname='face_hinge.clear_preview'
    bl_label='Face Hingeプレビュー削除'
    bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        _preview_clear()
        return {'FINISHED'}


class FACEHINGE_OT_generate(Operator):
    bl_idname='face_hinge.generate'
    bl_label='2オブジェクトをFace Hinge化'
    bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        s=context.scene.face_hinge_settings
        if context.mode!='OBJECT':
            self.report({'ERROR'},'Object Modeに切り替えてから確定してください')
            return {'CANCELLED'}
        col=None
        prior_visibility={}
        selected=tuple(context.selected_objects)
        active=context.view_layer.objects.active
        try:
            st=_cjm_ui.state(context.scene)
            if st and st.mode=='ROTARY' and getattr(st,'rotary_section','FACE')!='FACE':
                raise ValueError('単体／直接取付の生成ボタンを使用してください')
            plan=_plan(context,s)
            _preview_clear()
            col=_make_collection('FaceHinge_v020_Result', context.scene)
            if s.mode == 'TRUNNION':
                target_a,target_b=_build_trunnion_real(context,s,plan,col)
            else:
                target_a,target_b=_build_real(context,s,plan,col)
            # Successful stages have *all* modifiers baked. Originals are untouched.
            if s.hide_originals:
                for obj in (s.object_a,s.object_b):
                    prior_visibility[obj.name]=(obj.hide_get(),obj.hide_render)
                    obj.hide_set(True)
                    obj.hide_render=True
            # Select outputs, to make it clear which objects should be exported.
            for obj in context.selected_objects:
                obj.select_set(False)
            for obj in (target_a,target_b):
                obj.select_set(True)
            context.view_layer.objects.active=target_b
            s.last_error=''
            self.report({'INFO'},f'Face Hinge {s.mode} 生成完了。元A/Bは保持、複製にBoolean適用済み')
            return {'FINISHED'}
        except Exception as exc:
            s.last_error=str(exc)
            for obj_name, (was_hidden, was_render_hidden) in prior_visibility.items():
                obj=bpy.data.objects.get(obj_name)
                if obj is not None:
                    try:
                        obj.hide_set(was_hidden)
                        obj.hide_render=was_render_hidden
                    except (ReferenceError,RuntimeError):
                        pass
            if col:
                _destroy_collection(col)
            self.report({'ERROR'},'生成を中止: '+str(exc)[:180])
            return {'CANCELLED'}
        finally:
            if s.last_error:
                for obj in selected:
                    try:
                        if obj.name in bpy.data.objects and not obj.hide_get():obj.select_set(True)
                    except (ReferenceError,RuntimeError):pass
                if active and active.name in bpy.data.objects:
                    try:context.view_layer.objects.active=active
                    except (RuntimeError,TypeError):pass


class VIEW3D_PT_face_hinge(Panel):
    bl_label='面指定ヒンジ（Face Hinge）v0.2.5'
    bl_idname='VIEW3D_PT_face_hinge'
    bl_space_type='VIEW_3D'
    bl_region_type='UI'
    bl_category='Joint Maker'
    bl_parent_id='VIEW3D_PT_cjm_root'
    bl_options={'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls,context):
        return _cjm_ui.engine_visible(context,'face') and not (context.scene.cjm_settings.mode=='ROTARY' and getattr(context.scene.cjm_settings,'rotary_section','FACE')!='FACE')

    def draw(self,context):
        layout=self.layout
        s=context.scene.face_hinge_settings
        if s.mode != ('TRUNNION' if context.scene.cjm_settings.mode=='TRUNNION' else 'STRAIGHT'):
            layout.label(text='上部の機構を再選択してモードを同期',icon='ERROR')
            return
        mode_notice=layout.row()
        mode_notice.label(text=('現在：ソケット側面へ直付け軸（面登録不要）' if s.mode == 'TRUNNION'
                                else '現在：面から支持腕（A-B / A・B各1ナックル）'), icon='INFO')
        if s.mode == 'TRUNNION':
            box=layout.box()
            box.label(text='1. A=外側受け / B=ボールソケット',icon='MESH_CUBE')
            box.prop(s,'object_a',text='A：外側の受け')
            box.prop(s,'object_b',text='B：内側ソケット')
            box.operator('cjm.register_targets',text='選択中の2体を登録',icon='EYEDROPPER')
            box.label(text='アクティブな方をBソケットとして登録')
            box.label(text='※ 面選択は不要・既存U字受けを加工')
        else:
            box=layout.box()
            box.label(text='1. A/B の取付面を別々に記憶',icon='FACESEL')
            for side in ('A','B'):
                row=box.row(align=True)
                obj=getattr(s,'object_'+side.lower())
                face=getattr(s,'face_'+side.lower())
                row.label(text=f'{side}: {obj.name if obj else "未登録"} / Face {face if obj else "-"}')
                op=row.operator('face_hinge.capture_face',text='面を記憶',icon='EYEDROPPER')
                op.side=side
            box.label(text='※ 各メッシュの編集モードで1面だけ選択して登録')
            box.label(text='Aが軸の−側 / Bが＋側に各1ナックル')
        box=layout.box()
        box.label(text='2. 3Dカーソル = 回転軸中心',icon='PIVOT_CURSOR')
        _cjm_ui.face_prop(box,s,'axis',expand=True)
        _cjm_ui.face_prop(box,s,'reverse_axis')
        box.label(text='軸の向きはワールドX/Y/Zで固定（カーソル回転は無視）')
        if s.mode == 'TRUNNION':
            box=layout.box()
            box.label(text='3. B左右の軸・Aの受け穴',icon='MOD_SCREW')
            _cjm_ui.face_prop(box,s,'axle_diameter')
            _cjm_ui.face_prop(box,s,'pin_projection')
            _cjm_ui.face_prop(box,s,'pin_embed')
            _cjm_ui.face_prop(box,s,'radial_clearance')
            _cjm_ui.face_prop(box,s,'tip_clearance')
            _cjm_ui.face_prop(box,s,'axial_gap',text='受け穴の入口余裕')
            box.label(text='B側外端を自動判定し左右へ軸を直付け')
            box.label(text='軸穴はAに加工（ヨークは自動生成しません）')
        else:
            box=layout.box()
            box.label(text='3. A-B：各1ナックルとB一体軸',icon='MOD_SCREW')
            _cjm_ui.face_prop(box,s,'a_width');_cjm_ui.face_prop(box,s,'b_width')
            _cjm_ui.face_prop(box,s,'outer_diameter');_cjm_ui.face_prop(box,s,'axle_diameter')
            _cjm_ui.face_prop(box,s,'radial_clearance');_cjm_ui.face_prop(box,s,'axial_gap')
            _cjm_ui.face_prop(box,s,'cap_wall')
            if not s.shoulder_enabled:
                _cjm_ui.face_prop(box,s,'tip_clearance')
            _cjm_ui.face_prop(box,s,'radial_wall')
            shoulder_box=layout.box()
            shoulder_box.label(text='3-2. 肩付き軸（A内部に頭を収める）',icon='MOD_SCREW')
            _cjm_ui.face_prop(shoulder_box,s,'shoulder_enabled')
            if s.shoulder_enabled:
                _cjm_ui.face_prop(shoulder_box,s,'shoulder_diameter')
                _cjm_ui.face_prop(shoulder_box,s,'shoulder_thickness')
                _cjm_ui.face_prop(shoulder_box,s,'shoulder_radial_clearance')
                _cjm_ui.face_prop(shoulder_box,s,'shoulder_axial_clearance')
                shoulder_box.label(text='A内部に広い空間、入口は細い穴')
                shoulder_box.label(text='ON時、外径が不足なら自動で拡張')
                shoulder_box.label(text='※ 一体造形の隙間はスライサーで要確認',icon='INFO')
            box=layout.box()
            box.label(text='4. 選択面からの支持部',icon='ORIENTATION_NORMAL')
            _cjm_ui.face_prop(box,s,'support_width');_cjm_ui.face_prop(box,s,'support_thickness');_cjm_ui.face_prop(box,s,'embed_depth')
            box=layout.box()
            box.label(text='5. 回転逃げ（生成支持部のみ）',icon='DRIVER_ROTATIONAL_DIFFERENCE')
            _cjm_ui.face_prop(box,s,'minimum_angle');_cjm_ui.face_prop(box,s,'maximum_angle')
            _cjm_ui.face_prop(box,s,'angle_step');_cjm_ui.face_prop(box,s,'swing_clearance')
        box=layout.box()
        box.label(text='LIVE / プレビュー / 自動Boolean',icon='OVERLAY')
        box.prop(s,'live_enabled')
        if s.live_enabled:
            box.label(text='黄: 軸中心 / 緑: +方向 / 桃: -方向')
            box.label(text='左右ピンの取付方向も矢印表示')
            _cjm_ui.face_prop(box,s,'preview_angle',slider=True)
            if s.mode == 'TRUNNION':
                box.label(text='橙=B直付け軸 / 水色=A穴 / 黄=B傾き')
            else:
                box.label(text='青=Aの1個 / 橙=Bの1個 / 水色=A穴')
                if s.shoulder_enabled:
                    box.label(text='橙の太い輪=返し頭 / 水色の太い輪=収納空間')
        try:
            p=_plan(context,s)
            if s.mode == 'TRUNNION':
                t=p['trunnion']
                box.label(text=f'B幅 {t.socket_width:.2f} / 左右2軸 / 軸径 {2*t.pin_radius:.2f}')
            else:
                box.label(text=f'軸長 {p["span"].axle_length:.2f} / スイープ {len(p["angles"])}角度')
                if p.get('shoulder'):
                    sh=p['shoulder']
                    box.label(text=f'返し差 {sh.capture_lip:.2f} / 受け壁 {sh.remaining_wall:.2f}')
                    if sh.capture_lip < .20:
                        box.label(text='※ 現寸法の返し差は小さめ（試作向け）',icon='INFO')
                box.label(text=f'回転逃げ安全側の余裕 {p["sweep_padding"]:.2f}')
        except Exception as exc:
            r=box.row();r.alert=True;r.label(text=str(exc)[:105],icon='ERROR')
            if s.mode == 'STRAIGHT':
                box.label(text='直付け軸なら上の「作成方式」を切り替えてください', icon='INFO')
        row=box.row(align=True)
        row.operator('face_hinge.preview_parts',text='部品プレビュー',icon='HIDE_OFF')
        row.operator('face_hinge.clear_preview',text='削除',icon='X')
        box.prop(s,'hide_originals')
        box.operator('face_hinge.generate',text='自動Booleanで確定',icon='MOD_BOOLEAN')
        box.label(text='元のA/Bは変更せず複製品を生成')
        if s.mode == 'TRUNNION':
            box.label(text='※ A側の受け壁/肉厚・回転干渉は未検査')
            box.label(text='※ B内のボールジョイントには触れません')
        else:
            box.label(text='※ 元本体同士の回転干渉は未検査')
        box.label(text='※ Blender実機 / スライサーで要検証')


_CLASSES=(FACEHINGE_Settings,FACEHINGE_OT_assign_pair,FACEHINGE_OT_capture,FACEHINGE_OT_preview,
          FACEHINGE_OT_clear,FACEHINGE_OT_generate,VIEW3D_PT_face_hinge)


def _reset_scene_live_flags():
    """Disable LIVE safely; restricted Blender add-on context has no .scenes.

    Return False when access is temporarily restricted so the one-shot timer
    can perform the initial reset after Blender restores unrestricted access.
    """
    scenes = getattr(getattr(bpy, 'data', None), 'scenes', None)
    if scenes is None:
        return False
    try:
        for scene in scenes:
            settings = getattr(scene, 'face_hinge_settings', None)
            if settings is not None:
                try:
                    settings.live_enabled = False
                except (AttributeError, ReferenceError, RuntimeError):
                    continue
    except (AttributeError, ReferenceError, RuntimeError):
        return False
    return True


@persistent
def _on_load(_dummy):
    _reset_scene_live_flags()


def _delayed_startup_reset():
    """One-shot Blender timer: reset saved startup.blend LIVE after register."""
    # If disabled before the timer fires, do not touch bpy.data.
    if not hasattr(bpy.types.Scene, 'face_hinge_settings'):
        return None
    return None if _reset_scene_live_flags() else 0.25


def _schedule_startup_reset():
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    if timers is None:
        return
    try:
        if not timers.is_registered(_delayed_startup_reset):
            timers.register(_delayed_startup_reset, first_interval=0.0)
    except (AttributeError, ReferenceError, RuntimeError) as exc:
        # Optional timer must never prevent the child UI from registering.
        print(f'Face Hinge: startup LIVE reset timer skipped: {exc}')


def _cancel_startup_reset():
    timers = getattr(getattr(bpy, 'app', None), 'timers', None)
    if timers is None:
        return
    try:
        if timers.is_registered(_delayed_startup_reset):
            timers.unregister(_delayed_startup_reset)
    except (AttributeError, ReferenceError, RuntimeError):
        pass


def register():
    done=[]
    try:
        for cls in _CLASSES:
            bpy.utils.register_class(cls)
            done.append(cls)
        bpy.types.Scene.face_hinge_settings=PointerProperty(type=FACEHINGE_Settings)
        if _on_load not in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.append(_on_load)
        # bpy.data.scenes is hidden while register() runs under _RestrictData.
        # Reset immediately if possible, otherwise schedule after registration.
        if not _reset_scene_live_flags():
            _schedule_startup_reset()
        _install_overlay()
    except Exception:
        _cancel_startup_reset()
        _uninstall_overlay()
        if _on_load in bpy.app.handlers.load_post:
            bpy.app.handlers.load_post.remove(_on_load)
        if hasattr(bpy.types.Scene,'face_hinge_settings'):
            del bpy.types.Scene.face_hinge_settings
        for cls in reversed(done):
            bpy.utils.unregister_class(cls)
        raise


def unregister():
    _cancel_startup_reset()
    _uninstall_overlay()
    if _on_load in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(_on_load)
    _preview_clear()
    if hasattr(bpy.types.Scene,'face_hinge_settings'):
        del bpy.types.Scene.face_hinge_settings
    for cls in reversed(_CLASSES):
        bpy.utils.unregister_class(cls)
