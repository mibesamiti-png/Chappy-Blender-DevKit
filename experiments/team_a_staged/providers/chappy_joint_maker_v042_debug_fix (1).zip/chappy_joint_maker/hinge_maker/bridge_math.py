"""Hinge Maker connector-bridge geometry, independent of Blender.

CBDK-HMEXP-004 experimental geometry contract.  All coordinates are in the
same world-space length units; no bpy import and no hidden state mutation.
This is a Hinge Maker testbed helper, NOT a registered CBDK part.
"""
from __future__ import annotations

from dataclasses import dataclass
from math import isfinite, sqrt


def v(value):
    result = tuple(float(x) for x in value)
    if len(result) != 3 or not all(isfinite(x) for x in result):
        raise ValueError('Invalid 3D coordinate')
    return result


def add(a, b):
    return tuple(x + y for x, y in zip(a, b))


def sub(a, b):
    return tuple(x - y for x, y in zip(a, b))


def mul(a, s):
    return tuple(x * s for x in a)


def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def cross(a, b):
    return (a[1] * b[2] - a[2] * b[1],
            a[2] * b[0] - a[0] * b[2],
            a[0] * b[1] - a[1] * b[0])


def length(a):
    return sqrt(dot(a, a))


def unit(a):
    size = length(a)
    if size < 1e-9:
        raise ValueError('Zero-length direction')
    return mul(a, 1.0 / size)


def radial(a, z):
    return sub(a, mul(z, dot(a, z)))


@dataclass(frozen=True)
class BridgePlan:
    vertices: tuple[tuple[float, float, float], ...]
    faces: tuple[tuple[int, ...], ...]
    start: tuple[float, float, float]
    end: tuple[float, float, float]
    contact: tuple[float, float, float]
    reach: float
    embed: float
    face_width: float
    face_height: float
    root_radius: float
    axial_shift: float


def plan_bridge(*, knuckle_center, axis, surface_contact, body_center,
                outer_radius, hole_radius, knuckle_length, embed,
                width_ratio=0.65, max_reach=40.0):
    """Make a manifold rectangular root-to-body strut prism.

    The root overlaps *only the annular wall* of a tube, so it cannot clog
    the shaft bore. The far end penetrates beyond an actual body surface
    contact. A contact off the knuckle's axial lane is rejected rather than
    creating a strut through the neighboring rotating knuckle.
    """
    c = v(knuckle_center)
    z = unit(v(axis))
    surface = v(surface_contact)
    body = v(body_center)
    outer_radius, hole_radius = float(outer_radius), float(hole_radius)
    knuckle_length, embed = float(knuckle_length), float(embed)
    width_ratio, max_reach = float(width_ratio), float(max_reach)
    values = (outer_radius, hole_radius, knuckle_length, embed, width_ratio, max_reach)
    if not all(isfinite(n) for n in values) or not (
        outer_radius > hole_radius >= 0.0 and knuckle_length > 0.0
        and embed > 0.0 and 0.1 <= width_ratio <= 1.2 and max_reach > outer_radius
    ):
        raise ValueError('Invalid bridge dimensions')
    reach = length(sub(surface, c))
    if reach > max_reach:
        raise ValueError(f'本体表面まで{reach:.3f}（接続距離上限{max_reach:.3f}）: ヒンジ位置を調整してください')
    towards = radial(sub(surface, c), z)
    if length(towards) < 1e-5:
        towards = radial(sub(body, c), z)
    if length(towards) < 1e-5:
        raise ValueError('本体への半径方向を特定できません。3Dカーソルをヒンジ軸に配置し直してください')
    direction = unit(towards)
    surface_axial = dot(sub(surface, c), z)
    # Do not build a diagonal bridge through an adjacent A/B knuckle lane.
    if abs(surface_axial) >= knuckle_length * 0.5 - max(1e-5, knuckle_length * 0.02):
        raise ValueError(
            f'接続先がナックル幅の外側（軸方向差 {surface_axial:.3f}）: '
            'ヒンジ軸/本体位置を見直してください'
        )
    root_r = hole_radius + (outer_radius - hole_radius) * (0.66 if hole_radius else 0.70)
    start = add(c, mul(direction, root_r))
    to_interior = radial(sub(body, surface), z)
    # The nearest face may be on a complex, non-convex object; if the bbox
    # center does not indicate a usable interior, continue radially outwards.
    if length(to_interior) < 1e-7 or dot(unit(to_interior), direction) < 0.05:
        to_interior = direction
    end = add(surface, mul(unit(to_interior), embed))
    # Small/partly embedded objects can have a surface *inside* the barrel;
    # keep the prism long enough to overlap the barrel and that surface.
    if dot(sub(end, start), direction) < outer_radius * 0.20:
        end = add(end, mul(direction, outer_radius * 0.20 - dot(sub(end, start), direction)))
    travel = sub(end, start)
    if length(travel) < 1e-7 or dot(unit(travel), direction) < 0.55:
        raise ValueError('本体との接続が軸方向に偏りすぎています。ヒンジ位置を調整してください')

    tangent = unit(cross(z, direction))
    # For a tilted bridge, the second face axis is perpendicular to travel
    # and tangent; it remains as close to the hinge axis as possible.
    transverse = unit(cross(unit(travel), tangent))
    face_width = outer_radius * 2.0 * width_ratio
    face_height = min(knuckle_length * 0.76, outer_radius * 1.65)

    def four(center, h):
        hw, hh = face_width * 0.5, h * 0.5
        return tuple(add(add(center, mul(tangent, u * hw)), mul(transverse, w * hh))
                     for u, w in ((-1, -1), (1, -1), (1, 1), (-1, 1)))

    # A complete bridge, including its END face, must remain within its own
    # axial knuckle lane. Merely bounding the nearest point is insufficient.
    margin = max(1e-5, (outer_radius - hole_radius) * 0.035)
    axial_margin = max(1e-5, knuckle_length * 0.02)
    for _ in range(20):
        root_corners = four(start, face_height)
        end_corners = four(end, face_height)
        radial_min = min(length(radial(sub(p, c), z))
                         for p in root_corners + (start,))
        max_axial = max(abs(dot(sub(p, c), z))
                        for p in root_corners + end_corners)
        if radial_min >= hole_radius + margin and max_axial <= knuckle_length * 0.5 - axial_margin:
            break
        face_height *= 0.75
    else:
        raise ValueError('軸穴/隣接ナックルに干渉しないブリッジ断面を確保できません')
    if face_height < knuckle_length * 0.06:
        raise ValueError('接続ブリッジの高さを確保できません')
    vertices = root_corners + four(end, face_height)
    faces = ((3, 2, 1, 0), (4, 5, 6, 7), (0, 1, 5, 4),
             (1, 2, 6, 5), (2, 3, 7, 6), (3, 0, 4, 7))
    return BridgePlan(vertices, faces, start, end, surface, reach, embed,
                      face_width, face_height, root_r, surface_axial)
