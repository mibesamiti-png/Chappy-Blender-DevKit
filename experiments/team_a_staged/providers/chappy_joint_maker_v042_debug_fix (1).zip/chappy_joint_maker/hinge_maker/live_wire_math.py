"""Bpy-independent 3D wire guide plans derived from the hinge generator's dimensions.

No Boolean, real-mesh inspection, slicer checks or collision claims.  A cylinder
here is an *annotation* of a planned shaft, bore or knuckle, never a solid mesh.
"""
from dataclasses import dataclass
from math import cos, sin, pi, isfinite


GUIDE_MODES = ('ALL', 'AXLE', 'BORE', 'KNUCKLE', 'CLEARANCE', 'ERRORS')


@dataclass(frozen=True)
class WireCylinder:
    start: float
    end: float
    radius: float
    kind: str  # KNUCKLE / AXLE / BORE / RELIEF
    owner: str = ''
    focus: str = ''
    warning: bool = False


@dataclass(frozen=True)
class WireMarker:
    start: float
    end: float
    radius: float
    kind: str  # GAP / TIP / CAP / RADIAL / FACE
    focus: str
    warning: bool = False


def _cylinder(start, end, radius, kind, *, owner='', focus='', warning=False):
    nums = (float(start), float(end), float(radius))
    if not all(isfinite(n) for n in nums) or nums[2] <= 0 or nums[1] <= nums[0]:
        return None
    return WireCylinder(*nums, kind=kind, owner=owner, focus=focus, warning=warning)


def _marker(start, end, radius, kind, focus, warning=False):
    nums = (float(start), float(end), float(radius))
    if not all(isfinite(n) for n in nums) or nums[2] < 0:
        return None
    return WireMarker(*nums, kind, focus, warning)


def make_wire_plan(plan, settings, *, mode='ALL', focus='OVERVIEW', failed=()):
    """Return 3D annotation primitives without mutating the Blender scene.

    Geometry from make_guide_plan() uses exact knuckle, blind-bore and axle
    axial intervals. Radial values are taken from the current settings. Body
    relief is an *ideal cutter*, not the final post-Boolean body surface.
    """
    if mode not in GUIDE_MODES:
        mode = 'ALL'
    failed = set(failed)
    outside = float(settings.outer_diameter) * .5
    shaft = float(settings.pin_diameter) * .5
    bore = shaft + float(settings.pin_clearance)
    relief = outside + float(getattr(settings, 'body_relief_clearance', 0.0))
    if not all(isfinite(n) and n > 0 for n in (outside, shaft, bore)):
        return (), ()
    cylinders, markers = [], []

    def add_cyl(a, b, r, kind, owner='', key='', warnings=()):
        alert = bool(failed.intersection(warnings))
        if mode == 'ERRORS' and not alert:
            return
        should_show = (
            mode in ('ALL', 'ERRORS') or
            (mode == 'KNUCKLE' and kind == 'KNUCKLE') or
            (mode == 'AXLE' and kind == 'AXLE') or
            (mode == 'BORE' and kind == 'BORE') or
            (mode == 'CLEARANCE' and kind in ('AXLE', 'BORE', 'RELIEF'))
        )
        # In the full overview, relief cutter shells would obscure the real
        # barrel positions; only show relief when explicitly focused.
        if kind == 'RELIEF' and mode == 'ALL':
            should_show = focus in ('BODY_RELIEF', 'FACE_CLEARANCE')
        if should_show:
            item = _cylinder(a, b, r, kind, owner=owner, focus=key, warning=alert)
            if item is not None:
                cylinders.append(item)

    def add_mark(a, b, r, kind, key, warnings=()):
        alert = bool(failed.intersection(warnings))
        if mode == 'ERRORS' and not alert:
            return
        if mode in ('ALL', 'CLEARANCE', 'ERRORS') or (
            mode == 'KNUCKLE' and kind == 'GAP'
        ) or (mode == 'AXLE' and kind in ('TIP', 'CAP')) or (
            mode == 'BORE' and kind in ('TIP', 'CAP', 'RADIAL')
        ):
            item = _marker(a, b, r, kind, key, warning=alert)
            if item is not None:
                markers.append(item)

    for ix, segment in enumerate(plan.segments):
        warnings = ('SIDE_LENGTH', 'TOTAL_LENGTH') if ix != 1 else ('CENTER_LENGTH', 'TOTAL_LENGTH')
        if ix != 1:
            warnings += ('CAP_WALL',)
        add_cyl(segment.start, segment.end, outside, 'KNUCKLE',
                owner=segment.owner, key='DIAMETER', warnings=warnings + ('RADIAL_WALL',))

    if getattr(settings, 'hinge_style', 'INTEGRATED_AXLE') == 'THROUGH_PIN':
        if getattr(settings, 'pin_mode', 'SEPARATE') != 'NONE':
            extra = max(0.0, float(getattr(settings, 'pin_end_extra', 0.0)))
            shaft_limits = (plan.left - extra, plan.right + extra)
        else:
            shaft_limits = None
    else:
        shaft_limits = plan.axle
    if shaft_limits:
        add_cyl(*shaft_limits, shaft, 'AXLE', key='PIN_DIAMETER',
                warnings=('AXLE_LENGTH', 'AXLE_TIP', 'PIN_DIAMETER', 'PIN_CLEARANCE'))
    for a, b in plan.bores:
        add_cyl(a, b, bore, 'BORE', key='PIN_CLEARANCE',
                warnings=('RADIAL_WALL', 'PIN_CLEARANCE', 'PIN_DIAMETER', 'CAP_WALL'))

    for a, b in plan.gaps:
        add_mark(a, b, outside * 1.18, 'GAP', 'KNUCKLE_GAP',
                 ('KNUCKLE_GAP', 'TOTAL_LENGTH'))
    for a, b in plan.tips:
        add_mark(a, b, max(bore, shaft) * 1.10, 'TIP', 'AXLE_TIP',
                 ('AXLE_TIP', 'AXLE_LENGTH'))
    for a, b in plan.caps:
        add_mark(a, b, outside * .84, 'CAP', 'CAP_WALL', ('CAP_WALL',))
    # One radial marker on each actual bore, not inside the central solid B.
    for a, b in plan.bores:
        add_mark((a+b)*.5, (a+b)*.5, bore, 'RADIAL', 'PIN_CLEARANCE',
                 ('RADIAL_WALL', 'PIN_CLEARANCE'))

    if getattr(settings, 'make_body_relief', False) and mode in ('CLEARANCE','ALL','ERRORS'):
        gap = float(settings.knuckle_gap)
        requested = gap if getattr(settings, 'face_clearance_follow_gap', True) else float(settings.face_clearance)
        epsilon = min(max(gap, 0.0) * .05, max(.00001, float(plan.total) * .0001))
        face = min(max(0.0, requested), max(0.0, gap-epsilon))
        for seg in plan.segments:
            add_cyl(seg.start-face, seg.end+face, relief, 'RELIEF',
                    owner='B' if seg.owner == 'A' else 'A', key='BODY_RELIEF',
                    warnings=('BODY_RELIEF','FACE_CLEARANCE'))
        if focus == 'FACE_CLEARANCE' or 'FACE_CLEARANCE' in failed:
            for seg in plan.segments:
                add_mark(seg.start-face, seg.start, relief, 'FACE', 'FACE_CLEARANCE', ('FACE_CLEARANCE',))
                add_mark(seg.end, seg.end+face, relief, 'FACE', 'FACE_CLEARANCE', ('FACE_CLEARANCE',))
    return tuple(cylinders), tuple(markers)


def cylinder_edges(item, segments=24):
    """Pairs of (axial-z, perpendicular-u, perpendicular-v) local endpoints.

    Drawing these in two screen dimensions after world-space projection gives
    both end rings and four lengthwise rails, not only a centre line.
    """
    steps = max(12, min(64, int(segments)))
    r = item.radius
    for z in (item.start, item.end):
        for i in range(steps):
            t0, t1 = 2*pi*i/steps, 2*pi*(i+1)/steps
            yield ((z, r*cos(t0), r*sin(t0)), (z, r*cos(t1), r*sin(t1)))
    for t in (0., pi*.5, pi, 1.5*pi):
        yield ((item.start, r*cos(t), r*sin(t)),
               (item.end, r*cos(t), r*sin(t)))
