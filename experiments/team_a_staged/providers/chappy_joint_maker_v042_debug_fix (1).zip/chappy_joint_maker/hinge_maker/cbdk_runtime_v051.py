"""CBDK runtime subset embedded for the Hinge Maker experimental testbed.

Provenance / intent
-------------------
BLCTX-001 require_active_mesh
BLCTX-002 selected_mesh_objects
  Source family: mibesamiti-png/Chappy-Blender-DevKit
  parts/blender/context.py (main / feature/v0.17-undo-redo-probe)

BLMOD-001 ModifierSnapshot semantics
  Source family: parts/blender/modifiers.py

CBDK-HMEXP-001 modifier delta audit
  New experimental Hinge Maker candidate. It is intentionally *not* claimed as
  a registered/approved CBDK part. Manual Blender GUI testing of Hinge Maker is
  the proving ground before possible promotion back into CBDK.
"""
from __future__ import annotations

from dataclasses import dataclass


class BlenderContextError(RuntimeError):
    """Raised when a helper cannot safely use supplied Blender data."""


def require_active_mesh(context, *, mode: str | None = None):
    """CBDK BLCTX-001: return active mesh without hidden mode changes."""
    if context is None:
        raise BlenderContextError('A Blender context must be provided')
    obj = getattr(context, 'active_object', None)
    if obj is None or getattr(obj, 'type', None) != 'MESH' or getattr(obj, 'data', None) is None:
        raise BlenderContextError('An active mesh object is required')
    if mode is not None and getattr(context, 'mode', None) != mode:
        raise BlenderContextError(f'Context mode {mode!r} is required')
    return obj


def selected_mesh_objects(context) -> tuple:
    """CBDK BLCTX-002: detached tuple of selected Mesh objects."""
    if context is None:
        raise BlenderContextError('A Blender context must be provided')
    selected = getattr(context, 'selected_objects', None)
    if selected is None:
        raise BlenderContextError('Context does not expose selected_objects')
    return tuple(
        obj for obj in selected
        if getattr(obj, 'type', None) == 'MESH' and getattr(obj, 'data', None) is not None
    )


@dataclass(frozen=True)
class ModifierSnapshot:
    name: str
    type: str
    viewport: bool
    render: bool


def modifier_snapshot_object(obj) -> tuple[ModifierSnapshot, ...]:
    """BLMOD-001 semantics adapted to an explicit object argument.

    The CBDK original reads the active mesh from an explicit context. Hinge
    Maker has two targets (A/B), so this wrapper keeps the same detached,
    read-only snapshot contract while avoiding active-object shuffling.
    """
    if obj is None or getattr(obj, 'type', None) != 'MESH' or getattr(obj, 'data', None) is None:
        raise BlenderContextError('A mesh object is required for modifier snapshot')
    return tuple(
        ModifierSnapshot(
            name=str(mod.name),
            type=str(mod.type),
            viewport=bool(mod.show_viewport),
            render=bool(mod.show_render),
        )
        for mod in obj.modifiers
    )


@dataclass(frozen=True)
class ModifierDeltaAudit:
    valid: bool
    expected_added: int
    actual_added: int
    detail: str


def audit_modifier_delta(
    before: tuple[ModifierSnapshot, ...],
    after: tuple[ModifierSnapshot, ...],
    *,
    expected_added: int,
    required_type: str,
    required_name_prefix: str,
) -> ModifierDeltaAudit:
    """CBDK-HMEXP-001: verify only the expected tail modifiers were added.

    This is deliberately conservative. It does not claim that a Boolean shape
    is correct; it only checks modifier-stack bookkeeping for the non-applied
    Hinge Maker workflow.
    """
    if type(expected_added) is not int or expected_added < 0:
        raise BlenderContextError('expected_added must be a non-negative int')
    if not isinstance(required_type, str) or not required_type:
        raise BlenderContextError('required_type is required')
    if not isinstance(required_name_prefix, str) or not required_name_prefix:
        raise BlenderContextError('required_name_prefix is required')

    if len(after) < len(before):
        return ModifierDeltaAudit(False, expected_added, len(after) - len(before), '既存Modifierが減少')

    # Existing stack must remain byte-for-byte equivalent at the front.
    if after[:len(before)] != before:
        return ModifierDeltaAudit(False, expected_added, len(after) - len(before), '既存Modifier順序/状態が変化')

    added = after[len(before):]
    if len(added) != expected_added:
        return ModifierDeltaAudit(False, expected_added, len(added), f'追加数 {len(added)} / 期待 {expected_added}')

    bad = [m.name for m in added if m.type != required_type or not m.name.startswith(required_name_prefix)]
    if bad:
        return ModifierDeltaAudit(False, expected_added, len(added), '想定外Modifier: ' + ', '.join(bad[:4]))

    return ModifierDeltaAudit(True, expected_added, len(added), f'PASS +{len(added)} {required_type}')


def format_modifier_snapshot(snapshot: tuple[ModifierSnapshot, ...], *, limit: int = 5) -> str:
    if not snapshot:
        return 'none'
    items = [f'{m.name}:{m.type}' for m in snapshot[:max(1, limit)]]
    if len(snapshot) > limit:
        items.append(f'+{len(snapshot)-limit} more')
    return ', '.join(items)


# ---------------------------------------------------------------------------
# CBDK-HMEXP-003: exact Boolean modifier-plan audit
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class ModifierPlanSnapshot:
    name: str
    type: str
    viewport: bool
    render: bool
    operation: str | None
    object_name: str | None


def modifier_plan_snapshot_object(obj) -> tuple[ModifierPlanSnapshot, ...]:
    """Detached modifier snapshot including Boolean operation/target.

    Experimental Hinge Maker testbed helper.
    This extends the read-only BLMOD-001 idea without changing the source stack.
    """
    if obj is None or getattr(obj, 'type', None) != 'MESH' or getattr(obj, 'data', None) is None:
        raise BlenderContextError('A mesh object is required for modifier-plan snapshot')

    result = []
    for mod in obj.modifiers:
        op = None
        target_name = None
        if str(getattr(mod, 'type', '')) == 'BOOLEAN':
            op = str(getattr(mod, 'operation', ''))
            target = getattr(mod, 'object', None)
            target_name = getattr(target, 'name', None) if target is not None else None

        result.append(
            ModifierPlanSnapshot(
                name=str(mod.name),
                type=str(mod.type),
                viewport=bool(mod.show_viewport),
                render=bool(mod.show_render),
                operation=op,
                object_name=target_name,
            )
        )
    return tuple(result)


@dataclass(frozen=True)
class BooleanPlanAudit:
    valid: bool
    expected_added: int
    actual_added: int
    detail: str


def audit_boolean_modifier_plan(
    before: tuple[ModifierPlanSnapshot, ...],
    after: tuple[ModifierPlanSnapshot, ...],
    *,
    expected_plan: tuple[tuple[str, str, str], ...],
) -> BooleanPlanAudit:
    """Verify the exact tail Boolean plan added by one operation.

    expected_plan entries are:
        (exact_modifier_name, operation, exact_target_object_name)

    This checks bookkeeping only. It deliberately does not claim that the
    resulting geometry is visually/mechanically correct.
    """
    if not isinstance(expected_plan, tuple):
        raise BlenderContextError('expected_plan must be a tuple')

    if len(after) < len(before):
        return BooleanPlanAudit(
            False,
            len(expected_plan),
            len(after) - len(before),
            '既存Modifierが減少',
        )

    if after[:len(before)] != before:
        return BooleanPlanAudit(
            False,
            len(expected_plan),
            len(after) - len(before),
            '既存Modifier順序/状態が変化',
        )

    added = after[len(before):]

    if len(added) != len(expected_plan):
        return BooleanPlanAudit(
            False,
            len(expected_plan),
            len(added),
            f'追加数 {len(added)} / 期待 {len(expected_plan)}',
        )

    problems = []

    for index, (actual, expected) in enumerate(zip(added, expected_plan), start=1):
        exp_name, exp_operation, exp_object = expected

        if actual.type != 'BOOLEAN':
            problems.append(f'{index}: type={actual.type}')
            continue

        if actual.name != exp_name:
            problems.append(f'{index}: name={actual.name!r} expected={exp_name!r}')

        if actual.operation != exp_operation:
            problems.append(
                f'{index}: operation={actual.operation!r} expected={exp_operation!r}'
            )

        if actual.object_name != exp_object:
            problems.append(
                f'{index}: object={actual.object_name!r} expected={exp_object!r}'
            )

    if problems:
        return BooleanPlanAudit(
            False,
            len(expected_plan),
            len(added),
            ' / '.join(problems[:4]),
        )

    ops = ', '.join(entry[1] for entry in expected_plan) or 'none'

    return BooleanPlanAudit(
        True,
        len(expected_plan),
        len(added),
        f'PASS +{len(added)} [{ops}]',
    )

# ---------------------------------------------------------------------------
# CBDK-HMEXP-004: geometrical witness plan / safe failure for disconnected pieces
# ---------------------------------------------------------------------------
from math import isfinite


@dataclass(frozen=True)
class BridgeConnectionAudit:
    valid: bool
    expected: int
    actual: int
    detail: str


def audit_bridge_connections(witnesses, *, layout: str) -> BridgeConnectionAudit:
    """Check which owning body every generated barrel is connected *towards*.

    This is a geometry-contract check, NOT proof that the user's input mesh is
    manifold, the final Boolean is print-ready, or the hinge actually rotates.
    That requires evaluated-mesh / Blender integration and physical checking.
    """
    if layout not in ('ABA', 'BAB'):
        raise BlenderContextError('Unsupported hinge layout')
    if not isinstance(witnesses, (tuple, list)):
        raise BlenderContextError('Witnesses must be an ordered sequence')
    side = layout[0]
    middle = layout[1]
    expected = {(side, 'Left'), (middle, 'Center'), (side, 'Right')}
    actual = []
    problems = []
    for item in witnesses:
        if not isinstance(item, dict):
            problems.append('bad witness type')
            continue
        key = (item.get('owner'), item.get('label'))
        actual.append(key)
        for number in ('reach', 'embed', 'axial_shift'):
            value = item.get(number)
            if isinstance(value, bool) or not isinstance(value, (float, int)) or not isfinite(value):
                problems.append(f'{key} {number} invalid')
        if isinstance(item.get('reach'), (float, int)) and item['reach'] < 0:
            problems.append(f'{key} negative reach')
        if isinstance(item.get('embed'), (float, int)) and item['embed'] <= 0:
            problems.append(f'{key} nonpositive embed')
        if item.get('components') != 1:
            problems.append(f'{key} disconnected mesh islands')
    if len(actual) != len(expected) or set(actual) != expected or len(set(actual)) != len(actual):
        problems.append(f'owner coverage {actual!r} != {sorted(expected)!r}')
    return BridgeConnectionAudit(
        valid=(not problems), expected=len(expected), actual=len(actual),
        detail=('PASS all 3 knuckle bridges connected' if not problems
                else '; '.join(problems[:4])),
    )
