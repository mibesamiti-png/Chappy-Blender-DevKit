bl_info = {
    "name": "Hinge Maker + Face Hinge",
    "author": "OpenAI / Chappy",
    "version": (0, 5, 16),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > Hinge Maker",
    "description": "[自作アドオン] 通常ヒンジ + Face Hinge (直付け軸・面指定)",
    "category": "自作アドオン",
}

ADDON_TAGS = ("自作アドオン",)

# Failures in the optional Face Hinge submodule must be visible, not merely printed.
_FACE_HINGE_REGISTER_ERROR = None

import bpy
from .. import ui as _cjm_ui
# Blender files can save the LIVE switch in their Scene settings. Reset it
# every time a file is loaded so opening Blender never shows the overlay.
try:
    from bpy.app.handlers import persistent as _persistent
except (ImportError, AttributeError):  # Offline test stubs do not expose bpy.app
    def _persistent(func):
        return func

from mathutils import Matrix, Vector
from mathutils.bvhtree import BVHTree
from .bridge_math import plan_bridge
from .axle_math import plan_integrated_axle, AxleSpan
from .end_geometry import (plan_trim_knuckles, plan_blind_bores,
                           resolve_face_clearance, print_clearance_warnings)
from .boolean_order import ordered_boolean_operations
from bpy.types import Operator, Panel, PropertyGroup
from bpy.props import BoolProperty, EnumProperty, FloatProperty, IntProperty, PointerProperty, StringProperty

# CBDK embedded runtime components / experimental audit
from .cbdk_runtime_v051 import (
    BlenderContextError,
    require_active_mesh,
    selected_mesh_objects,
    modifier_snapshot_object,
    audit_modifier_delta,
    format_modifier_snapshot,
    modifier_plan_snapshot_object,
    audit_boolean_modifier_plan,
    audit_bridge_connections,
)

PREVIEW_COLLECTION = "HingeMaker_Preview"

from .live_guide_math import FOCUS_INFO
from .dimension_math import (auto_lengths, manual_lengths, usable_length,
                             edit_side, edit_center, trim_side_length,
                             trim_axle_from_side, minimum_total_for_blind_cap)
from .dimension_diagnostics import inspect_dimensions


def _guide_redraw(context):
    # The overlay is optional and never needed for geometry generation.
    try:
        from . import live_overlay
        live_overlay.tag_redraw(context)
    except (ImportError, AttributeError, RuntimeError):
        pass


def _guide_update(focus):
    """Focus the edited dimension; only redraw, never rebuild/Boolean meshes."""
    def update(self, context):
        try:
            if self.guide_focus != focus:
                self.guide_focus = focus
        except (AttributeError, TypeError):
            pass
        _guide_redraw(context)
    return update


def _guide_changed(self, context):
    _guide_redraw(context)


def _guide_prop(layout, settings, name, focus, *, text=None):
    """Settings slider plus a one-click visual-location button."""
    return _cjm_ui.focus_row(layout,settings,name,'hinge',focus,**({'text':text} if text is not None else {}))


def _resolved_edit_lengths(self):
    """Read-only calculation until first manual edit; supports old .blend files."""
    if (self.hinge_style == 'INTEGRATED_AXLE' and self.axle_end_mode == 'TRIM'):
        return (trim_side_length(self.trim_center_length, self.trim_axle_length,
                                 self.knuckle_gap, self.axle_tip_clearance),
                self.trim_center_length)
    if bool(self.get('_hm_manual_lengths', False)):
        return manual_lengths(self.total_length, self.knuckle_gap,
                              self.get('_hm_ref_usable', 0),
                              self.get('_hm_ref_side', 0),
                              self.get('_hm_ref_center', 0))
    return auto_lengths(self.total_length, self.knuckle_gap,
                        self.length_mode, self.center_ratio)


def _side_length_get(self):
    try:
        return max(0., _resolved_edit_lengths(self)[0])
    except (ValueError, TypeError, RuntimeError, ZeroDivisionError):
        return 0.


def _center_length_get(self):
    try:
        return max(0., _resolved_edit_lengths(self)[1])
    except (ValueError, TypeError, RuntimeError, ZeroDivisionError):
        return 0.


def _store_manual_lengths(self, usable, side, center):
    self['_hm_ref_usable'] = float(usable)
    self['_hm_ref_side'] = float(side)
    self['_hm_ref_center'] = float(center)
    self['_hm_manual_lengths'] = True


def _side_length_set(self, value):
    if self.hinge_style == 'INTEGRATED_AXLE' and self.axle_end_mode == 'TRIM':
        # Shaft-first mode: editing the side length adjusts axle length,
        # while the center length remains the chosen reference.
        self.trim_axle_length = max(.001, trim_axle_from_side(
            self.trim_center_length, value, self.knuckle_gap, self.axle_tip_clearance))
        return
    try:
        _store_manual_lengths(self, *edit_side(self.total_length,
                                               self.knuckle_gap, value))
    except (ValueError, TypeError):
        pass


def _center_length_set(self, value):
    if self.hinge_style == 'INTEGRATED_AXLE' and self.axle_end_mode == 'TRIM':
        # Keep axle length fixed in shaft-first mode; side length follows.
        self.trim_center_length = max(.001, float(value))
        return
    try:
        _store_manual_lengths(self, *edit_center(self.total_length,
                                                 self.knuckle_gap, value))
    except (ValueError, TypeError):
        pass


def _distribution_update(focus):
    def update(self, context):
        # Explicitly choosing the ratio/equal layout restores auto allocation.
        self['_hm_manual_lengths'] = False
        _guide_update(focus)(self, context)
        from .. import constraints
        constraints.changed(self,context,'hinge','center_ratio')
    return update


def _current_dimension_issues(settings):
    try:
        specs, span, _ = resolved_hinge_geometry(settings)
        return inspect_dimensions(settings, specs, span)
    except (ValueError, RuntimeError, TypeError, ZeroDivisionError) as exc:
        from .dimension_diagnostics import DimensionIssue, focus_from_error
        issues = list(inspect_dimensions(settings))
        issues.append(DimensionIssue(focus_from_error(str(exc)), str(exc)))
        return tuple(issues)


def ensure_object_mode():
    if bpy.context.mode == 'OBJECT':
        return
    if bpy.context.active_object is None:
        raise RuntimeError("Object Modeへ切り替える対象がありません。")
    bpy.ops.object.mode_set(mode='OBJECT')


def set_active(obj):
    ensure_object_mode()
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj


def get_or_create_collection(name, parent=None):
    col = bpy.data.collections.get(name)
    if col is not None:
        return col
    col = bpy.data.collections.new(name)
    (parent or bpy.context.scene.collection).children.link(col)
    return col


def unique_collection_name(base):
    if base not in bpy.data.collections:
        return base
    i = 1
    while True:
        candidate = f"{base}_{i:03d}"
        if candidate not in bpy.data.collections:
            return candidate
        i += 1


def is_live_object(obj):
    """A removed Blender RNA object raises ReferenceError on .name."""
    if obj is None:
        return False
    try:
        return obj.name in bpy.data.objects
    except ReferenceError:
        return False


def delete_object(obj):
    if is_live_object(obj):
        old_mesh = obj.data if obj.type == 'MESH' else None
        bpy.data.objects.remove(obj, do_unlink=True)
        if old_mesh is not None and old_mesh.users == 0:
            bpy.data.meshes.remove(old_mesh)


def remove_collection_tree(col):
    if col is None:
        return
    for child in list(col.children):
        remove_collection_tree(child)
    for obj in list(col.objects):
        bpy.data.objects.remove(obj, do_unlink=True)
    try:
        bpy.data.collections.remove(col)
    except Exception:
        pass


def clear_preview():
    # Also used during unregister(), when Blender may expose _RestrictData.
    collections = getattr(getattr(bpy, 'data', None), 'collections', None)
    if collections is None:
        return
    col = collections.get(PREVIEW_COLLECTION)
    if col is not None:
        remove_collection_tree(col)


def boolean_apply(target, cutter, operation):
    set_active(target)
    mod = target.modifiers.new(name=f"Hinge_{operation}", type='BOOLEAN')
    mod.operation = operation
    mod.solver = 'EXACT'
    mod.object = cutter
    try:
        bpy.ops.object.modifier_apply(modifier=mod.name)
    except Exception:
        try:
            target.modifiers.remove(mod)
        except Exception:
            pass
        raise


def add_boolean_modifier(target, source, operation, name):
    mod = target.modifiers.new(name=name, type='BOOLEAN')
    mod.operation = operation
    mod.solver = 'EXACT'
    mod.object = source
    return mod


def add_union_modifier(target, source, name):
    return add_boolean_modifier(
        target,
        source,
        'UNION',
        name,
    )


def add_cylinder(name, radius, depth, matrix_world, collection, vertices=48):
    bpy.ops.mesh.primitive_cylinder_add(
        vertices=max(12, int(vertices)),
        radius=radius,
        depth=depth,
        end_fill_type='NGON',
        location=(0.0, 0.0, 0.0),
    )
    obj = bpy.context.object
    obj.name = name
    for col in list(obj.users_collection):
        col.objects.unlink(obj)
    collection.objects.link(obj)
    obj.matrix_world = matrix_world
    return obj


def axis_matrix(location, axis_world, x_hint=None):
    z = Vector(axis_world).normalized()
    if x_hint is None:
        x_hint = Vector((1.0, 0.0, 0.0))
    x = Vector(x_hint)
    x = x - z * x.dot(z)
    if x.length < 1e-7:
        x = Vector((0.0, 1.0, 0.0))
        x = x - z * x.dot(z)
    x.normalize()
    y = z.cross(x).normalized()
    x = y.cross(z).normalized()
    return Matrix((
        (x.x, y.x, z.x, location.x),
        (x.y, y.y, z.y, location.y),
        (x.z, y.z, z.z, location.z),
        (0.0, 0.0, 0.0, 1.0),
    ))


def get_axis_world(context, settings):
    cursor_m = context.scene.cursor.matrix
    if settings.axis_mode == 'WORLD_X':
        axis = Vector((1.0, 0.0, 0.0))
    elif settings.axis_mode == 'WORLD_Y':
        axis = Vector((0.0, 1.0, 0.0))
    elif settings.axis_mode == 'WORLD_Z':
        axis = Vector((0.0, 0.0, 1.0))
    elif settings.axis_mode == 'CURSOR_X':
        axis = Vector(cursor_m.col[0].xyz)
    elif settings.axis_mode == 'CURSOR_Y':
        axis = Vector(cursor_m.col[1].xyz)
    else:
        axis = Vector(cursor_m.col[2].xyz)
    if settings.axis_flip:
        axis.negate()
    if axis.length < 1e-8:
        raise RuntimeError("ヒンジ軸方向を計算できません。")
    return axis.normalized()


def knuckle_lengths(settings):
    """One resolved source for generation, preview, 2D/3D guides and UI."""
    stored = getattr(settings, 'get', None)
    if bool(stored('_hm_manual_lengths', False) if callable(stored) else False):
        side, center = manual_lengths(
            settings.total_length, settings.knuckle_gap,
            stored('_hm_ref_usable', 0),
            stored('_hm_ref_side', 0),
            stored('_hm_ref_center', 0),
        )
    else:
        side, center = auto_lengths(
            settings.total_length, settings.knuckle_gap,
            settings.length_mode, settings.center_ratio,
        )
    if min(side, center) <= 0:
        raise RuntimeError('個別A/B長さが不足です。全長かA/Bの長さを調整してください')
    return side, center, side


def knuckle_specs(settings):
    l1, l2, l3 = knuckle_lengths(settings)
    gap = settings.knuckle_gap
    z1 = -settings.total_length * 0.5 + l1 * 0.5
    z2 = z1 + l1 * 0.5 + gap + l2 * 0.5
    z3 = z2 + l2 * 0.5 + gap + l3 * 0.5
    owners = ('A', 'B', 'A') if settings.layout_mode == 'ABA' else ('B', 'A', 'B')
    return [(owners[0], z1, l1, "Left"), (owners[1], z2, l2, "Center"), (owners[2], z3, l3, "Right")]


def resolved_hinge_geometry(settings):
    """Single source of truth for both generated knuckles and axle/bores."""
    if settings.hinge_style == 'INTEGRATED_AXLE' and settings.axle_end_mode == 'TRIM':
        trim = plan_trim_knuckles(
            layout=settings.layout_mode,
            center_length=settings.trim_center_length,
            axle_length=settings.trim_axle_length,
            knuckle_gap=settings.knuckle_gap,
            tip_clearance=settings.axle_tip_clearance,
            min_side_length=max(0.10, settings.pin_diameter * 0.25),
        )
        span = AxleSpan(trim.axle_start, trim.axle_end, 0.0,
                        settings.trim_axle_length, trim.specs[0][1],
                        trim.specs[2][1], False)
        return trim.specs, span, trim.total_length
    specs = tuple(knuckle_specs(settings))
    if settings.hinge_style == 'INTEGRATED_AXLE':
        axle = plan_integrated_axle(
            specs, total_length=settings.total_length,
            pin_end_extra=settings.pin_end_extra,
            follow_side_centers=settings.axle_follow_side_centers,
            prevent_overrun=settings.axle_prevent_overrun,
        )
    else:
        axle = None
    return specs, axle, settings.total_length


def _blind_bore_plan(settings, specs, axle_span, total_length):
    # Two independent capped cavities, never a full-length through cutter.
    return plan_blind_bores(
        specs, axle_start=axle_span.start, axle_end=axle_span.end,
        tip_clearance=settings.axle_tip_clearance,
        min_cap_wall=settings.minimum_cap_wall,
        opening_extension=max(0.002, total_length * 0.001),
    )


def validate_settings(settings):
    if settings.object_a is None or settings.object_a.type != 'MESH':
        raise RuntimeError("Object Aを指定してください。")
    if settings.object_b is None or settings.object_b.type != 'MESH':
        raise RuntimeError("Object Bを指定してください。")
    if settings.object_a == settings.object_b:
        raise RuntimeError("Object AとBは別オブジェクトを指定してください。")
    outer_r = settings.outer_diameter * 0.5
    axle_r = settings.pin_diameter * 0.5
    hole_r = axle_r + settings.pin_clearance
    if settings.total_length <= 0 or outer_r <= 0 or settings.pin_diameter <= 0:
        raise RuntimeError("ヒンジ寸法が不正です。")
    if axle_r >= outer_r:
        raise RuntimeError("軸径がヒンジ外径以上です。外径を大きくしてください。")
    if hole_r >= outer_r:
        raise RuntimeError("軸穴がヒンジ外径以上です。外径を大きくするか軸径/クリアランスを小さくしてください。")
    radial_wall = outer_r - hole_r
    min_radial_wall = float(getattr(settings, 'minimum_radial_wall', 0.4))
    if radial_wall + 1e-8 < min_radial_wall:
        raise RuntimeError(
            f'軸穴の外周肉厚が不足: 現在{radial_wall:.3f} / 最低'
            f'{min_radial_wall:.3f}。外径か軸径/穴隙間を調整してください'
        )
    specs, axle_span, computed_length = resolved_hinge_geometry(settings)
    if settings.make_body_relief:
        resolve_face_clearance(
            settings.knuckle_gap, settings.face_clearance_follow_gap,
            settings.face_clearance)
    if settings.hinge_style == 'INTEGRATED_AXLE':
        if settings.pin_clearance <= 0 or settings.knuckle_gap <= 0:
            raise RuntimeError('一体造形の可動ヒンジには軸穴とナックル間の正の隙間が必要です')
        if settings.axle_end_mode == 'BLIND':
            _blind_bore_plan(settings, specs, axle_span, computed_length)
        elif settings.axle_tip_clearance < 0:
            raise RuntimeError('軸先端の隙間が不正です')
    if settings.make_support_bridges:
        if settings.bridge_max_reach <= outer_r:
            raise RuntimeError("接続距離上限はヒンジ半径より大きくしてください")
        if settings.bridge_embed <= 0.0:
            raise RuntimeError("本体への食い込み量が必要です")


def create_tube_knuckle(collection, center_world, axis_world, length, outer_radius, hole_radius, segments, name):
    outer = add_cylinder(name, outer_radius, length, axis_matrix(center_world, axis_world), collection, segments)
    cutter = add_cylinder(
        f"{name}_Hole_TEMP",
        hole_radius,
        length + max(0.02, length * 0.04),
        axis_matrix(center_world, axis_world),
        collection,
        segments,
    )
    try:
        boolean_apply(outer, cutter, 'DIFFERENCE')
    finally:
        delete_object(cutter)
    return outer


def create_solid_knuckle(collection, center_world, axis_world, length, outer_radius, segments, name):
    return add_cylinder(
        name,
        outer_radius,
        length,
        axis_matrix(center_world, axis_world),
        collection,
        segments,
    )


def create_integrated_center_barrel(
    collection, center_world, axis_world, center_length, outer_radius,
    axle_radius, segments, name,
):
    """Create ONLY the central barrel; never bake the shaft here.

    In APPLY/MODIFIER, the shaft must be the *last* Union on its owner,
    after all opposing-barrel relief and axle-bore Differences are finished.
    The shaft is generated separately after the support bridges are built.
    """
    body = create_solid_knuckle(
        collection, center_world, axis_world, center_length,
        outer_radius, segments, name,
    )
    body["hinge_integrated_axle"] = True
    body["hinge_axle_diameter"] = axle_radius * 2.0
    return body


def evaluated_body_surface(context, body_obj, query_point):
    """Nearest evaluated body mesh surface in WORLD space (including modifiers).

    This does not change the user object, its transform or its modifier stack.
    A fresh BVH is used so no stale Blender object references are cached.
    """
    depsgraph = context.evaluated_depsgraph_get()
    evaluated = body_obj.evaluated_get(depsgraph)
    mesh = evaluated.to_mesh()
    try:
        if mesh is None or not mesh.polygons:
            raise RuntimeError(f"{body_obj.name}: 接続先本体に有効な面がありません")
        transform = evaluated.matrix_world
        vertices = [tuple(transform @ vert.co) for vert in mesh.vertices]
        polygons = [tuple(poly.vertices) for poly in mesh.polygons]
        bvh = BVHTree.FromPolygons(vertices, polygons, all_triangles=False)
        # Nearest point on the evaluated *surface*, not just the object origin.
        contact = bvh.find_nearest(query_point)
        if contact is None or contact[0] is None:
            raise RuntimeError(f"{body_obj.name}: 接続位置の検索に失敗しました")
        lo = [min(v[i] for v in vertices) for i in range(3)]
        hi = [max(v[i] for v in vertices) for i in range(3)]
        body_center = Vector(tuple((lo[i] + hi[i]) * 0.5 for i in range(3)))
        return Vector(contact[0]), body_center
    finally:
        evaluated.to_mesh_clear()


def make_bridge_object(collection, name, plan):
    """Create the watertight six-face prism from audited world coordinates."""
    mesh = bpy.data.meshes.new(f"{name}_Mesh")
    try:
        mesh.from_pydata(list(plan.vertices), [], list(plan.faces))
        mesh.update()
        obj = bpy.data.objects.new(name, mesh)
        collection.objects.link(obj)
        return obj
    except Exception:
        bpy.data.meshes.remove(mesh)
        raise


def mesh_component_count(mesh):
    """Count connected components without depending on Blender edit-mode ops."""
    parent = list(range(len(mesh.vertices)))
    def root(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i
    for edge in mesh.edges:
        a, b = (int(i) for i in edge.vertices)
        ra, rb = root(a), root(b)
        if ra != rb:
            parent[ra] = rb
    return len({root(i) for i in range(len(parent))})


def evaluated_mesh_component_count(context, obj):
    """Read-only evaluated-mesh component count after full modifier stack."""
    context.view_layer.update()
    depsgraph = context.evaluated_depsgraph_get()
    evaluated = obj.evaluated_get(depsgraph)
    mesh = evaluated.to_mesh()
    try:
        if mesh is None:
            raise RuntimeError(f"{obj.name}: 評価済みMeshが取得できません")
        return mesh_component_count(mesh)
    finally:
        evaluated.to_mesh_clear()


def attach_body_bridges(context, settings, collection, specs, axis, center, knuckles):
    """One load-bearing strut from each barrel to *its owning* body.

    Union into the generated barrel first, not directly into the user mesh.
    It thus remains in the preview/exported geometry and does not silently
    create a separate disconnected Boolean island on the user's object.
    """
    witnesses = []
    if not settings.make_support_bridges:
        return witnesses
    outer_radius = settings.outer_diameter * 0.5
    bore_radius = (settings.pin_diameter * 0.5 + settings.pin_clearance)
    for knuckle, (owner, offset, klen, label) in zip(knuckles, specs):
        body = settings.object_a if owner == 'A' else settings.object_b
        origin = center + axis * offset
        surface, body_center = evaluated_body_surface(context, body, origin)
        try:
            plan = plan_bridge(
                knuckle_center=tuple(origin), axis=tuple(axis),
                surface_contact=tuple(surface), body_center=tuple(body_center),
                outer_radius=outer_radius,
                hole_radius=(0.0 if
                    (settings.hinge_style == 'INTEGRATED_AXLE' and label == 'Center')
                    else bore_radius),
                knuckle_length=klen, embed=settings.bridge_embed,
                width_ratio=settings.bridge_width_ratio,
                max_reach=settings.bridge_max_reach,
            )
        except ValueError as exc:
            raise RuntimeError(f"{owner} {label}: {exc}") from exc
        bridge = make_bridge_object(collection, f"Hinge_{owner}_{label}_Bridge_TEMP", plan)
        try:
            boolean_apply(knuckle, bridge, 'UNION')
        finally:
            delete_object(bridge)
        islands = mesh_component_count(knuckle.data)
        if islands != 1:
            raise RuntimeError(
                f"{owner} {label}: ブリッジ結合後もメッシュが{islands}個に分離。"
                "生成を中止しました"
            )
        knuckle["hinge_support_bridge"] = True
        knuckle["hinge_bridge_reach"] = round(plan.reach, 5)
        knuckle["hinge_bridge_axial_shift"] = round(plan.axial_shift, 5)
        knuckle["hinge_bridge_embed"] = round(plan.embed, 5)
        witnesses.append({
            "owner": owner, "label": label, "reach": plan.reach,
            "embed": plan.embed, "components": islands,
            "axial_shift": plan.axial_shift,
        })
    audit = audit_bridge_connections(witnesses, layout=settings.layout_mode)
    if not audit.valid:
        raise RuntimeError(f"CBDK HMEXP-004 接続監査: {audit.detail}")
    return witnesses


def build_hinge_geometry(context, settings, collection, preview=False):
    validate_settings(settings)
    center = context.scene.cursor.location.copy()
    axis = get_axis_world(context, settings)
    outer_r = settings.outer_diameter * 0.5
    axle_r = settings.pin_diameter * 0.5
    hole_r = axle_r + settings.pin_clearance
    specs, axle_span, computed_length = resolved_hinge_geometry(settings)
    created, owned_a, owned_b = [], [], []

    center_index = 1
    center_owner = specs[center_index][0]

    for index, (owner, offset, length, label) in enumerate(specs):
        kc = center + axis * offset

        if (
            settings.hinge_style == 'INTEGRATED_AXLE'
            and index == center_index
        ):
            # Only build the barrel here. Building the shaft here caused
            # the later relief Difference to remove the shaft tips (v0.5.2).
            obj = create_integrated_center_barrel(
                collection, kc, axis, length, outer_r, axle_r,
                settings.radial_segments, f"Hinge_{owner}_{label}",
            )
            if abs(axle_span.center - offset) > 1e-7:
                raise RuntimeError('左右非対称の一体軸は現在未対応です')
            obj["hinge_role"] = "CENTER_AXLE_KNUCKLE"
            obj["hinge_axle_length"] = axle_span.length
            obj["hinge_axle_left_tip"] = axle_span.start
            obj["hinge_axle_right_tip"] = axle_span.end
            obj["hinge_axle_capped"] = axle_span.capped
        else:
            # BLIND: the side knuckles MUST start solid. A through-tube
            # cannot be made blind by merely shortening the later cutter.
            if (settings.hinge_style == 'INTEGRATED_AXLE'
                    and settings.axle_end_mode == 'BLIND'):
                obj = create_solid_knuckle(
                    collection, kc, axis, length, outer_r,
                    settings.radial_segments, f"Hinge_{owner}_{label}",
                )
                obj["hinge_role"] = "SOLID_SIDE_FOR_BLIND_BORE"
            else:
                obj = create_tube_knuckle(
                    collection, kc, axis, length, outer_r, hole_r,
                    settings.radial_segments, f"Hinge_{owner}_{label}",
                )
                obj["hinge_role"] = "KNUCKLE"

        obj["hinge_maker_generated"] = True
        obj["hinge_owner"] = owner
        (owned_a if owner == 'A' else owned_b).append(obj)
        created.append(obj)

    bridge_witnesses = attach_body_bridges(
        context, settings, collection, specs, axis, center, created,
    )

    # The integrated shaft is a separate, late Boolean source. It is not
    # unioned to the central barrel until *after* all body Differences.
    axle = None
    if axle_span is not None:
        axle = add_cylinder(
            "Hinge_Integrated_Axle_FINAL_UNION", axle_r, axle_span.length,
            axis_matrix(center + axis * axle_span.center, axis),
            collection, settings.radial_segments,
        )
        axle["hinge_maker_generated"] = True
        axle["hinge_deferred_axle"] = True
        axle["hinge_role"] = "INTEGRATED_AXLE_FINAL_UNION"
        axle["hinge_owner"] = center_owner
        axle["hinge_axle_length"] = axle_span.length
        axle["hinge_axle_left_tip"] = axle_span.start
        axle["hinge_axle_right_tip"] = axle_span.end
        created.append(axle)

    pin = None
    if (
        settings.hinge_style == 'THROUGH_PIN'
        and settings.pin_mode != 'NONE'
    ):
        pin_len = settings.total_length + settings.pin_end_extra * 2.0
        pin = add_cylinder(
            "Hinge_Pin",
            axle_r,
            pin_len,
            axis_matrix(center, axis),
            collection,
            settings.radial_segments,
        )
        pin["hinge_maker_generated"] = True
        pin["hinge_role"] = "PIN"
        pin["hinge_pin_mode"] = settings.pin_mode
        created.append(pin)

    if preview:
        for obj in created:
            obj.display_type = 'WIRE'
            obj.show_in_front = True
            obj.hide_render = True

    return {
        "created": created,
        "a": owned_a,
        "b": owned_b,
        "pin": pin,
        "axle": axle,
        "axis": axis,
        "center": center,
        "center_owner": center_owner,
        "bridge_witnesses": bridge_witnesses,
        "specs": specs,
        "axle_span": axle_span,
        "total_length": computed_length,
    }


def build_body_clearance_geometry(
    context,
    settings,
    result,
    collection,
    *,
    preview=False,
):
    """Create the cutters required for an actually rotating embedded hinge.

    Mechanical model
    ----------------
    A-B-A:
      - A owns the left/right knuckles.
      - B owns the center knuckle.
      - A body must make room for B's center barrel.
      - B body must make room for A's left/right barrels.

    B-A-B is the exact inverse.

    Axial clearance between neighboring knuckles is already represented by
    `knuckle_gap`. `body_relief_clearance` is therefore used as the radial
    clearance around the opposite moving barrel.

    In addition:
      - Integrated-axle style needs an axle bore through the side-owner body.
      - Through-pin style needs a continuous pin bore through both bodies.

    This fixes the old failure mode where a tubular generated knuckle could be
    Unioned to a solid body and the body's original material would silently fill
    the tube hole.
    """
    center = result["center"]
    axis = result["axis"]
    specs = result["specs"]

    outer_r = settings.outer_diameter * 0.5
    axle_r = settings.pin_diameter * 0.5
    hole_r = axle_r + settings.pin_clearance

    eps = max(
        0.02,
        result["total_length"] * 0.002,
    )

    diff_a = []
    diff_b = []
    created = []

    if settings.make_body_relief:
        relief_r = outer_r + settings.body_relief_clearance
        requested_face_gap = resolve_face_clearance(
            settings.knuckle_gap, settings.face_clearance_follow_gap,
            settings.face_clearance,
        )
        # Do not create coplanar cutter/own-barrel faces when linked gap ==
        # actual A/B spacing. Leave a tiny numerical separation (scale-aware).
        epsilon_face = min(settings.knuckle_gap * .05,
                           max(0.00001, result['total_length'] * .0001))
        face_gap = min(requested_face_gap,
                       max(0.0, settings.knuckle_gap - epsilon_face))

        for owner, offset, length, label in specs:
            # The *opposite* body must make room for this moving knuckle.
            target_side = 'B' if owner == 'A' else 'A'
            kc = center + axis * offset

            cutter = add_cylinder(
                f"Hinge_Clearance_{target_side}_for_{owner}_{label}",
                relief_r,
                length + face_gap * 2.0,
                axis_matrix(kc, axis),
                collection,
                settings.radial_segments,
            )

            cutter["hinge_maker_generated"] = True
            cutter["hinge_role"] = "BODY_RELIEF_CUTTER"
            cutter["hinge_relief_target"] = target_side
            cutter["hinge_relief_source_owner"] = owner
            cutter["hinge_relief_radial_clearance"] = settings.body_relief_clearance
            cutter["hinge_relief_axial_clearance"] = face_gap
            cutter["hinge_relief_axial_requested"] = requested_face_gap

            if target_side == 'A':
                diff_a.append(cutter)
            else:
                diff_b.append(cutter)

            created.append(cutter)

    # The original A/B body can fill an otherwise hollow knuckle after Union.
    # Therefore the bore cutter must be applied to the assembled owning body.
    bore_depth = result["total_length"] + settings.pin_end_extra * 2.0 + eps * 2.0

    if settings.hinge_style == 'INTEGRATED_AXLE':
        span = result["axle_span"]
        center_owner = result["center_owner"]
        side_owner = 'B' if center_owner == 'A' else 'A'
        if settings.axle_end_mode == 'BLIND':
            intervals = _blind_bore_plan(settings, specs, span, result["total_length"])
            for interval in intervals:
                cutter = add_cylinder(
                    f"Hinge_BlindBore_{side_owner}_{interval.label}",
                    hole_r, interval.length,
                    axis_matrix(center + axis * interval.center, axis),
                    collection, settings.radial_segments,
                )
                cutter["hinge_maker_generated"] = True
                cutter["hinge_role"] = "BLIND_BORE_CUTTER"
                cutter["hinge_relief_target"] = side_owner
                cutter["hinge_bore_cap_wall"] = interval.cap_wall
                cutter["hinge_axial_start"] = interval.start
                cutter["hinge_axial_end"] = interval.end
                (diff_a if side_owner == 'A' else diff_b).append(cutter)
                created.append(cutter)
        else:
            # TRIM produces two open tube knuckles.  Remove material from
            # their owning body only over the matched axle's full length,
            # including tiny openings at both tube outer ends.
            bore = add_cylinder(
                f"Hinge_OpenBore_{side_owner}", hole_r,
                result["total_length"] + eps * 2.0,
                axis_matrix(center, axis), collection, settings.radial_segments,
            )
            bore["hinge_maker_generated"] = True
            bore["hinge_role"] = "OPEN_BORE_CUTTER"
            bore["hinge_relief_target"] = side_owner
            (diff_a if side_owner == 'A' else diff_b).append(bore)
            created.append(bore)

    else:
        # A separate through-pin needs a continuous channel through both
        # source bodies, otherwise the original bodies can fill the knuckle
        # holes after Union.
        for side in ('A', 'B'):
            bore = add_cylinder(
                f"Hinge_PinBore_{side}",
                hole_r,
                bore_depth,
                axis_matrix(center, axis),
                collection,
                settings.radial_segments,
            )
            bore["hinge_maker_generated"] = True
            bore["hinge_role"] = "PIN_BORE_CUTTER"
            bore["hinge_relief_target"] = side

            if side == 'A':
                diff_a.append(bore)
            else:
                diff_b.append(bore)

            created.append(bore)

    if preview:
        for obj in created:
            obj.display_type = 'WIRE'
            obj.show_in_front = True
            obj.hide_render = True
            obj["hinge_clearance_preview"] = True

    return {
        "a": diff_a,
        "b": diff_b,
        "created": created,
    }


def _modifier_plan_for_target(target, union_sources, diff_sources, side_label,
                              late_union_sources=()):
    """Use the SAME order as auto-apply and baked preview."""
    plan = []
    union_idx, difference_idx = 0, 0
    for source, operation in ordered_boolean_operations(
            union_sources, diff_sources, late_union_sources):
        if operation == 'UNION':
            union_idx += 1
            name = (f"Hinge_{side_label}_FinalAxleUnion" if
                    source in late_union_sources else
                    f"Hinge_{side_label}_Union_{union_idx:02d}")
        else:
            difference_idx += 1
            name = f"Hinge_{side_label}_Clearance_{difference_idx:02d}"
        plan.append((name, operation, source.name))
    return tuple(plan)



def _make_staging_mesh(context, target, collection, label):
    """Bake evaluated input onto an isolated working object; never touch A/B."""
    if target.library or target.data.library or target.override_library:
        raise RuntimeError(f"{target.name}: リンク/ライブラリオーバーライド対象は自動確定できません")
    if target.data.shape_keys is not None:
        raise RuntimeError(f"{target.name}: シェイプキーを含むMeshは自動ベイクできません")
    dg = context.evaluated_depsgraph_get()
    ev = target.evaluated_get(dg)
    mesh = bpy.data.meshes.new_from_object(ev, preserve_all_data_layers=True, depsgraph=dg)
    if mesh is None or len(mesh.polygons) == 0:
        if mesh is not None:
            bpy.data.meshes.remove(mesh)
        raise RuntimeError(f"{target.name}: 評価済みの本体Meshが空です")
    stage = bpy.data.objects.new(f"_Hinge_Stage_{label}_TEMP", mesh)
    collection.objects.link(stage)
    stage.matrix_world = ev.matrix_world.copy()
    # Evaluated mesh coordinates are local to the evaluated object; the
    # original target must use the same transform or replacing its mesh would
    # silently move vertices (common with animated constraints).
    for r in range(4):
        for c in range(4):
            if abs(stage.matrix_world[r][c] - target.matrix_world[r][c]) > 1e-5:
                delete_object(stage)
                raise RuntimeError(f"{target.name}: 評価後に位置行列が変化しています。制約/アニメーションを確認してください")
    return stage


def _audit_staged_mesh(stage, base_count, label):
    if stage.type != 'MESH' or len(stage.data.polygons) == 0:
        raise RuntimeError(f"{label}: 自動適用後のMeshが空です")
    after = mesh_component_count(stage.data)
    # A previous body may contain multiple disconnected components. Union
    # should never *increase* that count if all generated parts are attached.
    if after > base_count:
        raise RuntimeError(
            f"{label}: 接続不良を検出しました（独立島 {base_count}→{after}）。"
            "本体に届かないナックルがあります。位置/接続距離を調整してください"
        )
    return after


def _backup_target(target, backup_collection, label):
    """Keep fully editable original mesh, modifiers and object props."""
    backup = target.copy()
    backup.data = target.data.copy()
    backup.name = f"HingeBackup_{label}_{target.name}"
    backup_collection.objects.link(backup)
    backup.hide_render = True
    backup.hide_set(True)
    backup["hinge_backup_of"] = target.name
    return backup


def preview_final_hinge_result(context, settings, result, clearance, collection):
    """Build real Boolean result on wireframe-only clones for safe review.

    A/B originals, their modifiers and mesh datablocks are not touched.
    The preview is disposable and is recreated on each Preview click.
    """
    generated_pin = result['pin']
    axle = result.get('axle')
    center_owner = result['center_owner']
    for label, target, unions, diffs in (
        ('A', settings.object_a, result['a'], clearance['a']),
        ('B', settings.object_b, result['b'], clearance['b']),
    ):
        union_sources = list(unions)
        if generated_pin is not None and settings.pin_mode == f'FIXED_{label}':
            union_sources.append(generated_pin)
        stage = _make_staging_mesh(context, target, collection, f'Preview_{label}')
        before = mesh_component_count(stage.data)
        late = (axle,) if axle is not None and center_owner == label else ()
        for source, op in ordered_boolean_operations(union_sources, diffs, late):
            boolean_apply(stage, source, op)
        _audit_staged_mesh(stage, before, f'Preview {label}')
        stage.name = f'HingePreview_Final_{label}'
        stage.display_type = 'WIRE'
        stage.show_in_front = True
        stage.hide_render = True
        stage['hinge_preview_final_baked'] = True
    # Raw knuckles/cutters must not obscure the resulting final wireframes.
    for obj in result['created'] + clearance['created']:
        if obj is not generated_pin or settings.pin_mode != 'SEPARATE':
            obj.hide_set(True)


def auto_apply_hinge_transaction(settings, result, union_a, union_b, diff_a, diff_b):
    """Stage all Booleans on disposable copies; commit only after both pass.

    Existing input modifiers are included in the evaluated mesh and then
    removed from committed originals to avoid applying them *twice*.  Full
    original objects are kept as hidden backups for user recovery. This is
    not proof that hinge rotates without collision; that requires manual test.
    """
    context = bpy.context
    axle = result.get('axle')
    center_owner = result['center_owner']
    stages = []
    backups = []
    prepared = []
    backup_col = None
    started_commit = False
    committed = False
    stage_collection = bpy.data.collections.new(unique_collection_name('HingeMaker_Staging'))
    context.scene.collection.children.link(stage_collection)
    try:
        reports = []
        for label, target, unions, diffs in (
            ('A', settings.object_a, union_a, diff_a),
            ('B', settings.object_b, union_b, diff_b),
        ):
            stage = _make_staging_mesh(context, target, stage_collection, label)
            stages.append(stage)
            original_islands = mesh_component_count(stage.data)
            late = (axle,) if axle is not None and center_owner == label else ()
            for index, (source, op) in enumerate(
                    ordered_boolean_operations(unions, diffs, late), start=1):
                if source.name not in bpy.data.objects:
                    raise RuntimeError(f"{label} Boolean{index}: ソースが消えました")
                try:
                    boolean_apply(stage, source, op)
                except Exception as exc:
                    raise RuntimeError(f"{label} Boolean{index} {op}: {exc}") from exc
            final_islands = _audit_staged_mesh(stage, original_islands, label)
            reports.append((label, original_islands, final_islands,
                            len(unions) + len(diffs) + len(late)))

        # Commit readiness: materialize both final meshes and backups *before*
        # touching either original. If validation failed, originals are intact.
        prepared = [stage.data.copy() for stage in stages]
        backup_col = bpy.data.collections.new(
            unique_collection_name('HingeMaker_Backups'))
        context.scene.collection.children.link(backup_col)
        for label, target in (('A', settings.object_a), ('B', settings.object_b)):
            backups.append(_backup_target(target, backup_col, label))
        started_commit = True
        for target, mesh in zip((settings.object_a, settings.object_b), prepared):
            target.data = mesh
            for mod in list(target.modifiers):
                target.modifiers.remove(mod)
            target["hinge_auto_applied_v054"] = True
        committed = True
        # Only after successful commit remove the temporary cutter/union parts.
        # An independent through-pin (SEPARATE) remains visible for printing.
        for obj in dict.fromkeys(union_a + union_b + diff_a + diff_b +
                                 ([axle] if axle is not None else [])):
            if is_live_object(obj):
                delete_object(obj)
        return {
            'status': 'passed',
            'detail': ('AUTO APPLY PASS | ' + ' / '.join(
                f"{side}: {count}ops islands {before}→{after}"
                for side, before, after, count in reports)),
        }
    except Exception:
        # This is expected to happen *before* commit in ordinary validation
        # failures. Unexpected commit-time exceptions can be recovered via
        # Blender Undo or the hidden HingeMaker_Backups collection.
        if not started_commit and backup_col is not None:
            remove_collection_tree(backup_col)
        if not started_commit:
            for mesh in prepared:
                if mesh.name in bpy.data.meshes and mesh.users == 0:
                    bpy.data.meshes.remove(mesh)
        raise
    finally:
        if stage_collection.name in bpy.data.collections:
            remove_collection_tree(stage_collection)


def _finish_generate_only_blind_bores(settings, result):
    """GENERATE_ONLY must not leave the new solid sides unbored."""
    if (settings.hinge_style != 'INTEGRATED_AXLE'
            or settings.axle_end_mode != 'BLIND'):
        return
    interval_plan = _blind_bore_plan(
        settings, result['specs'], result['axle_span'], result['total_length'])
    center, axis = result['center'], result['axis']
    side_owner = 'B' if result['center_owner'] == 'A' else 'A'
    side_objects = result[side_owner]
    if len(side_objects) != 2:
        raise RuntimeError('止まり穴の左右ナックルが見つかりません')
    for barrel, interval in zip(side_objects, interval_plan):
        cutter = add_cylinder(
            f'Hinge_OnlyBore_{interval.label}_TEMP',
            settings.pin_diameter*.5 + settings.pin_clearance,
            interval.length,
            axis_matrix(center + axis * interval.center, axis),
            barrel.users_collection[0], settings.radial_segments,
        )
        try:
            boolean_apply(barrel, cutter, 'DIFFERENCE')
            if mesh_component_count(barrel.data) != 1:
                raise RuntimeError(f'{interval.label}: 止まり穴生成でナックルが分離しました')
            barrel['hinge_bore_cap_wall'] = interval.cap_wall
        finally:
            delete_object(cutter)


def _finalize_unattached_integrated_axle(result):
    """For GENERATE_ONLY, no body Differences exist: join to the barrel now."""
    axle = result.get('axle')
    if axle is None:
        return
    barrel = next((obj for obj in result[result['center_owner']]
                   if obj.get('hinge_role') == 'CENTER_AXLE_KNUCKLE'), None)
    if barrel is None:
        raise RuntimeError('中央一体軸の結合先ナックルが見つかりません')
    boolean_apply(barrel, axle, 'UNION')
    if mesh_component_count(barrel.data) != 1:
        raise RuntimeError('中央一体軸を中央ナックルに結合できませんでした')
    delete_object(axle)
    result['axle'] = None
    result['created'].remove(axle)
    barrel['hinge_axle_final_union_after_difference'] = True


def attach_generated_hinge(settings, result, clearance):
    """Attach hinge pieces and the required mechanical clearance plan.

    v0.4 changes the body operation from:
        "Union my hinge pieces"

    to:
        1. Union my hinge pieces
        2. Difference the opposite knuckle envelopes (+ radial clearance)
        3. Difference the axle/pin bore required by the mechanism

    CBDK testbed coverage:
      - BLCTX-001 / BLCTX-002: object capture
      - BLMOD-001 semantics: detached modifier snapshots
      - HMEXP-001: legacy modifier-tail count audit
      - HMEXP-003: exact UNION/DIFFERENCE/object modifier-plan audit
    """
    if settings.attach_mode == 'GENERATE_ONLY':
        _finish_generate_only_blind_bores(settings, result)
        _finalize_unattached_integrated_axle(result)
        return {
            "status": "not_applicable",
            "detail": "ヒンジだけ生成: 本体Boolean監査対象外",
        }

    union_a = list(result["a"])
    union_b = list(result["b"])

    pin = result["pin"]

    if pin is not None:
        if settings.pin_mode == 'FIXED_A':
            union_a.append(pin)
        elif settings.pin_mode == 'FIXED_B':
            union_b.append(pin)

    diff_a = list(clearance["a"])
    diff_b = list(clearance["b"])
    axle = result.get('axle')
    center_owner = result['center_owner']
    late_a = (axle,) if axle is not None and center_owner == 'A' else ()
    late_b = (axle,) if axle is not None and center_owner == 'B' else ()

    if settings.attach_mode == 'APPLY':
        return auto_apply_hinge_transaction(settings, result, union_a, union_b,
                                            diff_a, diff_b)

    # MODIFIER wait mode: audit the exact mixed Boolean plan.
    before_a = modifier_plan_snapshot_object(settings.object_a)
    before_b = modifier_plan_snapshot_object(settings.object_b)
    baseline_components = None
    if settings.make_support_bridges:
        baseline_components = (
            evaluated_mesh_component_count(bpy.context, settings.object_a),
            evaluated_mesh_component_count(bpy.context, settings.object_b),
        )

    plan_a = _modifier_plan_for_target(
        settings.object_a,
        union_a,
        diff_a,
        'A',
        late_a,
    )
    plan_b = _modifier_plan_for_target(
        settings.object_b,
        union_b,
        diff_b,
        'B',
        late_b,
    )

    added = []

    try:
        for name, operation, object_name in plan_a:
            source = bpy.data.objects.get(object_name)

            if source is None:
                raise RuntimeError(
                    f"Boolean source missing: {object_name}"
                )

            mod = add_boolean_modifier(
                settings.object_a,
                source,
                operation,
                name,
            )
            added.append((settings.object_a, mod))

            source.display_type = 'WIRE'
            source.show_in_front = True
            source.hide_render = True
            source["hinge_pending_boolean_target"] = settings.object_a.name
            source["hinge_pending_boolean_operation"] = operation

        for name, operation, object_name in plan_b:
            source = bpy.data.objects.get(object_name)

            if source is None:
                raise RuntimeError(
                    f"Boolean source missing: {object_name}"
                )

            mod = add_boolean_modifier(
                settings.object_b,
                source,
                operation,
                name,
            )
            added.append((settings.object_b, mod))

            source.display_type = 'WIRE'
            source.show_in_front = True
            source.hide_render = True
            source["hinge_pending_boolean_target"] = settings.object_b.name
            source["hinge_pending_boolean_operation"] = operation

        after_a = modifier_plan_snapshot_object(settings.object_a)
        after_b = modifier_plan_snapshot_object(settings.object_b)

        audit_a = audit_boolean_modifier_plan(
            before_a,
            after_a,
            expected_plan=plan_a,
        )
        audit_b = audit_boolean_modifier_plan(
            before_b,
            after_b,
            expected_plan=plan_b,
        )

        if settings.cbdk_strict_modifier_audit and not (
            audit_a.valid
            and audit_b.valid
        ):
            for target, mod in reversed(added):
                try:
                    target.modifiers.remove(mod)
                except Exception:
                    pass

            raise RuntimeError(
                "CBDK Boolean計画監査で想定外差分。"
                "今回追加したModifierを可能な範囲で取り消しました。 "
                f"A={audit_a.detail} / B={audit_b.detail}"
            )

        connectivity_message = ''
        if baseline_components is not None:
            evaluated_components = (
                evaluated_mesh_component_count(bpy.context, settings.object_a),
                evaluated_mesh_component_count(bpy.context, settings.object_b),
            )
            connectivity_message = (
                f" / mesh islands A:{baseline_components[0]}→{evaluated_components[0]}"
                f" B:{baseline_components[1]}→{evaluated_components[1]}"
            )
            if any(new > old for new, old in zip(evaluated_components, baseline_components)):
                raise RuntimeError(
                    "CBDK HMEXP-004: Boolean後に本体の独立メッシュ島が増えました。"
                    "接続失敗の可能性があるため新規Modifierを取り消します"
                    + connectivity_message
                )
        return {
            "status": (
                "passed"
                if audit_a.valid and audit_b.valid
                else "warning"
            ),
            "detail": (
                f"A: {audit_a.detail} / "
                f"B: {audit_b.detail}" + connectivity_message
            ),
        }

    except Exception:
        # Do not leave half-added modifiers that would reference cutters
        # removed together with the failed generated collection.
        for target, mod in reversed(added):
            try:
                target.modifiers.remove(mod)
            except Exception:
                pass
        raise


class HINGEMAKER_Settings(PropertyGroup):
    guide_enabled: BoolProperty(
        name="数値ガイドを常時表示",
        description="3Dビューの左下に軽量な寸法断面図を表示。元メッシュ・Modifierは変更しません",
        default=False, options={'SKIP_SAVE'}, update=_guide_changed,
    )
    guide_focus: EnumProperty(
        name="表示する寸法",
        description="操作箇所を模式図で強調。各数値を触ると自動で切り替わります",
        items=[(key, title, detail) for key, (title, detail) in FOCUS_INFO.items()],
        default='KNUCKLE_GAP', update=_guide_changed,
    )
    guide_scene_enabled: BoolProperty(
        name="3D空間にも寸法位置を描画",
        description="実際の3Dカーソルとヒンジ軸に、穴や隙間の位置の線だけを投影します",
        default=True, update=_guide_changed,
    )
    guide_3d_mode: EnumProperty(
        name="3D立体ガイドの表示内容",
        description="寸法から計算した立体ワイヤーの表示対象。Boolean後の実メッシュではありません",
        items=[
            ('ALL', '全体', 'ナックル、中央軸、軸穴、隙間を一緒に表示'),
            ('AXLE', '軸', '中央一体軸または貫通ピンの径と長さ、先端を表示'),
            ('BORE', '穴', '穴径と穴の奥行き、先端の位置を表示'),
            ('KNUCKLE', 'ナックル', 'A/Bナックルの外径と軸方向間隔を表示'),
            ('CLEARANCE', 'クリアランス', '軸穴、軸、端面・外周の逃げを比較表示'),
            ('ERRORS', '要修正のみ', '寸法診断でエラーになったワイヤーのみ表示'),
        ],
        default='ALL', update=_guide_changed,
    )
    object_a: PointerProperty(name="Object A", type=bpy.types.Object)
    object_b: PointerProperty(name="Object B", type=bpy.types.Object)
    axis_mode: EnumProperty(
        name="ヒンジ軸",
        items=[
            ('CURSOR_X', "Cursor X", "3DカーソルのX軸"),
            ('CURSOR_Y', "Cursor Y", "3DカーソルのY軸"),
            ('CURSOR_Z', "Cursor Z", "3DカーソルのZ軸"),
            ('WORLD_X', "World X", "ワールドX軸"),
            ('WORLD_Y', "World Y", "ワールドY軸"),
            ('WORLD_Z', "World Z", "ワールドZ軸"),
        ],
        default='CURSOR_Z',
        update=_guide_update('OVERVIEW'),
    )
    axis_flip: BoolProperty(name="軸反転", default=False,
        update=_guide_update('OVERVIEW'),
    )
    layout_mode: EnumProperty(
        name="ナックル構成",
        items=[
            ('ABA', "A-B-A（左右=A）", "Object Aが左右ナックル、Object Bが中央ナックル"),
            ('BAB', "B-A-B（左右=B）", "Object Bが左右ナックル、Object Aが中央ナックル"),
        ],
        default='ABA',
        update=_guide_update('LAYOUT'),
    )
    total_length: FloatProperty(name="ヒンジ全長", default=10.0, min=0.1, soft_max=100.0, unit='LENGTH',
        update=_cjm_ui.constraint_update('hinge','total_length',_guide_update('TOTAL_LENGTH')),
    )
    outer_diameter: FloatProperty(name="外径", default=4.0, min=0.1, soft_max=50.0, unit='LENGTH',
        update=_cjm_ui.constraint_update('hinge','outer_diameter',_guide_update('DIAMETER')),
    )
    pin_diameter: FloatProperty(name="ピン径", default=2.0, min=0.05, soft_max=20.0, unit='LENGTH',
        update=_cjm_ui.constraint_update('hinge','pin_diameter',_guide_update('PIN_DIAMETER')),
    )
    pin_clearance: FloatProperty(
        name="ピン穴クリアランス",
        description="片側クリアランス。穴径 = ピン径 + 2×クリアランス",
        default=0.20, min=0.0, soft_max=2.0, unit='LENGTH',
        update=_cjm_ui.constraint_update('hinge','pin_clearance',_guide_update('PIN_CLEARANCE')),
    )
    knuckle_gap: FloatProperty(
        name="ナックル間クリアランス",
        description="ヒンジ軸方向のA/Bナックル間の隙間",
        default=0.20,
        min=0.0,
        soft_max=5.0,
        unit='LENGTH',
        update=_cjm_ui.constraint_update('hinge','knuckle_gap',_guide_update('KNUCKLE_GAP')),
    )
    face_clearance_follow_gap: BoolProperty(
        name="端面逃げをナックル間の隙間と連動",
        description="相手ナックルの本体逃げを軸方向にナックル間クリアランスまで拡張します",
        default=True,
        update=_guide_update('FACE_CLEARANCE'),
    )
    face_clearance: FloatProperty(
        name="端面逃げクリアランス",
        description="連動OFF時の、本体逃げの軸方向片側追加長。ナックル間の隙間を超える値は禁止",
        default=0.20, min=0.0, soft_max=5.0, unit='LENGTH',
        update=_guide_update('FACE_CLEARANCE'),
    )
    make_body_relief: BoolProperty(
        name="相手ナックルの逃げを本体に作る",
        description="A本体からBナックル、B本体からAナックルの外形をクリアランス付きでDifferenceします",
        default=True,
        update=_guide_update('BODY_RELIEF'),
    )
    body_relief_clearance: FloatProperty(
        name="本体逃げクリアランス",
        description="相手ナックル外周と本体ポケットの片側すき間。軸方向の隙間はナックル間クリアランスで管理します",
        default=0.20,
        min=0.0,
        soft_max=3.0,
        unit='LENGTH',
        update=_guide_update('BODY_RELIEF'),
    )
    length_mode: EnumProperty(
        name="長さ配分",
        items=[('EQUAL', "3等分", "3つを同じ長さ"), ('CENTER_LONG', "中央を長く", "中央を長めにする")],
        default='CENTER_LONG',
        update=_distribution_update('CENTER_LENGTH'),
    )
    center_ratio: FloatProperty(name="中央長さ倍率", default=1.40, min=0.2, soft_max=4.0,
        update=_distribution_update('CENTER_LENGTH'),
    )
    side_length_edit: FloatProperty(
        name="左右側の長さ（各1個）",
        description="片方の長さを編集すると中央を自動調整。全長変更では現在の比率に追従します",
        min=0.0, soft_max=100.0, unit='LENGTH',
        get=_side_length_get, set=_side_length_set,
        update=_cjm_ui.constraint_update('hinge','side_length_edit',_guide_update('SIDE_LENGTH')),
    )
    center_length_edit: FloatProperty(
        name="中央の長さ",
        description="中央を編集すると左右側を自動調整（方式Bは軸長固定で左右が変化）",
        min=0.0, soft_max=100.0, unit='LENGTH',
        get=_center_length_get, set=_center_length_set,
        update=_cjm_ui.constraint_update('hinge','center_length_edit',_guide_update('CENTER_LENGTH')),
    )
    make_support_bridges: BoolProperty(
        name="本体まで自動接続（推奨）",
        description="A左右/B中央の各ナックルから所有する本体の評価済み表面に接続ブリッジを伸ばします",
        default=True,
        update=_guide_update('BRIDGE_EMBED'),
    )
    bridge_embed: FloatProperty(
        name="本体への食い込み量",
        description="ブリッジ先端を本体表面より内側へ進める長さ。接触だけのBoolean失敗を避けます",
        default=0.60, min=0.01, soft_max=5.0, unit='LENGTH',
        update=_guide_update('BRIDGE_EMBED'),
    )
    bridge_width_ratio: FloatProperty(
        name="接続ブリッジ幅",
        description="ヒンジ外径に対する接続ブリッジ横幅の比率",
        default=0.65, min=0.1, max=1.2,
        update=_guide_update('BRIDGE_WIDTH'),
    )
    bridge_max_reach: FloatProperty(
        name="最大接続距離",
        description="この距離を超えて本体が離れている場合は、長すぎる接続棒を作らず失敗を報告します",
        default=40.0, min=0.1, soft_max=200.0, unit='LENGTH',
        update=_guide_update('BRIDGE_REACH'),
    )
    radial_segments: IntProperty(name="円周分割数", default=32, min=12, max=256)
    hinge_style: EnumProperty(
        name="ヒンジ方式",
        items=[
            ('INTEGRATED_AXLE', "中央一体軸", "中央の太いナックルと左右へ伸びる軸を一体化。左右ナックルだけに穴を作る"),
            ('THROUGH_PIN', "貫通ピン", "3つのナックルすべてに穴を作り、別ピンを通す従来方式"),
        ],
        default='INTEGRATED_AXLE',
        update=_guide_update('OVERVIEW'),
    )
    axle_end_mode: EnumProperty(
        name="一体軸の端部処理",
        items=[
            ('BLIND', "方式A：止まり穴（外側を閉じる）", "左右ナックルを中実で生成し、軸先端+隙間までの止まり穴を削る"),
            ('TRIM', "方式B：A/B長さ自動追従", "一体軸の全長から左右ナックルを逆算し、余分な外側筒を作らない"),
        ],
        default='BLIND',
        update=_guide_update('AXLE_TIP'),
    )
    axle_tip_clearance: FloatProperty(
        name="軸先端クリアランス",
        description="止まり穴では穴底と軸先端の隙間、追従では左右外端が軸先端より外側に出る量",
        default=0.20, min=0.0, soft_max=5.0, unit='LENGTH',
        update=_cjm_ui.constraint_update('hinge','axle_tip_clearance',_guide_update('AXLE_TIP')),
    )
    minimum_cap_wall: FloatProperty(
        name="最低閉鎖壁厚",
        description="止まり穴の左右外側に残す最小壁厚。確保できなければ生成を停止",
        default=0.80, min=0.05, soft_max=5.0, unit='LENGTH',
        update=_cjm_ui.constraint_update('hinge','minimum_cap_wall',_guide_update('CAP_WALL')),
    )
    minimum_radial_wall: FloatProperty(
        name="最低外周肉厚（軸穴）",
        description="円筒の半径方向の肉厚。外径/2 - (軸径/2 + 穴隙間) で判定",
        default=0.40, min=0.0, soft_max=5.0, unit='LENGTH',
        update=_cjm_ui.constraint_update('hinge','minimum_radial_wall',_guide_update('RADIAL_WALL')),
    )
    trim_axle_length: FloatProperty(
        name="B一体軸の基準全長",
        description="方式Bの最優先寸法。左右ナックル長・完成全長はここから自動計算",
        default=7.20, min=0.1, soft_max=100.0, unit='LENGTH',
        update=_guide_update('AXLE_LENGTH'),
    )
    trim_center_length: FloatProperty(
        name="中央ナックル長",
        description="方式Bで固定するB中央ナックル長。左右側は一体軸長から逆算",
        default=4.00, min=0.1, soft_max=100.0, unit='LENGTH',
        update=_guide_update('CENTER_LENGTH'),
    )
    pin_mode: EnumProperty(
        name="ピン方式",
        items=[
            ('SEPARATE', "別パーツ", "ピンを独立生成"),
            ('FIXED_A', "A側に固定", "ピンをObject A側へUnion"),
            ('FIXED_B', "B側に固定", "ピンをObject B側へUnion"),
            ('NONE', "ピンなし", "ピンを生成しない"),
        ],
        default='SEPARATE',
    )
    pin_end_extra: FloatProperty(name="ピン端余裕", default=0.40, min=0.0, soft_max=5.0, unit='LENGTH',
        update=_guide_update('AXLE_LENGTH'),
    )
    axle_follow_side_centers: BoolProperty(
        name="左右ナックルの中心まで追従",
        description="ABAでは左右Aの中心位置まで一体軸を延長。BABでは左右Bの中心まで延長します",
        default=True,
        update=_guide_update('AXLE_LENGTH'),
    )
    axle_prevent_overrun: BoolProperty(
        name="軸が外側へ突き抜けないようにする",
        description="一体軸の端を左右ナックルの外側端面より内側へ制限します",
        default=True,
        update=_guide_update('AXLE_TIP'),
    )
    attach_mode: EnumProperty(
        name="本体への取付",
        items=[
            ('GENERATE_ONLY', "ヒンジだけ生成", "本体にはBooleanしない"),
            ('MODIFIER', "Union待機", "Union Modifierだけ追加してヒンジをWIREで残す"),
            ('APPLY', "自動適用（推奨）", "ナックルUnion→本体逃げ/軸穴Difference→中央軸Unionを作業用Meshで確定。元データをバックアップ"),
        ],
        default='APPLY',
    )
    cbdk_strict_modifier_audit: BoolProperty(
        name="CBDK厳格Modifier監査",
        description="Union待機後に想定数/種類のModifierだけ増えたか検査し、異常時は今回追加分を可能な範囲で戻します",
        default=True,
    )
    cbdk_last_status: StringProperty(
        name="CBDK状態",
        default="未実行",
    )
    cbdk_last_detail: StringProperty(
        name="CBDK詳細",
        default="",
    )


class HINGEMAKER_OT_guide_focus(Operator):
    bl_idname = "hinge_maker.guide_focus"
    bl_label = "この寸法の位置を見る"
    bl_description = "指定した設定の場所をライブ模式図で強調します"
    focus: EnumProperty(items=[(key, title, detail)
                               for key, (title, detail) in FOCUS_INFO.items()])

    def execute(self, context):
        settings = context.scene.hinge_maker_settings
        settings.guide_enabled = True
        settings.guide_focus = self.focus
        _guide_redraw(context)
        return {'FINISHED'}


class HINGEMAKER_OT_reset_length_distribution(Operator):
    bl_idname = 'hinge_maker.reset_length_distribution'
    bl_label = '中央倍率から自動配分に戻す'
    bl_description = '個別寸法の手動配分を解除。全長と中央長さ倍率から再計算します'
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        s = context.scene.hinge_maker_settings
        s['_hm_manual_lengths'] = False
        _guide_redraw(context)
        return {'FINISHED'}


class HINGEMAKER_OT_capture_objects(Operator):
    bl_idname = "hinge_maker.capture_objects"
    bl_label = "選択中の2オブジェクトを設定"
    bl_description = "CBDK BLCTX-001/002で選択Meshを検査し、アクティブをA、もう片方をBに設定"

    def execute(self, context):
        try:
            selected = selected_mesh_objects(context)
            active = require_active_mesh(context)
        except BlenderContextError as exc:
            self.report({'ERROR'}, f"CBDK選択チェック: {exc}")
            return {'CANCELLED'}

        if len(selected) != 2:
            self.report({'ERROR'}, f"メッシュをちょうど2つ選択してください。現在 {len(selected)} 個です。")
            return {'CANCELLED'}
        if active not in selected:
            self.report({'ERROR'}, "アクティブMeshが選択2個の中にありません。")
            return {'CANCELLED'}

        other = selected[0] if selected[1] == active else selected[1]
        s = context.scene.hinge_maker_settings
        s.object_a = active
        s.object_b = other
        s.cbdk_last_status = "BLCTX PASS"
        s.cbdk_last_detail = f"BLCTX-001/002: A={active.name} / B={other.name}"
        self.report({'INFO'}, f"A: {active.name} / B: {other.name} / CBDK BLCTX PASS")
        return {'FINISHED'}


class HINGEMAKER_OT_swap_objects(Operator):
    bl_idname = "hinge_maker.swap_objects"
    bl_label = "A/B入れ替え"
    def execute(self, context):
        s = context.scene.hinge_maker_settings
        a = s.object_a
        s.object_a = s.object_b
        s.object_b = a
        return {'FINISHED'}


class HINGEMAKER_OT_cursor_to_ab_midpoint(Operator):
    bl_idname = "hinge_maker.cursor_to_ab_midpoint"
    bl_label = "カーソルをA/B中間へ"
    bl_description = "Object A/Bの原点の中間へ3Dカーソルを移動"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        s = context.scene.hinge_maker_settings
        if s.object_a is None or s.object_b is None:
            self.report({'ERROR'}, "先にObject A/Bを設定してください。")
            return {'CANCELLED'}
        context.scene.cursor.location = (
            s.object_a.matrix_world.translation + s.object_b.matrix_world.translation
        ) * 0.5
        self.report({'INFO'}, "3DカーソルをA/B原点の中間へ移動しました。")
        return {'FINISHED'}


class HINGEMAKER_OT_cbdk_preflight(Operator):
    bl_idname = "hinge_maker.cbdk_preflight"
    bl_label = "CBDK 生成前チェック"
    bl_description = "Object A/BとModifier Stackを読み取り専用で検査"

    def execute(self, context):
        s = context.scene.hinge_maker_settings
        try:
            validate_settings(s)
            a = modifier_snapshot_object(s.object_a)
            b = modifier_snapshot_object(s.object_b)
            s.cbdk_last_status = "PREFLIGHT PASS"
            s.cbdk_last_detail = (
                f"BLCTX/BLMOD: A mods={len(a)}, B mods={len(b)} | "
                f"A[{format_modifier_snapshot(a)}] B[{format_modifier_snapshot(b)}] | "
                f"relief={'ON' if s.make_body_relief else 'OFF'} "
                f"clearance={s.body_relief_clearance:.3f}"
            )
        except Exception as exc:
            s.cbdk_last_status = "PREFLIGHT FAIL"
            s.cbdk_last_detail = str(exc)
            self.report({'ERROR'}, f"CBDK preflight: {exc}")
            return {'CANCELLED'}
        self.report({'INFO'}, "CBDK preflight PASS")
        return {'FINISHED'}


class HINGEMAKER_OT_preview(Operator):
    bl_idname = "hinge_maker.preview"
    bl_label = "ヒンジプレビュー"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected_before = tuple(context.selected_objects)
        active_before = context.view_layer.objects.active
        try:
            ensure_object_mode()
            clear_preview()
            col = get_or_create_collection(PREVIEW_COLLECTION, context.scene.collection)
            s = context.scene.hinge_maker_settings

            result = build_hinge_geometry(
                context,
                s,
                col,
                preview=True,
            )
            if s.attach_mode == 'GENERATE_ONLY':
                _finish_generate_only_blind_bores(s, result)
                _finalize_unattached_integrated_axle(result)

            if s.attach_mode != 'GENERATE_ONLY':
                clearance = build_body_clearance_geometry(
                    context,
                    s,
                    result,
                    col,
                    preview=True,
                )
                if s.attach_mode == 'APPLY':
                    preview_final_hinge_result(context, s, result, clearance, col)

            # Axis guide is an Empty, not a mesh cylinder. This avoids the old
            # "pinなしなのに細い棒が生成された" confusion.
            axis_obj = bpy.data.objects.new("Hinge_Axis_Guide", None)
            col.objects.link(axis_obj)
            axis_obj.empty_display_type = 'ARROWS'
            axis_obj.empty_display_size = max(
                0.3,
                context.scene.hinge_maker_settings.outer_diameter * 0.8,
            )
            axis_obj.matrix_world = axis_matrix(
                result["center"],
                result["axis"],
            )
            axis_obj.show_in_front = True
            axis_obj["hinge_preview_axis_guide"] = True
        except Exception as exc:
            clear_preview()
            self.report({'ERROR'}, f"プレビュー失敗: {exc}")
            return {'CANCELLED'}
        finally:
            if context.mode == 'OBJECT':
                try:
                    bpy.ops.object.select_all(action='DESELECT')
                    for obj in selected_before:
                        if obj.name in bpy.data.objects:
                            obj.select_set(True)
                    if active_before is not None and active_before.name in bpy.data.objects:
                        context.view_layer.objects.active = active_before
                except Exception:
                    pass
        self.report({'INFO'}, "3Dカーソル位置にヒンジをプレビューしました。")
        return {'FINISHED'}


class HINGEMAKER_OT_preview_clear(Operator):
    bl_idname = "hinge_maker.preview_clear"
    bl_label = "プレビュー削除"
    def execute(self, context):
        clear_preview()
        return {'FINISHED'}


class HINGEMAKER_OT_generate(Operator):
    bl_idname = "hinge_maker.generate"
    bl_label = "3Dカーソル位置にヒンジを生成"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        s = context.scene.hinge_maker_settings
        col = None
        selected_before = tuple(context.selected_objects)
        active_before = context.view_layer.objects.active
        try:
            ensure_object_mode()
            clear_preview()
            validate_settings(s)

            # CBDK read-only preflight snapshot before any generation.
            before_a = modifier_snapshot_object(s.object_a)
            before_b = modifier_snapshot_object(s.object_b)

            col = get_or_create_collection(
                unique_collection_name("HingeMaker_Result"),
                context.scene.collection,
            )
            result = build_hinge_geometry(context, s, col, preview=False)

            clearance = {
                "a": [],
                "b": [],
                "created": [],
            }

            if s.attach_mode != 'GENERATE_ONLY':
                clearance = build_body_clearance_geometry(
                    context,
                    s,
                    result,
                    col,
                    preview=False,
                )

            audit = attach_generated_hinge(
                s,
                result,
                clearance,
            )

            all_result_objects = (
                list(result["created"])
                + list(clearance.get("created", []))
            )

            for obj in all_result_objects:
                if not is_live_object(obj):
                    continue
                obj["hinge_axis_x"] = result["axis"].x
                obj["hinge_axis_y"] = result["axis"].y
                obj["hinge_axis_z"] = result["axis"].z
                obj["hinge_center_x"] = result["center"].x
                obj["hinge_center_y"] = result["center"].y
                obj["hinge_center_z"] = result["center"].z
                obj["hinge_layout"] = s.layout_mode
                obj["hinge_style"] = s.hinge_style
                obj["hinge_gap"] = s.knuckle_gap
                obj["hinge_pin_clearance"] = s.pin_clearance
                obj["hinge_end_mode"] = s.axle_end_mode if s.hinge_style == 'INTEGRATED_AXLE' else 'THROUGH_PIN'
                obj["hinge_axle_tip_clearance"] = s.axle_tip_clearance
                obj["hinge_face_clearance"] = (s.knuckle_gap if s.face_clearance_follow_gap else s.face_clearance)
                obj["cbdk_testbed"] = True
                obj["cbdk_components"] = "BLCTX-001,BLCTX-002,BLMOD-001,CBDK-HMEXP-001,CBDK-HMEXP-003,CBDK-HMEXP-004"

            s.cbdk_last_status = str(audit.get("status", "unknown")).upper()
            summary = ", ".join(
                f"{w['owner']}-{w['label']}:{w['reach']:.2f}"
                for w in result.get("bridge_witnesses", [])
            )
            s.cbdk_last_detail = str(audit.get("detail", ""))
            if s.hinge_style == 'INTEGRATED_AXLE':
                warnings = print_clearance_warnings(
                    knuckle_gap=s.knuckle_gap,
                    radial_clearance=s.pin_clearance,
                    tip_clearance=s.axle_tip_clearance,
                    face_clearance=(s.knuckle_gap if s.face_clearance_follow_gap else s.face_clearance),
                )
                if warnings:
                    s.cbdk_last_detail += ' / 印刷前にスライス確認: ' + ', '.join(warnings)
            if summary:
                s.cbdk_last_detail += " / HMEXP-004 bridges " + summary

            # Preserve the preflight counts in the operation metadata without
            # holding live Modifier references.
            for obj in all_result_objects:
                if is_live_object(obj):
                    obj["cbdk_preflight_a_modifiers"] = len(before_a)
                    obj["cbdk_preflight_b_modifiers"] = len(before_b)

        except Exception as exc:
            s.cbdk_last_status = "GENERATE FAIL"
            s.cbdk_last_detail = str(exc)
            # Staging ensures APPLY does not edit A/B before both are verified.
            # If an unexpected Blender commit failure occurs, backups/Undo
            # remain available. Keep any backup collection for recovery.
            if col is not None:
                try:
                    remove_collection_tree(col)
                except Exception:
                    pass
            self.report({'ERROR'}, f"ヒンジ生成失敗: {exc}")
            return {'CANCELLED'}
        finally:
            # Boolean operators change selection/active object internally.
            if context.mode == 'OBJECT':
                try:
                    bpy.ops.object.select_all(action='DESELECT')
                    for obj in selected_before:
                        if obj.name in bpy.data.objects:
                            obj.select_set(True)
                    if active_before is not None and active_before.name in bpy.data.objects:
                        context.view_layer.objects.active = active_before
                except Exception:
                    pass

        if s.attach_mode == 'MODIFIER':
            self.report({'INFO'}, f"ヒンジ生成完了 / CBDK {s.cbdk_last_status}: {s.cbdk_last_detail}")
        elif s.attach_mode == 'APPLY':
            self.report({'INFO'}, "作業コピーで検査後、A/Bへ自動Apply完了。元形状バックアップを保存しました。")
        else:
            self.report({'INFO'}, "ヒンジだけ生成しました。")
        return {'FINISHED'}


class VIEW3D_PT_hinge_maker(Panel):
    bl_label = "Hinge Maker"
    bl_idname = "VIEW3D_PT_hinge_maker"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Joint Maker"

    @classmethod
    def poll(cls,context):
        return False

    def draw(self,context):
        pass


class VIEW3D_PT_hinge_maker_standard(Panel):
    bl_label = "通常ヒンジ"
    bl_idname = "VIEW3D_PT_hinge_maker_standard"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Joint Maker"
    bl_parent_id = "VIEW3D_PT_cjm_root"
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def poll(cls,context):
        return _cjm_ui.visible(context,'HINGE')

    def draw(self, context):
        layout = self.layout
        s = context.scene.hinge_maker_settings

        info = layout.box()
        info.label(text="タグ: 自作アドオン", icon='BOOKMARKS')
        info.label(text="相互逃げまで含む、実際に回る埋め込みヒンジを作成")

        live = layout.box()
        live.label(text="LIVE 寸法ガイド（数値変更に即反応）", icon='OVERLAY')
        live.prop(s, "guide_enabled", text="3Dビューに表示")
        if s.guide_enabled:
            live.prop(s, "guide_focus", text="注目する寸法")
            live.prop(s, "guide_scene_enabled", text="3D立体ワイヤーを表示")
            if s.guide_scene_enabled:
                live.prop(s, "guide_3d_mode", text="表示内容")
                live.label(text="青=A / 橙=B / 水色=穴 / 黄=注目 / 赤=要修正")
                live.label(text="軸は端面円と側面線で径・長さを表示")
            live.label(text="数値変更で注目箇所が自動切替", icon='INFO')
            live.label(text="各項目右の目アイコンでも位置を確認")
            live.label(text="立体ワイヤーは設計寸法。実形状は下のプレビュー")
        live.label(text="印刷クリアランスは環境依存。既定値は変更なし")

        ab = layout.box()
        ab.label(text="1. 2つの本体を設定", icon='MESH_DATA')
        ab.operator("cjm.register_targets", text="選択中の2オブジェクトを設定（A=アクティブ）", icon='EYEDROPPER')
        ab.prop(s, "object_a", text="Object A")
        ab.prop(s, "object_b", text="Object B")
        ab.operator(HINGEMAKER_OT_swap_objects.bl_idname, text="A/B入れ替え", icon='ARROW_LEFTRIGHT')

        pos = layout.box()
        pos.label(text="2. 位置と軸", icon='CURSOR')
        pos.label(text="中心位置 = 3Dカーソル", icon='INFO')
        pos.operator(HINGEMAKER_OT_cursor_to_ab_midpoint.bl_idname, text="カーソルをA/B中間へ", icon='CURSOR')
        pos.prop(s, "axis_mode", text="ヒンジ軸")
        pos.prop(s, "axis_flip")

        shape = layout.box()
        shape.label(text="3. ヒンジ形状", icon='MOD_SCREW')
        shape.prop(s, "hinge_style", expand=True)
        if s.hinge_style == 'INTEGRATED_AXLE':
            shape.label(text="中央の太い胴 + 左右に一体軸", icon='INFO')
            shape.label(text="左右ナックルだけに軸穴を作ります")
        else:
            shape.label(text="3ナックルすべてに穴 + 別ピン", icon='INFO')
        shape.prop(s, "layout_mode", expand=True)
        if s.hinge_style == 'INTEGRATED_AXLE' and s.axle_end_mode == 'TRIM':
            shape.label(text="方式Bではヒンジ全長は計算結果です", icon='INFO')
        else:
            _guide_prop(shape, s, "total_length", "TOTAL_LENGTH")
        _guide_prop(shape, s, "outer_diameter", "DIAMETER")
        is_trim = s.hinge_style == 'INTEGRATED_AXLE' and s.axle_end_mode == 'TRIM'
        if not is_trim:
            shape.prop(s, "length_mode", expand=True)
            if s.length_mode == 'CENTER_LONG':
                _guide_prop(shape, s, "center_ratio", "CENTER_LENGTH")
        shape.label(text="ナックル各部の長さ（左右対称）", icon='DRIVER_DISTANCE')
        _guide_prop(shape, s, "side_length_edit", "SIDE_LENGTH", text="左右側（各1個）")
        _guide_prop(shape, s, "center_length_edit", "CENTER_LENGTH", text="中央")
        if is_trim:
            shape.label(text="方式B：左右編集→軸長変更 / 中央編集→左右追従")
        elif s.get('_hm_manual_lengths', False):
            shape.label(text="個別寸法モード：全長変更時もA:B比率を維持", icon='INFO')
            shape.operator(HINGEMAKER_OT_reset_length_distribution.bl_idname,
                           text="倍率による自動配分へ戻す", icon='FILE_REFRESH')
        else:
            shape.label(text="左右/中央を直接編集すると個別寸法モードへ切替")
        shape.prop(s, "make_support_bridges")
        if s.make_support_bridges:
            col_br = shape.column(align=True)
            _guide_prop(col_br, s, "bridge_embed", "BRIDGE_EMBED")
            _guide_prop(col_br, s, "bridge_width_ratio", "BRIDGE_WIDTH")
            _guide_prop(col_br, s, "bridge_max_reach", "BRIDGE_REACH")
            shape.label(text="A左右/B中央それぞれの本体表面へ接続", icon='LINKED')
        _guide_prop(shape, s, "knuckle_gap", "KNUCKLE_GAP")
        shape.label(
            text="↑ 軸方向のA/Bナックル間の隙間",
            icon='INFO',
        )

        relief = layout.box()
        relief.label(
            text="4. 本体側の回転逃げ",
            icon='MOD_BOOLEAN',
        )
        relief.prop(
            s,
            "make_body_relief",
        )

        if s.make_body_relief:
            _guide_prop(relief, s, "body_relief_clearance", "BODY_RELIEF")
            relief.prop(s, "face_clearance_follow_gap")
            if not s.face_clearance_follow_gap:
                _guide_prop(relief, s, "face_clearance", "FACE_CLEARANCE")
            relief.label(text="端面方向の本体逃げをナックル間隙以下に制限", icon='INFO')
            relief.label(
                text="A本体 ← Bナックル外形をDifference",
                icon='REMOVE',
            )
            relief.label(
                text="B本体 ← Aナックル外形をDifference",
                icon='REMOVE',
            )

        if s.hinge_style == 'INTEGRATED_AXLE':
            relief.label(
                text=("左右側にB軸先端+隙間まで止まり穴" if
                      s.axle_end_mode == 'BLIND' else
                      "左右側の長さを軸に追従・開放穴"),
                icon='INFO',
            )
        else:
            relief.label(
                text="A/B両本体に貫通ピン穴も自動作成",
                icon='INFO',
            )

        pin = layout.box()
        if s.hinge_style == 'INTEGRATED_AXLE':
            pin.label(text="5. 一体軸・端部処理", icon='EMPTY_SINGLE_ARROW')
            pin.prop(s, "axle_end_mode", expand=True)
            _guide_prop(pin, s, "pin_diameter", "PIN_DIAMETER", text="一体軸径")
            _guide_prop(pin, s, "pin_clearance", "PIN_CLEARANCE", text="軸穴クリアランス（片側）")
            _guide_prop(pin, s, "axle_tip_clearance", "AXLE_TIP")
            pin.label(text=f"穴径: {s.pin_diameter+s.pin_clearance*2.0:.3f}", icon='DRIVER_DISTANCE')
            _guide_prop(pin, s, "minimum_radial_wall", "RADIAL_WALL")
            radial = (s.outer_diameter - s.pin_diameter) * .5 - s.pin_clearance
            radial_row = pin.row()
            radial_row.alert = radial < s.minimum_radial_wall - 1e-8
            radial_row.label(text=f"軸穴の外周肉厚: {radial:.3f} / 最低 {s.minimum_radial_wall:.3f}",
                             icon='ERROR' if radial_row.alert else 'CHECKMARK')
            if s.axle_end_mode == 'BLIND':
                pin.label(text="A: 中実ナックル → 短いDifferenceで止まり穴")
                _guide_prop(pin, s, "minimum_cap_wall", "CAP_WALL")
                pin.prop(s, "axle_follow_side_centers")
                pin.prop(s, "axle_prevent_overrun")
                if not s.axle_follow_side_centers:
                    pin.prop(s, "pin_end_extra", text="手動軸の端余裕")
            else:
                pin.label(text="B: B一体軸の全長が基準", icon='INFO')
                _guide_prop(pin, s, "trim_axle_length", "AXLE_LENGTH")
                _guide_prop(pin, s, "trim_center_length", "CENTER_LENGTH")
            try:
                specs, span, total = resolved_hinge_geometry(s)
                pin.label(text=f"軸長: {span.length:.3f} / 完成全長: {total:.3f}", icon='DRIVER_DISTANCE')
                if s.axle_end_mode == 'BLIND':
                    walls = _blind_bore_plan(s, specs, span, total)
                    pin.label(text=f"止まり穴の外壁厚 L:{walls[0].cap_wall:.3f} R:{walls[1].cap_wall:.3f}")
                else:
                    pin.label(text=f"左右各ナックル長: {specs[0][2]:.3f}")
            except (ValueError, RuntimeError) as exc:
                pin.label(text="寸法要修正（下の赤い診断を確認）", icon='ERROR')
            if min(s.pin_clearance, s.knuckle_gap, s.axle_tip_clearance) < .30:
                pin.label(text="注意: 0.3未満の隙間あり。スライサーで確認", icon='ERROR')
            pin.label(text="Differenceを先にApply → 最後に中央軸Union", icon='INFO')
            pin.label(text="一括印刷: スライス後の可動部融合に注意", icon='INFO')
        else:
            pin.label(text="5. 貫通ピン", icon='EMPTY_SINGLE_ARROW')
            _guide_prop(pin, s, "pin_diameter", "PIN_DIAMETER", text="ピン径")
            _guide_prop(pin, s, "pin_clearance", "PIN_CLEARANCE", text="ピン穴クリアランス")
            pin.label(
                text=f"実効穴径: {s.pin_diameter + s.pin_clearance * 2.0:.3f}",
                icon='DRIVER_DISTANCE',
            )
            pin.prop(s, "pin_mode")
            if s.pin_mode != 'NONE':
                pin.prop(s, "pin_end_extra")


        problems = _current_dimension_issues(s)
        diag_box = layout.box()
        title_row = diag_box.row()
        title_row.alert = bool(problems)
        title_row.label(text=(f"寸法診断: {len(problems)}件の要修正" if problems else "寸法診断: 計算上は条件内"),
                        icon='ERROR' if problems else 'CHECKMARK')
        if problems:
            for issue in problems[:4]:
                row_issue = diag_box.row(align=True)
                row_issue.alert = True
                row_issue.label(text=issue.message[:110], icon='ERROR')
                focus_button = row_issue.operator('hinge_maker.guide_focus', text='', icon='HIDE_OFF')
                focus_button.focus = issue.focus if issue.focus in FOCUS_INFO else 'OVERVIEW'
            if len(problems) > 4:
                diag_box.label(text=f'ほか {len(problems)-4} 件。設定を見直してください')
        elif s.hinge_style == 'INTEGRATED_AXLE' and s.axle_end_mode == 'BLIND':
            try:
                specs, axle_span, total = resolved_hinge_geometry(s)
                left_outer = specs[0][1] - specs[0][2]*.5
                right_outer = specs[2][1] + specs[2][2]*.5
                lwall = axle_span.start - s.axle_tip_clearance - left_outer
                rwall = right_outer - axle_span.end - s.axle_tip_clearance
                diag_box.label(text=f'閉鎖壁厚 左 {lwall:.3f} / 右 {rwall:.3f} / 最低 {s.minimum_cap_wall:.3f}')
                if not s.get('_hm_manual_lengths', False) and s.axle_follow_side_centers:
                    ratio = 1.0 if s.length_mode=='EQUAL' else s.center_ratio
                    need = minimum_total_for_blind_cap(gap=s.knuckle_gap, center_ratio=ratio,
                        tip_clearance=s.axle_tip_clearance, min_cap_wall=s.minimum_cap_wall)
                    diag_box.label(text=f'配分を維持する場合の全長目安: {need:.3f} 以上')
            except (ValueError, RuntimeError):
                pass
        diag_box.label(text='※ 設計上の寸法診断。実Boolean/スライス結果の検査ではありません')

        attach = layout.box()
        attach.label(text="6. 本体への取付", icon='MOD_BOOLEAN')
        attach.prop(s, "attach_mode", expand=True)
        if s.attach_mode == 'MODIFIER':
            attach.label(
                text="Union + 相互Difference + 軸穴Difference を待機",
                icon='INFO',
            )
            attach.label(
                text="生成形状/CutterはWIREで残るので後から確認可能",
            )
        elif s.attach_mode == 'APPLY':
            attach.label(text="プレビュー = 完成形状のワイヤー（本体は無変更）", icon='INFO')
            attach.label(text="作業コピーでBooleanを順次適用・検査")
            attach.label(text="成功時だけA/Bを確定（元形状はバックアップ）")
            attach.label(text="既存のModifierも確定されます", icon='ERROR')

        cbdk_box = layout.box()
        cbdk_box.label(text="CBDK Experimental", icon='EXPERIMENTAL')
        cbdk_box.label(text="BLCTX-001 / BLCTX-002 / BLMOD-001", icon='LINKED')
        cbdk_box.label(text="HMEXP-001: Modifier差分監査")
        cbdk_box.label(text="HMEXP-003: UNION/DIFFERENCE計画監査")
        cbdk_box.prop(s, "cbdk_strict_modifier_audit")
        cbdk_box.operator(HINGEMAKER_OT_cbdk_preflight.bl_idname, text="生成前チェック", icon='CHECKMARK')
        status_row = cbdk_box.row()
        status_row.alert = ("FAIL" in s.cbdk_last_status or "WARNING" in s.cbdk_last_status)
        status_row.label(text=f"状態: {s.cbdk_last_status}")
        if s.cbdk_last_detail:
            cbdk_box.label(text=s.cbdk_last_detail[:120], icon='INFO')

        quality = layout.box()
        quality.label(text="詳細", icon='PREFERENCES')
        quality.prop(s, "radial_segments")

        row = layout.row(align=True)
        row.operator(HINGEMAKER_OT_preview.bl_idname, text="プレビュー", icon='HIDE_OFF')
        row.operator(HINGEMAKER_OT_preview_clear.bl_idname, text="削除", icon='X')

        col = layout.column()
        col.scale_y = 1.45
        col.operator(HINGEMAKER_OT_generate.bl_idname, text="3Dカーソル位置にヒンジを生成", icon='MOD_SCREW')


classes = (
    HINGEMAKER_Settings,
    HINGEMAKER_OT_guide_focus,
    HINGEMAKER_OT_reset_length_distribution,
    HINGEMAKER_OT_capture_objects,
    HINGEMAKER_OT_swap_objects,
    HINGEMAKER_OT_cursor_to_ab_midpoint,
    HINGEMAKER_OT_cbdk_preflight,
    HINGEMAKER_OT_preview,
    HINGEMAKER_OT_preview_clear,
    HINGEMAKER_OT_generate,
    VIEW3D_PT_hinge_maker,
    VIEW3D_PT_hinge_maker_standard,
)


def _reset_live_overlay_on_open():
    """Reset only the ephemeral LIVE switch; do not change dimensions or meshes."""
    for scene in getattr(getattr(bpy, 'data', None), 'scenes', ()):
        settings = getattr(scene, 'hinge_maker_settings', None)
        if settings is None:
            continue
        try:
            settings.guide_enabled = False
        except (AttributeError, ReferenceError, RuntimeError):
            # Read-only or stale scenes should never block a file load.
            continue
    _guide_redraw(None)


@_persistent
def _live_overlay_load_post(_dummy):
    """Even old .blend/startup.blend files with LIVE=ON open with LIVE=OFF."""
    _reset_live_overlay_on_open()


def _register_live_startup_handler():
    handlers = getattr(getattr(getattr(bpy, 'app', None), 'handlers', None),
                       'load_post', None)
    if handlers is not None and _live_overlay_load_post not in handlers:
        handlers.append(_live_overlay_load_post)


def _unregister_live_startup_handler():
    handlers = getattr(getattr(getattr(bpy, 'app', None), 'handlers', None),
                       'load_post', None)
    if handlers is not None and _live_overlay_load_post in handlers:
        handlers.remove(_live_overlay_load_post)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.hinge_maker_settings = PointerProperty(type=HINGEMAKER_Settings)
    _register_live_startup_handler()
    _reset_live_overlay_on_open()
    try:
        from . import live_overlay
        live_overlay.install()
    except (ImportError, RuntimeError, AttributeError) as exc:
        print(f"Hinge Maker: ライブ寸法ガイドを開始できません: {exc}")
    global _FACE_HINGE_REGISTER_ERROR
    _FACE_HINGE_REGISTER_ERROR = None
    try:
        from . import face_hinge
        face_hinge.register()
    except Exception as exc:
        import traceback
        _FACE_HINGE_REGISTER_ERROR = f"{type(exc).__name__}: {exc}"
        print(f"Hinge Maker: Face Hingeパネルを開始できません: {_FACE_HINGE_REGISTER_ERROR}")
        traceback.print_exc()


def unregister():
    try:
        from . import face_hinge
        face_hinge.unregister()
    except (ImportError, RuntimeError, AttributeError) as exc:
        print(f"Hinge Maker: Face Hinge終了処理: {exc}")
    _unregister_live_startup_handler()
    try:
        from . import live_overlay
        live_overlay.uninstall()
    except (ImportError, RuntimeError, AttributeError):
        pass
    clear_preview()
    if hasattr(bpy.types.Scene, "hinge_maker_settings"):
        del bpy.types.Scene.hinge_maker_settings
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
