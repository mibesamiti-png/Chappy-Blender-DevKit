"""Blender-independent geometry contracts for Face Hinge Maker 0.1.1 (prototype).

Units are Blender scene units. No actual mesh/BVH collision or slicer validation.
"""
from dataclasses import dataclass
from math import ceil, cos, isfinite, pi, radians, sin, sqrt


@dataclass(frozen=True)
class Span:
    center_width: float
    side_width: float
    gap: float
    outer_radius: float
    axle_radius: float
    bore_radius: float
    left_center: float
    right_center: float
    left_outer: float
    left_inner: float
    right_inner: float
    right_outer: float
    shaft_min: float
    shaft_max: float
    cap_wall: float
    tip_clearance: float

    @property
    def axle_length(self):
        return self.shaft_max - self.shaft_min

    @property
    def total_length(self):
        return self.right_outer - self.left_outer


def plan_span(*, center_width, side_width, gap, outer_diameter,
              axle_diameter, radial_clearance, cap_wall, tip_clearance,
              min_radial_wall=0.30):
    fields = locals().copy()
    for key, value in fields.items():
        if not isfinite(float(value)):
            raise ValueError(f'{key}: 有限の数値を指定してください')
    if min(center_width, side_width, outer_diameter, axle_diameter) <= 0:
        raise ValueError('ナックル・軸の寸法は0より大きくしてください')
    if min(gap, radial_clearance, cap_wall, tip_clearance, min_radial_wall) < 0:
        raise ValueError('クリアランス・壁厚は負にできません')
    outer = outer_diameter / 2
    shaft = axle_diameter / 2
    bore = shaft + radial_clearance
    if outer - bore < min_radial_wall:
        raise ValueError(f'軸穴周囲の肉厚が不足（現在 {outer-bore:.3f} / 最低 {min_radial_wall:.3f}）')
    if side_width < cap_wall + tip_clearance + 0.05:
        raise ValueError('A側ナックルが短く、止まり穴の外壁を確保できません')
    left_inner = -center_width / 2 - gap
    right_inner = center_width / 2 + gap
    left_outer = left_inner - side_width
    right_outer = right_inner + side_width
    shaft_min = left_outer + cap_wall + tip_clearance
    shaft_max = right_outer - cap_wall - tip_clearance
    if shaft_min >= left_inner or shaft_max <= right_inner:
        raise ValueError('中央軸がAナックルに十分入りません')
    return Span(center_width, side_width, gap, outer, shaft, bore,
                (left_outer+left_inner)/2, (right_outer+right_inner)/2,
                left_outer, left_inner, right_inner, right_outer,
                shaft_min, shaft_max, cap_wall, tip_clearance)



@dataclass(frozen=True)
class ABSpan:
    """Two-knuckle straight hinge: one A knuckle beside one B knuckle.

    Negative axis: A, positive axis: B. B owns one integrated axle,
    which enters A's single blind bore. No third knuckle is generated.
    """
    a_width: float
    b_width: float
    gap: float
    outer_radius: float
    axle_radius: float
    bore_radius: float
    a_outer: float
    a_inner: float
    b_inner: float
    b_outer: float
    a_center: float
    b_center: float
    bore_start: float
    bore_end: float
    shaft_min: float
    shaft_max: float
    cap_wall: float
    tip_clearance: float

    @property
    def axle_length(self):
        return self.shaft_max - self.shaft_min

    @property
    def total_length(self):
        return self.b_outer - self.a_outer


def plan_ab_span(*, a_width, b_width, gap, outer_diameter,
                 axle_diameter, radial_clearance, cap_wall,
                 tip_clearance, min_radial_wall=0.30):
    """Lay out a print-in-place A-B two-knuckle hinge on one axis.

    A occupies the negative side of the cursor, B the positive side.
    The A bore opens toward the inter-knuckle gap but leaves an outer cap;
    the B axle is unioned last and ends shy of the blind end of A's bore.
    This is geometry planning, not a printer or collision guarantee.
    """
    inputs = locals().copy()
    if any(not isfinite(float(value)) for value in inputs.values()):
        raise ValueError('ヒンジ寸法には有限の値を指定してください')
    if min(a_width, b_width, outer_diameter, axle_diameter) <= 0:
        raise ValueError('ナックル・軸の寸法は0より大きくしてください')
    if min(gap, radial_clearance, cap_wall, tip_clearance, min_radial_wall) < 0:
        raise ValueError('クリアランス・壁厚は負にできません')
    outer_radius = outer_diameter/2
    axle_radius = axle_diameter/2
    bore_radius = axle_radius+radial_clearance
    if outer_radius-bore_radius < min_radial_wall:
        raise ValueError(f'軸穴周囲の肉厚が不足（現在 {outer_radius-bore_radius:.3f} / 最低 {min_radial_wall:.3f}）')
    if a_width < cap_wall+tip_clearance+0.05:
        raise ValueError('Aナックルが短く、止まり穴と軸先端の隙間を確保できません')
    a_inner = -gap/2
    a_outer = a_inner-a_width
    b_inner = gap/2
    b_outer = b_inner+b_width
    bore_start = a_outer+cap_wall
    # Extend the bore slightly into the gap so that its A-side entrance opens.
    bore_end = a_inner+max(0.05, min(gap*0.25, 0.15))
    shaft_min = bore_start+tip_clearance
    # B axle must actually overlap the solid B knuckle; for a thin B barrel,
    # choose a proportional overlap instead of penetrating beyond its end.
    overlap = min(b_width*0.75, max(axle_radius*0.65, 0.15))
    shaft_max = b_inner+overlap
    if shaft_min >= a_inner-0.05:
        raise ValueError('A側の軸差し込み長が不足しています')
    if shaft_max <= b_inner:
        raise ValueError('B側の一体軸がナックルに接続できません')
    return ABSpan(a_width,b_width,gap,outer_radius,axle_radius,bore_radius,
                  a_outer,a_inner,b_inner,b_outer,
                  (a_outer+a_inner)/2,(b_inner+b_outer)/2,
                  bore_start,bore_end,shaft_min,shaft_max,
                  cap_wall,tip_clearance)


@dataclass(frozen=True)
class ShoulderHead:
    """Captured end-head on B's axle, inside an A-side closed counterbore.

    All distances are signed axial offsets from the 3D cursor. A is on the
    negative side, B on the positive side. The narrow entry bore meets the
    wider inner chamber, leaving a retaining lip at the entrance.
    """
    head_start: float
    head_end: float
    head_radius: float
    cavity_start: float
    cavity_end: float
    cavity_radius: float
    mouth_start: float
    mouth_end: float
    shaft_start: float
    capture_lip: float
    remaining_wall: float
    throat_length: float


def plan_shoulder_head(span, *, shoulder_diameter, shoulder_thickness,
                       shoulder_radial_clearance, shoulder_axial_clearance,
                       min_radial_wall=0.35, min_capture_lip=0.10,
                       min_throat_length=0.35):
    """Plan a headed axle trapped in A's *internal* stepped blind bore.

    Not a proximal collar: the enlarged head is at B axle's free end INSIDE A,
    as in the user-supplied sketch. A smaller bore opens at the A/B interface;
    a larger chamber begins behind the bore and ends before the outer cap.
    The result is a geometric stop against axial withdrawal, provided the
    printed clearances actually separate the parts. No assembly/print promise.
    """
    vals=(shoulder_diameter,shoulder_thickness,shoulder_radial_clearance,
          shoulder_axial_clearance,min_radial_wall,min_capture_lip,min_throat_length)
    if any(not isfinite(float(v)) for v in vals):
        raise ValueError('肩付き軸の寸法には有限の値を指定してください')
    if shoulder_diameter<=0 or shoulder_thickness<=0:
        raise ValueError('肩の直径・厚みは0より大きくしてください')
    if shoulder_radial_clearance<=0 or shoulder_axial_clearance<=0:
        raise ValueError('肩と内部空間のクリアランスは0より大きくしてください')
    if min(min_radial_wall,min_capture_lip,min_throat_length)<=0:
        raise ValueError('保持幅・壁厚・入口長の最低値は0より大きくしてください')
    head_radius=shoulder_diameter/2.0
    capture_lip=head_radius-span.bore_radius
    if capture_lip+1e-9<min_capture_lip:
        raise ValueError(f'返しが小さすぎます（入口穴半径との差 {capture_lip:.3f} / 最低 {min_capture_lip:.3f}）')
    cavity_radius=head_radius+shoulder_radial_clearance
    wall=span.outer_radius-cavity_radius
    if wall+1e-9<min_radial_wall:
        required=2*(cavity_radius+min_radial_wall)
        raise ValueError(f'受け内部の肉厚不足。ナックル外径を {required:.2f} 以上にしてください')
    # A outside end has a solid cap. An internal enlarged chamber houses the
    # head with clearance on *both* axial sides, so the head never fuses to A.
    cavity_start=span.a_outer+span.cap_wall
    head_start=cavity_start+shoulder_axial_clearance
    head_end=head_start+shoulder_thickness
    cavity_end=head_end+shoulder_axial_clearance
    throat=span.a_inner-cavity_end
    if throat+1e-9<min_throat_length:
        required=span.cap_wall+shoulder_thickness+2*shoulder_axial_clearance+min_throat_length
        raise ValueError(f'Aナックルが短く、頭を保持する入口を作れません。Aナックル長を {required:.2f} 以上にしてください')
    # Slight overlap between the stepped cutters, avoiding a coplanar seam
    # at their junction. The wide chamber never extends through the A mouth.
    blend=min(0.05,throat*0.10)
    mouth_start=cavity_end-blend
    mouth_end=span.bore_end
    shaft_start=head_start+shoulder_thickness*0.45
    if shaft_start>=span.shaft_max or mouth_start>=mouth_end:
        raise ValueError('軸と返しの接続が成立しません。寸法を見直してください')
    return ShoulderHead(head_start,head_end,head_radius,
                        cavity_start,cavity_end,cavity_radius,
                        mouth_start,mouth_end,shaft_start,
                        capture_lip,wall,throat)

def sweep_angles(minimum, maximum, max_step=5.0):
    """Sample the requested operating arc AND the path from neutral (0°).

    The mechanism is constructed at 0°. If the requested interval starts at,
    say, 20°, the 0°→20° transfer must also have clearance. Simply appending
    0° as a lone sample leaves an unsampled angular gap and may produce a very
    large, destructive safety-padding value.
    """
    if not all(isfinite(float(x)) for x in (minimum, maximum, max_step)):
        raise ValueError('可動角は有限の数値にしてください')
    if minimum > maximum:
        raise ValueError('最小角度が最大角度を超えています')
    if minimum < -180 or maximum > 180:
        raise ValueError('可動範囲は-180度から180度までです')
    if max_step <= 0 or max_step > 30:
        raise ValueError('角度刻みは0より大きく30度以下にしてください')
    sweep_min, sweep_max = min(0.0, minimum), max(0.0, maximum)
    segments = max(1, int(ceil((sweep_max-sweep_min)/max_step)))
    if segments > 180:
        raise ValueError('角度サンプルが多すぎます。刻みを大きくしてください')
    actual_step = (sweep_max-sweep_min)/segments
    # Preserve requested endpoints and neutral explicitly, not just samples
    # from a larger equally-spaced interval; step is <= max_step everywhere.
    angles = [sweep_min + i*actual_step for i in range(segments+1)]
    angles.extend([minimum, maximum, 0.0])
    return tuple(sorted(set(round(x, 9) for x in angles)))


def sweep_padding(max_radius, angle_step_degrees, clearance):
    """Conservative nearest-sample motion bound, not exact continuous sweep."""
    if min(max_radius, clearance) < 0 or angle_step_degrees < 0:
        raise ValueError('負のサンプル半径・隙間は使えません')
    return clearance + 2 * max_radius * sin(radians(angle_step_degrees)/4)


def rotate_xyz(point, center, axis, angle_degrees):
    """Rodrigues rotation, axis need not be normalized."""
    p = tuple(float(a)-float(b) for a,b in zip(point, center))
    a = tuple(float(x) for x in axis)
    ln = sqrt(sum(x*x for x in a))
    if ln <= 1e-10:
        raise ValueError('回転軸がありません')
    a = tuple(x/ln for x in a)
    cs, sn = cos(radians(angle_degrees)), sin(radians(angle_degrees))
    cr = (a[1]*p[2]-a[2]*p[1], a[2]*p[0]-a[0]*p[2], a[0]*p[1]-a[1]*p[0])
    dot = sum(x*y for x,y in zip(a,p))
    return tuple(float(c) + p[i]*cs + cr[i]*sn + a[i]*dot*(1-cs)
                 for i,c in enumerate(center))


@dataclass(frozen=True)
class TrunnionSpan:
    """World-axis offsets relative to the 3D cursor, in scene units.

    B is the moving socket. Pins are welded to B; the bores are subtracted
    only from the existing A yoke. There are intentionally no support arms.
    """
    left_surface: float
    right_surface: float
    left_pin_inner: float
    left_pin_outer: float
    right_pin_inner: float
    right_pin_outer: float
    left_bore_inner: float
    left_bore_outer: float
    right_bore_inner: float
    right_bore_outer: float
    pin_radius: float
    bore_radius: float

    @property
    def socket_width(self):
        return self.right_surface - self.left_surface


def plan_trunnion(*, socket_min, socket_max, axle_diameter,
                  radial_clearance, pin_projection, pin_embed,
                  tip_clearance, axial_gap):
    """Plan paired, coaxial side pins from the moving socket's axial bounds.

    The 3D cursor must lie within the socket's *axial* extent, and there must
    be enough surface material for pin overlap. Yoke wall position/thickness
    cannot be inferred from its overall bbox: the user must inspect it.
    """
    inputs = locals().copy()
    if any(not isfinite(float(x)) for x in inputs.values()):
        raise ValueError('軸寸法には有限の値を指定してください')
    if axle_diameter <= 0 or pin_projection <= 0 or pin_embed <= 0:
        raise ValueError('軸径・軸突出長・埋め込み長は0より大きくしてください')
    if min(radial_clearance, tip_clearance, axial_gap) < 0:
        raise ValueError('クリアランスは負にできません')
    if socket_min >= socket_max:
        raise ValueError('Bソケットの軸方向の範囲が不正です')
    # The side pins should start inside each side of B. The moving object's
    # centre/pivot must therefore lie between its two side faces.
    if socket_min >= -pin_embed or socket_max <= pin_embed:
        raise ValueError('3DカーソルがBの軸方向中心から外れています（埋め込み長も確認）')
    # The bore crosses the mouth of the yoke and extends past the pin tip.
    # The extra axial_gap reach opens the mouth even with slight frame overlap.
    return TrunnionSpan(
        left_surface=socket_min, right_surface=socket_max,
        left_pin_inner=socket_min + pin_embed,
        left_pin_outer=socket_min - pin_projection,
        right_pin_inner=socket_max - pin_embed,
        right_pin_outer=socket_max + pin_projection,
        left_bore_inner=socket_min + axial_gap,
        left_bore_outer=socket_min - pin_projection - tip_clearance,
        right_bore_inner=socket_max - axial_gap,
        right_bore_outer=socket_max + pin_projection + tip_clearance,
        pin_radius=axle_diameter/2.0,
        bore_radius=axle_diameter/2.0 + radial_clearance,
    )


def guide_arrow_segments(start, end, head_size=0.25):
    """Blender-independent 3D arrow wire for LIVE direction diagnostics.

    The arrow tip is *end*. A stable perpendicular is chosen for any X/Y/Z
    orientation, including negative world axes. Nothing here modifies meshes.
    """
    start = tuple(float(v) for v in start)
    end = tuple(float(v) for v in end)
    if len(start) != 3 or len(end) != 3:
        raise ValueError('方向ガイドには3次元座標が必要です')
    if not isfinite(head_size) or head_size <= 0 or not all(
            isfinite(x) for x in (*start, *end)):
        raise ValueError('方向ガイドの寸法が不正です')
    v = tuple(end[i] - start[i] for i in range(3))
    length = sqrt(sum(x*x for x in v))
    if length < 1e-8:
        raise ValueError('方向ガイドの始点と終点が重なっています')
    d = tuple(x/length for x in v)
    ref = (0., 0., 1.) if abs(d[2]) < .9 else (0., 1., 0.)
    perp = (d[1]*ref[2] - d[2]*ref[1],
            d[2]*ref[0] - d[0]*ref[2],
            d[0]*ref[1] - d[1]*ref[0])
    size = min(float(head_size), length*.42)
    center = tuple(end[i]-d[i]*size for i in range(3))
    left = tuple(center[i]+perp[i]*size*.55 for i in range(3))
    right = tuple(center[i]-perp[i]*size*.55 for i in range(3))
    return ((start, end), (end, left), (end, right))


def guide_axis_segments(pivot, axis, half_extent, head_size=.25):
    """Cursor-centered axis and outward arrows (negative and positive)."""
    pivot = tuple(float(x) for x in pivot)
    axis = tuple(float(x) for x in axis)
    if len(pivot) != 3 or len(axis) != 3:
        raise ValueError('方向ガイドには3次元座標が必要です')
    if not all(isfinite(x) for x in (*pivot, *axis, half_extent, head_size)):
        raise ValueError('方向ガイドに有限値を指定してください')
    length = sqrt(sum(x*x for x in axis))
    if length < 1e-8 or half_extent <= 0:
        raise ValueError('方向ガイドの軸長が不正です')
    unit = tuple(x/length for x in axis)
    negative = tuple(pivot[i]-unit[i]*half_extent for i in range(3))
    positive = tuple(pivot[i]+unit[i]*half_extent for i in range(3))
    center_negative = tuple(pivot[i]-unit[i]*half_extent*.3 for i in range(3))
    center_positive = tuple(pivot[i]+unit[i]*half_extent*.3 for i in range(3))
    return {
        'center_line': ((negative, positive),),
        'negative_arrow': guide_arrow_segments(center_negative, negative, head_size),
        'positive_arrow': guide_arrow_segments(center_positive, positive, head_size),
    }
