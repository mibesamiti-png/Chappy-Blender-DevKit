"""Bounded, deterministic dimension repair. No Blender or geometry operations."""
from dataclasses import dataclass
from math import isfinite, asin, degrees, cos, radians, sin, fsum
from heapq import heappop, heappush
from itertools import count

EPS=0.0001  # guard against RNA float32 rounding at strict planner boundaries

@dataclass(frozen=True)
class Rule:
    name: str
    terms: dict
    minimum: float
    def deficit(self,v):
        return self.minimum-sum(v[k]*c for k,c in self.terms.items())

@dataclass(frozen=True)
class Result:
    values: dict
    ok: bool
    reason: str
    explored: int

# Positive coefficients mean the value needs to grow; negative means shrink.
def rules(kind,v,opt):
    r=[]
    def add(name,minimum,**terms):r.append(Rule(name,terms,minimum))
    if kind=='central_pair':
        # Each joint keeps its own fixed length and mechanical rules. The
        # max of the two radial envelopes is expressed by four inequalities.
        a,b,d=opt['projection']
        for side in ('upper','lower'):
            local={k[len(side)+1:]:x for k,x in v.items() if k.startswith(side+'.')}
            for rule in rules('central',local,opt[side]):
                r.append(Rule(('上側：' if side=='upper' else '下側：')+rule.name,{side+'.'+k:c for k,c in rule.terms.items()},rule.minimum))
        for u in ('slot','guard'):
            for l in ('slot','guard'):
                terms={};offset=0.
                for side,part in (('upper',u),('lower',l)):
                    # A fixed axial length already fixes the axial envelope.
                    # Substitute that equality instead of chasing alternating
                    # length/separation violations on the same dimensions.
                    length=opt[side].get('length')
                    if length is None:
                        terms.update({side+'.'+k:-a*c for k,c in (('a_width',1),('b_width',.5),('axial_gap',1))})
                    else:
                        offset+=a*length/2
                    if part=='slot':terms.update({side+'.outer_diameter':-.5*b,side+'.swing_clearance':-b})
                    else:
                        terms.update({side+'.axle_diameter':-.5*b,side+'.radial_clearance':-b})
                        offset+=b*v[side+'.radial_wall']
                r.append(Rule('上下の加工領域の離隔',terms,-d+offset+EPS))
    elif kind=='legacy_pair':
        a,b,d=opt['projection']
        terms={}
        for side in ('upper','lower'):
            local={k[len(side)+1:]:x for k,x in v.items() if k.startswith(side+'.')}
            for rule in rules('rotary',local,opt[side]):
                r.append(Rule(side+': '+rule.name,{side+'.'+k:c for k,c in rule.terms.items()},rule.minimum))
            # Toward the other pivot: B is positive, A negative. Reverse
            # axis and the direction of the upper/lower projection matter.
            width=opt[side]['toward_width']
            terms.update({side+'.'+width:-a,side+'.axial_gap':-.5*a,side+'.outer_diameter':-.5*b})
        r.append(Rule('上下ナックルの離隔',terms,-d+EPS))
    elif kind=='trunnion':
        for k in ('axle_diameter','pin_projection','pin_embed','radial_clearance','tip_clearance','axial_gap'):
            add('側面軸の寸法・隙間',EPS if k in ('axle_diameter','pin_projection','pin_embed') else 0.,**{k:1})
        add('B側面の埋め込み上限',-opt['embed_limit']+EPS,pin_embed=-1)
    elif kind=='hinge':
        add('軸穴の最低外周肉厚',2*v['minimum_radial_wall']+EPS,outer_diameter=1,pin_diameter=-1,pin_clearance=-2)
        if opt.get('integrated'):
            for k in ('pin_clearance','knuckle_gap'):add('一体造形の正の隙間',EPS,**{k:1})
        if not opt.get('trim'):
            add('全長とナックル間隙',EPS,total_length=1,knuckle_gap=-2)
            if opt.get('blind_factor') is not None:
                f=opt['blind_factor']
                add('止まり穴の最低閉鎖壁厚',f*v['minimum_cap_wall']+EPS,total_length=1,knuckle_gap=-2,axle_tip_clearance=-f)
            elif opt.get('min_usable'):
                add('止まり穴の最低閉鎖壁厚',opt['min_usable'],total_length=1,knuckle_gap=-2)
        if opt.get('face_clearance') is not None:add('端面逃げとナックル間隙',opt['face_clearance'],knuckle_gap=1)
        if opt.get('bridge_max') is not None:add('支持部の到達距離',EPS-2*opt['bridge_max'],outer_diameter=-1)
    elif kind=='ball':
        if opt.get('socket'):
            if opt.get('retain',True):
                add('球の抜け止め（開口は球径未満）',EPS,ball_diameter=1,opening_diameter=-1)
            add('開口はキャビティ内径未満',EPS,ball_diameter=1,opening_diameter=-1,clearance=2)
            if opt.get('shaft') and not opt.get('motion'):
                add('軸は開口より細く',EPS,opening_diameter=1,shaft_diameter=-1)
    elif kind in ('rotary','central'):
        add('軸穴の最低外周肉厚',2*v['radial_wall']+EPS,outer_diameter=1,axle_diameter=-1,radial_clearance=-2)
        tip='shoulder_axial_clearance' if kind=='rotary' and opt.get('shoulder') else 'tip_clearance'
        add('ナックルの軸方向長さ',v['cap_wall']+(.051 if kind=='rotary' else EPS),a_width=1,**{tip:-1})
        for k in ('radial_clearance','axial_gap') + (('shoulder_radial_clearance','shoulder_axial_clearance') if kind=='rotary' and opt.get('shoulder') else ('tip_clearance',)):
            add('一体造形の正の隙間',EPS,**{k:1})
        if kind=='central':
            if 'swing_clearance' in v:add('中央支持の正の逃げ隙間',EPS,swing_clearance=1)
            add('支持腕幅と中央ナックル長',0,b_width=1,support_width=-1)
        elif opt.get('shoulder'):
            add('肩付き軸の保持代',.2+EPS,shoulder_diameter=1,axle_diameter=-1,radial_clearance=-2)
            add('返し頭の外周肉厚',2*v['radial_wall']+EPS,outer_diameter=1,shoulder_diameter=-1,shoulder_radial_clearance=-2)
            add('返し頭の収納長と入口',v['cap_wall']+.35+EPS,a_width=1,shoulder_thickness=-1,shoulder_axial_clearance=-2)
        if kind=='central' and opt.get('separation') is not None:
            # Exact projection of the generation planner's guard/slot envelope.
            # Other joint is kept fixed during this local repair.
            a,b,remaining=opt['separation']
            for terms in ({'outer_diameter':-.5*b,'swing_clearance':-b}, {'axle_diameter':-.5*b,'radial_clearance':-b}):
                offset=b*v['radial_wall'] if 'axle_diameter' in terms else 0.
                if opt.get('length') is None:
                    terms.update(a_width=-a,b_width=-a/2,axial_gap=-a)
                else:
                    offset+=a*opt['length']/2
                add('上下の加工領域の離隔',-remaining+offset+EPS,**terms)
        if opt.get('length') is not None:
            m=2 if kind=='central' else 1
            terms={'a_width':m,'b_width':1,'axial_gap':m}
            add('固定した全長',opt['length'],**terms)
            add('固定した全長',-opt['length'],**{k:-c for k,c in terms.items()})
    elif kind=='swap':
        c=v['radial_clearance']
        add('爪の突出量と隙間',EPS,lug_projection=1,radial_clearance=-1)
        add('差込軸と半径隙間',EPS,diameter=1,radial_clearance=-4)
        # max(.5,a) + max(.5,wall/2) => all four linear inequalities.
        for a_coeff,a_const in ((2,.5),(3,0)):
            for w_coeff,w_const in ((0,.5),(.5,0)):
                add('爪の上の保持壁',a_const+w_const+EPS,depth=1,lug_height=-1,axial_clearance=-a_coeff,wall=-w_coeff)
        if v['diameter']>4*c:
            pad=degrees(asin(2*c/v['diameter']))+1
            # Eliminate lock_angle from the two angular inequalities.
            # This necessary condition prevents repairs bouncing between
            # mutually incompatible lower and upper lock-angle limits.
            add('爪角幅と固定角の成立範囲',-(360/opt['lug_count']-2-3*pad-2*EPS),lug_angle=-2)
            add('固定角と爪の保持代',pad+EPS,lock_angle=1,lug_angle=-1)
            add('隣接する爪溝との離隔',-(360/opt['lug_count']-2-2*pad-EPS),lock_angle=-1,lug_angle=-1)
        sag=1-cos(radians(1))
        add('隙間とメッシュ分解能',EPS,diameter=-.5,lug_projection=-1,radial_clearance=1/sag-1)
    return r


def _polish_linear(kind, candidate, original, options, bounds, locked, score, validator):
    """Restore unnecessary changes without crossing a linear constraint.

    Fixed-length equalities remain intact; no nonlinear swap approximation.
    Bounded coordinate passes, always revalidate before accepting a move.
    """
    if kind not in ('hinge','ball','rotary','central','central_pair'):
        return candidate
    v=dict(candidate)
    for _ in range(2):
        improved=False
        for k in bounds:
            if k in locked or abs(v[k]-original[k])<=1e-7:continue
            lo,hi=sorted((v[k],original[k]))
            # A value restored exactly to its original is permitted, even
            # when manually entered below the automatic repair floor.
            target=original[k]
            for r in rules(kind,v,options):
                c=r.terms.get(k,0.)
                if abs(c)<1e-14:continue
                edge=v[k]+r.deficit(v)/c
                if c>0:lo=max(lo,edge)
                else:hi=min(hi,edge)
            if lo>hi+1e-9:continue
            nv=max(lo,min(hi,target))
            if abs(nv-target)>1e-8:
                blo,bhi=bounds[k]
                if not blo<=nv<=bhi:continue
            else:nv=target
            if abs(nv-v[k])<=1e-7:continue
            w={**v,k:nv}
            if score(w)>=score(v):continue
            if any(r.deficit(w)>1e-7*max(1,abs(r.minimum)) for r in rules(kind,w,options)):continue
            if validator is not None:
                try:validator(w)
                except (ValueError,RuntimeError,TypeError,OverflowError):continue
            v=w;improved=True
        if not improved:break
    return v


def _linear_interval_conflict(kind, original, options, bounds, locked, passes=8):
    """Conservative infeasibility certificate for the encoded linear rows.

    The interval hull includes the original manual value even when outside
    automatic repair bounds. Propagation only shrinks that outer relaxation;
    an empty interval therefore excludes all repair candidates. No nonlinear
    rows or external validators are used to assert infeasibility.
    """
    if kind not in ('hinge','ball','rotary','central','central_pair'):
        return None
    adjustable=set(bounds)-set(locked)
    if not adjustable:return None  # existing immediate failure path
    # These fields enter rule constants; never freeze an adjustable constant.
    if any(k.rsplit('.',1)[-1] in ('minimum_radial_wall','minimum_cap_wall','radial_wall','cap_wall') for k in adjustable):
        return None
    intervals={k:(x,x) for k,x in original.items()}
    for k in adjustable:
        lo,hi=bounds[k];x=original[k]
        if not (isfinite(lo) and isfinite(hi) and lo<=hi):return None
        # The solver permits a tiny tolerance and an unchanged manual value.
        intervals[k]=(min(lo,x)-1e-8,max(hi,x)+1e-8)
    rows=rules(kind,original,options)
    if not all(isfinite(r.minimum) and all(isfinite(c) for c in r.terms.values()) for r in rows):return None
    for _ in range(passes):
        changed=False
        for r in rows:
            terms=[(k,c) for k,c in r.terms.items() if c!=0.]
            maxima=[c*intervals[k][1 if c>0 else 0] for k,c in terms]
            if not all(isfinite(x) for x in maxima):return None
            try:
                maximum=fsum(maxima)
                magnitude=fsum(abs(x) for x in maxima)
            except OverflowError:return None
            # At least the acceptance tolerance, plus a scale-aware roundoff
            # margin. Never prove infeasibility at a numerical boundary.
            slack=1e-7*max(1.,abs(r.minimum))+1e-10*max(1.,abs(r.minimum),magnitude)
            threshold=r.minimum-slack
            if maximum<threshold:return r.name
            for i,(k,c) in enumerate(terms):
                if k not in adjustable:continue
                others=fsum(maxima[:i]+maxima[i+1:])
                edge=(threshold-others)/c
                if not isfinite(edge):continue
                lo,hi=intervals[k]
                # Outward rounding of the inferred endpoint.
                pad=1e-10*max(1.,abs(edge))
                new=(max(lo,edge-pad),hi) if c>0 else (lo,min(hi,edge+pad))
                if new[0]>new[1]:return r.name
                if new!=intervals[k]:intervals[k]=new;changed=True
        if not changed:break
    return None


def repair(kind,values,options,bounds,locked=(),edited=None,limit=768,validator=None,preferred=()):
    original=dict(values); keys=tuple(bounds); locked=set(locked); preferred=set(preferred)
    if not all(isfinite(x) for x in original.values()):return Result(original,False,'有限の数値を指定してください',0)
    adjustable=[k for k in keys if k not in locked]
    conflict=_linear_interval_conflict(kind,original,options,bounds,locked)
    if conflict is not None:
        return Result(original,False,conflict+'：固定条件と補正許容範囲では数値制約が成立しません',0)
    def score(v):
        diff=[k for k in keys if abs(v[k]-original[k])>1e-7]
        return (int(edited in diff),len(preferred.intersection(diff)),len(diff),sum(abs(v[k]-original[k])/max(abs(original[k]),1.) for k in diff))
    heap=[];serial=count();seen=set();heappush(heap,(score(original),next(serial),original));n=0;first=''
    while heap and n<limit:
        _,_,v=heappop(heap);token=tuple(round(v[k],7) for k in keys)
        if token in seen:continue
        seen.add(token);n+=1
        checks=rules(kind,v,options)
        for k,(lo,hi) in bounds.items():
            # Existing manual values outside repair bounds may remain, but a
            # candidate must never newly cross a repair bound.
            if abs(v[k]-original[k])>1e-8:
                checks.extend((Rule('補正許容下限',{k:1},lo),Rule('補正許容上限',{k:-1},-hi)))
        bad=next((r for r in checks if r.deficit(v)>1e-7*max(1,abs(r.minimum))),None)
        if bad is None:
            if validator is not None:
                try:validator(v)
                except (ValueError,RuntimeError,TypeError,OverflowError) as exc:
                    if not first:first=str(exc)
                    continue
            return Result(_polish_linear(kind,v,original,options,bounds,locked,score,validator),True,'寸法条件成立',n)
        if not first:first=bad.name
        proposals={k:v[k]+bad.deficit(v)/bad.terms[k] for k in adjustable if abs(bad.terms.get(k,0.))>1e-14}
        # Angular inequalities are nonlinear in clearance/diameter. Invert
        # asin exactly for alternative moves instead of freezing their values.
        if kind=='swap' and bad.name in ('固定角と爪の保持代','隣接する爪溝との離隔','爪角幅と固定角の成立範囲'):
            if bad.name=='固定角と爪の保持代':
                angle=v['lock_angle']-v['lug_angle']-1-EPS*2
            elif bad.name=='隣接する爪溝との離隔':
                angle=(360/options['lug_count']-2-v['lock_angle']-v['lug_angle'])/2-1-EPS*2
            else:
                angle=(360/options['lug_count']-2-2*v['lug_angle'])/3-1-EPS*2
            if 0<angle<90:
                q=sin(radians(angle))
                proposals.update(radial_clearance=v['diameter']*q/2,diameter=2*v['radial_clearance']/q)
        for k,nv in proposals.items():
            if k not in adjustable:continue
            lo,hi=bounds[k];nv=min(hi,max(lo,nv))
            if abs(nv-v[k])<1e-8:continue
            w={**v,k:nv};heappush(heap,(score(w),next(serial),w))
    return Result(original,False,first+'：探索した候補では解が見つかりません（成立不能の証明ではありません）' if not heap else first+'：探索上限に到達',n)
