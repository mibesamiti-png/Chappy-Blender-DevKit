"""Shared UI only; the bundled engines retain their geometry and RNA IDs."""
import bpy
from bpy.types import Operator, Panel, PropertyGroup
from bpy.props import EnumProperty, StringProperty, BoolProperty, FloatProperty
from pathlib import Path

CATEGORY = 'Joint Maker'
ROOT = 'VIEW3D_PT_cjm_root'
# template_icon uses actual preview scale; operator icons remain standard-size.
ICON_SIZES = {'SMALL': (0.0, 0.0), 'MEDIUM': (2.2, 0.30), 'LARGE': (3.2, 0.38)}
MODES = (('BALL','ボールジョイント','多方向可動'),('ROTARY','回転ジョイント','A-B / 肩付き軸'),('HINGE','通常ヒンジ','ABA / BAB'),('TRUNNION','側面直付け軸','左右ピン・複合関節'),('SWAP','着脱ジョイント','差し込み・回転固定'),('DOUBLE','二重関節','上下2軸・3部品'))
FACE_INFO = {
 'axis':('回転軸','3Dカーソルを通るワールド軸'), 'reverse_axis':('軸方向反転','軸の正負を入れ替える'),
 'axle_diameter':('一体軸径','回転する細い軸の直径'), 'outer_diameter':('ナックル外径','ヒンジ外周の直径'),
 'a_width':('Aナックル長','受け側の軸方向長さ'), 'b_width':('Bナックル長','軸側の軸方向長さ'),
 'radial_clearance':('軸穴クリアランス','軸と穴の片側の隙間'), 'axial_gap':('軸方向の隙間','A/B端面の隙間（直付けでは穴入口余裕）'),
 'cap_wall':('最低閉鎖壁厚','止まり穴の奥に残す壁'), 'radial_wall':('最低外周肉厚','穴と外周の間の壁'),
 'tip_clearance':('軸先端クリアランス','軸端と穴底の隙間'), 'shoulder_enabled':('肩付き軸','太い頭を受け内部に収納する抜け止め'),
 'shoulder_diameter':('返し頭の直径','受けの入口より大きい頭の直径'), 'shoulder_thickness':('返し頭の厚み','頭の軸方向長さ'),
 'shoulder_radial_clearance':('頭の半径方向隙間','頭の外周と収納穴の片側隙間'), 'shoulder_axial_clearance':('頭の軸方向隙間','頭の端面と収納穴の隙間'),
 'pin_projection':('軸突出長','ソケット外面からピン先端まで'), 'pin_embed':('軸埋め込み長','ソケット外面より内側に入る長さ'),
 'support_width':('支持腕の幅','回転軸を腕の長手に直交投影した方向。ナックル長の85%が上限'), 'support_thickness':('支持腕の厚み','回転軸と腕の長手の両方に直交する方向'), 'embed_depth':('本体への埋め込み','選択面の法線と逆方向に、腕の始点を本体内へ移動'),
 'minimum_angle':('最小角','回転逃げを作る負側の境界'), 'maximum_angle':('最大角','回転逃げを作る正側の境界'),
 'angle_step':('Booleanサンプル間隔','回転逃げの角度刻み'), 'swing_clearance':('回転逃げクリアランス','掃引領域に加える余裕'), 'preview_angle':('表示角度','ワイヤー上の回転姿勢（実体は動かさない）'),
}
_ICONS = None
_ICON_ERROR = ''

def state(scene):
    return getattr(scene,'cjm_settings',None)

def visible(context, mode, section=None):
    s=state(getattr(context,'scene',None))
    return bool(s and s.mode==mode and (section is None or s.ball_section==section))

def engine_visible(context, engine):
    s=state(getattr(context,'scene',None))
    if s is None: return False
    return {'ball':s.mode=='BALL','hinge':s.mode=='HINGE','face':s.mode in ('ROTARY','TRUNNION'),'swap':s.mode=='SWAP','double':s.mode=='DOUBLE'}[engine]

def redraw(context):
    for area in getattr(getattr(context,'screen',None),'areas',()):
        if area.type=='VIEW_3D': area.tag_redraw()

def live_off(scene):
    for name,prop in [('ball_joint_settings','live_guide_enabled'),('hinge_maker_settings','guide_enabled'),('face_hinge_settings','live_enabled'),('cjm_swap','live_enabled'),('cjm_double','live_enabled')]:
        s=getattr(scene,name,None)
        if s is not None: setattr(s,prop,False)

def clear_part_previews():
    """Clear only the preview collections owned by the bundled engines."""
    from . import ball_joint, hinge_maker
    from .hinge_maker import face_hinge
    ball_joint.clear_joint_preview()
    ball_joint.clear_body_receiver_preview()
    hinge_maker.clear_preview()
    face_hinge._preview_clear()


def face_mode_mismatch(scene, mode):
    f=getattr(scene,'face_hinge_settings',None)
    return bool(f is not None and mode in ('ROTARY','TRUNNION') and
                f.mode != ('STRAIGHT' if mode=='ROTARY' else 'TRUNNION'))


def constraint_capture(self,context):
    from . import constraints
    constraints.capture(context)

def constraint_active(context,engine):
    from . import constraints
    return constraints.active(context,engine)

def switch(self,context):
    scene=getattr(context,'scene',None)
    if scene is None: return
    live_off(scene)
    clear_part_previews()
    if self.mode=='BALL':
        b=getattr(scene,'ball_joint_settings',None)
        if b is not None and self.ball_section=='GENERATE': b.live_view_mode='JOINT'
        elif b is not None and b.live_view_mode=='JOINT': b.live_view_mode='MOUNT'
    f=getattr(scene,'face_hinge_settings',None)
    if f is not None and self.mode in ('ROTARY','TRUNNION'):
        f.mode='STRAIGHT' if self.mode=='ROTARY' else 'TRUNNION'
        self.face_focus='axle_diameter'
    constraint_capture(self,context)
    redraw(context)

def section_switch(self,context):
    scene=getattr(context,'scene',None)
    if scene is not None:
        live_off(scene)
        clear_part_previews()
        b=getattr(scene,'ball_joint_settings',None)
        if b is not None and self.mode=='BALL': b.live_view_mode='JOINT' if self.ball_section=='GENERATE' else 'MOUNT'
    redraw(context)

class CJM_Settings(PropertyGroup):
    auto_constraints: BoolProperty(name="寸法の自動補正",default=False,options={"SKIP_SAVE"},update=constraint_capture)
    constraint_clearance_floor: FloatProperty(name="自動補正の隙間下限",description="自動で隙間を縮める際の下限。すでに手動指定した小さい正値は維持。内部寸法単位",default=.4,min=.0001,precision=4)
    constraint_ball_retention: BoolProperty(name="球の抜け止めを維持",description="開口径を球径未満に保つ。可動切欠き全体の保持は別途確認",default=True)
    debug_enabled: BoolProperty(name="デバッグモード",default=False,options={"SKIP_SAVE"})
    mode: EnumProperty(name='機構',items=MODES,default='BALL',update=switch)
    ball_section: EnumProperty(name='操作',items=[('GENERATE','単体生成','通常の球関節'),('MOUNT','本体取付・分割','取付・本体受け・任意分割')],default='GENERATE',update=section_switch)
    rotary_section: EnumProperty(name='操作',items=[('FACE','面から支持腕','従来のA-B'),('SOLO','単体生成','面登録なし'),('ATTACH','直接取付','A/Bに直接結合')],default='FACE',update=section_switch)
    icon_size: EnumProperty(name='寸法アイコン',items=[('SMALL','小','従来のコンパクト表示'),('MEDIUM','中','拡大した寸法イラスト'),('LARGE','大','さらに大きい寸法イラスト')],default='MEDIUM',update=lambda self,context:redraw(context))
    show_diagram: BoolProperty(name='寸法説明図',default=True)
    face_focus: StringProperty(default='axle_diameter')
    face_view: EnumProperty(name='3D表示',items=[('ALL','全体','基本の形状'),('FOCUS','注目','選んだ種類の形状・警告を優先表示'),('DEBUG','デバッグ','掃引・取付面・方向も表示')],default='ALL',update=lambda self,context:redraw(context))

SWAP_INFO = {
 'axis':('着脱軸','3Dカーソルを通る軸。正方向が引き抜き方向'),
 'diameter':('差込軸径','爪を含まない軸本体の直径'),
 'depth':('差込穴の深さ','受け入口から穴底までの距離'),
 'lug_count':('爪数','周方向に等間隔で配置する爪の個数'),
 'lug_height':('爪の高さ','爪の軸方向の長さ'),
 'lug_projection':('爪の突出量','軸外周から爪先までの半径方向距離'),
 'lug_angle':('爪の角幅','軸中心から見た爪の周方向角度'),
 'lock_angle':('固定角度','入口溝から固定位置までの回転角度'),
 'direction':('固定方向','引き抜く側から見た固定時の回転方向'),
 'radial_clearance':('半径方向隙間','軸・爪と受け穴の片側の隙間'),
 'axial_clearance':('軸方向隙間','爪溝の上下と受け入口側の余裕'),
 'wall':('受けの外壁・底厚','回転溝外周と受け底に残す厚さ'),
 'flange':('取付台座厚','軸の根元にある台座の軸方向長さ'),
}

CENTRAL_INFO={**FACE_INFO,
 'a_width':('左右受け長（片側）','中央溝の端から各受けの外側までの距離。A/Cは既存本体を削るだけ'),
 'b_width':('中央ナックル長','B側の中央円筒の軸方向長さ'),
 'cap_wall':('左右閉鎖壁厚','ピン穴の奥に残す壁厚（両側）'),
 'radial_wall':('最低軸受け肉厚','ピン穴外周から残すべき最小肉厚'),
 'support_width':('B支持腕の幅','中央Bだけから伸びる腕の幅'),
 'support_thickness':('B支持腕の厚み','B支持腕の回転面内の厚み'),
 'embed_depth':('Bへの埋め込み','Bの選択面から内側へ支持腕を埋め込む深さ'),
 'swing_clearance':('支持腕・ナックル逃げ','支持腕の掃引と中央溝の隙間。本体外形は角度サンプルで切削'),
 'tip_clearance':('ピン先端隙間','左右のピン先端と穴底の距離'),
 'axial_gap':('中央溝の片側隙間','B中央ナックル端とA/C受けの隙間（左右）'),
}

def swap_changed(prop):
    def update(self,context):
        self.live_focus=prop
        redraw(context)
    return update

def face_changed(prop):
    def update(self,context):
        st=state(getattr(context,'scene',None))
        if st is not None: st.face_focus=prop
        redraw(context)
    return update

def icon_id(key):
    try: return _ICONS[key].icon_id if _ICONS is not None else 0
    except (KeyError,ReferenceError): return 0

def load_icons():
    global _ICONS,_ICON_ERROR
    try:
        import bpy.utils.previews
        _ICONS=bpy.utils.previews.new()
        for path in sorted((Path(__file__).parent/'icons').glob('*.png')):
            _ICONS.load(path.stem,str(path),'IMAGE')
    except Exception as exc:
        _ICON_ERROR=str(exc)
        print('CJM icons:',exc)

def unload_icons():
    global _ICONS
    if _ICONS is not None:
        import bpy.utils.previews
        bpy.utils.previews.remove(_ICONS)
        _ICONS=None

def icon_kwargs(key,fallback='INFO'):
    i=icon_id(key)
    return {'icon_value':i} if i else {'icon':fallback}

class CJM_OT_select(Operator):
    bl_idname='cjm.select_mechanism'
    bl_label='機構を選択'
    mode: StringProperty()
    def execute(self,context):
        if self.mode not in {m[0] for m in MODES}: return {'CANCELLED'}
        st=context.scene.cjm_settings
        if st.mode != self.mode:
            st.mode=self.mode
        elif face_mode_mismatch(context.scene, self.mode):
            switch(st,context)
        return {'FINISHED'}

class CJM_OT_focus(Operator):
    bl_idname='cjm.focus_dimension'
    bl_label='寸法説明図で確認'
    bl_description='設定箇所を断面図で強調します。目のボタン以外ではLIVEをONにしません'
    engine: StringProperty()
    key: StringProperty()
    view: StringProperty(default='')
    live: BoolProperty(default=False)
    def execute(self,context):
        from . import ball_joint, hinge_maker
        scene=context.scene; st=scene.cjm_settings
        if self.engine not in ('ball','hinge','face','swap','double') or not engine_visible(context,self.engine):
            return {'CANCELLED'}
        if self.engine=='ball':
            if self.key not in ball_joint._BJ_FOCUS_INFO: return {'CANCELLED'}
            s=scene.ball_joint_settings; s.live_focus=self.key
            if self.view in ('JOINT','MOUNT','BODY'): s.live_view_mode=self.view
            if self.live: s.live_guide_enabled=True
        elif self.engine=='hinge':
            if self.key not in hinge_maker.FOCUS_INFO: return {'CANCELLED'}
            s=scene.hinge_maker_settings; s.guide_focus=self.key
            if self.live: s.guide_enabled=True
        elif self.engine=='face':
            if self.key not in FACE_INFO: return {'CANCELLED'}
            st.face_focus=self.key
            if self.live: scene.face_hinge_settings.live_enabled=True
        elif self.engine=='swap':
            if self.key not in SWAP_INFO: return {'CANCELLED'}
            s=scene.cjm_swap; s.live_focus=self.key
            if self.live: s.live_enabled=True
        elif self.engine=='double':
            if self.key not in FACE_INFO or self.view not in ('UPPER','LOWER'):return {'CANCELLED'}
            d=scene.cjm_double;d.active_joint=self.view;j=d.upper if self.view=='UPPER' else d.lower;j.live_focus=self.key
            if self.live:d.live_enabled=True
        else: return {'CANCELLED'}
        st.show_diagram=True
        redraw(context)
        return {'FINISHED'}

def constraint_update(engine,prop,original):
    def update(self,context):
        original(self,context)
        from . import constraints
        constraints.changed(self,context,engine,prop)
    return update


def focus_row(layout,s,prop,engine,key,view='',**kwargs):
    st=state(getattr(bpy.context,'scene',None))
    prefix=st.mode.lower() if engine=='face' and st else engine
    if engine=='double':prefix='central' if bpy.context.scene.cjm_double.design=='CENTRAL' else 'rotary'
    if prefix=='rotary' and not s.shoulder_enabled and not key.startswith('shoulder_'): prefix='rotary_plain'
    ident=icon_id(prefix+'_'+key)
    if engine=='ball':
        active=getattr(s,'live_focus','')==key and (not view or getattr(s,'live_view_mode','')==view)
        is_live=getattr(s,'live_guide_enabled',False)
    elif engine=='hinge':
        active=getattr(s,'guide_focus','')==key; is_live=getattr(s,'guide_enabled',False)
    elif engine=='swap':
        active=s.live_focus==key; is_live=s.live_enabled
    elif engine=='double':
        d=bpy.context.scene.cjm_double;active=d.active_joint==view and s.live_focus==key;is_live=d.live_enabled
    else:
        active=bool(st and st.face_focus==key); is_live=getattr(s,'live_enabled',False)
    size=getattr(st,'icon_size','MEDIUM')
    scale,factor=ICON_SIZES.get(size,ICON_SIZES['MEDIUM'])
    if scale and ident:
        # Native template_icon enlarges the actual image, not just button height.
        # Keep a separate clickable diagram button: template_icon is display-only.
        row=layout.row(align=True)
        split=row.split(factor=factor,align=True)
        preview=split.column(align=True)
        preview.template_icon(icon_value=ident,scale=scale)
        body=split.column(align=True)
        body.prop(s,prop,**kwargs)
        controls=body.row(align=True)
        op=controls.operator('cjm.focus_dimension',text='説明図',icon='IMAGE_DATA',depress=active)
    else:
        row=layout.row(align=True)
        op=row.operator('cjm.focus_dimension',text='',**icon_kwargs(prefix+'_'+key,'DRIVER_DISTANCE'),depress=active)
        row.prop(s,prop,**kwargs)
        controls=row
    op.engine=engine; op.key=key; op.view=view; op.live=False
    eye=controls.operator('cjm.focus_dimension',text='',icon='HIDE_OFF' if is_live and active else 'HIDE_ON',depress=bool(is_live and active))
    eye.engine=engine; eye.key=key; eye.view=view; eye.live=True
    if st and st.auto_constraints:
        from . import constraints
        constraints.lock_button(controls,bpy.context,engine,view,prop,s)
    return row

def face_prop(layout,s,prop,**kwargs):
    return focus_row(layout,s,prop,'face',prop,**kwargs)

class VIEW3D_PT_cjm_root(Panel):
    bl_idname=ROOT
    bl_label='Chappy Joint Maker v0.2.9'
    bl_space_type='VIEW_3D'; bl_region_type='UI'; bl_category=CATEGORY
    def draw(self,context):
        from . import ball_joint, hinge_maker
        l=self.layout; scene=context.scene; s=scene.cjm_settings
        grid=l.column(align=True)
        for i in range(0,len(MODES),2):
            row=grid.row(align=True); row.scale_y=1.4
            for mode,label,_ in MODES[i:i+2]:
                cell=row.column(align=True)
                ident=icon_id('mode_'+mode)
                if ident: cell.template_icon(icon_value=ident,scale=3.5)
                op=cell.operator('cjm.select_mechanism',text=label, depress=s.mode==mode,**icon_kwargs('mode_'+mode,'MOD_SCREW'))
                op.mode=mode
        l.label(text=next(m[2] for m in MODES if m[0]==s.mode),icon='INFO')
        l.label(text='タグ: 自作アドオン',icon='BOOKMARKS')
        l.label(text='寸法アイコンサイズ')
        l.prop(s,'icon_size',expand=True)
        from . import constraints
        constraints.panel(l,context)
        if s.mode=='DOUBLE':
            d=scene.cjm_double; j=d.upper if d.active_joint=='UPPER' else d.lower
            row=l.row(align=True);row.prop(s,'show_diagram',text='寸法説明図',icon='IMAGE_DATA');row.prop(d,'live_enabled',icon='HIDE_OFF')
            l.prop(d,'active_joint',expand=True)
            if d.live_enabled:l.prop(s,'face_view',expand=True)
            if s.show_diagram:
                box=l.box();info=CENTRAL_INFO if d.design=='CENTRAL' else FACE_INFO;title,detail=info.get(j.live_focus,('二重関節','上側・下側を個別設定'))
                box.label(text=title);prefix='central' if d.design=='CENTRAL' else ('rotary' if j.shoulder_enabled else 'rotary_plain');ident=icon_id(prefix+'_'+j.live_focus) or icon_id('mode_DOUBLE')
                if ident:box.template_icon(icon_value=ident,scale=7.)
                for i in range(0,len(detail),24):box.label(text=detail[i:i+24])
            return
        if s.mode=='SWAP':
            sw=scene.cjm_swap; row=l.row(align=True)
            row.prop(s,'show_diagram',text='寸法説明図',icon='IMAGE_DATA')
            row.prop(sw,'live_enabled',text='3D LIVE',icon='HIDE_OFF')
            if sw.live_enabled:l.prop(s,'face_view',expand=True)
            if s.show_diagram:
                b=l.box(); title,detail=SWAP_INFO.get(sw.live_focus,('全体構造','設定アイコンで対象を選択'))
                b.label(text=title,icon='DRIVER_DISTANCE')
                ident=icon_id('swap_'+sw.live_focus) or icon_id('mode_SWAP')
                if ident:b.template_icon(icon_value=ident,scale=7.0)
                for i in range(0,len(detail),24):b.label(text=detail[i:i+24])
                b.label(text='模式図（実寸形状ではありません）')
            return
        if s.mode=='BALL': l.prop(s,'ball_section',expand=True)
        if s.mode=='ROTARY': l.prop(s,'rotary_section',expand=True)
        if (s.mode=='BALL' and s.ball_section=='MOUNT') or s.mode in ('HINGE','TRUNNION'):
            l.operator('cjm.register_targets',text='選択中の本体を登録',icon='EYEDROPPER')
            l.label(text='選択1体＝取付先' if s.mode=='BALL' else ('2体選択 / アクティブ=A' if s.mode=='HINGE' else '2体選択 / アクティブ=B'))
        if s.mode=='BALL':
            b=scene.ball_joint_settings; key=b.live_focus
            info=ball_joint._BJ_FOCUS_INFO; prefix='ball'; live=(b,'live_guide_enabled')
        elif s.mode=='HINGE':
            h=scene.hinge_maker_settings; key=h.guide_focus
            info=hinge_maker.FOCUS_INFO; prefix='hinge'; live=(h,'guide_enabled')
        else:
            key=s.face_focus; info=FACE_INFO; prefix=s.mode.lower(); live=(scene.face_hinge_settings,'live_enabled')
            if prefix=='rotary' and not live[0].shoulder_enabled and not key.startswith('shoulder_'): prefix='rotary_plain'
            if s.mode=='TRUNNION' and key=='axial_gap': info={**FACE_INFO,'axial_gap':('受け穴入口余裕','ソケット外面側へ受け穴を延長する量')}
        row=l.row(align=True); row.prop(s,'show_diagram',text='寸法説明図',icon='IMAGE_DATA')
        row.prop(live[0],live[1],text='3D LIVE',icon='HIDE_OFF')
        if live[0] and getattr(live[0],live[1],False):
            l.prop(s,'face_view',expand=True)
        if s.show_diagram:
            b=l.box(); title,detail=info.get(key,('全体構造','設定アイコンで対象を選択'))
            b.label(text=title,icon='DRIVER_DISTANCE')
            ident=icon_id(prefix+'_'+key) or icon_id('mode_'+s.mode)
            if ident: b.template_icon(icon_value=ident,scale=7.0)
            # Blender does not wrap labels automatically; split Japanese text.
            for i in range(0,len(detail),24): b.label(text=detail[i:i+24])
            b.label(text='模式図（実寸形状ではありません）')
            if _ICON_ERROR: b.label(text='画像読込失敗: '+_ICON_ERROR[:32],icon='ERROR')

from . import debug_fixtures
CLASSES=(CJM_Settings,CJM_OT_select,CJM_OT_focus,VIEW3D_PT_cjm_root,*debug_fixtures.CLASSES)
