"""Bounded comparison of historical hypotheses, never a commit or a proof of validity."""
from dataclasses import dataclass, asdict
import json
from . import shape_trials as trials, shape_candidates as candidates

MAX_CANDIDATES=3

@dataclass(frozen=True)
class Comparison:
    status: str
    measured: float | None = None
    threshold: float | None = None
    message: str = ''
    code: str = ''


def classify(base, outcome):
    if outcome.status=='PASS':return Comparison('PASS',message='生成時検査通過（未適用）')
    if outcome.status!='FAILED' or outcome.diagnostic is None:
        return Comparison('ERROR',message=outcome.message)
    d=outcome.diagnostic
    if d.code in ('OPERATION_FAILED','INPUT'):
        return Comparison('ERROR',message='原因未確定または入力エラー：比較中止',code=d.code)
    result=dict(measured=d.measured,threshold=d.threshold,code=d.code)
    if not trials.matches(base,d) or not base.unit or base.unit!=d.unit:
        return Comparison('DIFFERENT',**result,message='別の失敗・比較不可')
    if any(v is None for v in (base.measured,base.threshold,d.measured,d.threshold)) or not (base.measured>base.threshold>=0 and d.measured>d.threshold>=0):
        return Comparison('UNCOMPARABLE',**result,message='測定情報不足・比較不可')
    # Both raw measured volume and excess above the generator threshold must agree.
    # A changed threshold alone is not evidence of physical improvement.
    def direction(a,b):
        tol=max(1e-15,1e-6*max(abs(a),abs(b)))
        return -1 if b<a-tol else 1 if b>a+tol else 0
    raw=direction(base.measured,d.measured)
    excess=direction(base.measured-base.threshold,d.measured-d.threshold)
    if raw==excess==-1:status,msg='IMPROVED','同一失敗の不足・交差体積が減少（未解決）'
    elif raw==excess==1:status,msg='WORSE','同一失敗の不足・交差体積が増加'
    elif raw==excess==0:status,msg='UNCHANGED','測定値に有意な差なし'
    else:status,msg='MIXED','測定値と判定超過量の変化が一致しない'
    return Comparison(status,**result,message=msg)


def run(expected,base,items,attempt,check=lambda:None,*,require_first_pass=False):
    """One fresh baseline, at most three independent candidates. Stop on error.
    Exceptions (including cleanup errors) propagate; callers discard results.
    """
    if not 1<=len(items)<=MAX_CANDIDATES or (require_first_pass and len(items)<2):raise ValueError('候補数が範囲外です')
    check();original=attempt(base);check()
    if original.status=='ERROR':return {'status':'ERROR','message':original.message,'rows':[]}
    if original.status!='FAILED' or original.diagnostic is None or not trials.matches(expected,original.diagnostic):
        return {'status':'STALE','message':'現在の形状で同じ失敗を再現できません','rows':[]}
    actual=original.diagnostic;rows=[];status='DONE'
    for item,proxy in items:
        check();out=attempt(proxy);check();result=classify(actual,out)
        rows.append({'item':item,'result':asdict(result)})
        if result.status=='ERROR':status='ERROR';break
        if require_first_pass and len(rows)==1 and result.status!='PASS':status='STALE';break
    # Only completed comparisons can recommend a passing candidate. Numeric preference, not geometry quality.
    passed=[i for i,r in enumerate(rows) if r['result']['status']=='PASS']
    def preference(i):
        changes=candidates.components(rows[i]['item'])
        return (sum(c['policy']=='PREFERRED' for c in changes),sum(abs(c['after']-c['before'])/max(abs(c['before']),1e-15) for c in changes),i)
    preferred=min(passed,key=preference) if status=='DONE' and passed else None
    return {'preferred':preferred,'status':status,'message':{'DONE':'比較完了（未適用）','ERROR':'処理エラーで比較中止','STALE':'成功候補を再現できないため中止'}[status],
            'baseline':asdict(actual),'rows':rows}


def encode(advice,record):
    return json.dumps({'advice':advice,'record':record},ensure_ascii=False,allow_nan=False)


def display(payload,advice):
    if not payload or not advice:return None
    r=json.loads(payload)
    return r['record'] if r['advice']==advice else None
