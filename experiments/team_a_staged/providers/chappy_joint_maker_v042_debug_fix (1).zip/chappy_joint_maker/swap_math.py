"""JOINT-SWAP-001: independent, closed polar-cell meshes for twist locks.
Local +Z is the removal direction; z=0 is the socket mouth.
"""
from dataclasses import dataclass
import math

@dataclass(frozen=True)
class Spec:
    diameter: float=10.
    depth: float=6.
    lug_height: float=1.5
    lug_projection: float=1.5
    lug_angle: float=24.
    lock_angle: float=45.
    radial_clearance: float=.4
    axial_clearance: float=.4
    wall: float=2.
    flange: float=2.
    lug_count: int=2
    direction: int=1

@dataclass(frozen=True)
class Plan:
    spec: Spec
    r: float
    lug_r: float
    bore: float
    track: float
    outer: float
    tip: float
    lug_low: float
    lug_high: float
    channel_low: float
    channel_high: float
    half: float
    pad: float
    pitch: float


def plan(s):
    nums=[s.diameter,s.depth,s.lug_height,s.lug_projection,s.lug_angle,s.lock_angle,s.radial_clearance,s.axial_clearance,s.wall,s.flange]
    if not all(math.isfinite(x) and x>0 for x in nums):raise ValueError('寸法は有限の正数にしてください')
    if s.lug_count not in (2,3,4) or s.direction not in (-1,1):raise ValueError('爪数または方向が不正')
    r=s.diameter/2; lug_r=r+s.lug_projection;bore=r+s.radial_clearance;track=lug_r+s.radial_clearance
    if s.lug_projection<=s.radial_clearance:raise ValueError('爪の突出量を半径隙間より大きくしてください')
    if s.radial_clearance>=r*.5:raise ValueError('半径隙間が大きすぎます')
    if s.wall<.2 or s.flange<.2:raise ValueError('壁・台座は0.2以上にしてください')
    if s.lug_angle<4 or s.lock_angle>150:raise ValueError('爪角度または固定角度が範囲外')
    pitch=360/s.lug_count;half=s.lug_angle/2
    # Angular clearance at the smallest relevant radius, plus polygon margin.
    pad=math.degrees(math.asin(s.radial_clearance/r))+1.
    if s.lock_angle<=2*half+pad:raise ValueError('固定角度が小さく、爪全体が抜き溝から外れません')
    if s.lock_angle+2*(half+pad)>=pitch-2:raise ValueError('隣の爪溝と干渉します：角度または爪数を減らしてください')
    tip=-s.depth+s.axial_clearance; low=tip+max(.5,s.axial_clearance); high=low+s.lug_height
    cl=low-s.axial_clearance;ch=high+s.axial_clearance
    if ch>=-max(.5,s.wall*.5):raise ValueError('差込深さ不足：爪の上に保持壁を残してください')
    if cl<=-s.depth:raise ValueError('爪溝の底位置が不正')
    # keep radial clearance larger than polygon sagitta (<= 2-degree sectors).
    if s.radial_clearance<=track*(1-math.cos(math.radians(1))):raise ValueError('隙間がメッシュ分解能より小さすぎます')
    return Plan(s,r,lug_r,bore,track,track+s.wall,tip,low,high,cl,ch,half,pad,pitch)


def signed_phase(angle,p):
    return (angle*p.spec.direction+p.pitch/2)%p.pitch-p.pitch/2


def in_slot(angle,p,sweep):
    # Check periodic intervals without the +/- pitch/2 discontinuity.
    x=(angle*p.spec.direction+p.half+p.pad)%p.pitch
    return x < 2*(p.half+p.pad)+(p.spec.lock_angle if sweep else 0)


def angles(p):
    # Shared exact angular breakpoints, then subdivide into <= 2 degree sectors.
    bounds={0.,360.}
    for i in range(p.spec.lug_count):
        for a in (-p.half,p.half,-p.half-p.pad,p.half+p.pad,p.spec.lock_angle+p.half+p.pad):
            bounds.add(round((i*p.pitch+p.spec.direction*a)%360,10))
    base=sorted(bounds);out=[]
    for a,b in zip(base,base[1:]):
        if b-a<1e-8:continue
        n=math.ceil((b-a)/2)
        out.extend(a+(b-a)*i/n for i in range(n))
    return out+[360.]


def mesh_cells(rs,zs,aa,occupied):
    """Boundary of occupied annular prism cells. Central faces collapse to triangles."""
    na=len(aa)-1; nr=len(rs)-1;nz=len(zs)-1
    cells={(i,j,k) for i in range(nr) for j in range(na) for k in range(nz) if occupied(i,(aa[j]+aa[j+1])/2,k)}
    verts=[];faces=[];idx={}
    def vertex(i,j,k):
        j=j%na if i else 0; key=i,j,k
        if key not in idx:
            a=math.radians(aa[j]);idx[key]=len(verts);verts.append((rs[i]*math.cos(a),rs[i]*math.sin(a),zs[k]))
        return idx[key]
    for i,j,k in sorted(cells):
        # Cell winding: radial then angular then +Z gives outward faces.
        v=[(i,j,k),(i+1,j,k),(i+1,j+1,k),(i,j+1,k),(i,j,k+1),(i+1,j,k+1),(i+1,j+1,k+1),(i,j+1,k+1)]
        for d,f in [((0,0,-1),(0,3,2,1)),((0,0,1),(4,5,6,7)),((0,-1,0),(0,1,5,4)),((1,0,0),(1,2,6,5)),((0,1,0),(2,3,7,6)),((-1,0,0),(3,0,4,7))]:
            ni,nj,nk=i+d[0],(j+d[1])%na,k+d[2]
            if (ni,nj,nk) in cells:continue
            face=tuple(dict.fromkeys(vertex(*v[n]) for n in f))
            if len(face)>=3:faces.append(face)
    return verts,faces


def male_mesh(p):
    s=p.spec;rs=[0.,p.r,p.lug_r,p.outer];zs=[p.tip,p.lug_low,p.lug_high,s.axial_clearance,s.axial_clearance+s.flange]
    return mesh_cells(rs,zs,angles(p),lambda i,a,k:k==3 or i==0 or (i==1 and k==1 and abs(signed_phase(a,p))<p.half))


def female_mesh(p,cutter=False):
    s=p.spec;rs=[0.,p.bore,p.track,p.outer]
    zs=[-s.depth-s.wall,-s.depth,p.channel_low,p.channel_high,0.]
    if cutter:zs=zs[1:]+[max(.5,s.axial_clearance)]
    def occ(i,a,k):
        z=(zs[k]+zs[k+1])/2
        if z< -s.depth:return not cutter
        void=i==0 or (i==1 and (p.channel_low<z<p.channel_high and in_slot(a,p,True) or z>=p.channel_high and in_slot(a,p,False)))
        # Above the mouth, only extend the insertion slots and the central bore.
        return void if cutter else not void
    return mesh_cells(rs,zs,angles(p),occ)


def spec_from(s):return Spec(**{name:getattr(s,name) for name in Spec.__dataclass_fields__ if name not in ('lug_count','direction')},lug_count=int(s.lug_count),direction=int(s.direction))
