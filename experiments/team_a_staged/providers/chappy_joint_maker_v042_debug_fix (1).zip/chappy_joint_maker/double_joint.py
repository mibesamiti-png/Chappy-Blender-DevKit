"""Two face-anchored hinges with a single shared central part."""
import bpy,bmesh
from bpy.types import Operator,Panel,PropertyGroup
from bpy.props import PointerProperty,FloatProperty,FloatVectorProperty,IntProperty,StringProperty,BoolProperty,EnumProperty
from mathutils import Vector,Matrix
from types import SimpleNamespace as NS
from . import ui,double_math as dm,central_joint as cj,shape_diagnostics as diag,shape_candidates as candidates,shape_trials as trials,shape_comparison as comparison,shape_apply as adoption
from .hinge_maker import face_hinge as fh
from .geometry_ops import solid,intersect_volume,stage
from .common_tools import restore_selection,selected_meshes

# Defaults deliberately use the tested shoulder fixture dimensions, not the old
# 4-unit outer diameter (too narrow for the default captured head).
FIELDS={
 'outer_diameter':(5.,.2,'ナックル外径'), 'axle_diameter':(2.,.1,'軸径'),
 'a_width':(3.5,.1,'受けナックル長'), 'b_width':(3.5,.1,'軸ナックル長'),
 'radial_clearance':(.4,0.,'軸穴片側隙間'), 'axial_gap':(.4,0.,'軸方向隙間'),
 'cap_wall':(.8,0.,'閉鎖壁厚'), 'radial_wall':(.35,0.,'最低外周肉厚'), 'tip_clearance':(.4,0.,'軸先端隙間'),
 'shoulder_diameter':(3.4,.2,'返し頭径'), 'shoulder_thickness':(.5,.05,'返し頭厚'),
 'shoulder_radial_clearance':(.4,.01,'頭の半径方向隙間'), 'shoulder_axial_clearance':(.35,.01,'頭の軸方向隙間'),
 'support_width':(1.8,.15,'支持腕の幅'), 'support_thickness':(2.2,.15,'支持腕の厚み'), 'embed_depth':(.5,.01,'埋め込み深さ'),
 'swing_clearance':(.4,0.,'回転逃げ隙間'), 'angle_step':(5.,.5,'角度刻み')}
AXES=[(a,a,'') for a in 'XYZ']
SLOTS=('a','bu','bl','c')

def redraw(self,context):ui.redraw(context)
def design_changed(self,context):
    self.live_enabled=False;ui.constraint_capture(self,context);ui.redraw(context)
def changed(key):
    def update(self,context):
        self.live_focus=key
        root=getattr(getattr(context,'scene',None),'cjm_double',None)
        if root is not None:
            if self.as_pointer()==root.upper.as_pointer():root.active_joint='UPPER'
            elif self.as_pointer()==root.lower.as_pointer():root.active_joint='LOWER'
        ui.redraw(context)
        if root is not None:
            from . import constraints
            side = "UPPER" if self.as_pointer()==root.upper.as_pointer() else "LOWER"
            constraints.changed(self,context,"double",key,side)
    return update

class CJM_DoubleSpec(PropertyGroup):
    __annotations__={k:FloatProperty(name=label,default=v,min=m,**({'max':30.} if k=='angle_step' else {}),update=changed(k)) for k,(v,m,label) in FIELDS.items()}
    shoulder_enabled:BoolProperty(name='肩付き軸（抜け止め）',default=True,update=changed('shoulder_enabled'))
    reverse_axis:BoolProperty(name='軸方向反転',default=False,update=changed('reverse_axis'))
    minimum_angle:FloatProperty(name='最小角度',default=0,min=-180,max=180,update=changed('minimum_angle'))
    maximum_angle:FloatProperty(name='最大角度',default=45,min=-180,max=180,update=changed('maximum_angle'))
    preview_angle:FloatProperty(name='表示角度',default=0,min=-180,max=180,update=changed('preview_angle'),options={'SKIP_SAVE'})
    pivot:FloatVectorProperty(name='軸中心（ワールド座標）',size=3,subtype='TRANSLATION',update=redraw)
    pivot_set:BoolProperty(default=False,update=redraw)
    live_focus:StringProperty(default='outer_diameter',options={'SKIP_SAVE'})

class CJM_DoubleSettings(PropertyGroup):
    design:EnumProperty(name="構造",items=[("CENTRAL","中央支持 ABA+CBC","Bだけに支持部・ピンを追加。A/Cは切削のみ"),("LEGACY","従来 AB+AB","従来の両側支持腕")],default="CENTRAL",update=design_changed)
    upper:PointerProperty(type=CJM_DoubleSpec)
    lower:PointerProperty(type=CJM_DoubleSpec)
    axis:EnumProperty(name='共通回転軸',items=AXES,default='X',update=redraw)
    live_enabled:BoolProperty(name='3D LIVE',default=False,options={'SKIP_SAVE'},update=redraw)
    active_joint:EnumProperty(items=[('UPPER','上側',''),('LOWER','下側','')],default='UPPER',update=redraw)
    hide_originals:BoolProperty(name='成功後に原本を非表示',default=True)
    status:StringProperty(default='',options={'SKIP_SAVE'})
    last_generation_diagnostic:StringProperty(default='',options={'SKIP_SAVE'})
    last_shape_candidates:StringProperty(default='',options={'SKIP_SAVE'})
    last_shape_comparison:StringProperty(default='',options={'SKIP_SAVE'})
    __annotations__={**locals().get('__annotations__',{}),**{k:PointerProperty(type=bpy.types.Object,name=label) for k,label in [('object_a','A：上部'),('object_b','B：中央'),('object_c','C：下部')]},**{f'face_{k}':IntProperty(default=-1) for k in SLOTS},**{f'signature_{k}':StringProperty(default='') for k in SLOTS}}

def slot_owner(slot):return 'b' if slot in ('bu','bl') else slot

def remember(s,slot,obj,index,signature=None):
    owner=slot_owner(slot);old=getattr(s,'object_'+owner)
    if old!=obj:
        for k in SLOTS:
            if slot_owner(k)==owner:setattr(s,'face_'+k,-1);setattr(s,'signature_'+k,'')
    setattr(s,'object_'+owner,obj);setattr(s,'face_'+slot,index)
    if signature is None:signature=','.join(str(v) for v in obj.data.polygons[index].vertices)
    setattr(s,'signature_'+slot,signature)

def pair_settings(s,joint,side):
    slots=('a','bu') if side=='UPPER' else ('bl','c')
    if not joint.pivot_set:raise ValueError(('上側' if side=='UPPER' else '下側')+'軸中心を記憶してください')
    values={k:getattr(joint,k) for k in (*FIELDS,'shoulder_enabled','reverse_axis','minimum_angle','maximum_angle','preview_angle')}
    values.update(mode='STRAIGHT',axis=s.axis)
    for k,slot in zip(('a','b'),slots):
        values['object_'+k]=getattr(s,'object_'+slot_owner(slot));values['face_'+k]=getattr(s,'face_'+slot);values['signature_'+k]=getattr(s,'signature_'+slot)
    return NS(**values)

def plans(context,s):
    dm.validate_registration(s)
    if s.design=="CENTRAL":
        pairs=[(j,cj.plan(s,j,i)) for i,j in enumerate((s.upper,s.lower))]
        cj.separation(pairs[0][1],pairs[1][1]);return pairs
    # Reuse legacy planning with a read-only cursor proxy; never change real cursor.
    pairs=[]
    for side,j in [('UPPER',s.upper),('LOWER',s.lower)]:
        settings=pair_settings(s,j,side)
        proxy=NS(scene=NS(cursor=NS(location=Vector(j.pivot))))
        pairs.append((settings,fh._plan(proxy,settings)))
    dm.separation(pairs[0][1],pairs[1][1]);return pairs

class CJM_OT_double_capture(Operator):
    bl_idname='cjm.double_capture';bl_label='取付面を記憶';bl_options={'REGISTER','UNDO'}
    slot:EnumProperty(items=[(k,k,'') for k in SLOTS])
    def execute(self,context):
        obj=context.edit_object
        if not ui.visible(context,'DOUBLE') or context.mode!='EDIT_MESH' or obj is None:return {'CANCELLED'}
        bm=bmesh.from_edit_mesh(obj.data);bm.faces.ensure_lookup_table();bm.faces.index_update();bm.verts.index_update()
        faces=[f for f in bm.faces if f.select and not f.hide]
        if len(faces)!=1:self.report({'ERROR'},'面を1枚だけ選択してください');return {'CANCELLED'}
        s=context.scene.cjm_double;slot=self.slot;owner=slot_owner(slot)
        if any(getattr(s,'object_'+k)==obj for k in 'abc' if k!=owner):self.report({'ERROR'},'別の部品として登録済みです');return {'CANCELLED'}
        other='bl' if slot=='bu' else 'bu'
        if owner=='b' and s.object_b is not None and s.object_b!=obj and getattr(s,'face_'+other)>=0:
            self.report({'ERROR'},'中央Bは上下で同じ物体を使用してください（変更時は登録クリア）');return {'CANCELLED'}
        if owner=='b' and getattr(s,'face_'+other)==faces[0].index:self.report({'ERROR'},'Bの上下は別の面を指定してください');return {'CANCELLED'}
        f=faces[0];remember(s,slot,obj,f.index,','.join(str(v.index) for v in f.verts));ui.redraw(context);return {'FINISHED'}

class CJM_OT_double_pivot(Operator):
    bl_idname='cjm.double_pivot';bl_label='カーソルを軸中心として記憶';bl_options={'REGISTER','UNDO'}
    side:EnumProperty(items=[('UPPER','上',''),('LOWER','下','')])
    def execute(self,context):
        if not ui.visible(context,'DOUBLE'):return {'CANCELLED'}
        s=context.scene.cjm_double;j=s.upper if self.side=='UPPER' else s.lower;j.pivot=context.scene.cursor.location;j.pivot_set=True;ui.redraw(context);return {'FINISHED'}

class CJM_OT_double_clear(Operator):
    bl_idname='cjm.double_clear';bl_label='登録をクリア';bl_options={'REGISTER','UNDO'}
    def execute(self,context):
        if not ui.visible(context,'DOUBLE'):return {'CANCELLED'}
        s=context.scene.cjm_double
        for k in 'abc':setattr(s,'object_'+k,None)
        for k in SLOTS:setattr(s,'face_'+k,-1);setattr(s,'signature_'+k,'')
        s.upper.pivot_set=s.lower.pivot_set=False;s.status='';s.last_generation_diagnostic='';s.last_shape_candidates='';s.last_shape_comparison='';ui.redraw(context);return {'FINISHED'}

def build(context,s,col,pairs):
    (up,pu),(lo,pl)=pairs
    if s.design=='CENTRAL':
        a,b,c=cj.build(context,s,col,pairs)
    else:
        a,b1=fh._build_real(context,up,pu,col)
        context.view_layer.update()
        lo=NS(**vars(lo));lo.object_a=b1
        b,c=fh._build_real(context,lo,pl,col)
        context.view_layer.update()
        fh._remove(b1)
    out=(a,b,c);vols=[solid(o) for o in out]
    for i,j in ((0,1),(1,2),(0,2)):
        pair='ABC'[i]+'ABC'[j]
        with diag.operation('初期姿勢検査',component=pair):
            overlap=intersect_volume(context,out[i],out[j],col);limit=max(1e-15,min(vols[i],vols[j])*1e-8)
            if overlap>limit:diag.fail('NEUTRAL_INTERFERENCE','初期姿勢検査',f'{pair[0]}/{pair[1]} が初期姿勢で干渉しています',component=pair,angle=0.,measured=overlap,threshold=limit,unit='体積（内部単位³）')
    for o,k,src in zip(out,'ABC',(s.object_a,s.object_b,s.object_c)):
        o.name='CJM_Double_'+k
        for key in list(o.keys()):
            if key.startswith('face_hinge_'):del o[key]
        o['cjm_double_design']=s.design;o['cjm_mechanism']='DOUBLE';o['cjm_owner']=k;o['cjm_original_name']=src.name
        o['cjm_upper_pivot']=list(pu['pivot']);o['cjm_lower_pivot']=list(pl['pivot']);o['cjm_upper_axis']=list(pu['axis']);o['cjm_lower_axis']=list(pl['axis'])
        o['cjm_upper_range']=[up.minimum_angle,up.maximum_angle];o['cjm_lower_range']=[lo.minimum_angle,lo.maximum_angle]
        if s.design=='CENTRAL':o['cjm_upper_step']=up.angle_step;o['cjm_lower_step']=lo.angle_step
        o['cjm_double_result']=col.name;o['cjm_neutral_matrix']=[v for row in o.matrix_world for v in row]
    return out

class CJM_OT_double_generate(Operator):
    bl_idname='cjm.double_generate';bl_label='上下2関節を一括生成';bl_options={'REGISTER','UNDO'}
    @classmethod
    def poll(cls,context):return ui.visible(context,'DOUBLE') and context.mode=='OBJECT'
    def execute(self,context):
        if not self.poll(context):return {'CANCELLED'}
        s=context.scene.cjm_double;col=None;selected=tuple(context.selected_objects);active=context.view_layer.objects.active;visibility=[]
        s.last_generation_diagnostic='';s.last_shape_candidates='';s.last_shape_comparison=''
        try:
            with diag.operation('登録・寸法検査',code='INPUT'):
                pairs=plans(context,s)
            with diag.operation('生成処理'):
                col=fh._make_collection('CJM_Double_Result',context.scene);out=build(context,s,col,pairs)
            if s.hide_originals:
                for o in (s.object_a,s.object_b,s.object_c):
                    visibility.append((o,o.hide_get(),o.hide_render));o.hide_set(True);o.hide_render=True
            restore_selection(context,out,out[2]);s.live_enabled=False;s.status='生成完了：3部品 / 初期姿勢の干渉なし';self.report({'INFO'},s.status);return {'FINISHED'}
        except Exception as e:
            for o,h,r in visibility:o.hide_set(h);o.hide_render=r
            if col is not None:fh._destroy_collection(col)
            restore_selection(context,selected,active);s.status=str(e)
            detail=e.diagnostic if isinstance(e,diag.ShapeFailure) else diag.Diagnostic('OPERATION_FAILED','生成結果の反映',str(e) or type(e).__name__)
            s.last_generation_diagnostic=detail.encode()
            # Secondary advice must never mask the original generation error.
            try:s.last_shape_candidates=candidates.capture(context,s,detail)
            except Exception:s.last_shape_candidates=''
            self.report({'ERROR'},str(e));return {'CANCELLED'}

class CJM_OT_double_trial(Operator):
    bl_idname='cjm.double_trial';bl_label='候補を隔離試行（適用しない）'
    bl_options={'REGISTER'}
    index:IntProperty(default=0,min=0,max=2)
    @classmethod
    def poll(cls,context):return ui.visible(context,'DOUBLE') and context.mode=='OBJECT' and context.scene.cjm_double.design=='CENTRAL'
    def execute(self,context):
        if not self.poll(context):return {'CANCELLED'}
        s=context.scene.cjm_double
        try:
            detail,item=trials.select(context,s,self.index)
            base,trial=trials.proxies(s,FIELDS,item)
            def inventory():
                return tuple(frozenset(x.as_pointer() for x in collection) for collection in (bpy.data.objects,bpy.data.meshes,bpy.data.collections))
            def attempt(proxy):
                return trials.attempt(context,proxy,plans=plans,build=build,create=fh._make_collection,destroy=fh._destroy_collection,restore=restore_selection,inventory=inventory,inspection_angles=cj.cm.inspection_angles)
            result=trials.run(detail,base,trial,attempt)
            s.status='隔離試行：'+result.message
            if result.diagnostic is not None:s.status+=' / '+result.diagnostic.code
            self.report({'INFO' if result.status=='PASS' else 'WARNING'},s.status)
            ui.redraw(context);return {'FINISHED'}
        except Exception as e:
            s.status='隔離試行中止：'+str(e);self.report({'ERROR'},s.status);return {'CANCELLED'}

class CJM_OT_double_compare(Operator):
    bl_idname='cjm.double_compare';bl_label='候補を一括比較（適用しない）'
    bl_options={'REGISTER'}
    expand:BoolProperty(default=False,options={'SKIP_SAVE'})
    refine:BoolProperty(default=False,options={'SKIP_SAVE'})
    pair:BoolProperty(default=False,options={'SKIP_SAVE'})
    pair_refine:BoolProperty(default=False,options={'SKIP_SAVE'})
    pair_exchange:BoolProperty(default=False,options={'SKIP_SAVE'})
    @classmethod
    def poll(cls,context):return ui.visible(context,'DOUBLE') and context.mode=='OBJECT' and context.scene.cjm_double.design=='CENTRAL'
    def execute(self,context):
        if not self.poll(context):return {'CANCELLED'}
        s=context.scene.cjm_double;previous=s.last_shape_comparison;s.last_shape_comparison=''
        initial_advice=s.last_shape_candidates;expanded=False
        try:
            detail=diag.Diagnostic.decode(s.last_generation_diagnostic)
            source=None
            refining=getattr(self,'refine',False)
            pairing=getattr(self,'pair',False)
            expanding=getattr(self,'expand',False)
            pair_refining=getattr(self,'pair_refine',False)
            exchanging=getattr(self,'pair_exchange',False)
            if sum(map(bool,(refining,pairing,expanding,pair_refining,exchanging)))>1:raise ValueError('探索モードが重複しています')
            if refining or pairing or expanding or pair_refining or exchanging:
                data=candidates.inputs(context,s)
                if data is None or candidates.display(context,s,detail) is None:raise ValueError('候補が古いため探索できません')
                make=candidates.pair_exchange if exchanging else candidates.pair_refinement if pair_refining else candidates.refinement if refining else candidates.pairing if pairing else candidates.expansion
                fresh=make(initial_advice,comparison.display(previous,initial_advice),detail,data,s)
                if not fresh:raise ValueError('交換探索できる成功候補がありません' if exchanging else '連動候補を最適化できません' if pair_refining else '連動探索できる候補がありません' if pairing else '中間寸法を探索できる成功候補がありません' if refining else '追加探索できる改善候補がありません')
                source=adoption.source_signature(context,s)
                s.last_shape_candidates=fresh;expanded=True
            advice=s.last_shape_candidates;items=candidates.display(context,s,detail)
            refined=candidates.is_refined(advice)
            paired=candidates.is_paired(advice)
            pair_refined=candidates.is_pair_refined(advice)
            exchanged=candidates.is_pair_exchanged(advice)
            if (refined or paired or pair_refined or exchanged) and source is None:source=adoption.source_signature(context,s)
            if refined or pair_refined or exchanged:candidates.check_history_source(advice,source)
            if not items or len(items)>comparison.MAX_CANDIDATES:raise ValueError('有効な補正候補がありません')
            def check():
                if s.last_shape_candidates!=advice or s.last_generation_diagnostic!=detail.encode() or candidates.display(context,s,detail)!=items:
                    raise RuntimeError('比較中に設定または登録が変化しました')
                if source is not None and adoption.source_signature(context,s)!=source:raise RuntimeError('追加探索中に元メッシュが変化しました')
                for index,item in enumerate(items):
                    if trials.select(context,s,index)!=(detail,item):raise RuntimeError('候補が変化しました')
            check();pairs=[]
            for item in items:
                base,proxy=trials.proxies(s,FIELDS,item);pairs.append((item,proxy))
            def inventory():
                return tuple(frozenset(x.as_pointer() for x in collection) for collection in (bpy.data.objects,bpy.data.meshes,bpy.data.collections))
            def attempt(proxy):
                return trials.attempt(context,proxy,plans=plans,build=build,create=fh._make_collection,destroy=fh._destroy_collection,restore=restore_selection,inventory=inventory,inspection_angles=cj.cm.inspection_angles)
            result=comparison.run(detail,base,pairs,attempt,check,require_first_pass=refined or pair_refined or exchanged)
            if refined or paired or pair_refined or exchanged:result['source']=repr(source)
            s.last_shape_comparison=comparison.encode(advice,result)
            s.status=('2寸法交換探索：' if exchanged else '2寸法局所最適化：' if pair_refined else '2寸法連動比較：' if paired else '中間寸法探索：' if refined else '追加探索：' if expanded else '候補比較：')+result['message']
            self.report({'INFO' if result['status']=='DONE' else 'WARNING'},s.status)
            ui.redraw(context);return {'FINISHED'}
        except Exception as e:
            if expanded:s.last_shape_candidates=initial_advice
            s.last_shape_comparison='';s.status='候補比較中止：'+str(e);self.report({'ERROR'},s.status);return {'CANCELLED'}

class CJM_OT_double_apply_candidate(Operator):
    bl_idname='cjm.double_apply_candidate';bl_label='再検証して寸法だけ適用';bl_options={'REGISTER','UNDO'}
    index:IntProperty(default=0,min=0,max=2)
    @classmethod
    def poll(cls,context):return ui.visible(context,'DOUBLE') and context.mode=='OBJECT' and context.scene.cjm_double.design=='CENTRAL'
    def execute(self,context):
        if not self.poll(context):return {'CANCELLED'}
        from . import constraints as c
        s=context.scene.cjm_double
        try:
            detail,item=trials.select(context,s,self.index)
            advice=s.last_shape_candidates;payload=s.last_shape_comparison
            items=candidates.display(context,s,detail)
            paired='changes' in item
            if paired:adoption.passing_item(payload,advice,items,self.index,allow_pair=True)
            else:adoption.passing_item(payload,advice,items,self.index)
            base,trial=trials.proxies(s,FIELDS,item)
            source=adoption.source_signature(context,s)
            data=candidates.inputs(context,s)
            registration=candidates.signature(data,s)
            def read():
                return {side+'.'+k:getattr(j,k) for side,j in [('upper',s.upper),('lower',s.lower)] for k in (*FIELDS,'shoulder_enabled','reverse_axis','minimum_angle','maximum_angle','preview_angle','pivot_set','pivot')}
            # RNA vectors are live views; use immutable copies.
            def state():return {k:tuple(v) if k.endswith('.pivot') else v for k,v in read().items()}
            original=state()
            focus=(s.active_joint,s.upper.live_focus,s.lower.live_focus)
            meta=('_cjm_snapshot_central','_cjm_constraint_status')
            previous=[{k:(k in j,j.get(k)) for k in meta} for j in (s.upper,s.lower)]
            def check():
                if s.last_shape_candidates!=advice or s.last_shape_comparison!=payload or trials.select(context,s,self.index)!=(detail,item) or candidates.inputs(context,s)!=data or state()!=original or adoption.source_signature(context,s)!=source:
                    raise RuntimeError('再検証中にモデルまたは設定が変化しました')
            def inventory():return tuple(frozenset(x.as_pointer() for x in collection) for collection in (bpy.data.objects,bpy.data.meshes,bpy.data.collections))
            def attempt(proxy):return trials.attempt(context,proxy,plans=plans,build=build,create=fh._make_collection,destroy=fh._destroy_collection,restore=restore_selection,inventory=inventory,inspection_angles=cj.cm.inspection_angles)
            adoption.verify(detail,base,trial,attempt,check)
            changes={i['side'].lower()+'.'+i['key']:i['after'] for i in candidates.components(item)}
            if paired and len(changes)!=2:raise ValueError('連動寸法が無効です')
            def write(k,x):
                side,prop=k.split('.',1);setattr(getattr(s,side),prop,x)
            def restore_focus():s.active_joint,s.upper.live_focus,s.lower.live_focus=focus
            def restore(values):
                remaining=c.restore_dimensions(state,write,values)
                restore_focus()
                for j,old in zip((s.upper,s.lower),previous):
                    for k,(present,v) in old.items():
                        if present:j[k]=v
                        elif k in j:del j[k]
                return remaining
            def finish():
                restore_focus()
                if adoption.source_signature(context,s)!=source:raise ValueError('寸法反映中に元メッシュが変化しました')
                current=candidates.inputs(context,s)
                # The clearance floor can depend on the current dimension; only
                # adopted fields' bounds are allowed to change accordingly.
                if current is None or current[0]!={**data[0],**changes} or current[1]!=data[1] or current[3:]!=data[3:] or any(current[2].get(k)!=v for k,v in data[2].items() if k not in changes):
                    raise ValueError('寸法反映中に制約条件が変化しました')
                if candidates.signature(data,s)!=registration:raise ValueError('登録条件が変化しました')
                if any(k not in current[2] or not current[2][k][0]<=v<=current[2][k][1] for k,v in changes.items()):raise ValueError('寸法反映後の範囲違反')
                if not candidates.numerically_valid(current[0],current[1],current[4]):raise ValueError('寸法反映後の数値制約不成立')
                for j in (s.upper,s.lower):c.snapshot(j,'central');j['_cjm_constraint_status']='隔離検査済み候補を手動適用'
            with c.suspended():
                if paired:adoption.commit_many(state,write,restore,finish,original,changes)
                else:
                    key,value=next(iter(changes.items()));adoption.commit(state,write,restore,finish,original,key,value)
            s.last_generation_diagnostic='';s.last_shape_candidates='';s.last_shape_comparison=''
            s.status='寸法のみ適用済み：生成ボタンで確定してください';ui.redraw(context);self.report({'INFO'},s.status);return {'FINISHED'}
        except Exception as e:
            s.last_shape_comparison='';s.status='候補適用中止：'+str(e);self.report({'ERROR'},s.status);return {'CANCELLED'}

class CJM_OT_double_inspect(Operator):
    bl_idname='cjm.double_inspect';bl_label='選択した生成3部品の可動干渉検査';bl_options={'REGISTER','UNDO'}
    @classmethod
    def poll(cls,context):return ui.visible(context,'DOUBLE') and context.mode=='OBJECT'
    def execute(self,context):
        if not self.poll(context):return {'CANCELLED'}
        s=context.scene.cjm_double;col=None;selected=tuple(context.selected_objects);active=context.view_layer.objects.active
        try:
            objs=selected_meshes(context,3)
            roles={o.get('cjm_owner'):o for o in objs if o.get('cjm_mechanism')=='DOUBLE'}
            if set(roles)!=set('ABC') or len({o.get('cjm_double_result') for o in objs})!=1:raise ValueError('同じ二重関節の生成結果A/B/Cを3体選択してください')
            objs=[roles[k] for k in 'ABC'];meta=objs[0]
            for o in objs:
                now=[v for row in o.matrix_world for v in row];old=o.get('cjm_neutral_matrix',())
                if len(old)!=16 or max(abs(a-b) for a,b in zip(now,old))>1e-5:raise ValueError('生成時の姿勢へ戻してください（軸は生成時ワールド座標）')
            pu={'pivot':Vector(meta['cjm_upper_pivot']),'axis':Vector(meta['cjm_upper_axis'])};pl={'pivot':Vector(meta['cjm_lower_pivot']),'axis':Vector(meta['cjm_lower_axis'])}
            upper=dm.samples(*meta['cjm_upper_range']);lower=dm.samples(*meta['cjm_lower_range'])
            col=fh._make_collection('CJM_Double_Inspect',context.scene);copies=[stage(context,o,col,'CJM_Double_Probe_'+k) for o,k in zip(objs,'ABC')];original=[o.matrix_world.copy() for o in copies];vols=[solid(o) for o in copies]
            if meta.get('cjm_double_design')=='CENTRAL':
                # AB depends only on u; BC depends only on l (common rigid
                # upper rotation cancels). AC still needs the coarse grid.
                du=cj.cm.inspection_angles(*meta['cjm_upper_range'],meta.get('cjm_upper_step',5.))
                dl=cj.cm.inspection_angles(*meta['cjm_lower_range'],meta.get('cjm_lower_step',5.))
                cases=[(u,0.,0,1) for u in du]+[(0.,l,1,2) for l in dl]+[(u,l,0,2) for u in upper for l in lower]
                count=0;first=None;peak=0.
                for u,l,i,j in cases:
                    transforms=dm.transforms(Matrix,pu,pl,(u,l))
                    for k in (i,j):copies[k].matrix_world=transforms[k]@original[k]
                    context.view_layer.update()
                    v=intersect_volume(context,copies[i],copies[j],col);peak=max(peak,v)
                    if v>max(1e-15,min(vols[i],vols[j])*1e-8):
                        count+=1
                        if first is None:first=(u,l,'ABC'[i]+'ABC'[j])
                s.status=f'干渉 {count}/{len(cases)} 組 / 最大体積 {peak:.3g}'
                if first:s.status+=f' / 初回 {first[0]:g}°, {first[1]:g}° {first[2]}'
                self.report({'WARNING' if count else 'INFO'},s.status);return {'FINISHED'}
            count=0;first=None;peak=0.
            for u in upper:
                for l in lower:
                    for o,t,m in zip(copies,dm.transforms(Matrix,pu,pl,(u,l)),original):o.matrix_world=t@m
                    context.view_layer.update();hit=False
                    for i,j in ((0,1),(1,2),(0,2)):
                        v=intersect_volume(context,copies[i],copies[j],col);peak=max(peak,v)
                        if v>max(1e-15,min(vols[i],vols[j])*1e-8):
                            hit=True
                            if first is None:first=(u,l,'ABC'[i]+'ABC'[j])
                    count+=int(hit)
            s.status=f'干渉 {count}/{len(upper)*len(lower)} 姿勢 / 最大体積 {peak:.3g}'
            if first:s.status+=f' / 初回 {first[0]:g}°, {first[1]:g}° {first[2]}'
            self.report({'WARNING' if count else 'INFO'},s.status);return {'FINISHED'}
        except Exception as e:s.status=str(e);self.report({'ERROR'},str(e));return {'CANCELLED'}
        finally:
            if col is not None:fh._destroy_collection(col)
            restore_selection(context,selected,active)

class VIEW3D_PT_cjm_double(Panel):
    bl_idname='VIEW3D_PT_cjm_double';bl_label='二重関節（A-B-C）';bl_space_type='VIEW_3D';bl_region_type='UI';bl_category=ui.CATEGORY;bl_parent_id=ui.ROOT
    @classmethod
    def poll(cls,context):return ui.visible(context,'DOUBLE')
    def draw(self,context):
        l=self.layout;s=context.scene.cjm_double;l.prop(s,'design');l.label(text='各物体を1体ずつ編集し面を1枚記憶')
        if s.live_enabled:
            box=l.box();box.label(text='上下の連動LIVE（表示専用）')
            for side,j,title in [('UPPER',s.upper,'上側角度'),('LOWER',s.lower,'下側角度')]:
                ui.focus_row(box,j,'preview_angle','double','preview_angle',view=side,text=title,slider=True)
                actual=max(min(0.,j.minimum_angle),min(max(0.,j.maximum_angle),j.preview_angle));box.label(text=f'表示 {actual:g}°（範囲外は境界まで）')
            box.label(text='青A / 橙B / 緑C・本体は外接箱')
        for slot,title in [('a','A：上部'),('bu','B：中央 上面'),('bl','B：中央 下面'),('c','C：下部')]:
            o=getattr(s,'object_'+slot_owner(slot));i=getattr(s,'face_'+slot);row=l.row();row.operator('cjm.double_capture',text=title,icon='EYEDROPPER').slot=slot;row.label(text=(o.name[:12]+' / '+str(i)) if o and i>=0 else '未登録')
        l.operator('cjm.double_clear',icon='X');l.prop(s,'axis',expand=True)
        for side,j,title in [('UPPER',s.upper,'上側 A-B'),('LOWER',s.lower,'下側 B-C')]:
            b=l.box();b.label(text=title);b.operator('cjm.double_pivot',text='3Dカーソルを軸中心に記憶',icon='PIVOT_CURSOR').side=side
            b.label(text='登録済み' if j.pivot_set else '軸中心未登録',icon='CHECKMARK' if j.pivot_set else 'ERROR');b.prop(j,'pivot')
            for key in ('reverse_axis','outer_diameter','axle_diameter','a_width','b_width','radial_clearance','axial_gap','cap_wall','radial_wall','shoulder_enabled','shoulder_diameter','shoulder_thickness','shoulder_radial_clearance','shoulder_axial_clearance','tip_clearance','support_width','support_thickness','embed_depth','minimum_angle','maximum_angle','angle_step','swing_clearance'):
                if s.design=='CENTRAL' and key.startswith('shoulder_'):continue
                if key.startswith('shoulder_') and key!='shoulder_enabled' and not j.shoulder_enabled:continue
                if key=='tip_clearance' and j.shoulder_enabled and s.design=='LEGACY':continue
                ui.focus_row(b,j,key,'double',key,view=side,**({'text':ui.CENTRAL_INFO[key][0]} if s.design=='CENTRAL' and key in ui.CENTRAL_INFO else {}))
        try:
            pairs=plans(context,s);gap=(cj.separation if s.design=='CENTRAL' else dm.separation)(pairs[0][1],pairs[1][1]);l.label(text=f'新規加工領域の離隔余裕 {gap:.3g}',icon='CHECKMARK');ok=True
        except (ValueError,RuntimeError,ReferenceError,AttributeError) as e:l.label(text=str(e)[:64],icon='ERROR');ok=False
        l.prop(s,'hide_originals');row=l.row();row.enabled=ok and context.mode=='OBJECT';row.operator('cjm.double_generate',icon='MOD_BOOLEAN');l.label(text='原本保持 / A・Cは切削のみ' if s.design=='CENTRAL' else '原本保持・支持腕のみ回転逃げ加工');l.label(text='中央本体は余裕付き凸包で逃げ加工 / A-Cは検査のみ' if s.design=='CENTRAL' else '全可動範囲の外装干渉は未保証',icon='INFO');l.operator('cjm.double_inspect',icon='VIEWZOOM');l.label(text='中央支持：AB/BC細分検査・AC粗い組合せ' if s.design=='CENTRAL' else '最小・中間・最大・0°の組合せ')
        if s.status:l.label(text=s.status[:65])
        if s.last_generation_diagnostic:
            try:
                detail=diag.Diagnostic.decode(s.last_generation_diagnostic)
                b=l.box();b.label(text='前回の生成失敗（自動再試行なし）',icon='ERROR')
                for line in detail.lines():
                    # Narrow sidebar: split long Japanese text into visible chunks.
                    for start in range(0,len(line),28):b.label(text=line[start:start+28])
                if s.last_shape_candidates:
                    try:items=candidates.display(context,s,detail)
                    except (ValueError,TypeError,AttributeError,ReferenceError,RuntimeError,OverflowError,KeyError):items=None
                    if items is None:b.label(text='条件変更：候補は非表示',icon='INFO')
                    else:
                        b.label(text='前回の試行候補（数値検査のみ）',icon='INFO')
                        b.label(text='形状・強度未検証 / 自動適用なし')
                        if not items:b.label(text='単一寸法の候補なし（解なしとは限らない）')
                        for index,item in enumerate(items):
                            if 'changes' in item:b.label(text='2寸法連動候補（未適用）',icon='INFO')
                            for change in candidates.components(item):
                                j=s.upper if change['side']=='UPPER' else s.lower
                                b.label(text=('上側 ' if change['side']=='UPPER' else '下側 ')+j.bl_rna.properties[change['key']].name)
                                b.label(text=f"{change['before']:.5g} → {change['after']:.5g}"+('（優先維持）' if change['policy']=='PREFERRED' else ''))
                            row=b.row();row.enabled=context.mode=='OBJECT';row.operator('cjm.double_trial',text='この候補を隔離試行',icon='VIEWZOOM').index=index
                        if items:
                            b.label(text='個別：元条件 → 1候補 / 未適用',icon='INFO')
                            row=b.row();row.enabled=context.mode=='OBJECT';op=row.operator('cjm.double_compare',icon='VIEWZOOM');op.expand=False;op.refine=False;op.pair=False;op.pair_refine=False;op.pair_exchange=False
                            b.label(text='一括：元条件1回＋最大3候補 / 未適用')
                            record=comparison.display(s.last_shape_comparison,s.last_shape_candidates)
                            if record:
                                cb=b.box();cb.label(text='前回の比較結果（形状編集は未追跡）',icon='INFO')
                                baseline=record.get('baseline')
                                if baseline and baseline['measured'] is not None and baseline['threshold'] is not None:
                                    cb.label(text=f"元の実測 {baseline['measured']:.6g} / 境界 {baseline['threshold']:.6g}")
                                for i,entry in enumerate(record['rows']):
                                    item=entry['item'];result=entry['result']
                                    for change in candidates.components(item):
                                        j=s.upper if change['side']=='UPPER' else s.lower
                                        cb.label(text=j.bl_rna.properties[change['key']].name+f" → {change['after']:.5g}")
                                    cb.label(text=result['message'],icon='CHECKMARK' if result['status']=='PASS' else 'INFO')
                                    if i==record.get('preferred'):cb.label(text='寸法維持の優先候補（未適用）',icon='INFO')
                                    if record['status']=='DONE' and result['status']=='PASS':
                                        row=cb.row();row.enabled=context.mode=='OBJECT';row.operator('cjm.double_apply_candidate',text='再検証して2寸法を一括適用' if 'changes' in item else '再検証して寸法だけ適用',icon='CHECKMARK').index=i
                                    if result['code']:cb.label(text=result['code'])
                                    if result['measured'] is not None and result['threshold'] is not None:
                                        cb.label(text=f"実測 {result['measured']:.6g} / 境界 {result['threshold']:.6g}")
                                cb.label(text=record['message'])
                                if candidates.is_refined(s.last_shape_candidates):cb.label(text=f'中間探索 {candidates.refinement_depth(s.last_shape_candidates)}/{candidates.MAX_REFINEMENT_STEPS} 段階（履歴は探索用）')
                                data=candidates.inputs(context,s)
                                if data is not None and candidates.expansion(s.last_shape_candidates,record,detail,data,s):
                                    row=cb.row();row.enabled=context.mode=='OBJECT';op=row.operator('cjm.double_compare',text='改善候補を追加探索（未適用）',icon='VIEWZOOM');op.expand=True;op.refine=False;op.pair=False;op.pair_refine=False;op.pair_exchange=False
                                    cb.label(text='元寸法から最大20% / 最大3候補')
                                if data is not None and candidates.pairing(s.last_shape_candidates,record,detail,data,s):
                                    row=cb.row();row.enabled=context.mode=='OBJECT';op=row.operator('cjm.double_compare',text='2寸法を組み合わせて比較（未適用）',icon='VIEWZOOM');op.pair=True;op.pair_refine=False;op.pair_exchange=False;op.expand=False;op.refine=False
                                    cb.label(text='同じ側・最大3組 / 適用なし')
                                if data is not None and candidates.pair_refinement(s.last_shape_candidates,record,detail,data,s):
                                    row=cb.row();row.enabled=context.mode=='OBJECT';op=row.operator('cjm.double_compare',text='成功した2寸法を元に近づける（未適用）',icon='VIEWZOOM');op.pair_refine=True;op.pair_exchange=False;op.pair=False;op.expand=False;op.refine=False
                                    cb.label(text='元条件＋成功解＋最大2改善候補 / 1段階')
                                if data is not None and candidates.pair_exchange(s.last_shape_candidates,record,detail,data,s):
                                    row=cb.row();row.enabled=context.mode=='OBJECT';op=row.operator('cjm.double_compare',text='2寸法の変更量を交換探索（未適用）',icon='VIEWZOOM');op.pair_exchange=True;op.pair_refine=False;op.pair=False;op.expand=False;op.refine=False
                                    cb.label(text='元条件＋成功解＋最大2交換候補 / 1段階')
                                if data is not None and candidates.refinement(s.last_shape_candidates,record,detail,data,s):
                                    row=cb.row();row.enabled=context.mode=='OBJECT';op=row.operator('cjm.double_compare',text='成功候補を元寸法に近づける（未適用）',icon='VIEWZOOM');op.refine=True;op.expand=False;op.pair=False;op.pair_refine=False;op.pair_exchange=False
                                    cb.label(text=f'元条件＋成功候補＋中間寸法 / 次 {candidates.refinement_depth(s.last_shape_candidates)+1}/{candidates.MAX_REFINEMENT_STEPS} 段階')
            except (ValueError,TypeError):pass

CLASSES=(CJM_DoubleSpec,CJM_DoubleSettings,CJM_OT_double_capture,CJM_OT_double_pivot,CJM_OT_double_clear,CJM_OT_double_generate,CJM_OT_double_trial,CJM_OT_double_compare,CJM_OT_double_apply_candidate,CJM_OT_double_inspect,VIEW3D_PT_cjm_double)
