"""Pure wire geometry for SWAP LIVE. No scene or mesh mutations."""
from functools import lru_cache
import math
from . import swap_math as sm
RECEIVER=(.32,.67,.96,.65)
PLUG=(1.,.57,.22,.92)
GAP=(.22,.95,.85,.9)
FOCUS=(1.,.85,.24,1.)
WARN=(1.,.19,.18,1.)
AXIS=(.87,.8,.36,.8)

def sub(a,b):return tuple(x-y for x,y in zip(a,b))
def cross(a,b):return (a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0])
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def normal(v,f):
    n=cross(sub(v[f[1]],v[f[0]]),sub(v[f[2]],v[f[0]])); length=math.sqrt(dot(n,n))
    return tuple(x/length for x in n) if length else (0.,0.,0.)
def feature_edges(geo):
    """Exact mesh edges at sharp transitions, omit coplanar tessellation."""
    v,f=geo; adj={}
    for face in f:
        n=normal(v,face)
        for a,b in zip(face,face[1:]+face[:1]):adj.setdefault(tuple(sorted((a,b))),[]).append(n)
    cos=math.cos(math.radians(12))
    return tuple((v[a],v[b]) for (a,b),ns in adj.items() if len(ns)!=2 or dot(*ns)<cos)
def pt(r,z,a=0):
    a=math.radians(a);return (r*math.cos(a),r*math.sin(a),z)
def arc(r,z,start=0,end=360):
    n=max(1,math.ceil(abs(end-start)/4)); ps=[pt(r,z,start+(end-start)*i/n) for i in range(n+1)]
    return tuple(zip(ps,ps[1:]))
def line(a,b):return ((a,b),)
def vertical(r,z1,z2,a=0):return line(pt(r,z1,a),pt(r,z2,a))
def radial(r1,r2,z,a=0):return line(pt(r1,z,a),pt(r2,z,a))
def pose(p,insertion,rotation):
    """Fractions in [0,100]. Rotate only once fully inserted."""
    i=max(0.,min(100.,float(insertion)));r=max(0.,min(100.,float(rotation)))
    return (-p.tip+max(.5,p.spec.axial_clearance))*(1-i/100),p.spec.direction*p.spec.lock_angle*r/100 if i==100 else 0.
def moved(edges,dz,angle):
    a=math.radians(angle);c,s=math.cos(a),math.sin(a)
    def point(p):x,y,z=p;return (x*c-y*s,x*s+y*c,z+dz)
    return tuple((point(a),point(b)) for a,b in edges)
@lru_cache(maxsize=8)
def cached(spec):
    p=sm.plan(spec)
    receiver=feature_edges(sm.female_mesh(p));plug=feature_edges(sm.male_mesh(p));cutter=feature_edges(sm.female_mesh(p,True))
    grid=sm.angles(p)[:-1]
    guides=tuple(min(grid,key=lambda x:abs(x-a)) for a in (0,90,180,270))
    receiver+=tuple(e for a in guides for e in vertical(p.outer,-spec.depth-spec.wall,0,a))
    plug+=tuple(e for a in guides for e in vertical(p.r,p.lug_high,spec.axial_clearance,a))
    return p,receiver,plug,cutter
def dimensions(p,key,dz,angle):
    s=p.spec; a=angle; z=p.lug_high+dz; d=s.direction; out=()
    if key=='axis':return line((0,0,-s.depth-s.wall-2),(0,0,s.axial_clearance+s.flange+dz+2))
    if key=='diameter':return moved(arc(p.r,s.axial_clearance)+radial(-p.r,p.r,s.axial_clearance),dz,angle)
    if key=='depth':return vertical(p.outer,0,-s.depth)+arc(p.bore,-s.depth)
    if key=='lug_height':return tuple(e for k in range(s.lug_count) for e in vertical(p.lug_r,p.lug_low+dz,p.lug_high+dz,k*p.pitch+a))
    if key=='lug_projection':return tuple(e for k in range(s.lug_count) for e in radial(p.r,p.lug_r,z,k*p.pitch+a))
    if key in ('lug_angle','lug_count'):
        return tuple(e for k in range(s.lug_count) for e in arc(p.lug_r,z,k*p.pitch+a-p.half,k*p.pitch+a+p.half))
    if key in ('lock_angle','direction'):
        for k in range(s.lug_count):
            end=k*p.pitch+d*s.lock_angle; rr=p.track
            out+=arc(rr,p.channel_high,k*p.pitch,end)+radial(p.bore,rr,p.channel_high,end)
            t=pt(rr,p.channel_high,end);out+=line(t,pt(rr*.83,p.channel_high,end-d*8))+line(t,pt(rr*1.09,p.channel_high,end-d*8))
        return out
    if key=='radial_clearance':return arc(p.bore,0)+radial(p.r,p.bore,0)+arc(p.track,p.channel_high)+radial(p.lug_r,p.track,p.channel_high)
    if key=='axial_clearance':return vertical(p.track,p.channel_low,p.lug_low)+vertical(p.track,p.lug_high,p.channel_high)+vertical(p.outer,0,s.axial_clearance)
    if key=='wall':return radial(p.track,p.outer,p.channel_high)+vertical(p.outer,-s.depth-s.wall,-s.depth)+arc(p.outer,-s.depth-s.wall)
    if key=='flange':return vertical(p.outer,s.axial_clearance+dz,s.axial_clearance+s.flange+dz,a)+arc(p.outer,s.axial_clearance+s.flange+dz)
    return ()
def groups(spec,key,insertion,rotation,view):
    p,receiver,plug,cutter=cached(spec); dz,angle=pose(p,insertion,rotation)
    axis=dimensions(p,'axis',dz,angle);highlight=dimensions(p,key,dz,angle)
    dim=view=='FOCUS'; result=[(receiver,RECEIVER[:3]+(.22,) if dim else RECEIVER),(moved(plug,dz,angle),PLUG[:3]+(.3,) if dim else PLUG)]
    if view=='DEBUG' or key in ('radial_clearance','axial_clearance','lock_angle','direction','lug_angle'):
        result.append((cutter,GAP[:3]+(.5,)))
    else:
        track=tuple(e for k in range(spec.lug_count) for z in (p.channel_low,p.channel_high) for e in arc(p.track,z,k*p.pitch-spec.direction*(p.half+p.pad),k*p.pitch+spec.direction*(spec.lock_angle+p.half+p.pad)))
        result.append((track,GAP))
    result.extend(((axis,AXIS),(highlight,FOCUS)))
    return result
