"""RNA/UI adapter. Only explicit numerical corrections; no mesh operations."""
from contextlib import contextmanager
import bpy
import json
from math import sqrt, isfinite
from bpy.types import Operator
from bpy.props import StringProperty
from . import constraint_math as cm

# Adjustable dimensions and manually editable safety thresholds are separate.
# Previous permanent locks become ordinary default locks, preserving old files.
CONFIG={
 'hinge':(('outer_diameter','pin_diameter','total_length','pin_clearance','knuckle_gap','axle_tip_clearance'),('minimum_radial_wall','minimum_cap_wall')),
 'ball':(('ball_diameter','opening_diameter','shaft_diameter','clearance'),()),
 'rotary':(('outer_diameter','axle_diameter','a_width','b_width','shoulder_diameter','shoulder_thickness','radial_clearance','tip_clearance','axial_gap','shoulder_radial_clearance','shoulder_axial_clearance'),('radial_wall','cap_wall')),
 'central':(('outer_diameter','axle_diameter','a_width','b_width','support_width','radial_clearance','tip_clearance','axial_gap','swing_clearance'),('radial_wall','cap_wall')),
 'trunnion':(('axle_diameter','pin_projection','pin_embed','radial_clearance','tip_clearance','axial_gap'),()),
 'swap':(('diameter','depth','lug_height','lug_projection','lug_angle','lock_angle','radial_clearance','axial_clearance','wall'),()),
}
DEFAULT_LOCKED=frozenset(('pin_clearance','knuckle_gap','axle_tip_clearance','clearance','radial_clearance','tip_clearance','axial_gap','shoulder_radial_clearance','shoulder_axial_clearance','axial_clearance','wall','swing_clearance'))
ICONS={'FREE':'UNLOCKED','PREFERRED':'SHIELD','LOCKED':'LOCKED'}
NEXT={'FREE':'PREFERRED','PREFERRED':'LOCKED','LOCKED':'FREE'}

def lock_state(s,k):
    state=s.get('_cjm_policy_'+k,'')
    if state in NEXT:return state
    return 'LOCKED' if s.get('_cjm_lock_'+k,k in DEFAULT_LOCKED) else 'FREE'

def cycle_lock(s,k):
    state=NEXT[lock_state(s,k)];s['_cjm_policy_'+k]=state
    # Preserve the legacy bool for readers of an older release.
    s['_cjm_lock_'+k]=state=='LOCKED'
    return state

_busy=0
@contextmanager
def suspended():
    global _busy
    _busy+=1
    try:yield
    finally:_busy-=1


def target(context,engine,side=''):
    sc=context.scene;st=getattr(sc,'cjm_settings',None)
    if st is None:return None,None
    if engine=='double' and st.mode=='DOUBLE' and side in ('UPPER','LOWER'):
        d=sc.cjm_double;return (d.upper if side=='UPPER' else d.lower),('central' if d.design=='CENTRAL' else 'rotary')
    if engine=='face' and st.mode in ('ROTARY','TRUNNION'):
        obj=sc.face_hinge_settings
        if st.mode=='TRUNNION' and not hasattr(obj,'pin_embed'):return None,None
        return obj,('trunnion' if st.mode=='TRUNNION' else 'rotary')
    for e,mode,name in [('hinge','HINGE','hinge_maker_settings'),('ball','BALL','ball_joint_settings'),('swap','SWAP','cjm_swap')]:
        if engine==e and st.mode==mode:return getattr(sc,name,None),e
    return None,None


def current(context):
    mode=context.scene.cjm_settings.mode
    return [('double','UPPER'),('double','LOWER')] if mode=='DOUBLE' else [({'HINGE':'hinge','BALL':'ball','ROTARY':'face','SWAP':'swap','TRUNNION':'face'}[mode],'')]


def active(context,engine):
    st=getattr(getattr(context,'scene',None),'cjm_settings',None)
    return bool(st and st.auto_constraints and target(context,engine)[0] is not None)


def snapshot(s,kind):
    adj,protected=CONFIG[kind]
    extra={'rotary':('shoulder_enabled',),'swap':('lug_count',),'ball':('make_socket','make_shaft','make_motion_cut')}.get(kind,())
    s['_cjm_snapshot_'+kind]=json.dumps({k:getattr(s,k) for k in (*adj,*protected,*extra)})


def capture(context):
    st=getattr(getattr(context,'scene',None),'cjm_settings',None)
    if st is None or not st.auto_constraints:return
    for engine,side in current(context):
        s,kind=target(context,engine,side)
        if s is not None:snapshot(s,kind)


def length(s,kind):return (2 if kind=='central' else 1)*(s.a_width+s.axial_gap)+s.b_width

def options(s,kind,context):
    if kind=='hinge':
        opt={'integrated':s.hinge_style=='INTEGRATED_AXLE','trim':s.hinge_style=='INTEGRATED_AXLE' and s.axle_end_mode=='TRIM','bridge_max':s.bridge_max_reach if s.make_support_bridges else None,'face_clearance':s.face_clearance if s.make_body_relief and not s.face_clearance_follow_gap else None}
        if s.hinge_style=='INTEGRATED_AXLE' and s.axle_end_mode=='BLIND' and s.axle_follow_side_centers:
            ratio=s.center_ratio if s.length_mode!='EQUAL' else 1.
            if s.get('_hm_manual_lengths',False):
                side=s.get('_hm_ref_side',0.);center=s.get('_hm_ref_center',0.)
                if side>0 and center>0:ratio=center/side
            opt['blind_factor']=2*(2+ratio)
        return opt
    if kind=='ball':return {'socket':s.make_socket or context.scene.cjm_settings.ball_section=='MOUNT','shaft':s.make_shaft,'motion':s.make_motion_cut,'retain':getattr(context.scene.cjm_settings,'constraint_ball_retention',True)}
    if kind=='swap':return {'lug_count':int(s.lug_count)}
    if kind=='trunnion':
        from .hinge_maker.face_hinge import trunnion_bounds
        lo,hi=trunnion_bounds(context,s)
        if not lo<0<hi:raise ValueError('3DカーソルをBの軸方向範囲内に置いてください')
        return {'socket_min':lo,'socket_max':hi,'embed_limit':min(-lo,hi)}
    opt={'shoulder':s.shoulder_enabled and kind=='rotary','length':s.get('_cjm_length_'+kind) if '_cjm_length_'+kind in s else None}
    if kind=='central':opt['separation']=central_separation(context,s)
    return opt

def pair_projection(root):
    if root is None or not all(getattr(j,'pivot_set',False) for j in (root.upper,root.lower)):return None
    delta=[float(b)-float(a) for a,b in zip(root.upper.pivot,root.lower.pivot)]
    dist=sqrt(sum(x*x for x in delta))
    if not isfinite(dist) or dist<1e-8:raise ValueError('上下の軸中心を離してください')
    a=min(1.,abs(delta['XYZ'.index(root.axis)])/dist);b=sqrt(max(0.,1-a*a))
    return a,b,dist


def central_separation(context,s):
    root=getattr(context.scene,'cjm_double',None)
    projection=pair_projection(root)
    if projection is None:return None
    a,b,dist=projection
    other=root.lower if s.as_pointer()==root.upper.as_pointer() else root.upper
    extent=a*(other.a_width+other.b_width/2+other.axial_gap)+b*max(other.outer_diameter/2+other.swing_clearance,other.axle_diameter/2+other.radial_clearance+other.radial_wall)
    return a,b,dist-extent


def validate(kind,v,opt,s):
    from types import SimpleNamespace as NS
    if kind=='central':
        from .central_math import span
        span(NS(**{**{k:getattr(s,k) for k in ('swing_clearance','support_thickness','embed_depth')},**v}))
    elif kind=='rotary':
        from .hinge_maker.face_hinge_math import plan_ab_span,plan_shoulder_head
        p=plan_ab_span(a_width=v['a_width'],b_width=v['b_width'],gap=v['axial_gap'],outer_diameter=v['outer_diameter'],axle_diameter=v['axle_diameter'],radial_clearance=v['radial_clearance'],cap_wall=v['cap_wall'],tip_clearance=v['shoulder_axial_clearance'] if opt['shoulder'] else v['tip_clearance'],min_radial_wall=v['radial_wall'])
        if opt['shoulder']:plan_shoulder_head(p,shoulder_diameter=v['shoulder_diameter'],shoulder_thickness=v['shoulder_thickness'],shoulder_radial_clearance=v['shoulder_radial_clearance'],shoulder_axial_clearance=v['shoulder_axial_clearance'],min_radial_wall=v['radial_wall'])
    elif kind=='trunnion':
        from .hinge_maker.face_hinge_math import plan_trunnion
        plan_trunnion(socket_min=opt['socket_min'],socket_max=opt['socket_max'],**v)
    elif kind=='swap':
        from .swap_math import plan,Spec
        plan(Spec(**v,flange=s.flange,lug_count=int(s.lug_count),direction=int(s.direction)))
    elif kind=='hinge':
        # Radial/overall-length repair only. Existing linked length/axle checks stay authoritative.
        if s.hinge_style=='INTEGRATED_AXLE' and min(v['pin_clearance'],v['knuckle_gap'])<=0:raise ValueError('一体造形には正の隙間が必要です')
        from . import hinge_maker as h
        class Proxy:
            def __getattr__(self,k):return v[k] if k in v else getattr(s,k)
        proxy=Proxy();specs,axle,total=h.resolved_hinge_geometry(proxy)
        if s.make_body_relief:h.resolve_face_clearance(proxy.knuckle_gap,s.face_clearance_follow_gap,s.face_clearance)
        if s.hinge_style=='INTEGRATED_AXLE' and s.axle_end_mode=='BLIND':h._blind_bore_plan(proxy,specs,axle,total)
        if s.make_support_bridges and s.bridge_max_reach<=v['outer_diameter']/2:raise ValueError('接続距離上限はヒンジ半径より大きくしてください')


def restore_dimensions(read,write,original):
    """Best-effort rollback, verify all original observed values afterwards."""
    with suspended():
        for _ in range(2):
            for k,x in original.items():
                if read()[k]==x:continue
                try:write(k,x)
                except (ValueError,RuntimeError,TypeError,OverflowError,AttributeError):pass
    actual=read()
    return [k for k,x in original.items() if actual[k]!=x]


def hinge_distribution(s):
    """Simple allocation fallback: preserve total, reserve blind-cap space.
    Store the allocation in the same reference fields as manual length editing.
    No change to total, gap or safety thresholds is made here.
    """
    if lock_state(s,'center_ratio')=='LOCKED':return None
    from .hinge_maker.dimension_math import auto_lengths,manual_lengths
    if s.hinge_style=='INTEGRATED_AXLE' and s.axle_end_mode=='TRIM':return None
    usable=s.total_length-2*s.knuckle_gap
    if usable<=0:return None
    if s.get('_hm_manual_lengths',False):
        side,center=manual_lengths(s.total_length,s.knuckle_gap,s.get('_hm_ref_usable',0),s.get('_hm_ref_side',0),s.get('_hm_ref_center',0))
    else:side,center=auto_lengths(s.total_length,s.knuckle_gap,s.length_mode,s.center_ratio)
    minimum=cm.EPS*2
    if s.hinge_style=='INTEGRATED_AXLE' and s.axle_end_mode=='BLIND' and s.axle_follow_side_centers:
        minimum=max(minimum,2*(s.minimum_cap_wall+s.axle_tip_clearance)+cm.EPS*2)
    maximum=(usable-cm.EPS*2)/2
    if minimum>maximum:return None
    corrected=max(minimum,min(maximum,side))
    if abs(corrected-side)<1e-7 and center>0:return None
    return {'_hm_ref_usable':usable,'_hm_ref_side':corrected,'_hm_ref_center':usable-2*corrected,'_hm_manual_lengths':True}


def run(context,s,kind,edited=None):
    # Try preserving the total before falling back to the existing solver.
    # Allocation is an ordinary lockable dimension group, not a new search.
    preferred_allocation=kind=='hinge' and lock_state(s,'center_ratio')=='PREFERRED'
    if preferred_allocation and _run(context,s,kind,edited):return True
    if preferred_allocation and '復元未完了' in s.get('_cjm_constraint_status',''):return False
    if kind=='hinge':
        try:proposal=hinge_distribution(s)
        except (ValueError,RuntimeError,TypeError,OverflowError):proposal=None
        if proposal:
            missing=object();old={k:s.get(k,missing) for k in proposal}
            with suspended():
                for k,x in proposal.items():s[k]=x
            ok=False
            try:ok=_run(context,s,kind,edited)
            finally:
                if not ok:
                    with suspended():
                        for k,x in old.items():
                            if x is missing:del s[k]
                            else:s[k]=x
            if ok:
                s['_cjm_constraint_status']='長さ配分を補正 / '+s['_cjm_constraint_status'];return True
            if '復元未完了' in s.get('_cjm_constraint_status',''):return False
    if preferred_allocation:return False
    return _run(context,s,kind,edited)


def _run(context,s,kind,edited=None):
    adj,protected=CONFIG[kind]
    try:opt=options(s,kind,context)
    except (ValueError,RuntimeError,TypeError,OverflowError) as exc:
        s['_cjm_constraint_status']='補正不可：'+str(exc);return False
    original={k:float(getattr(s,k)) for k in (*adj,*protected)}
    bounds={k:(float(s.bl_rna.properties[k].hard_min),float(s.bl_rna.properties[k].hard_max)) for k in adj}
    locked={k for k in adj if lock_state(s,k)=='LOCKED'}
    preferred={k for k in adj if lock_state(s,k)=='PREFERRED'}
    # User floor is a limit on automatic reductions, not a retroactive
    # override of intentionally entered smaller positive values.
    floor=float(getattr(context.scene.cjm_settings,'constraint_clearance_floor',.01))
    for k in DEFAULT_LOCKED.intersection(bounds)-{'wall'}:
        lo,hi=bounds[k];bounds[k]=(min(hi,max(lo,min(floor,original[k]) if original[k]>0 else floor,cm.EPS)),hi)
    if kind=='swap':
        lo,hi=bounds['wall'];bounds['wall']=(max(.2,lo),hi)
    if kind=='hinge' and opt['trim']:locked.add('total_length')
    try:
        result=cm.repair(kind,original,opt,bounds,locked,edited,validator=lambda v:validate(kind,v,opt,s),preferred=preferred)
        if not result.ok:raise ValueError(result.reason)
        validate(kind,result.values,opt,s)
    except (ValueError,RuntimeError,TypeError,OverflowError) as exc:
        s['_cjm_constraint_status']='補正不可：'+str(exc);return False
    changes={k:x for k,x in result.values.items() if k in adj and abs(x-original[k])>1e-7}
    focus={k:getattr(s,k) for k in ('live_focus','guide_focus','live_view_mode') if hasattr(s,k)}
    try:
        with suspended():
            for k,x in changes.items():setattr(s,k,x)
            actual={k:float(getattr(s,k)) for k in original}
            if any(actual[k]!=original[k] for k in locked|set(protected)):raise ValueError('固定値が変化しました')
            if any(actual[k]!=original[k] for k in original if k not in changes):raise ValueError('予定外の寸法が変化しました')
            for k,(lo,hi) in bounds.items():
                if abs(actual[k]-original[k])>1e-7 and not lo-2e-6<=actual[k]<=hi+2e-6:raise ValueError('補正範囲外')
            if any(r.deficit(actual)>2e-6*max(1,abs(r.minimum)) for r in cm.rules(kind,actual,opt)):raise ValueError('数値丸め後の制約不成立')
            validate(kind,actual,opt,s)
    except (ValueError,RuntimeError,TypeError,OverflowError) as exc:
        # RNA update callbacks can affect fields outside the planned changes.
        # Restore the entire observed dimension set, not just the proposals.
        remaining=restore_dimensions(lambda:{k:float(getattr(s,k)) for k in original},lambda k,x:setattr(s,k,x),original)
        s['_cjm_constraint_status']='補正不可：'+str(exc)+(' / 復元未完了：'+', '.join(remaining) if remaining else '')
        return False
    finally:
        with suspended():
            for k,x in focus.items():setattr(s,k,x)
    changes={k:x for k,x in actual.items() if k in adj and abs(x-original[k])>1e-7}
    def label(k):return s.bl_rna.properties[k].name
    s['_cjm_constraint_status']=' / '.join(f'{label(k)} {original[k]:.5g} → {actual[k]:.5g}' for k in changes) or '対象寸法の補正不要'
    snapshot(s,kind)
    return True


def pair_ready(context):
    root=getattr(context.scene,'cjm_double',None)
    if root is None or not all(getattr(j,'pivot_set',False) for j in (root.upper,root.lower)):return False
    if root.design=='CENTRAL':return True
    return all(getattr(root,'object_'+k,None) is not None for k in ('a','b','c')) and all(getattr(root,'face_'+k,-1)>=0 for k in ('a','bu','bl','c'))


def legacy_check(root, values):
    """Reuse the actual generation planner on read-only candidate settings."""
    from types import SimpleNamespace as NS
    from . import double_math as dm
    dm.validate_registration(root)
    from . import double_joint as dj
    from .hinge_maker import face_hinge as fh
    from mathutils import Vector
    plans=[]
    for side,j in (('UPPER',root.upper),('LOWER',root.lower)):
        spec=dj.pair_settings(root,j,side)
        for k,x in values[side.lower()].items():setattr(spec,k,x)
        plans.append(fh._plan(NS(scene=NS(cursor=NS(location=Vector(j.pivot)))),spec))
    dm.separation(*plans)


def run_pair(context,side=None,edited=None):
    """Atomic paired repair. No geometry operations; axes are immutable inputs."""
    root=context.scene.cjm_double
    joints={'upper':root.upper,'lower':root.lower}
    kind='central' if root.design=='CENTRAL' else 'rotary'
    pair_kind='central_pair' if kind=='central' else 'legacy_pair'
    adj,protected=CONFIG[kind]
    original={};bounds={};locked=set();preferred=set();opt={}
    def key(p,k):return p+'.'+k
    def local(v,p):return {k:v[key(p,k)] for k in (*adj,*protected)}
    def read():return {key(p,k):float(getattr(j,k)) for p,j in joints.items() for k in (*adj,*protected)}
    def status(msg):
        for j in joints.values():j['_cjm_constraint_status']=msg
    try:
        if kind=='rotary':
            from . import double_math as dm
            dm.validate_registration(root)
        opt['projection']=pair_projection(root)
        if opt['projection'] is None:raise ValueError('上下の軸中心を登録してください')
        original=read()
        floor=float(getattr(context.scene.cjm_settings,'constraint_clearance_floor',.01))
        for p,j in joints.items():
            opt[p]={'shoulder':kind=='rotary' and j.shoulder_enabled,'length':j.get('_cjm_length_'+kind)}
            if kind=='rotary':
                delta=root.lower.pivot['XYZ'.index(root.axis)]-root.upper.pivot['XYZ'.index(root.axis)]
                forward=(delta>=0)==(p=='upper')
                opt[p]['toward_width']='b_width' if forward!=j.reverse_axis else 'a_width'
            for k in adj:
                q=key(p,k);lo=float(j.bl_rna.properties[k].hard_min);hi=float(j.bl_rna.properties[k].hard_max)
                if k in DEFAULT_LOCKED:lo=min(hi,max(lo,min(floor,original[q]) if original[q]>0 else floor,cm.EPS))
                bounds[q]=(lo,hi)
                state=lock_state(j,k)
                if state=='LOCKED':locked.add(q)
                elif state=='PREFERRED':preferred.add(q)
        def check(v):
            if kind=='rotary':
                for p,j in joints.items():validate(kind,local(v,p),opt[p],j)
                legacy_check(root,{p:local(v,p) for p in joints});return
            a,b,d=opt['projection'];extent=0.
            for p,j in joints.items():
                q=local(v,p);validate(kind,q,opt[p],j)
                extent+=a*(q['a_width']+q['b_width']/2+q['axial_gap'])+b*max(q['outer_diameter']/2+q['swing_clearance'],q['axle_diameter']/2+q['radial_clearance']+q['radial_wall'])
            if not d>extent:raise ValueError('上下のヒンジ加工領域が重なります')
        result=cm.repair(pair_kind,original,opt,bounds,locked,key(side.lower(),edited) if side and edited else None,limit=4096,validator=check,preferred=preferred)
        if not result.ok:raise ValueError(result.reason)
        check(result.values)
    except (ValueError,RuntimeError,TypeError,OverflowError) as exc:
        status('補正不可：'+str(exc));return False
    changes={q:x for q,x in result.values.items() if q in bounds and abs(x-original[q])>1e-7}
    focus={p:getattr(j,'live_focus',None) for p,j in joints.items()};active=getattr(root,'active_joint',None)
    try:
        with suspended():
            for q,x in changes.items():
                p,k=q.split('.');setattr(joints[p],k,x)
            actual=read()
            for q in locked|{key(p,k) for p in joints for k in protected}:
                if actual[q]!=original[q]:raise ValueError('固定値が変化しました')
            if any(actual[q]!=original[q] for q in original if q not in changes):raise ValueError('予定外の寸法が変化しました')
            for q,(lo,hi) in bounds.items():
                if abs(actual[q]-original[q])>1e-7 and not lo-2e-6<=actual[q]<=hi+2e-6:raise ValueError('補正範囲外')
            if any(r.deficit(actual)>2e-6*max(1,abs(r.minimum)) for r in cm.rules(pair_kind,actual,opt)):raise ValueError('数値丸め後の制約不成立')
            check(actual)
    except (ValueError,RuntimeError,TypeError,OverflowError) as exc:
        def write(q,x):
            p,k=q.split('.');setattr(joints[p],k,x)
        remaining=restore_dimensions(read,write,original)
        status('補正不可：'+str(exc)+(' / 復元未完了：'+', '.join(remaining) if remaining else ''));return False
    finally:
        with suspended():
            for p,j in joints.items():
                if focus[p] is not None:j.live_focus=focus[p]
            if active is not None:root.active_joint=active
    for p,j in joints.items():
        msg=[]
        for q in changes:
            if q.startswith(p+'.'):
                k=q.split('.')[1];msg.append(f'{j.bl_rna.properties[k].name} {original[q]:.5g} → {actual[q]:.5g}')
        j['_cjm_constraint_status']='上下連動：'+(' / '.join(msg) or '対象寸法の補正不要')
        snapshot(j,kind)
    return True


def changed(s,context,engine,prop,side=''):
    if _busy:return
    st=getattr(getattr(context,'scene',None),'cjm_settings',None)
    if st is None or not st.auto_constraints:return
    obj,kind=target(context,engine,side)
    if obj is None or obj.as_pointer()!=s.as_pointer():return
    if kind=='hinge' and prop in ('center_ratio','side_length_edit','center_length_edit','length_mode'):
        run(context,s,kind);return
    if prop not in (*CONFIG[kind][0],*CONFIG[kind][1],'lug_count','shoulder_enabled','make_socket','make_shaft','make_motion_cut'):return
    # Keep existing LIVE focus on the user's edit, not the correction target.
    focus={k:getattr(s,k) for k in ('live_focus','guide_focus','live_view_mode') if hasattr(s,k)}
    paired=engine=='double' and pair_ready(context)
    ok=run_pair(context,side,prop) if paired else run(context,s,kind,prop)
    if not ok:
        # Reject an impossible single edit when the last observed values still
        # match. Never restore unrelated fields or a stale snapshot.
        try:old=json.loads(s.get('_cjm_snapshot_'+kind,'{}'))
        except (ValueError,TypeError):old={}
        other_ok=True
        if paired:
            root=context.scene.cjm_double;other=root.lower if side=='UPPER' else root.upper
            try:other_old=json.loads(other.get('_cjm_snapshot_'+kind,'{}'));other_ok=bool(other_old) and all(getattr(other,k)==x for k,x in other_old.items())
            except (ValueError,TypeError):other_ok=False
        if other_ok and prop in old and all(getattr(s,k)==x for k,x in old.items() if k!=prop):
            requested=getattr(s,prop);reason=s['_cjm_constraint_status']
            with suspended():
                setattr(s,prop,old[prop])
            try:
                adj,protected=CONFIG[kind];v={k:float(getattr(s,k)) for k in (*adj,*protected)};opt=options(s,kind,context)
                if any(r.deficit(v)>2e-6*max(1,abs(r.minimum)) for r in cm.rules(kind,v,opt)):raise ValueError('以前の寸法も不成立')
                validate(kind,v,opt,s)
                if paired:
                    oa,op=CONFIG[kind];ov={k:float(getattr(other,k)) for k in (*oa,*op)};oo=options(other,kind,context)
                    if any(r.deficit(ov)>2e-6*max(1,abs(r.minimum)) for r in cm.rules(kind,ov,oo)):raise ValueError('反対側の以前の寸法も不成立')
                    validate(kind,ov,oo,other)
                    if kind=='rotary':legacy_check(root,{'upper':v if side=='UPPER' else ov,'lower':ov if side=='UPPER' else v})
                s['_cjm_constraint_status']=reason+' / 操作値を元に戻しました'
            except (ValueError,RuntimeError,TypeError,OverflowError):
                with suspended():setattr(s,prop,requested)
    with suspended():
        for k,x in focus.items():setattr(s,k,x)
    if engine=='face':st.face_focus=prop


def lock_button(layout,context,engine,side,prop,s):
    obj,kind=target(context,engine,side)
    if obj is None or obj.as_pointer()!=s.as_pointer():return
    if prop in CONFIG[kind][0]:
        if kind=='hinge' and prop=='total_length' and options(s,kind,context)['trim']:return
        state=lock_state(s,prop);op=layout.operator('cjm.constraint_lock',text='',icon=ICONS[state],depress=state=='LOCKED');op.engine=engine;op.side=side;op.prop=prop
    elif prop in CONFIG[kind][1]:layout.label(text='',icon='INFO')


class CJM_OT_constraint_lock(Operator):
    bl_idname='cjm.constraint_lock';bl_label='自動補正対象の固定切替';bl_options={'UNDO'}
    bl_description='自由 → 優先維持 → 固定 → 自由。固定は自動変更禁止（手動変更可）。全長固定は従来どおりON/OFF'
    engine:StringProperty();side:StringProperty();prop:StringProperty()
    def execute(self,context):
        s,kind=target(context,self.engine,self.side)
        if s is None or not context.scene.cjm_settings.auto_constraints:return {'CANCELLED'}
        if self.prop=='__length__' and kind in ('central','rotary'):
            key='_cjm_length_'+kind
            if key in s:del s[key]
            else:s[key]=length(s,kind)
        elif self.prop in CONFIG[kind][0] or (kind=='hinge' and self.prop=='center_ratio'):
            cycle_lock(s,self.prop)
        else:return {'CANCELLED'}
        snapshot(s,kind)
        return {'FINISHED'}

class CJM_OT_constraint_repair(Operator):
    bl_idname='cjm.constraint_repair';bl_label='現在の寸法を補正';bl_options={'UNDO'}
    def execute(self,context):
        if not context.scene.cjm_settings.auto_constraints:return {'CANCELLED'}
        if context.scene.cjm_settings.mode=='DOUBLE' and pair_ready(context):
            return {'FINISHED'} if run_pair(context) else {'CANCELLED'}
        targets=[target(context,e,side) for e,side in current(context)]
        targets=[(s,k) for s,k in targets if s is not None]
        if not targets:return {'CANCELLED'}
        saved=[(s,k,{p:getattr(s,p) for p in (*CONFIG[k][0],*CONFIG[k][1])}) for s,k in targets]
        for s,k in targets:
            if not run(context,s,k):
                reason=s.get('_cjm_constraint_status','補正不可')
                with suspended():
                    for obj,kind,vals in saved:
                        for prop,val in vals.items():
                            if getattr(obj,prop)!=val:setattr(obj,prop,val)
                        snapshot(obj,kind)
                        obj['_cjm_constraint_status']=reason+' / 一括補正を取り消しました'
                return {'CANCELLED'}
        return {'FINISHED'}


def panel(layout,context):
    st=context.scene.cjm_settings;b=layout.box();b.prop(st,'auto_constraints',text='寸法の自動補正')
    if not st.auto_constraints:return
    if st.mode=='TRUNNION':b.label(text='Bの軸方向範囲で埋め込み長を補正（受けの肉厚は別途確認）',icon='INFO')
    b.label(text='自由 → 優先維持 → 固定 → 自由');b.label(text='鍵：固定 / 盾：優先維持');b.label(text='情報マーク：最低肉厚・閉鎖壁の下限',icon='INFO');b.label(text='隙間の解除は印刷精度に注意',icon='INFO');b.prop(st,'constraint_clearance_floor');b.label(text='手動の小さい正値は維持',icon='INFO')
    if st.mode=='BALL':b.prop(st,'constraint_ball_retention')
    if st.mode=='DOUBLE':
        b.label(text='上下連動補正：軸中心は固定',icon='INFO')
        b.label(text='上下の軸（従来型は面も）を登録すると有効' if not pair_ready(context) else '反対側の自由寸法も調整可能')
    for engine,side in current(context):
        s,kind=target(context,engine,side)
        if s is None:continue
        if side:b.label(text='上側' if side=='UPPER' else '下側')
        if kind=='hinge':
            row=b.row(align=True);state=lock_state(s,'center_ratio');op=row.operator('cjm.constraint_lock',text='長さ配分：'+{'FREE':'自由','PREFERRED':'優先維持','LOCKED':'固定'}[state],icon=ICONS[state]);op.engine=engine;op.side=side;op.prop='center_ratio'
        if kind in ('rotary','central'):
            key='_cjm_length_'+kind;fixed=key in s;row=b.row(align=True);op=row.operator('cjm.constraint_lock',text='全長固定' if not fixed else f'全長固定 {s[key]:.5g}',icon='LOCKED' if fixed else 'UNLOCKED',depress=fixed);op.engine=engine;op.side=side;op.prop='__length__'
            row.label(text=f'現在 {length(s,kind):.5g}')
        msg=s.get('_cjm_constraint_status','対象寸法を変更してください')
        for i in range(0,len(msg),25):b.label(text=msg[i:i+25],icon='ERROR' if i==0 and msg.startswith('補正不可') else 'NONE')
    b.operator('cjm.constraint_repair',icon='FILE_REFRESH');b.label(text='数値制約のみ／Booleanの成功は未保証',icon='INFO')

CLASSES=(CJM_OT_constraint_lock,CJM_OT_constraint_repair)
