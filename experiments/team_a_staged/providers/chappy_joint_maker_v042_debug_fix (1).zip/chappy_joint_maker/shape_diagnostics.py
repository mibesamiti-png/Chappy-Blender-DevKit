"""Structured generation diagnostics. No geometry, RNA writes or auto retries.
A geometric failure is evidence about this attempt, never a proof of infeasibility.
"""
from dataclasses import dataclass, asdict
from contextlib import contextmanager
from math import isfinite
import json

# A stable code is an interface for later candidate selection, not a retry permission.
_HINTS = {
    'BEARING_INITIAL': '受けの位置・外形、軸径、受け幅を確認。最低肉厚と隙間を守る。',
    'BEARING_AFTER_SWEEP': '支持腕幅・厚み、逃げ範囲、凸包の過剰な切削を確認。最低肉厚を削らない。',
    'POSE_INTERFERENCE': '角度刻み・回転逃げ隙間・外形を確認。軸穴の隙間とは区別する。',
    'NEUTRAL_INTERFERENCE': '対象部品の初期配置を確認。A-Cは自動切削しない。',
    'COMPONENT_CHANGED': '分断・結合状態を確認。原因を特定するまで自動変更しない。',
    'NO_CUT': '加工対象とカッターの位置・Boolean結果を確認。',
    'INPUT': '登録面・軸中心・数値制約を確認。',
    'OPERATION_FAILED': '入力メッシュと処理段階を確認。原因未確定のため自動再試行しない。',
}

@dataclass(frozen=True)
class Diagnostic:
    code: str
    phase: str
    message: str
    side: str = ''
    component: str = ''
    angle: float | None = None
    bearing_sign: int | None = None
    measured: float | None = None
    threshold: float | None = None
    unit: str = ''

    def __post_init__(self):
        if self.code not in _HINTS: raise ValueError('unknown diagnostic code')
        for v in (self.angle,self.measured,self.threshold):
            if v is not None and not isfinite(v): raise ValueError('nonfinite diagnostic')

    def lines(self):
        line = self.code + ' / ' + self.phase
        if self.side: line += ' / ' + {'UPPER':'上側','LOWER':'下側'}.get(self.side,self.side)
        if self.component: line += ' / ' + self.component
        if self.bearing_sign is not None: line += f' / 軸方向 {self.bearing_sign:+d}'
        if self.angle is not None: line += f' / 設定角 {self.angle:g}°'
        out=[line]
        if self.measured is not None and self.threshold is not None:
            out.append(f'実測 {self.measured:.6g} / 判定境界 {self.threshold:.6g} {self.unit}')
        out.append(self.message)
        out.append(_HINTS[self.code])
        return out

    def encode(self):
        return json.dumps(asdict(self),ensure_ascii=False,allow_nan=False)

    @classmethod
    def decode(cls, payload):
        return cls(**json.loads(payload))

class ShapeFailure(ValueError):
    def __init__(self, diagnostic):
        self.diagnostic=diagnostic
        super().__init__(diagnostic.message)


def fail(code,phase,message,**kw):
    raise ShapeFailure(Diagnostic(code,phase,message,**kw))

@contextmanager
def operation(phase,side='',component='',angle=None,code='OPERATION_FAILED'):
    """Preserve typed evidence; enrich only previously unclassified exceptions."""
    try:
        yield
    except ShapeFailure:
        raise
    except Exception as exc:
        raise ShapeFailure(Diagnostic(code,phase,str(exc) or type(exc).__name__,side,component,angle)) from exc


def guard_failure(phase,side,component,sign,required,overlap,tolerance):
    """Same strict predicate as original guard check, with measured missing volume."""
    missing=required-overlap
    if missing>tolerance:
        fail('BEARING_INITIAL' if phase=='受け初期検査' else 'BEARING_AFTER_SWEEP',phase,
             'A/Cの軸受け肉厚または閉鎖壁が不足しています。軸位置・可動範囲を見直してください',
             side=side,component=component,bearing_sign=sign,measured=missing,threshold=tolerance,unit='体積（内部単位³）')
