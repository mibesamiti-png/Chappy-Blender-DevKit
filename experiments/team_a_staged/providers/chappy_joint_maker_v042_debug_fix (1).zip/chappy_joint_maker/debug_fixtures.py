"""Opt-in, disposable test inputs. No calls to production generation operators."""
import math
import bpy
from bpy.types import Operator, Panel
from bpy.props import EnumProperty
try:
    from bpy.app.handlers import persistent
except ImportError:
    persistent=lambda f:f

CASES=(
 ('BALL','ボール単体','単体生成の基準位置・試験寸法を設定（本体なし）'),
 ('BALL_QUICK','ボール：クイック取付','取付用の閉じた本体'),
 ('BALL_BODY','ボール：本体受け生成','球キャビティ加工前の本体'),
 ('BALL_SPLIT','ボール：受けの任意分割','球状空洞付きの独立した試験受け'),
 ('HINGE','通常ヒンジ ABA/BAB','向かい合う本体2個'),
 ('FACE','A-B支持腕','向かい合う面を自動登録'),
 ('FACE_HEAD','A-B支持腕＋肩付き軸','抜け止め付き支持腕用'),
 ('ROTARY_SOLO','回転ジョイント単体','肩付き軸の試験寸法と基準位置'),
 ('ROTARY_ATTACH','回転ジョイント直接取付','ナックルに重なる本体2個'),
 ('TRUNNION','側面直付け軸','U字の受けと球状空洞付きソケット'),
 ('SPLIT','共通：任意分割','球状空洞付き立体'),
 ('MOTION','共通：可動干渉検査','0°で非干渉、Z軸90°で干渉する2体'),
 ('DIAG','共通：メッシュ診断','閉じた立体と面が1枚欠けた立体'),
 ('SWAP','頭部交換・着脱ジョイント','試験寸法・入口位置を設定（本体なし）'),
 ('SWAP_ATTACH','着脱：本体・頭部へ直接取付','受け用本体と台座に重なる頭部'),
 ('DOUBLE','二重関節：従来AB+AB','4面・上下2軸・試験寸法を自動登録'),
 ('DOUBLE_CENTRAL','中央支持 ABA+CBC','対称3パーツ・A/C受け本体を自動登録'),
)

# Faces have outward normals; grid cells share vertices and internal faces are removed.
def box_mesh(lo,hi,opened=False):
    x,y,z=lo; X,Y,Z=hi
    v=[(x,y,z),(X,y,z),(X,Y,z),(x,Y,z),(x,y,Z),(X,y,Z),(X,Y,Z),(x,Y,Z)]
    f=[(0,3,2,1),(4,5,6,7),(0,1,5,4),(1,2,6,5),(2,3,7,6),(3,0,4,7)]
    if opened: del f[1]
    return v,f

def yoke_mesh():
    xs=(-10.,-6.4,6.4,10.); ys=(-6.,6.); zs=(-9.,-7.,6.)
    occupied={(0,0,0),(1,0,0),(2,0,0),(0,0,1),(2,0,1)}
    verts=[];faces=[];ids={}; dirs=((0,0,-1),(0,0,1),(0,-1,0),(1,0,0),(0,1,0),(-1,0,0))
    for i,j,k in sorted(occupied):
        v,f=box_mesh((xs[i],ys[j],zs[k]),(xs[i+1],ys[j+1],zs[k+1]))
        for face,d in zip(f,dirs):
            if (i+d[0],j+d[1],k+d[2]) in occupied: continue
            out=[]
            for n in face:
                p=v[n]
                if p not in ids: ids[p]=len(verts);verts.append(p)
                out.append(ids[p])
            faces.append(tuple(out))
    return verts,faces

def socket_mesh(half=8.5,bottom=-8.5,top=4.6,r=5.4,mouth=3.75,n=48):
    """Independent analytic square shell, sphere cavity and cylindrical opening.
    Does not rely on the very Boolean engine being tested."""
    if not (0<mouth<r<half and bottom<-r and top>math.sqrt(r*r-mouth*mouth) and n%8==0):
        raise ValueError('invalid test socket')
    v=[];f=[]; rings=[]
    def ring(z,rad,square=False):
        ids=[]
        for i in range(n):
            a=i*2*math.pi/n; x,y=math.cos(a),math.sin(a)
            fac=rad/max(abs(x),abs(y)) if square else rad
            ids.append(len(v));v.append((fac*x,fac*y,z))
        rings.append(ids)
    ring(bottom,half,True);ring(top,half,True);ring(top,mouth)
    theta=math.asin(mouth/r)
    for j in range(25):
        t=theta+(math.pi-theta)*j/25
        ring(r*math.cos(t),r*math.sin(t))
    for a,b in zip(rings,rings[1:]):
        for i in range(n):
            k=(i+1)%n;f.append((a[i],a[k],b[k],b[i]))
    lo=len(v);v.append((0,0,bottom));hi=len(v);v.append((0,0,-r))
    for i in range(n):
        k=(i+1)%n;f.append((lo,rings[0][k],rings[0][i]));f.append((rings[-1][i],rings[-1][k],hi))
    return v,f

def fixture_specs(case):
    def box(role,lo,hi,opened=False):return role,box_mesh(lo,hi,opened)
    if case in ('BALL','ROTARY_SOLO','SWAP'):return []
    if case=='BALL_QUICK':return [box('Body',(-12,-12,-12),(12,12,7.0))]
    if case=='BALL_BODY':return [box('Body',(-8.5,-8.5,-8.5),(8.5,8.5,4.6))]
    if case in ('BALL_SPLIT','SPLIT'):return [('Socket',socket_mesh())]
    if case=='HINGE':return [box('A',(-6,-9,-3),(6,-3,3)),box('B',(-6,3,-3),(6,9,3))]
    if case in ('FACE','FACE_HEAD'):
        return [box('A',(-3.7,-9,-3),(0.0,-5,3)),box('B',(0.0,5,-3),(4.,9,3))]
    if case=='ROTARY_ATTACH':return [box('A',(-3.7,-8,-2),(-.2,-1.55,2)),box('B',(.2,1.55,-2),(4.,8,2))]
    if case=='TRUNNION':return [('A',yoke_mesh()),('B',socket_mesh(half=6,bottom=-6,top=6,r=4.4,mouth=3.1))]
    if case=='SWAP_ATTACH':return [box('A',(-10,-10,-10),(10,10,0)),box('B',(-9,-9,1),(9,9,5))]
    if case=='DOUBLE_CENTRAL':return [box('A',(-7,-18,-5),(7,-8,5)),box('B',(-3,-5,-3),(3,5,3)),box('C',(-7,8,-5),(7,18,5))]
    if case=='DOUBLE':return [box('A',(-3.7,-18,-3),(0,-13,3)),box('B',(-3.7,-5,-3),(4,5,3)),box('C',(0,13,-3),(4,18,3))]
    if case=='MOTION':return [box('A',(-1,4,-1),(1,7,1)),box('B',(2,-.7,-.7),(8,.7,.7))]
    if case=='DIAG':return [box('Closed',(-5,-2,-2),(-1,2,2)),box('Open',(1,-2,-2),(5,2,2),True)]
    raise ValueError('unknown case')

BALL_VALUES=dict(placement_mode='CURSOR',use_reference_rotation=False,global_scale=1.,outer_shape='SPHERE',ball_diameter=10.,clearance=.4,wall_thickness=2.,opening_diameter=7.5,make_socket=True,make_shaft=True,shaft_diameter=3.2,shaft_length=10.,make_socket_shaft=False,make_motion_cut=False,make_dowels=False,split_axis='X',keep_whole_socket=False,mount_include_socket_shaft=False,body_receiver_cut_depth=0.,body_receiver_plane_axis='WORLD_X',body_receiver_plane_offset=0.,body_receiver_flip=False,body_receiver_make_dowels=False,body_receiver_show_split_guides=False,mount_clearance=.4,mount_make_insertion_path=False,body_receiver_hide_source=True)
FACE_VALUES=dict(axis='X',reverse_axis=False,a_width=3.5,b_width=3.5,outer_diameter=5.,axle_diameter=2.,radial_clearance=.4,axial_gap=.4,cap_wall=.8,radial_wall=.35,tip_clearance=.4,shoulder_diameter=3.4,shoulder_thickness=.5,shoulder_radial_clearance=.4,shoulder_axial_clearance=.35,support_width=1.8,support_thickness=2.2,embed_depth=.5,minimum_angle=-20.,maximum_angle=20.,angle_step=5.,swing_clearance=.4,preview_angle=0.,pin_projection=2.5,pin_embed=.5,hide_originals=True)
HINGE_VALUES=dict(axis_mode='WORLD_X',axis_flip=False,layout_mode='ABA',total_length=10.,outer_diameter=4.,pin_diameter=2.,pin_clearance=.4,knuckle_gap=.4,face_clearance_follow_gap=True,make_body_relief=True,body_relief_clearance=.4,length_mode='CENTER_LONG',center_ratio=1.4,make_support_bridges=True,bridge_embed=.6,bridge_width_ratio=.65,bridge_max_reach=40.,hinge_style='INTEGRATED_AXLE',axle_end_mode='BLIND',axle_tip_clearance=.4,minimum_cap_wall=.8,minimum_radial_wall=.4,axle_follow_side_centers=True,axle_prevent_overrun=True,attach_mode='APPLY')

def set_values(s,values):
    for k,v in values.items():setattr(s,k,v)

def remember_face(s,side,obj,index):
    p=obj.data.polygons[index];setattr(s,'object_'+side,obj);setattr(s,'face_'+side,index)
    setattr(s,'signature_'+side,','.join(str(i) for i in p.vertices))

def configure(context,case,objs):
    from . import ui
    scene=context.scene; st=scene.cjm_settings
    ui.live_off(scene)
    if case.startswith('BALL'):
        st.mode='BALL';st.ball_section='GENERATE' if case=='BALL' else 'MOUNT'
        b=scene.ball_joint_settings;set_values(b,BALL_VALUES)
        b.mount_target=objs.get('Body');b.mount_cutter=None;b.body_receiver_split_target=objs.get('Socket')
        b.live_view_mode='JOINT' if case=='BALL' else ('MOUNT' if case=='BALL_QUICK' else 'BODY')
        b.body_receiver_show_split_guides=case=='BALL_SPLIT'
    elif case=='HINGE':
        st.mode='HINGE';s=scene.hinge_maker_settings;set_values(s,HINGE_VALUES);s.object_a=objs['A'];s.object_b=objs['B']
    elif case in ('FACE','FACE_HEAD','ROTARY_SOLO','ROTARY_ATTACH','TRUNNION'):
        st.mode='TRUNNION' if case=='TRUNNION' else 'ROTARY'
        if case!='TRUNNION':st.rotary_section={'ROTARY_SOLO':'SOLO','ROTARY_ATTACH':'ATTACH'}.get(case,'FACE')
        s=scene.face_hinge_settings;s.mode='TRUNNION' if case=='TRUNNION' else 'STRAIGHT'
        s.shoulder_enabled=False;set_values(s,FACE_VALUES);s.shoulder_enabled=case in ('FACE_HEAD','ROTARY_SOLO','ROTARY_ATTACH')
        s.object_a=objs.get('A');s.object_b=objs.get('B');s.face_a=s.face_b=-1;s.signature_a=s.signature_b=''
        if case in ('FACE','FACE_HEAD'):
            remember_face(s,'a',objs['A'],4);remember_face(s,'b',objs['B'],2)
    elif case in ('DOUBLE','DOUBLE_CENTRAL'):
        from . import double_joint as dj
        from mathutils import Vector
        st.mode='DOUBLE';s=scene.cjm_double;s.axis='X';s.status='';s.last_generation_diagnostic='';s.last_shape_candidates='';s.hide_originals=True;s.design='CENTRAL' if case=='DOUBLE_CENTRAL' else 'LEGACY'
        for k in 'abc':setattr(s,'object_'+k,None)
        for slot,role,index in [('a','A',4),('bu','B',2),('bl','B',4),('c','C',2)]:dj.remember(s,slot,objs[role],index)
        for j,y,angle in ((s.upper,-9,45),(s.lower,9,90)):
            for k,(v,_,_) in dj.FIELDS.items():setattr(j,k,v)
            j.shoulder_enabled=case=='DOUBLE';j.reverse_axis=False;j.minimum_angle=0.;j.maximum_angle=angle;j.preview_angle=0.;j.pivot=scene.cursor.location+Vector((0,y if case=='DOUBLE' else y*10/9,0));j.pivot_set=True;j.live_focus='outer_diameter'
        s.active_joint='UPPER'
    elif case in ('SWAP','SWAP_ATTACH'):
        from .swap_math import Spec
        st.mode='SWAP';s=scene.cjm_swap;defaults=Spec()
        for k in defaults.__dataclass_fields__:
            v=getattr(defaults,k);setattr(s,k,str(v) if k in ('lug_count','direction') else v)
        s.axis='Z';s.pose='SEPARATE';s.status='';s.live_insertion=100;s.live_rotation=0;s.live_focus='diameter'
    else:
        s=scene.cjm_common
        if case=='SPLIT':s.split_target=objs['Socket'];s.split_axis='X';s.hide_split_source=True
        if case=='MOTION':
            s.fixed=objs['A'];s.moving=objs['B'];s.motion_mode='SINGLE';s.motion_axis='Z';s.angle_min=0.;s.angle_max=90.;s.angle_step=15.
            s.motion_axis_2='X';s.motion_axis_3='Y'
            for suffix in ('_2','_3'):
                setattr(s,'angle_min'+suffix,-10.);setattr(s,'angle_max'+suffix,10.);setattr(s,'angle_step'+suffix,10.)
    ui.live_off(scene);ui.redraw(context)


def enabled(context):
    return bool(getattr(getattr(getattr(context,'scene',None),'cjm_settings',None),'debug_enabled',False))

def origin_for(context):
    # Keep test inputs apart from existing mesh bounds, including hidden objects.
    cursor=tuple(context.scene.cursor.location);edges=[]
    for o in context.scene.objects:
        if o.type=='MESH':
            from mathutils import Vector
            edges.extend(float((o.matrix_world@Vector(c)).x) for c in o.bound_box)
    return (max([cursor[0]]+[x+30. for x in edges]),cursor[1],cursor[2])

def create_mesh(col,role,geometry,origin,case):
    verts,faces=geometry;mesh=bpy.data.meshes.new('CJM_TEST_'+role);obj=None
    try:
        mesh.from_pydata(verts,[],faces);mesh.update()
        obj=bpy.data.objects.new('CJM_TEST_'+role,mesh);col.objects.link(obj);obj.location=origin
        obj['cjm_debug_fixture']=True;obj['cjm_debug_case']=case;obj['cjm_debug_role']=role
        if role=='Socket':
            obj['body_receiver_cavity_center']=origin;obj['body_receiver_cavity_radius']=5.4
        return obj
    except Exception:
        if obj is not None:bpy.data.objects.remove(obj,do_unlink=True)
        if mesh.users==0:bpy.data.meshes.remove(mesh)
        raise

class CJM_OT_debug_fixture(Operator):
    bl_idname='cjm.debug_fixture';bl_label='テスト用オブジェクトを準備';bl_options={'REGISTER','UNDO'}
    bl_description='試験用寸法・対象・カーソルを設定。元のメッシュは加工しません'
    case: EnumProperty(items=CASES)
    @classmethod
    def poll(cls,context):return enabled(context) and context.mode=='OBJECT'
    def execute(self,context):
        if not self.poll(context):return {'CANCELLED'}
        if self.case not in {c[0] for c in CASES}:return {'CANCELLED'}
        col=None;objs={};old_cursor=context.scene.cursor.location.copy()
        selected=list(context.selected_objects);active=context.view_layer.objects.active
        try:
            specs=fixture_specs(self.case);origin=origin_for(context)
            if specs:
                col=bpy.data.collections.new('CJM_DEBUG_'+self.case);context.scene.collection.children.link(col)
                col['cjm_debug_fixture']=True
                for role,geo in specs:objs[role]=create_mesh(col,role,geo,origin,self.case)
            context.scene.cursor.location=origin
            context.view_layer.update()
            from . import constraints
            context.scene.cjm_settings.auto_constraints=False
            with constraints.suspended():configure(context,self.case,objs)
            for o in list(context.selected_objects):o.select_set(False)
            for o in objs.values():o.select_set(True)
            context.view_layer.objects.active=objs.get('A' if self.case=='HINGE' else 'B') or next(iter(objs.values()),None)
            context.view_layer.update()
        except Exception as exc:
            if col is not None:
                for o in list(col.objects):
                    mesh=o.data;bpy.data.objects.remove(o,do_unlink=True)
                    if mesh.users==0:bpy.data.meshes.remove(mesh)
                bpy.data.collections.remove(col)
            context.scene.cursor.location=old_cursor
            for o in list(context.selected_objects):o.select_set(False)
            for o in selected:o.select_set(True)
            context.view_layer.objects.active=active
            self.report({'ERROR'},f'試験準備失敗: {exc}');return {'CANCELLED'}
        # Optional viewport framing, no operator dependency for fixture success.
        if getattr(context,'area',None) and context.area.type=='VIEW_3D':
            try:
                region=next(r for r in context.area.regions if r.type=='WINDOW')
                with context.temp_override(region=region):
                    if objs:bpy.ops.view3d.view_selected(use_all_regions=False)
                    else:bpy.ops.view3d.view_center_cursor()
            except Exception:pass
        self.report({'INFO'},'試験準備完了。通常の生成・検査ボタンでテストしてください')
        return {'FINISHED'}

class VIEW3D_PT_cjm_debug(Panel):
    bl_idname='VIEW3D_PT_cjm_debug';bl_label='デバッグ用テストモデル'
    bl_space_type='VIEW_3D';bl_region_type='UI';bl_category='Joint Maker';bl_parent_id='VIEW3D_PT_cjm_root';bl_options={'DEFAULT_CLOSED'}
    def draw(self,context):
        l=self.layout;s=context.scene.cjm_settings;l.prop(s,'debug_enabled',text='デバッグモード',icon='TOOL_SETTINGS')
        if not enabled(context):return
        l.label(text='試験値・登録先・カーソルを変更します',icon='INFO')
        l.label(text='準備後は寸法の自動補正OFF')
        l.label(text='元メッシュ保持 / 新規 CJM_DEBUG_*')
        if context.mode!='OBJECT':l.label(text='オブジェクトモードに切替',icon='ERROR')
        for title,start,end in [('ボールジョイント',0,4),('ヒンジ・回転ジョイント',4,10),('共通加工ツール',10,13),('着脱ジョイント',13,15),('二重関節',15,17)]:
            b=l.box();b.label(text=title);b.enabled=context.mode=='OBJECT'
            for key,label,_ in CASES[start:end]:b.operator('cjm.debug_fixture',text=label,icon='MESH_CUBE').case=key
        l.label(text='生成ボタンは通常の機構パネルにあります')

@persistent
def reset_on_load(_dummy):
    for scene in getattr(bpy.data,'scenes',()):
        st=getattr(scene,'cjm_settings',None)
        if st is not None:st.debug_enabled=False;st.auto_constraints=False
        d=getattr(scene,'cjm_double',None)
        if d is not None:d.live_enabled=False;d.upper.preview_angle=0.;d.lower.preview_angle=0.
        sw=getattr(scene,'cjm_swap',None)
        if sw is not None:sw.live_enabled=False;sw.live_insertion=100;sw.live_rotation=0;sw.live_focus='diameter'

CLASSES=(CJM_OT_debug_fixture,VIEW3D_PT_cjm_debug)
