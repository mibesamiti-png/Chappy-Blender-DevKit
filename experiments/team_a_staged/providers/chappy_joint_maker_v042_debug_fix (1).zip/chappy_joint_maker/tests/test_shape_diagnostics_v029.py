"""Offline evidence tests for the real guard and generation operator bodies.
Blender APIs and geometric measurements are simulated, not physical evidence.
"""
import ast,unittest
from pathlib import Path
from types import SimpleNamespace as NS
from unittest.mock import Mock
from test_constraints_v021 import root
from chappy_joint_maker import shape_diagnostics as d

def extract(file,name,env,cls=None):
    tree=ast.parse((root/file).read_text())
    if cls:tree=next(n for n in tree.body if isinstance(n,ast.ClassDef) and n.name==cls)
    node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
    exec(compile(ast.Module(body=[node],type_ignores=[]),str(root/file),'exec'),env)
    return env[name]

class Diagnostics(unittest.TestCase):
    def test_guard_threshold(self):
        d.guard_failure('受け初期検査','UPPER','A',-1,10,9.5,.5)
        with self.assertRaises(d.ShapeFailure) as cm:
            d.guard_failure('受け初期検査','UPPER','A',-1,10,9.49,.5)
        e=cm.exception.diagnostic
        self.assertEqual((e.code,e.side,e.component,e.bearing_sign),('BEARING_INITIAL','UPPER','A',-1))
        self.assertAlmostEqual(e.measured,.51);self.assertEqual(e.threshold,.5)
    def test_guard_stage(self):
        with self.assertRaises(d.ShapeFailure) as cm:
            d.guard_failure('逃げ加工後検査','LOWER','C',1,10,8,.01)
        self.assertEqual(cm.exception.diagnostic.code,'BEARING_AFTER_SWEEP')
        self.assertEqual(cm.exception.diagnostic.measured,2)
    def test_encode_roundtrip(self):
        e=d.Diagnostic('POSE_INTERFERENCE','可動姿勢検査','干渉','LOWER','C',17.5,measured=.001,threshold=.0001,unit='体積')
        self.assertEqual(d.Diagnostic.decode(e.encode()),e)
        self.assertIn('17.5°',e.lines()[0]);self.assertIn('下側',e.lines()[0])
    def test_unclassified_exception_preserves_cause(self):
        exc=RuntimeError('Boolean failed')
        with self.assertRaises(d.ShapeFailure) as cm:
            with d.operation('可動逃げ加工','UPPER','A',25):raise exc
        self.assertIs(cm.exception.__cause__,exc)
        self.assertEqual(cm.exception.diagnostic.code,'OPERATION_FAILED')
        self.assertEqual(cm.exception.diagnostic.angle,25)
    def test_nested_evidence_preserved(self):
        e=d.Diagnostic('COMPONENT_CHANGED','最終接続検査','分断',component='B',measured=2,threshold=1)
        with self.assertRaises(d.ShapeFailure) as cm:
            with d.operation('外側'):raise d.ShapeFailure(e)
        self.assertIs(cm.exception.diagnostic,e)
    def test_nonfinite_rejected(self):
        with self.assertRaises(ValueError):d.Diagnostic('NO_CUT','test','test',measured=float('nan'))
    def test_actual_guard_body_and_cleanup(self):
        remove=Mock();cylinder=Mock(side_effect=['guard','bore']);apply=Mock()
        fn=extract('central_joint.py','require_guard',dict(diag=d,cylinder=cylinder,bj=NS(boolean_apply=apply),fh=NS(_remove=remove),solid=lambda o:10.,intersect_volume=lambda *a:9.,tolerance=lambda v:1e-6))
        p={'span':NS(guard_end=5.,bore_end=4.,slot_half=2.,guard_radius=2.,bore_radius=1.)}
        with self.assertRaises(d.ShapeFailure) as cm:fn(None,'target',p,None,'逃げ加工後検査','LOWER','C')
        self.assertEqual(cm.exception.diagnostic.code,'BEARING_AFTER_SWEEP');self.assertEqual(cm.exception.diagnostic.bearing_sign,-1)
        self.assertEqual([x.args[0] for x in remove.call_args_list],['bore','guard'])
        apply.assert_called_once_with('guard','bore','DIFFERENCE')
    def test_actual_guard_success_checks_both_sides(self):
        remove=Mock();apply=Mock();fn=extract('central_joint.py','require_guard',dict(diag=d,cylinder=lambda *a:object(),bj=NS(boolean_apply=apply),fh=NS(_remove=remove),solid=lambda o:10.,intersect_volume=lambda *a:10.,tolerance=lambda v:1e-6))
        p={'span':NS(guard_end=5.,bore_end=4.,slot_half=2.,guard_radius=2.,bore_radius=1.)}
        fn(None,'target',p,None,'受け初期検査','UPPER','A');self.assertEqual(apply.call_count,2);self.assertEqual(remove.call_count,4)

class Operator(unittest.TestCase):
    def setup_case(self,plan_error=None,build_error=None):
        # Real execute body, stub Blender API. No actual Boolean.
        self.s=NS(last_generation_diagnostic='stale',status='',hide_originals=False,live_enabled=True)
        self.ctx=NS(scene=NS(cjm_double=self.s),selected_objects=['orig'],view_layer=NS(objects=NS(active='orig')))
        self.col=object();self.destroy=Mock();self.restore=Mock();self.plan=Mock(return_value='plans',side_effect=plan_error);self.build=Mock(return_value=('A','B','C'),side_effect=build_error);self.report=Mock()
        env=dict(diag=d,plans=self.plan,build=self.build,fh=NS(_make_collection=lambda *a:self.col,_destroy_collection=self.destroy),restore_selection=self.restore)
        fn=extract('double_joint.py','execute',env,'CJM_OT_double_generate')
        return fn(NS(poll=lambda c:True,report=self.report),self.ctx)
    def test_failure_cleanup_and_no_retry(self):
        e=d.Diagnostic('BEARING_AFTER_SWEEP','逃げ加工後検査','不足','LOWER','C',measured=.2,threshold=.0001)
        self.assertEqual(self.setup_case(build_error=d.ShapeFailure(e)),{'CANCELLED'})
        self.assertEqual(d.Diagnostic.decode(self.s.last_generation_diagnostic),e)
        self.destroy.assert_called_once_with(self.col);self.restore.assert_called_once_with(self.ctx,('orig',),'orig');self.build.assert_called_once();self.plan.assert_called_once()
    def test_input_failure_no_build(self):
        self.assertEqual(self.setup_case(plan_error=ValueError('未登録')),{'CANCELLED'})
        self.assertEqual(d.Diagnostic.decode(self.s.last_generation_diagnostic).code,'INPUT');self.destroy.assert_not_called();self.build.assert_not_called()
    def test_success_clears_old_failure(self):
        self.assertEqual(self.setup_case(),{'FINISHED'});self.assertEqual(self.s.last_generation_diagnostic,'');self.destroy.assert_not_called();self.restore.assert_called_once_with(self.ctx,('A','B','C'),'C');self.assertFalse(self.s.live_enabled)
    def test_unknown_failure_is_not_infeasibility(self):
        self.assertEqual(self.setup_case(build_error=RuntimeError('unexpected')) ,{'CANCELLED'})
        self.assertEqual(d.Diagnostic.decode(self.s.last_generation_diagnostic).code,'OPERATION_FAILED');self.build.assert_called_once()

class BuildStages(unittest.TestCase):
    def simulate(self,guard_phase=None,pose_hit=False):
        class Identity:
            def copy(self):return self
            def __matmul__(self,v):return v
        self.objects={};self.removed=[];self.guards=[];self.intersections=0
        def stage(context,obj,col,name):
            o=NS(name=name,matrix_world=Identity(),data=NS(vertices=[NS(co=(0,0,0))]))
            self.objects[name]=o;return o
        def guard(context,target,p,col,phase,side,component):
            self.guards.append((phase,side,component))
            if (phase,side)==guard_phase:d.guard_failure(phase,side,component,1,1.,.5,1e-5)
        def intersect(*args):
            self.intersections+=1
            # Two checks per sweep sample (one angle); next is pose validation.
            return .1 if pose_hit and self.intersections==3 else 0.
        env=dict(diag=d,stage=stage,fh=NS(_mesh_components=lambda data:1,_remove=self.removed.append),solid=lambda o:10.,hull_geometry=lambda points:(points,[]),union_checked=Mock(),beam=lambda *a:'beam',cylinder=lambda *a:'cyl',cut=Mock(),require_guard=guard,body_envelope=lambda *a:stage(None,None,None,'envelope'),pose=lambda *a:Identity(),cm=NS(relative_angle=lambda i,a:a if i==0 else -a,inspection_angles=lambda *a:[17.5]),intersect_volume=intersect,tolerance=lambda v:1e-6,bj=NS(boolean_apply=Mock()))
        fn=extract('central_joint.py','build',env)
        span=NS(hub_radius=2,hub_half=2,pin_radius=1,pin_end=4,slot_radius=3,slot_half=2,bore_radius=1.4,bore_end=4.5)
        j=NS(minimum_angle=0.,maximum_angle=45.,angle_step=5.)
        pairs=[(j,dict(span=span,angles=[0.],pad=.4)) for _ in range(2)]
        context=NS(view_layer=NS(update=lambda:None));s=NS(object_a='a',object_b='b',object_c='c')
        return fn(context,s,None,pairs)
    def test_actual_build_initial_guard(self):
        with self.assertRaises(d.ShapeFailure) as cm:self.simulate(('受け初期検査','UPPER'))
        self.assertEqual(cm.exception.diagnostic.code,'BEARING_INITIAL');self.assertEqual(self.intersections,0)
    def test_actual_build_late_guard(self):
        with self.assertRaises(d.ShapeFailure) as cm:self.simulate(('逃げ加工後検査','LOWER'))
        self.assertEqual(cm.exception.diagnostic.code,'BEARING_AFTER_SWEEP');self.assertEqual(cm.exception.diagnostic.component,'C');self.assertEqual(len(self.removed),4)
        self.assertEqual(len(self.guards),4)
    def test_actual_build_pose_evidence(self):
        with self.assertRaises(d.ShapeFailure) as cm:self.simulate(pose_hit=True)
        e=cm.exception.diagnostic;self.assertEqual(e.code,'POSE_INTERFERENCE');self.assertEqual(e.angle,17.5);self.assertEqual(e.measured,.1);self.assertEqual(len(self.removed),2)

if __name__=='__main__':unittest.main()
