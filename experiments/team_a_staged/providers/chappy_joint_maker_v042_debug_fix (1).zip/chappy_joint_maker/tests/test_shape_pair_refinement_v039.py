"""Bounded local pair search; mock generation only."""
import json, unittest
from unittest.mock import Mock, patch
from types import SimpleNamespace as NS
import test_shape_pairs_v037 as pair_tests
from test_shape_diagnostics_v029 import extract
from test_constraints_v022 import lock
from chappy_joint_maker import shape_candidates as p, shape_trials as t, shape_comparison as c, shape_apply as a, shape_diagnostics as d

class PairRefinement(unittest.TestCase):
    def setUp(self):
        pair_tests.Pairs.setUp(self)
        self.payload=pair_tests.Pairs.pair(self);self.parents=json.loads(self.payload)['candidates']
        self.result={'status':'DONE','source':'1','rows':[{'item':i,'result':{'status':'PASS'}} for i in self.parents]}
        self.s.last_shape_candidates=self.payload;self.s.last_shape_comparison=c.encode(self.payload,self.result)
    def refine(self):return p.pair_refinement(self.payload,self.result,self.e,self.data,self.s)
    def items(self):return json.loads(self.refine())['candidates']
    def test_candidates(self):
        items=self.items();self.assertEqual(len(items),3);self.assertEqual(items[0],self.parents[0]);self.assertEqual(items,p.recompute(self.refine(),self.e,self.data))
        self.assertEqual(p.inputs(self.ctx,self.s),self.data)
        for item in items[1:]:
            self.assertLess(p.pair_cost(item),p.pair_cost(items[0]))
            for old,new in zip(items[0]['changes'],item['changes']):
                self.assertEqual(old['key'],new['key']);self.assertTrue(min(old['before'],old['after'])<=new['after']<=max(old['before'],old['after']));self.assertNotEqual(new['after'],new['before'])
        self.assertEqual(sum(x['after']!=y['after'] for x,y in zip(items[0]['changes'],items[1]['changes'])),2)
        self.assertEqual(sum(x['after']!=y['after'] for x,y in zip(items[0]['changes'],items[2]['changes'])),1)
    def test_numeric_filter(self):
        parent=self.parents[0];real=p.numerically_valid;old=self.data[0]
        def valid(v,opt,extras):
            delta=[abs(v[k]-old[k]) for k in old if v[k]!=old[k]]
            if len(delta)==2 and p.pair_cost({'changes':[dict(ch,after=v[ch['side'].lower()+'.'+ch['key']]) for ch in parent['changes']]})<p.pair_cost(parent):return False
            return real(v,opt,extras)
        with patch.object(p,'numerically_valid',side_effect=valid):self.assertEqual(self.refine(),'')
    def test_missing_source(self):del self.result['source'];self.assertEqual(self.refine(),'')
    def test_no_pass(self):self.result['rows'][0]['result']['status']='IMPROVED';self.assertEqual(self.refine(),'')
    def test_incomplete(self):self.result['status']='ERROR';self.assertEqual(self.refine(),'')
    def test_wrong_rows(self):self.result['rows']=[];self.assertEqual(self.refine(),'')
    def test_no_recursion(self):self.assertEqual(p.pair_refinement(self.refine(),self.result,self.e,self.data,self.s),'')
    def test_invalid_index(self):
        for idx in (-1,True,None,3):self.assertEqual(p.pair_refined_propose(self.e,self.data,json.loads(self.payload)['keys'],idx),[])
    def test_tampered(self):
        r=json.loads(self.refine());r['candidates'][1]['changes'][0]['after']*=.9;self.s.last_shape_candidates=json.dumps(r);self.assertRaises(ValueError,t.select,self.ctx,self.s,1)
    def test_lock(self):
        self.s.last_shape_candidates=self.refine();lock(self.u,self.parents[0]['changes'][0]['key']);self.assertRaises(ValueError,t.select,self.ctx,self.s,0)
    def run_compare(self,outcomes):
        items=self.items();fn=Mock(side_effect=outcomes);r=c.run(self.e,None,[(i,i) for i in items],fn,require_first_pass=True);return r,fn
    def test_incumbent_failure_stops(self):
        r,fn=self.run_compare([self.fail,self.fail]);self.assertEqual(r['status'],'STALE');self.assertEqual(fn.call_count,2);self.assertIsNone(r['preferred'])
    def test_keep_incumbent(self):
        r,fn=self.run_compare([self.fail,self.ok,self.fail,self.fail]);self.assertEqual(r['preferred'],0);self.assertEqual(fn.call_count,4)
    def test_prefer_joint_midpoint(self):
        r,fn=self.run_compare([self.fail,self.ok,self.ok,self.ok]);self.assertEqual(r['preferred'],1);self.assertEqual(fn.call_count,4)
    def test_coordinate_success_and_adoption_gate(self):
        r,fn=self.run_compare([self.fail,self.ok,self.fail,self.ok]);self.assertEqual(r['preferred'],2);payload=self.refine();self.assertEqual(a.passing_item(c.encode(payload,r),payload,self.items(),2,allow_pair=True),self.items()[2])
        self.assertRaises(ValueError,a.passing_item,c.encode(payload,r),payload,self.items(),1,allow_pair=True)
    def test_error_stops(self):
        r,fn=self.run_compare([self.fail,self.ok,t.Outcome('ERROR','bad')]);self.assertEqual(r['status'],'ERROR');self.assertIsNone(r['preferred']);self.assertEqual(fn.call_count,3)
    def operator(self,source):
        attempt=Mock(side_effect=[self.fail,self.ok,self.fail,self.ok]);env=dict(diag=d,candidates=p,trials=NS(select=t.select,proxies=t.proxies,attempt=attempt),comparison=c,adoption=NS(source_signature=Mock(return_value=source)),FIELDS=pair_tests.Pairs.fields(self),bpy=NS(),plans=None,build=None,fh=NS(_make_collection=None,_destroy_collection=None),restore_selection=None,cj=NS(cm=NS(inspection_angles=None)),ui=NS(redraw=Mock()))
        fn=extract('double_joint.py','execute',env,'CJM_OT_double_compare');res=fn(NS(poll=lambda _:True,report=Mock(),pair_refine=True),self.ctx)
        self.assertEqual(p.inputs(self.ctx,self.s),self.data);return res,attempt
    def test_operator(self):
        res,attempt=self.operator(1);self.assertEqual(res,{'FINISHED'},self.s.status);self.assertEqual(attempt.call_count,4);self.assertTrue(p.is_pair_refined(self.s.last_shape_candidates));self.assertEqual(c.display(self.s.last_shape_comparison,self.s.last_shape_candidates)['preferred'],2)
    def test_operator_source_stale(self):
        res,attempt=self.operator(2);self.assertEqual(res,{'CANCELLED'});attempt.assert_not_called();self.assertEqual(self.s.last_shape_candidates,self.payload);self.assertEqual(self.s.last_shape_comparison,'')
    def test_refined_operator_adoption(self):
        # Reuse the v0.3.8 end-to-end extracted operator test, with a new
        # candidate reconstructed from its refined-stage record rather than PAIRED.
        from test_shape_pair_apply_v038 import PairAdoption
        obj=PairAdoption();obj.setUp()
        obj.result['source']='1'
        payload=p.pair_refinement(obj.payload,obj.result,obj.e,obj.data,obj.s)
        obj.payload=payload;obj.items=json.loads(payload)['candidates'];obj.s.last_shape_candidates=payload
        # Select the new coordinate candidate, not the incumbent.
        obj.result={'status':'DONE','rows':[{'item':i,'result':{'status':'PASS'}} for i in obj.items]}
        obj.s.last_shape_comparison=c.encode(payload,obj.result)
        attempt=Mock(side_effect=[obj.failure,obj.ok]);before=p.inputs(obj.ctx,obj.s)[0]
        env=dict(__name__='chappy_joint_maker.double_joint',__package__='chappy_joint_maker',candidates=p,trials=NS(select=t.select,proxies=t.proxies,attempt=attempt),adoption=NS(passing_item=a.passing_item,verify=a.verify,commit=a.commit,commit_many=a.commit_many,source_signature=Mock(return_value=1)),FIELDS=pair_tests.Pairs.fields(obj),bpy=NS(),plans=None,build=None,fh=NS(_make_collection=None,_destroy_collection=None),restore_selection=None,cj=NS(cm=NS(inspection_angles=None)),ui=NS(redraw=Mock()))
        fn=extract('double_joint.py','execute',env,'CJM_OT_double_apply_candidate')
        res=fn(NS(poll=lambda _:True,report=Mock(),index=2),obj.ctx)
        self.assertEqual(res,{'FINISHED'},obj.s.status)
        self.assertEqual(p.inputs(obj.ctx,obj.s)[0],{**before,**{ch['side'].lower()+'.'+ch['key']:ch['after'] for ch in obj.items[2]['changes']}})
        self.assertEqual(attempt.call_count,2);self.assertEqual(obj.s.last_shape_candidates,'')
