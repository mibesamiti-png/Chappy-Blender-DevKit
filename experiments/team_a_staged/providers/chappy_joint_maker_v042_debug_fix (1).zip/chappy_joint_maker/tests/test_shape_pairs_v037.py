"""Bounded two-field hypotheses; synthetic geometry results, not Blender tests."""
import json, unittest
from unittest.mock import Mock, patch
from types import SimpleNamespace as NS
from test_shape_candidates_v030 import fixture, detail
from test_shape_diagnostics_v029 import extract
from test_constraints_v022 import lock, free
from chappy_joint_maker import shape_candidates as p, shape_trials as t, shape_comparison as c, shape_apply as a, shape_diagnostics as d

class Pairs(unittest.TestCase):
    def setUp(self):
        self.u,self.l,self.ctx,self.s=fixture();self.u.preview_angle=self.l.preview_angle=0.
        self.e=detail(unit='volume');self.s.last_generation_diagnostic=self.e.encode()
        self.data=p.inputs(self.ctx,self.s);self.advice=p.capture(self.ctx,self.s,self.e);self.s.last_shape_candidates=self.advice
        self.initial=p.display(self.ctx,self.s,self.e)
        self.record={'status':'DONE','rows':[{'item':i,'result':{'status':'UNCHANGED'}} for i in self.initial]}
        self.fail=t.Outcome('FAILED','failure',self.e);self.ok=t.Outcome('PASS','success')
    def pair(self):return p.pairing(self.advice,self.record,self.e,self.data,self.s)
    def items(self):return json.loads(self.pair())['candidates']
    def test_pair_unchanged_singles(self):
        items=self.items();self.assertEqual(len(items),1);self.assertEqual(items[0]['changes'],self.initial);self.assertEqual(p.inputs(self.ctx,self.s),self.data)
    def test_three_fields_three_pairs(self):
        free(self.u,'swing_clearance');self.u.swing_clearance=.6
        data=p.inputs(self.ctx,self.s);initial=p.propose(self.e,*data);self.assertEqual(len(initial),3)
        out=p.paired_propose(self.e,data,[i['key'] for i in initial]);self.assertEqual(len(out),3)
        self.assertEqual(len({tuple(sorted(i['key'] for i in x['changes'])) for x in out}),3)
    def test_combined_numeric_check(self):
        keys=[i['key'] for i in self.initial];old=self.data[0];real=p.numerically_valid
        def valid(v,options,extras):
            if sum(v[k]!=old[k] for k in old)>1:return False
            return real(v,options,extras)
        with patch.object(p,'numerically_valid',side_effect=valid):
            self.assertEqual(p.propose(self.e,*self.data),self.initial)
            self.assertEqual(p.paired_propose(self.e,self.data,keys),[])
    def test_pass_blocks_pair(self):self.record['rows'][0]['result']['status']='PASS';self.assertEqual(self.pair(),'')
    def test_different_blocks_pair(self):self.record['rows'][0]['result']['status']='DIFFERENT';self.assertEqual(self.pair(),'')
    def test_incomplete_blocks_pair(self):self.record['status']='ERROR';self.assertEqual(self.pair(),'')
    def test_mismatched_rows(self):self.record['rows'].reverse();self.assertEqual(self.pair(),'')
    def test_bad_keys(self):
        k=self.initial[0]['key'];self.assertEqual(p.paired_propose(self.e,self.data,[k,k]),[]);self.assertEqual(p.paired_propose(self.e,self.data,[k,'invalid']),[])
    def test_no_recursion(self):self.assertEqual(p.pairing(self.pair(),self.record,self.e,self.data,self.s),'')
    def test_lock_after(self):self.s.last_shape_candidates=self.pair();lock(self.u,self.initial[0]['key']);self.assertRaises(ValueError,t.select,self.ctx,self.s,0)
    def test_tampered(self):
        payload=json.loads(self.pair());payload['candidates'][0]['changes'][0]['after']*=.8;self.s.last_shape_candidates=json.dumps(payload);self.assertRaises(ValueError,t.select,self.ctx,self.s,0)
    def fields(self):return tuple(k for k in vars(self.u) if k in ('outer_diameter','support_width','a_width','b_width','axle_diameter','radial_clearance','axial_gap','cap_wall','radial_wall','tip_clearance','shoulder_diameter','shoulder_thickness','shoulder_radial_clearance','shoulder_axial_clearance','support_thickness','embed_depth','swing_clearance','angle_step'))
    def test_proxy_both_changes(self):
        item=self.items()[0];base,trial=t.proxies(self.s,self.fields(),item)
        for i in item['changes']:
            self.assertEqual(getattr(base.upper,i['key']),i['before']);self.assertEqual(getattr(trial.upper,i['key']),i['after'])
        self.assertEqual(vars(base.lower),vars(trial.lower));self.assertEqual(p.inputs(self.ctx,self.s),self.data)
    def test_synthetic_synergy_and_no_adopt(self):
        payload=self.pair();items=self.items();self.s.last_shape_candidates=payload
        fn=Mock(side_effect=[self.fail,self.ok]);result=c.run(self.e,None,[(i,i) for i in items],fn)
        self.assertEqual(result['preferred'],0);self.assertEqual(result['rows'][0]['result']['status'],'PASS');self.assertEqual(fn.call_count,2)
        self.assertRaises(ValueError,a.passing_item,c.encode(payload,result),payload,items,0)
    def test_unknown_error_stops(self):
        item=self.items()[0];fn=Mock(side_effect=[self.fail,t.Outcome('ERROR','bad')]);r=c.run(self.e,None,[(item,1),(item,2)],fn);self.assertEqual(r['status'],'ERROR');self.assertEqual(fn.call_count,2)
    def operator(self,drift=False,stale=False):
        self.s.last_shape_comparison=c.encode(self.advice,self.record)
        attempt=Mock(side_effect=[self.ok if stale else self.fail,self.ok]);sig=Mock(side_effect=[1,1,1,2] if drift else None,return_value=1)
        env=dict(diag=d,candidates=p,trials=NS(select=t.select,proxies=t.proxies,attempt=attempt),comparison=c,adoption=NS(source_signature=sig),FIELDS=self.fields(),bpy=NS(),plans=None,build=None,fh=NS(_make_collection=None,_destroy_collection=None),restore_selection=None,cj=NS(cm=NS(inspection_angles=None)),ui=NS(redraw=Mock()))
        fn=extract('double_joint.py','execute',env,'CJM_OT_double_compare');res=fn(NS(poll=lambda x:True,report=Mock(),pair=True),self.ctx)
        self.assertEqual(p.inputs(self.ctx,self.s),self.data)
        if drift:self.assertEqual(res,{'CANCELLED'});self.assertEqual(self.s.last_shape_candidates,self.advice);self.assertEqual(self.s.last_shape_comparison,'')
        else:
            self.assertEqual(res,{'FINISHED'},self.s.status);r=c.display(self.s.last_shape_comparison,self.s.last_shape_candidates);self.assertEqual(r['status'],'STALE' if stale else 'DONE')
        self.assertEqual(attempt.call_count,1 if drift or stale else 2)
    def test_operator_pair(self):self.operator()
    def test_operator_drift(self):self.operator(drift=True)
    def test_operator_stale(self):self.operator(stale=True)
