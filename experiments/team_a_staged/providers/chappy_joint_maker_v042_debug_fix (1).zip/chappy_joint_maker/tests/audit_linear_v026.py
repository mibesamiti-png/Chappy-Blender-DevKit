"""Offline comparison only; SciPy is not required by Blender addon."""
import itertools, random, json, time
from scipy.optimize import linprog
from test_constraints_v021 import cm

KEYS=('outer_diameter','axle_diameter','a_width','b_width','support_width')
def score(v,o,keys,edited=None,preferred=()):
    diff=[k for k in keys if abs(v[k]-o[k])>1e-7]
    return (int(edited in diff),len(set(preferred)&set(diff)),len(diff),sum(abs(v[k]-o[k])/max(abs(o[k]),1) for k in diff))

def reference_rules(kind,v,opt):
    # Unreduced separation equations: independent of the runtime's new
    # fixed-length substitution. Other local inequalities are shared.
    if kind=='central':
        rr=cm.rules(kind,v,{**opt,'separation':None})
        a,b,d=opt['separation']; sides=('',)
    else:
        rr=[]; a,b,d=opt['projection']; sides=('upper.','lower.')
        for prefix in sides:
            local={k[len(prefix):]:x for k,x in v.items() if k.startswith(prefix)}
            for r in cm.rules('central',local,{**opt[prefix[:-1]],'separation':None}):
                rr.append(cm.Rule(r.name,{prefix+k:c for k,c in r.terms.items()},r.minimum))
    for parts in itertools.product(('slot','guard'),repeat=len(sides)):
        terms={};offset=0.
        for prefix,part in zip(sides,parts):
            terms.update({prefix+'a_width':-a,prefix+'b_width':-a/2,prefix+'axial_gap':-a})
            if part=='slot':terms.update({prefix+'outer_diameter':-b/2,prefix+'swing_clearance':-b})
            else:
                terms.update({prefix+'axle_diameter':-b/2,prefix+'radial_clearance':-b})
                offset+=b*v[prefix+'radial_wall']
        rr.append(cm.Rule('unreduced separation',terms,-d+offset+cm.EPS))
    return rr

def reference(v,opt,bounds,locked=(),edited=None,preferred=(),kind='central'):
    # Fixed support enumeration; exact LP for each subset, weighted L1 via slack variables.
    keys=tuple(k for k in bounds if k not in locked); rr=reference_rules(kind,v,opt)
    subsets=[s for n in range(len(keys)+1) for s in itertools.combinations(keys,n)]
    subsets.sort(key=lambda s:(edited in s,len(set(s)&set(preferred)),len(s)))
    best=None; bestscore=None
    for s in subsets:
        tier=(int(edited in s),len(set(s)&set(preferred)),len(s))
        if bestscore is not None and tier>bestscore[:3]:break
        if not s:
            if all(r.deficit(v)<=1e-8 for r in rr):return dict(v)
            continue
        n=len(s); A=[]; b=[]
        for r in rr:
            A.append([-r.terms.get(k,0) for k in s]+[0]*n)
            b.append(sum(c*v[k] for k,c in r.terms.items() if k not in s)-r.minimum)
        for i,k in enumerate(s):
            for sign in (1,-1):
                row=[0.]*(2*n);row[i]=sign;row[n+i]=-1;A.append(row);b.append(sign*v[k])
        lp=linprog([0]*n+[1/max(abs(v[k]),1) for k in s],A_ub=A,b_ub=b,bounds=[bounds[k] for k in s]+[(0,None)]*n,method='highs')
        if lp.success:
            x={**v,**dict(zip(s,lp.x[:n]))}; sc=score(x,v,bounds,edited,preferred)
            if bestscore is None or sc<bestscore:best=x;bestscore=sc
    return best

def cases():
    rng=random.Random(2601)
    for i in range(200):
        v=dict(outer_diameter=rng.uniform(2,8),axle_diameter=rng.uniform(.5,4),a_width=rng.uniform(1,6),b_width=rng.uniform(1,6),support_width=rng.uniform(1,6),radial_clearance=.4,tip_clearance=.4,axial_gap=.4,swing_clearance=.4,radial_wall=.35,cap_wall=.8)
        keys=KEYS+('radial_clearance','axial_gap') if i>=100 else KEYS
        bounds={k:(.2,10.) if k in KEYS else (.1,1.) for k in keys}
        for k in KEYS:
            if rng.random()<.45:bounds[k]=(max(.2,v[k]-rng.uniform(.05,2)),v[k]+rng.uniform(.05,2))
        locked={k for k in keys if rng.random()<.15}; edited=rng.choice(keys); preferred={k for k in keys if rng.random()<.2}
        opt=dict(length=rng.uniform(5,14),separation=(.6,.8,rng.uniform(3,8)))
        yield i,v,opt,bounds,locked,edited,preferred

def pair_cases():
    rng=random.Random(2602)
    for i in range(60):
        v={}; opt={'projection':(0.6,0.8,rng.uniform(7,18))}; bounds={}
        for side in ('upper','lower'):
            local=dict(outer_diameter=rng.uniform(3,8),axle_diameter=2.,a_width=rng.uniform(2,4),b_width=rng.uniform(2,4),support_width=1.8,radial_clearance=.4,tip_clearance=.4,axial_gap=.4,swing_clearance=.4,radial_wall=.35,cap_wall=.8)
            opt[side]={'length':rng.uniform(7,12) if i%3==0 or (side=='upper' and i%3==1) else None}
            v.update({side+'.'+k:x for k,x in local.items()})
            bounds.update({side+'.'+k:(.2,10.) for k in ('outer_diameter','a_width','b_width')})
        locked={k for k in bounds if rng.random()<.1};edited=rng.choice(tuple(bounds));preferred={k for k in bounds if rng.random()<.2}
        yield i,v,opt,bounds,locked,edited,preferred

def audit(kind='central'):
    stats=dict(cases=0,feasible=0,missed=0,suboptimal=0,matched=0,infeasible=0,unexpected=0); examples=[]
    for i,v,opt,bounds,locked,edited,preferred in (cases() if kind=='central' else pair_cases()):
        ref=reference(v,opt,bounds,locked,edited,preferred,kind=kind); r=cm.repair(kind,v,opt,bounds,locked,edited=edited,preferred=preferred,limit=4096 if kind=='central_pair' else 768)
        stats['cases']+=1
        if ref is None:
            stats['infeasible']+=1
            if r.ok:stats['unexpected']+=1
            continue
        stats['feasible']+=1
        sr=score(ref,v,bounds,edited,preferred); sc=score(r.values,v,bounds,edited,preferred)
        if not r.ok or sc[:3]>sr[:3] or (sc[:3]==sr[:3] and sc[3]>sr[3]+1e-6):
            typ='missed' if not r.ok else 'suboptimal';stats[typ]+=1;examples.append(dict(i=i,type=typ,values=v,options=opt,bounds=bounds,locked=sorted(locked),edited=edited,preferred=sorted(preferred),reference=ref,result=r.values,score=sc,reference_score=sr))
        else:stats['matched']+=1
    return dict(stats=stats,examples=examples)
if __name__=='__main__':
    print(json.dumps({k:audit(k) for k in ('central','central_pair')},ensure_ascii=False,indent=2))
