"""Synthetic search history and extracted operator checks; no Blender runtime."""
import json, unittest
from unittest.mock import Mock
from types import SimpleNamespace as NS
from test_shape_candidates_v030 import fixture,detail
from test_shape_diagnostics_v029 import extract
from test_constraints_v022 import lock
from chappy_joint_maker import shape_candidates as p,shape_comparison as c,shape_trials as t,shape_apply as a,shape_diagnostics as d

class History(unittest.TestCase):
    def setUp(self):
        self.u,self.l,self.ctx,self.s=fixture();self.u.preview_angle=self.l.preview_angle=0.
        self.e=detail(unit='volume');self.s.last_generation_diagnostic=self.e.encode()
        self.data=p.inputs(self.ctx,self.s);initial=p.capture(self.ctx,self.s,self.e)
        items=json.loads(initial)['candidates'];rec={'status':'DONE','rows':[{'item':i,'result':{'status':'PASS'}} for i in items]}
        self.payload=p.refinement(initial,rec,self.e,self.data,self.s)
        self.fail=t.Outcome('FAILED','failure',self.e);self.ok=t.Outcome('PASS','pass')
    def compare(self,payload,outcome):
        items=json.loads(payload)['candidates'];fn=Mock(side_effect=[self.fail,self.ok,outcome]);r=c.run(self.e,None,[(i,i) for i in items],fn,require_first_pass=True);r['source']='1';self.assertEqual(fn.call_count,3);return r
    def advance(self,payload,outcome):return p.refinement(payload,self.compare(payload,outcome),self.e,self.data,self.s)
    def items(self,payload):return json.loads(payload)['candidates']
    def test_success_moves_pass_endpoint(self):
        old=self.items(self.payload);new=self.advance(self.payload,self.ok);parent,mid=self.items(new)
        self.assertEqual(parent,old[1]);self.assertAlmostEqual(mid['after'],(parent['before']+parent['after'])/2,places=5)
        self.assertEqual(p.recompute(new,self.e,self.data),[parent,mid])
    def test_failure_moves_failed_endpoint(self):
        old=self.items(self.payload);new=self.advance(self.payload,self.fail);parent,mid=self.items(new)
        self.assertEqual(parent,old[0]);self.assertAlmostEqual(mid['after'],(parent['after']+old[1]['after'])/2,places=5)
        self.assertNotEqual(mid,old[1])
    def test_bounded_mixed_path(self):
        payload=self.payload;seen=set()
        for step,out in enumerate([self.fail,self.ok,self.fail,self.ok],1):
            self.assertEqual(p.refinement_depth(payload),step);parent,mid=self.items(payload)
            self.assertNotIn(mid['after'],seen);seen.add(mid['after'])
            result=self.compare(payload,out);passed=result['preferred'];self.assertEqual(a.passing_item(c.encode(payload,result),payload,[parent,mid],passed),[parent,mid][passed])
            payload=p.refinement(payload,result,self.e,self.data,self.s)
            if step<4:self.assertTrue(payload)
        self.assertEqual(payload,'');self.assertEqual(p.inputs(self.ctx,self.s),self.data)
    def test_different_failure_stops(self):
        other=t.Outcome('FAILED','other',detail('POSE_INTERFERENCE',unit='volume'))
        self.assertEqual(self.advance(self.payload,other),'')
    def test_unknown_error_stops(self):self.assertEqual(self.advance(self.payload,t.Outcome('ERROR','error')),'')
    def test_missing_source_stops(self):
        r=self.compare(self.payload,self.ok);del r['source'];self.assertEqual(p.refinement(self.payload,r,self.e,self.data,self.s),'')
    def test_wrong_source_stops(self):
        new=self.advance(self.payload,self.ok);r=self.compare(new,self.ok);r['source']='2';self.assertEqual(p.refinement(new,r,self.e,self.data,self.s),'');self.assertRaises(ValueError,p.check_history_source,new,2);p.check_history_source(new,1)
    def test_tampered_history_or_candidates(self):
        new=json.loads(self.advance(self.payload,self.ok));new['history']=['FAIL'];self.s.last_shape_candidates=json.dumps(new);self.assertRaises(ValueError,t.select,self.ctx,self.s,0)
        new['history']=['PASS']*4;self.assertEqual(p.recompute(json.dumps(new),self.e,self.data),[])
    def test_lock_rejects_path(self):
        new=self.advance(self.payload,self.ok);self.s.last_shape_candidates=new;lock(self.u,self.items(new)[0]['key']);self.assertRaises(ValueError,t.select,self.ctx,self.s,0)
    def test_parent_replay_failure(self):
        new=self.advance(self.payload,self.ok);items=self.items(new);fn=Mock(side_effect=[self.fail,self.fail]);r=c.run(self.e,None,[(i,i) for i in items],fn,require_first_pass=True);self.assertEqual(r['status'],'STALE');self.assertEqual(fn.call_count,2);self.assertEqual(p.refinement(new,r,self.e,self.data,self.s),'')
    def operator(self,source):
        self.s.last_shape_candidates=self.payload;self.s.last_shape_comparison=c.encode(self.payload,self.compare(self.payload,self.fail))
        fields=tuple(k for k in vars(self.u) if k in ('outer_diameter','support_width','a_width','b_width','axle_diameter','radial_clearance','axial_gap','cap_wall','radial_wall','tip_clearance','shoulder_diameter','shoulder_thickness','shoulder_radial_clearance','shoulder_axial_clearance','support_thickness','embed_depth','swing_clearance','angle_step'))
        attempt=Mock(side_effect=[self.fail,self.ok,self.ok]);env=dict(diag=d,candidates=p,trials=NS(select=t.select,proxies=t.proxies,attempt=attempt),comparison=c,adoption=NS(source_signature=Mock(return_value=source)),FIELDS=fields,bpy=NS(),plans=None,build=None,fh=NS(_make_collection=None,_destroy_collection=None),restore_selection=None,cj=NS(cm=NS(inspection_angles=None)),ui=NS(redraw=Mock()))
        fn=extract('double_joint.py','execute',env,'CJM_OT_double_compare');result=fn(NS(poll=lambda x:True,report=Mock(),refine=True),self.ctx)
        self.assertEqual(p.inputs(self.ctx,self.s),self.data);return result,attempt
    def test_operator_continues(self):
        result,attempt=self.operator(1);self.assertEqual(result,{'FINISHED'});self.assertEqual(attempt.call_count,3);self.assertEqual(p.refinement_depth(self.s.last_shape_candidates),2)
    def test_operator_mesh_edit_rejects_before_trial(self):
        result,attempt=self.operator(2);self.assertEqual(result,{'CANCELLED'});attempt.assert_not_called();self.assertEqual(self.s.last_shape_candidates,self.payload);self.assertEqual(self.s.last_shape_comparison,'')
