"""Read-only diagnostic hypotheses; no real geometry or Blender runtime."""
import unittest,json
from unittest.mock import Mock
from test_shape_diagnostics_v029 import extract
from types import SimpleNamespace as NS
from test_constraints_v024 import pair
from test_constraints_v022 import lock,free,prefer
from chappy_joint_maker import shape_candidates as p,shape_diagnostics as d


def fixture():
    a,b,ctx=pair(d=12.,outer=5.)
    s=ctx.scene.cjm_double
    for j in (a,b):
        j.minimum_angle=0.;j.maximum_angle=45.;j.angle_step=5.;j.reverse_axis=False
    for k in 'abc':setattr(s,'object_'+k,None)
    for i,k in enumerate(('a','bu','bl','c')):
        setattr(s,'face_'+k,i);setattr(s,'signature_'+k,str(i))
    return a,b,ctx,s


def detail(code='BEARING_AFTER_SWEEP',side='UPPER',**kw):
    args=dict(code=code,phase=p.DIRECTIONS.get(code,('不明',))[0],message='test',side=side,component='A' if side=='UPPER' else 'C',measured=.2,threshold=.001,angle=17.5 if code=='POSE_INTERFERENCE' else None)
    args.update(kw);return d.Diagnostic(**args)

class Candidates(unittest.TestCase):
    def setUp(self):self.a,self.b,self.ctx,self.s=fixture()
    def propose(self,code='BEARING_AFTER_SWEEP',side='UPPER',**kw):return p.propose(detail(code,side,**kw),*p.inputs(self.ctx,self.s))
    def test_after_only_supported_fields_and_no_write(self):
        before=p.inputs(self.ctx,self.s);out=self.propose();self.assertEqual(before,p.inputs(self.ctx,self.s))
        self.assertEqual({x['key'] for x in out},{'outer_diameter','support_width'});self.assertTrue(all(x['side']=='UPPER' and x['after']<x['before'] for x in out))
    def test_initial_guard_candidates(self):
        self.assertEqual({x['key'] for x in self.propose('BEARING_INITIAL')},{'axle_diameter','a_width'})
    def test_fixed_length(self):
        self.a['_cjm_length_central']=2*(self.a.a_width+self.a.axial_gap)+self.a.b_width
        self.assertEqual([x['key'] for x in self.propose('BEARING_INITIAL')],['axle_diameter'])
    def test_lower(self):self.assertTrue(all(x['side']=='LOWER' for x in self.propose(side='LOWER')))
    def test_lock(self):
        lock(self.a,'outer_diameter','support_width');self.assertEqual(self.propose(),[])
    def test_preferred_last(self):
        prefer(self.a,'support_width');self.assertEqual([x['key'] for x in self.propose()],['outer_diameter','support_width'])
    def test_clearance_floor(self):
        free(self.a,'swing_clearance');self.assertNotIn('swing_clearance',[x['key'] for x in self.propose()]);self.a.swing_clearance=.6
        self.assertIn('swing_clearance',[x['key'] for x in self.propose()]);self.assertTrue(all(x['after']>=.4 for x in self.propose() if x['key']=='swing_clearance'))
    def test_pose_direction(self):
        free(self.a,'swing_clearance');out=self.propose('POSE_INTERFERENCE');self.assertEqual(len(out),1);self.assertGreater(out[0]['after'],out[0]['before'])
    def test_pose_locked(self):self.assertEqual(self.propose('POSE_INTERFERENCE'),[])
    def test_pose_separation(self):
        free(self.a,'swing_clearance');self.b.pivot=(0.,0.,5.801)
        self.assertEqual(self.propose('POSE_INTERFERENCE'),[])
    def test_unsupported_or_inconsistent_diagnostic(self):
        for code in ('OPERATION_FAILED','NEUTRAL_INTERFERENCE','NO_CUT','COMPONENT_CHANGED','INPUT'):
            self.assertEqual(self.propose(code),[])
        self.assertEqual(self.propose(component='C'),[]);self.assertEqual(self.propose(measured=.0001),[]);self.assertEqual(self.propose('POSE_INTERFERENCE',angle=None),[])
    def test_invalid_original(self):self.a.axle_diameter=20.;self.assertEqual(self.propose(),[])
    def test_bounds(self):
        self.a.bl_rna.properties['outer_diameter'].hard_min=5.;self.assertNotIn('outer_diameter',[x['key'] for x in self.propose()])
    def test_capture_and_stale(self):
        e=detail();self.s.last_shape_candidates=p.capture(self.ctx,self.s,e)
        self.assertEqual(p.display(self.ctx,self.s,e),self.propose());self.a.outer_diameter=5.1
        self.assertIsNone(p.display(self.ctx,self.s,e))
    def test_policy_and_registration_stale(self):
        e=detail();self.s.last_shape_candidates=p.capture(self.ctx,self.s,e);lock(self.a,'support_width');self.assertIsNone(p.display(self.ctx,self.s,e))
        self.s.last_shape_candidates=p.capture(self.ctx,self.s,e);self.s.face_bu=9;self.assertIsNone(p.display(self.ctx,self.s,e))
    def test_stale_diagnostic(self):
        e=detail();self.s.last_shape_candidates=p.capture(self.ctx,self.s,e);self.assertIsNone(p.display(self.ctx,self.s,detail(side='LOWER')))
    def test_legacy_no_capture(self):self.s.design='LEGACY';self.assertEqual(p.capture(self.ctx,self.s,detail()),'')

class Integration(unittest.TestCase):
    def simulate(self, capture_error=False, success=False):
        a,b,ctx,s=fixture();s.status='';s.hide_originals=False;s.live_enabled=True
        s.last_shape_candidates='old';s.last_generation_diagnostic='old'
        ctx.selected_objects=['original'];ctx.view_layer=NS(objects=NS(active='original'))
        e=detail();build=Mock(return_value=('A','B','C'),side_effect=None if success else d.ShapeFailure(e))
        capture=Mock(side_effect=RuntimeError('advice failed') if capture_error else p.capture)
        destroy=Mock();restore=Mock();report=Mock();col=object()
        env=dict(diag=d,candidates=NS(capture=capture),plans=Mock(return_value='plans'),build=build,fh=NS(_make_collection=lambda *a:col,_destroy_collection=destroy),restore_selection=restore)
        fn=extract('double_joint.py','execute',env,'CJM_OT_double_generate')
        result=fn(NS(poll=lambda c:True,report=report),ctx)
        build.assert_called_once()
        if success:
            self.assertEqual(result,{'FINISHED'});self.assertEqual(s.last_shape_candidates,'');capture.assert_not_called();destroy.assert_not_called()
        else:
            self.assertEqual(result,{'CANCELLED'});destroy.assert_called_once_with(col);restore.assert_called_once_with(ctx,('original',),'original');capture.assert_called_once();self.assertEqual(d.Diagnostic.decode(s.last_generation_diagnostic),e)
            if capture_error:self.assertEqual(s.last_shape_candidates,'')
            else:self.assertTrue(p.display(ctx,s,e))
    def test_failed_attempt_records_advice_without_retry(self):self.simulate()
    def test_advice_failure_preserves_original_error(self):self.simulate(capture_error=True)
    def test_success_clears_advice(self):self.simulate(success=True)

if __name__=='__main__':unittest.main()
