import unittest
from types import SimpleNamespace as NS
from unittest.mock import patch
from test_constraints_v021 import c,cm,ctx,hinge,rotary,Settings, fm
from test_constraints_v022 import lock,prefer
from test_constraints_v024 import pair
from chappy_joint_maker.hinge_maker import knuckle_lengths

class Basic(unittest.TestCase):
    def test_hinge_keep_total_and_cap(self):
        s=hinge(total_length=8.);lock(s,'total_length');self.assertTrue(c.run(ctx('HINGE',s),s,'hinge'))
        self.assertEqual(s.total_length,8.);self.assertEqual(s.axle_tip_clearance,.4)
        a,b,_=knuckle_lengths(s);self.assertGreater(a,2.4);self.assertGreater(b,0.)
    def test_hinge_distribution_lock(self):
        s=hinge(total_length=8.);lock(s,'total_length','center_ratio');self.assertFalse(c.run(ctx('HINGE',s),s,'hinge'));self.assertNotIn('_hm_manual_lengths',s)
    def test_hinge_preferred_fallback(self):
        s=hinge(total_length=8.);lock(s,'total_length');prefer(s,'center_ratio');self.assertTrue(c.run(ctx('HINGE',s),s,'hinge'));self.assertTrue(s['_hm_manual_lengths'])
    def test_hinge_manual_negative_center(self):
        s=hinge();s.update(_hm_manual_lengths=True,_hm_ref_usable=9.2,_hm_ref_side=5.,_hm_ref_center=-.8)
        self.assertTrue(c.run(ctx('HINGE',s),s,'hinge'));self.assertGreater(knuckle_lengths(s)[1],0.)
    def test_hinge_rollback_refs(self):
        s=hinge(total_length=8.,outer_diameter=1.);lock(s,'total_length','outer_diameter','pin_diameter');self.assertFalse(c.run(ctx('HINGE',s),s,'hinge'));self.assertNotIn('_hm_manual_lengths',s)
    def trunnion(self,embed=3.):
        return Settings(axle_diameter=2.,pin_projection=2.5,pin_embed=embed,radial_clearance=.4,tip_clearance=.4,axial_gap=.4)
    def test_trunnion_bounds(self):
        s=self.trunnion();cc=ctx('TRUNNION',s);opt=dict(socket_min=-2.,socket_max=4.,embed_limit=2.)
        self.assertEqual(c.target(cc,'face')[1],'trunnion')
        with patch.object(c,'options',return_value=opt):self.assertTrue(c.run(cc,s,'trunnion','pin_embed'))
        self.assertLess(s.pin_embed,2.);self.assertEqual(s.pin_projection,2.5)
    def test_trunnion_lock(self):
        s=self.trunnion();lock(s,'pin_embed');cc=ctx('TRUNNION',s)
        with patch.object(c,'options',return_value=dict(socket_min=-2.,socket_max=4.,embed_limit=2.)):self.assertFalse(c.run(cc,s,'trunnion'))
        self.assertEqual(s.pin_embed,3.)
    def test_trunnion_zero_manual_gap(self):
        s=self.trunnion(1.);s.axial_gap=0.;cc=ctx('TRUNNION',s)
        with patch.object(c,'options',return_value=dict(socket_min=-2.,socket_max=4.,embed_limit=2.)):self.assertTrue(c.run(cc,s,'trunnion'))
        self.assertEqual(s.axial_gap,0.)
    def legacy(self,delta=(0.,0.,6.)):
        a,b,cc=pair(delta=delta,outer=8.);root=cc.scene.cjm_double;root.design='LEGACY'
        a.reverse_axis=b.reverse_axis=False;a.shoulder_enabled=b.shoulder_enabled=False
        for i,k in enumerate(('a','b','c')):setattr(root,'object_'+k,NS(type='MESH',data=object(),as_pointer=lambda i=i:i+1))
        for i,k in enumerate(('a','bu','bl','c')):setattr(root,'face_'+k,i)
        return a,b,cc
    def test_legacy_radial_pair(self):
        a,b,cc=self.legacy();self.assertTrue(c.pair_ready(cc))
        with patch.object(c,'legacy_check') as check:self.assertTrue(c.run_pair(cc,'UPPER','outer_diameter'));self.assertTrue(check.called)
        self.assertEqual(a.outer_diameter,8.);self.assertLess(b.outer_diameter,4.);self.assertGreater(6-(a.outer_diameter+b.outer_diameter)/2,0.)
    def test_legacy_axial_reverse(self):
        a,b,cc=self.legacy((6.,0.,0.));a.reverse_axis=True
        with patch.object(c,'legacy_check'):self.assertTrue(c.run_pair(cc,'UPPER','a_width'))
        self.assertGreater(6-a.a_width-b.a_width-(a.axial_gap+b.axial_gap)/2,0.)
    def test_legacy_both_locked(self):
        a,b,cc=self.legacy();lock(a,'outer_diameter');lock(b,'outer_diameter')
        with patch.object(c,'legacy_check'):self.assertFalse(c.run_pair(cc))
        self.assertEqual((a.outer_diameter,b.outer_diameter),(8.,5.))
    def test_legacy_planner_rejection(self):
        a,b,cc=self.legacy()
        with patch.object(c,'legacy_check',side_effect=ValueError('support overlap')):self.assertFalse(c.run_pair(cc))
        self.assertEqual((a.outer_diameter,b.outer_diameter),(8.,5.))
