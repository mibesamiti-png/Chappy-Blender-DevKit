"""Paired central hinge constraints and transaction regressions."""
import unittest,math,random
from test_constraints_v021 import c,cm,ctx,rotary,central_math
from test_constraints_v022 import lock,free,prefer


def pair(d=7.,outer=8.,delta=None):
    a=rotary(outer_diameter=outer,pivot_set=True,pivot=(0.,0.,0.))
    b=rotary(pivot_set=True,pivot=delta or (0.,0.,d))
    cc=ctx('DOUBLE',a,b);cc.scene.cjm_double.axis='X';cc.scene.cjm_settings.constraint_clearance_floor=.4
    return a,b,cc


def projection_gap(a,b,cc):
    x,y,d=c.pair_projection(cc.scene.cjm_double)
    def extent(j):
        sp=central_math.span(j)
        return x*sp.guard_end+y*max(sp.slot_radius,sp.guard_radius)
    return d-extent(a)-extent(b)

class Paired(unittest.TestCase):
    def test_preserve_edited_upper_by_lower(self):
        a,b,cc=pair();self.assertTrue(c.run_pair(cc,'UPPER','outer_diameter'))
        self.assertEqual(a.outer_diameter,8.);self.assertLess(b.outer_diameter,5.);self.assertGreater(projection_gap(a,b,cc),0)
    def test_two_changes_required(self):
        a,b,cc=pair(d=6.);self.assertTrue(c.run_pair(cc,'UPPER','outer_diameter'))
        self.assertEqual(a.outer_diameter,8.);self.assertLess(b.outer_diameter,3.5);self.assertLess(b.axle_diameter,2.)
        self.assertGreater(projection_gap(a,b,cc),0);self.assertEqual(b.radial_wall,.35);self.assertEqual(b.radial_clearance,.4)
    def test_both_sides_change_with_bounds(self):
        a,b,cc=pair(d=6.,outer=6.);a.bl_rna.properties['outer_diameter'].hard_min=5.4;b.bl_rna.properties['outer_diameter'].hard_min=4.4
        self.assertTrue(c.run_pair(cc,'UPPER','outer_diameter'));self.assertLess(a.outer_diameter,6.);self.assertLess(b.outer_diameter,5.);self.assertGreater(projection_gap(a,b,cc),0.)
    def test_locked_lower(self):
        a,b,cc=pair();lock(b,'outer_diameter','axle_diameter');self.assertTrue(c.run_pair(cc,'UPPER','outer_diameter'))
        self.assertEqual(b.outer_diameter,5.);self.assertEqual(b.axle_diameter,2.);self.assertLess(a.outer_diameter,8.);self.assertGreater(projection_gap(a,b,cc),0)
    def test_both_locked(self):
        a,b,cc=pair();lock(a,'outer_diameter');lock(b,'outer_diameter');self.assertFalse(c.run_pair(cc,'UPPER','outer_diameter'))
        self.assertEqual((a.outer_diameter,b.outer_diameter),(8.,5.));self.assertIn('補正不可',b['_cjm_constraint_status'])
    def test_reverse_edit(self):
        a,b,cc=pair(outer=5.);b.outer_diameter=8.;self.assertTrue(c.run_pair(cc,'LOWER','outer_diameter'))
        self.assertEqual(b.outer_diameter,8.);self.assertLess(a.outer_diameter,5.)
    def test_preferred_vs_free(self):
        a,b,cc=pair();prefer(a,'outer_diameter');self.assertTrue(c.run_pair(cc));self.assertEqual(a.outer_diameter,8.);self.assertLess(b.outer_diameter,5.)
    def test_preferred_fallback(self):
        a,b,cc=pair();lock(a,'outer_diameter');prefer(b,'outer_diameter');self.assertTrue(c.run_pair(cc));self.assertLess(b.outer_diameter,5.)
    def test_axial_projection_fixed_lengths_impossible(self):
        a,b,cc=pair(outer=5.,delta=(10.,0.,0.));a['_cjm_length_central']=b['_cjm_length_central']=11.3
        self.assertFalse(c.run_pair(cc));self.assertEqual(a.a_width,3.5);self.assertEqual(b.a_width,3.5)
    def test_axial_projection(self):
        a,b,cc=pair(outer=5.,delta=(10.,0.,0.));self.assertTrue(c.run_pair(cc));self.assertGreater(projection_gap(a,b,cc),0)
        self.assertEqual((a.outer_diameter,b.outer_diameter),(5.,5.))
    def test_diagonal_projection_and_lengths(self):
        a,b,cc=pair(outer=8.,delta=(6.,0.,8.));a['_cjm_length_central']=b['_cjm_length_central']=11.3
        self.assertTrue(c.run_pair(cc,'UPPER','outer_diameter'));self.assertGreater(projection_gap(a,b,cc),0)
        self.assertAlmostEqual(c.length(a,'central'),11.3,places=5);self.assertAlmostEqual(c.length(b,'central'),11.3,places=5)
    def test_no_change_if_feasible(self):
        a,b,cc=pair(d=20.);self.assertTrue(c.run_pair(cc));self.assertEqual(a.outer_diameter,8.);self.assertEqual(b.outer_diameter,5.)
    def test_same_axis_center(self):
        a,b,cc=pair(delta=(0.,0.,0.));self.assertFalse(c.run_pair(cc));self.assertIn('軸中心',a['_cjm_constraint_status'])
    def test_callback_pair_and_snapshots(self):
        a,b,cc=pair(outer=5.);c.capture(cc);a.outer_diameter=8.;c.changed(a,cc,'double','outer_diameter','UPPER')
        self.assertEqual(a.outer_diameter,8.);self.assertLess(b.outer_diameter,5.);self.assertEqual(a.pivot,(0.,0.,0.));self.assertEqual(b.pivot,(0.,0.,7.));self.assertIn('上下連動',b['_cjm_constraint_status'])
        import json
        self.assertEqual(json.loads(b['_cjm_snapshot_central'])['outer_diameter'],b.outer_diameter)
    def test_callback_failed_edit_rollback(self):
        a,b,cc=pair(outer=5.);lock(a,'outer_diameter');lock(b,'outer_diameter');c.capture(cc);a.outer_diameter=8.;c.changed(a,cc,'double','outer_diameter','UPPER');self.assertEqual(a.outer_diameter,5.)
    def test_callback_failed_stale_other_not_rollback(self):
        a,b,cc=pair(outer=5.);lock(a,'outer_diameter');lock(b,'outer_diameter');c.capture(cc);b.outer_diameter=5.1;a.outer_diameter=8.;c.changed(a,cc,'double','outer_diameter','UPPER');self.assertEqual(a.outer_diameter,8.)
    def test_operator_pair(self):
        a,b,cc=pair();self.assertEqual(c.CJM_OT_constraint_repair().execute(cc),{'FINISHED'});self.assertGreater(projection_gap(a,b,cc),0)
    def test_no_axes_or_legacy(self):
        a,b,cc=pair();b.pivot_set=False;self.assertFalse(c.pair_ready(cc));b.pivot_set=True;cc.scene.cjm_double.design='LEGACY';self.assertFalse(c.pair_ready(cc))
    def test_off(self):
        a,b,cc=pair();cc.scene.cjm_settings.auto_constraints=False;c.changed(a,cc,'double','outer_diameter','UPPER');self.assertEqual(b.outer_diameter,5.)
    def test_apply_rollback_on_rna_clamp(self):
        a,b,cc=pair();base=type(b)
        class Clamp(base):
            def __setattr__(self,k,v):
                if k=='outer_diameter' and v<5.:v=5.
                super().__setattr__(k,v)
        b.__class__=Clamp
        self.assertFalse(c.run_pair(cc,'UPPER','outer_diameter'))
        self.assertEqual((a.outer_diameter,b.outer_diameter,b.axle_diameter),(8.,5.,2.))
        self.assertIn('補正不可',a['_cjm_constraint_status'])
    def test_focus_restored_after_other_side_update(self):
        a,b,cc=pair();root=cc.scene.cjm_double;root.active_joint='UPPER';a.live_focus='outer_diameter';b.live_focus='axial_gap'
        base=type(b)
        class Callback(base):
            def __setattr__(self,k,v):
                super().__setattr__(k,v)
                if k=='outer_diameter':self.live_focus=k;root.active_joint='LOWER'
        b.__class__=Callback
        self.assertTrue(c.run_pair(cc,'UPPER','outer_diameter'))
        self.assertEqual(root.active_joint,'UPPER');self.assertEqual(b.live_focus,'axial_gap')
    def test_rules_match_projection_random(self):
        rng=random.Random(24)
        for i in range(200):
            a,b,cc=pair(d=8,outer=5.,delta=(rng.uniform(0,15),0.,rng.uniform(0,15)))
            for j in (a,b):j.outer_diameter=rng.uniform(4,10);j.a_width=rng.uniform(2,5);j.b_width=rng.uniform(2,5)
            adj,protected=c.CONFIG['central'];v={p+'.'+k:getattr(j,k) for p,j in [('upper',a),('lower',b)] for k in (*adj,*protected)}
            opt={'projection':c.pair_projection(cc.scene.cjm_double),'upper':{},'lower':{}}
            r=[r for r in cm.rules('central_pair',v,opt) if r.name=='上下の加工領域の離隔']
            self.assertAlmostEqual(max(x.deficit(v) for x in r),cm.EPS-projection_gap(a,b,cc),places=10)

if __name__=='__main__':unittest.main()
