"""Regression: generation and legacy numerical correction share registration gate."""
import unittest
from test_constraints_v021 import c
from test_constraints_v024 import pair
from chappy_joint_maker import double_math as dm

class Mesh:
    type='MESH'
    data=object()
    def as_pointer(self):return id(self)

class Registration(unittest.TestCase):
    def setUp(self):
        self.a,self.b,self.cc=pair(delta=(0.,0.,6.))
        self.root=self.cc.scene.cjm_double
        self.root.design='LEGACY'
        self.a.reverse_axis=self.b.reverse_axis=False
        self.a.shoulder_enabled=self.b.shoulder_enabled=False
        for k in ('a','b','c'):setattr(self.root,'object_'+k,Mesh())
        for i,k in enumerate(('a','bu','bl','c')):setattr(self.root,'face_'+k,i)
    def test_valid_registration(self):
        dm.validate_registration(self.root)
    def test_same_outer_object(self):
        self.root.object_c=self.root.object_a
        self.assertTrue(c.pair_ready(self.cc))
        with self.assertRaisesRegex(ValueError,'異なる3個'):dm.validate_registration(self.root)
        self.assertFalse(c.run_pair(self.cc,'UPPER','outer_diameter'))
        self.assertEqual((self.a.outer_diameter,self.b.outer_diameter),(8.,5.))
        self.assertIn('異なる3個',self.a['_cjm_constraint_status'])
    def test_nonmesh(self):
        self.root.object_c.type='CURVE'
        self.assertFalse(c.run_pair(self.cc));self.assertIn('異なる3個',self.a['_cjm_constraint_status'])
    def test_missing_mesh_data(self):
        self.root.object_c.data=None
        self.assertFalse(c.run_pair(self.cc));self.assertIn('異なる3個',self.a['_cjm_constraint_status'])
    def test_same_central_face(self):
        self.root.face_bl=self.root.face_bu
        self.assertFalse(c.run_pair(self.cc));self.assertIn('異なる面',self.a['_cjm_constraint_status'])
