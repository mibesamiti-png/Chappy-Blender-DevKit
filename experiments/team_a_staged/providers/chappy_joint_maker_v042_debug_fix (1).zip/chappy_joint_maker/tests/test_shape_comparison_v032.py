"""Comparative evidence tests; no Blender geometry."""
import unittest
from unittest.mock import Mock
from types import SimpleNamespace as NS
from test_shape_candidates_v030 import fixture,detail
from test_shape_diagnostics_v029 import extract
from chappy_joint_maker import shape_comparison as c,shape_trials as t,shape_diagnostics as d,shape_candidates as p

class Compare(unittest.TestCase):
    def setUp(self):
        self.e=detail(measured=.2,threshold=.01,unit='volume');self.fail=t.Outcome('FAILED','fail',self.e);self.ok=t.Outcome('PASS','pass');self.items=[({'id':i,'policy':'FREE','before':1.,'after':.95},object()) for i in range(3)];self.base=object()
    def outcome(self,**kwargs):
        return t.Outcome('FAILED','fail',detail(**{'measured':.2,'threshold':.01,'unit':'volume',**kwargs}))
    def classify(self,**kwargs):return c.classify(self.e,self.outcome(**kwargs)).status
    def test_improved(self):self.assertEqual(self.classify(measured=.1),'IMPROVED')
    def test_worse(self):self.assertEqual(self.classify(measured=.3),'WORSE')
    def test_unchanged(self):self.assertEqual(self.classify(measured=.20000001),'UNCHANGED')
    def test_threshold_only(self):self.assertEqual(self.classify(threshold=.05),'MIXED')
    def test_conflicting_metrics(self):self.assertEqual(self.classify(measured=.21,threshold=.1),'MIXED')
    def test_different_side(self):self.assertEqual(self.classify(side='LOWER'),'DIFFERENT')
    def test_different_bearing(self):self.assertEqual(self.classify(bearing_sign=1),'DIFFERENT')
    def test_different_pose(self):self.assertEqual(self.classify(angle=2),'DIFFERENT')
    def test_different_unit(self):self.assertEqual(self.classify(unit='other'),'DIFFERENT')
    def test_no_measurement(self):self.assertEqual(self.classify(measured=None),'UNCOMPARABLE')
    def test_not_above_threshold(self):self.assertEqual(self.classify(measured=.005),'UNCOMPARABLE')
    def test_pass(self):self.assertEqual(c.classify(self.e,self.ok).status,'PASS')
    def test_batch_fresh_baseline_once(self):
        # Historical measurement is deliberately different; fresh baseline decides.
        fn=Mock(side_effect=[self.outcome(measured=.1),self.outcome(measured=.15),self.ok,self.outcome(side='LOWER')]);r=c.run(self.e,self.base,self.items,fn)
        self.assertEqual(r['status'],'DONE');self.assertEqual([x['result']['status'] for x in r['rows']],['WORSE','PASS','DIFFERENT']);self.assertEqual([x.args[0] for x in fn.call_args_list],[self.base,*[p for _,p in self.items]])
    def test_baseline_pass(self):
        fn=Mock(return_value=self.ok);self.assertEqual(c.run(self.e,self.base,self.items,fn)['status'],'STALE');fn.assert_called_once()
    def test_baseline_error(self):
        fn=Mock(return_value=t.Outcome('ERROR','bad'));self.assertEqual(c.run(self.e,self.base,self.items,fn)['status'],'ERROR');fn.assert_called_once()
    def test_candidate_error_stops(self):
        fn=Mock(side_effect=[self.fail,self.ok,t.Outcome('ERROR','bad')]);r=c.run(self.e,self.base,self.items,fn);self.assertEqual(r['status'],'ERROR');self.assertEqual(len(r['rows']),2);self.assertEqual(fn.call_count,3)
    def test_unknown_diagnostic_stops(self):
        fn=Mock(side_effect=[self.fail,self.outcome(code='OPERATION_FAILED')]);r=c.run(self.e,self.base,self.items,fn);self.assertEqual(r['status'],'ERROR');self.assertEqual(fn.call_count,2)
    def test_cleanup_exception(self):
        fn=Mock(side_effect=[self.fail,RuntimeError('cleanup')]);self.assertRaises(RuntimeError,c.run,self.e,self.base,self.items,fn);self.assertEqual(fn.call_count,2)
    def test_settings_drift(self):
        fn=Mock(return_value=self.fail);check=Mock(side_effect=[None,RuntimeError('drift')]);self.assertRaises(RuntimeError,c.run,self.e,self.base,self.items,fn,check);fn.assert_called_once()
    def test_candidate_limit(self):
        fn=Mock();self.assertRaises(ValueError,c.run,self.e,self.base,self.items+[self.items[0]],fn);fn.assert_not_called()
    def test_preferred_only_among_passes(self):
        self.items[0][0].update(policy='PREFERRED',after=.99);self.items[1][0].update(after=.9);self.items[2][0].update(after=.98)
        fn=Mock(side_effect=[self.fail,self.ok,self.ok,self.ok]);r=c.run(self.e,self.base,self.items,fn);self.assertEqual(r['preferred'],2)
    def test_no_preferred_if_error(self):
        fn=Mock(side_effect=[self.fail,self.ok,t.Outcome('ERROR','bad')]);self.assertIsNone(c.run(self.e,self.base,self.items,fn)['preferred'])
    def test_no_preferred_if_no_pass(self):
        fn=Mock(return_value=self.fail);self.assertIsNone(c.run(self.e,self.base,self.items,fn)['preferred'])
    def test_record_stale(self):
        r={'status':'DONE','rows':[]};payload=c.encode('original',r);self.assertEqual(c.display(payload,'original'),r);self.assertIsNone(c.display(payload,'other'))

class Integration(unittest.TestCase):
    def test_compare_operator_preserves_source_and_records(self):
        a,b,ctx,s=fixture();a.preview_angle=b.preview_angle=0.;e=detail(unit='volume');s.last_generation_diagnostic=e.encode();s.last_shape_candidates=p.capture(ctx,s,e);s.last_shape_comparison='old';before=p.inputs(ctx,s)
        fields=('outer_diameter','support_width','a_width','b_width','axle_diameter');attempt=Mock(side_effect=[t.Outcome('FAILED','fail',e),t.Outcome('PASS','pass'),t.Outcome('FAILED','fail',detail(measured=.1,unit='volume'))]);tr=NS(select=t.select,proxies=t.proxies,attempt=attempt)
        env=dict(diag=d,candidates=p,trials=tr,comparison=c,FIELDS=fields,bpy=NS(),plans=None,build=None,fh=NS(_make_collection=None,_destroy_collection=None),restore_selection=None,cj=NS(cm=NS(inspection_angles=None)),ui=NS(redraw=Mock()))
        fn=extract('double_joint.py','execute',env,'CJM_OT_double_compare');result=fn(NS(poll=lambda x:True,report=Mock()),ctx)
        self.assertEqual(result,{'FINISHED'});self.assertEqual(before,p.inputs(ctx,s));self.assertEqual(attempt.call_count,3);self.assertEqual(c.display(s.last_shape_comparison,s.last_shape_candidates)['status'],'DONE')

if __name__=='__main__':unittest.main()
