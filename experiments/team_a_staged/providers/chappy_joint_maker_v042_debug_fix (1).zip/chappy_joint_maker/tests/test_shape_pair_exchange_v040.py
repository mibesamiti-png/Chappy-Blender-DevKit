"""One bounded exchange after pair refinement; synthetic generator outcomes."""
import json, unittest
from unittest.mock import Mock, patch
from types import SimpleNamespace as NS
import test_shape_pairs_v037 as pair_tests
import test_shape_pair_refinement_v039 as ref_tests
from test_shape_diagnostics_v029 import extract
from test_constraints_v022 import lock, prefer
from chappy_joint_maker import shape_candidates as p, shape_trials as t, shape_comparison as c, shape_apply as a, shape_diagnostics as d

class Exchange(unittest.TestCase):
    def setUp(self):
        ref_tests.PairRefinement.setUp(self)
        self.make_refined()
    def make_refined(self):
        self.refined=p.pair_refinement(self.payload,self.result,self.e,self.data,self.s)
        self.ref_items=json.loads(self.refined)['candidates']
        self.record={'status':'DONE','source':'1','rows':[{'item':i,'result':{'status':'PASS' if n==0 else 'UNCHANGED'}} for n,i in enumerate(self.ref_items)]}
        self.s.last_shape_candidates=self.refined;self.s.last_shape_comparison=c.encode(self.refined,self.record)
    def exchange(self):return p.pair_exchange(self.refined,self.record,self.e,self.data,self.s)
    def items(self):return json.loads(self.exchange())['candidates']
    def test_two_directions(self):
        items=self.items();self.assertEqual(len(items),3);self.assertEqual(items[0],self.ref_items[0]);self.assertEqual(items,p.recompute(self.exchange(),self.e,self.data))
        grows=[]
        for item in items[1:]:
            self.assertLess(p.pair_cost(item),p.pair_cost(items[0]));signs=[]
            for old,new in zip(items[0]['changes'],item['changes']):
                delta=old['after']-old['before'];nd=new['after']-new['before'];self.assertGreater(delta*nd,0);signs.append(abs(nd)>abs(delta));self.assertAlmostEqual(nd/delta,1.25 if signs[-1] else .5,places=5)
                self.assertLessEqual(abs(nd),.2*old['before'])
            self.assertEqual(sum(signs),1);grows.append(signs)
        self.assertNotEqual(*grows);self.assertEqual(p.inputs(self.ctx,self.s),self.data)
    def test_choose_best_pass(self):
        self.record['rows'][1]['result']['status']='PASS';self.assertEqual(self.items()[0],self.ref_items[1])
    def test_no_incumbent_pass(self):self.record['rows'][0]['result']['status']='UNCHANGED';self.assertEqual(self.exchange(),'')
    def test_missing_source(self):del self.record['source'];self.assertEqual(self.exchange(),'')
    def test_source_mismatch(self):self.record['source']='2';self.assertEqual(self.exchange(),'')
    def test_incomplete(self):self.record['status']='ERROR';self.assertEqual(self.exchange(),'')
    def test_rows_mismatch(self):self.record['rows'].reverse();self.assertEqual(self.exchange(),'')
    def test_no_recursion(self):self.assertEqual(p.pair_exchange(self.exchange(),self.record,self.e,self.data,self.s),'')
    def test_bad_indices(self):
        keys=json.loads(self.refined)['keys']
        for idx in (-1,True,None,3):self.assertEqual(p.pair_exchanged_propose(self.e,self.data,keys,0,idx),[])
    def test_bound(self):
        with patch.object(p,'MAX_EXCHANGE_FRACTION',.05):self.assertEqual(self.exchange(),'')
    def test_preferred_not_grown(self):
        prefer(self.u,'support_width');self.data=p.inputs(self.ctx,self.s);self.payload=p.capture(self.ctx,self.s,self.e)
        initial=json.loads(self.payload)['candidates'];r={'status':'DONE','rows':[{'item':i,'result':{'status':'UNCHANGED'}} for i in initial]}
        self.payload=p.pairing(self.payload,r,self.e,self.data,self.s);self.parents=json.loads(self.payload)['candidates'];self.result={'status':'DONE','source':'1','rows':[{'item':i,'result':{'status':'PASS'}} for i in self.parents]};self.make_refined()
        items=self.items();self.assertEqual(len(items),2)
        prev=next(i for i in items[0]['changes'] if i['policy']=='PREFERRED');new=next(i for i in items[1]['changes'] if i['policy']=='PREFERRED');self.assertLess(abs(new['after']-new['before']),abs(prev['after']-prev['before']))
    def test_numeric_filter(self):
        parent=self.ref_items[0];original=self.data[0];real=p.numerically_valid
        def valid(v,opt,extras):
            if any(abs(v[ch['side'].lower()+'.'+ch['key']]-ch['before'])>abs(ch['after']-ch['before']) for ch in parent['changes']):return False
            return real(v,opt,extras)
        with patch.object(p,'numerically_valid',side_effect=valid):self.assertEqual(self.exchange(),'')
    def test_tampering(self):
        payload=json.loads(self.exchange());payload['candidates'][1]['changes'][0]['after']*=.99;self.s.last_shape_candidates=json.dumps(payload);self.assertRaises(ValueError,t.select,self.ctx,self.s,1)
    def test_locked(self):
        self.s.last_shape_candidates=self.exchange();lock(self.u,self.ref_items[0]['changes'][0]['key']);self.assertRaises(ValueError,t.select,self.ctx,self.s,0)
    def operator(self,source,outcomes):
        attempt=Mock(side_effect=outcomes);env=dict(diag=d,candidates=p,trials=NS(select=t.select,proxies=t.proxies,attempt=attempt),comparison=c,adoption=NS(source_signature=Mock(return_value=source)),FIELDS=pair_tests.Pairs.fields(self),bpy=NS(),plans=None,build=None,fh=NS(_make_collection=None,_destroy_collection=None),restore_selection=None,cj=NS(cm=NS(inspection_angles=None)),ui=NS(redraw=Mock()))
        fn=extract('double_joint.py','execute',env,'CJM_OT_double_compare');res=fn(NS(poll=lambda _:True,report=Mock(),pair_exchange=True),self.ctx)
        self.assertEqual(p.inputs(self.ctx,self.s),self.data);return res,attempt
    def test_exchange_success(self):
        res,fn=self.operator(1,[self.fail,self.ok,self.fail,self.ok]);self.assertEqual(res,{'FINISHED'},self.s.status);self.assertEqual(fn.call_count,4);self.assertTrue(p.is_pair_exchanged(self.s.last_shape_candidates));result=c.display(self.s.last_shape_comparison,self.s.last_shape_candidates);self.assertEqual(result['preferred'],2);self.assertEqual(a.passing_item(self.s.last_shape_comparison,self.s.last_shape_candidates,[r['item'] for r in result['rows']],2,allow_pair=True),result['rows'][2]['item'])
    def test_stale_source(self):
        res,fn=self.operator(2,[]);self.assertEqual(res,{'CANCELLED'});fn.assert_not_called();self.assertEqual(self.s.last_shape_candidates,self.refined)
    def test_incumbent_failure(self):
        res,fn=self.operator(1,[self.fail,self.fail]);self.assertEqual(res,{'FINISHED'});self.assertEqual(fn.call_count,2);self.assertEqual(c.display(self.s.last_shape_comparison,self.s.last_shape_candidates)['status'],'STALE')
    def test_unknown_error(self):
        res,fn=self.operator(1,[self.fail,self.ok,t.Outcome('ERROR','bad')]);self.assertEqual(res,{'FINISHED'});self.assertEqual(fn.call_count,3);r=c.display(self.s.last_shape_comparison,self.s.last_shape_candidates);self.assertEqual(r['status'],'ERROR');self.assertIsNone(r['preferred'])
    def test_keep_incumbent(self):
        res,fn=self.operator(1,[self.fail,self.ok,self.fail,self.fail]);self.assertEqual(res,{'FINISHED'});self.assertEqual(fn.call_count,4);self.assertEqual(c.display(self.s.last_shape_comparison,self.s.last_shape_candidates)['preferred'],0)
    def test_exchange_operator_adoption(self):
        from test_shape_pair_apply_v038 import PairAdoption
        obj=PairAdoption();obj.setUp();obj.result['source']='1'
        refined=p.pair_refinement(obj.payload,obj.result,obj.e,obj.data,obj.s);items=json.loads(refined)['candidates']
        record={'status':'DONE','source':'1','rows':[{'item':i,'result':{'status':'PASS' if n==0 else 'UNCHANGED'}} for n,i in enumerate(items)]}
        payload=p.pair_exchange(refined,record,obj.e,obj.data,obj.s);items=json.loads(payload)['candidates'];obj.s.last_shape_candidates=payload
        result={'status':'DONE','rows':[{'item':i,'result':{'status':'PASS'}} for i in items]};obj.s.last_shape_comparison=c.encode(payload,result)
        attempt=Mock(side_effect=[obj.failure,obj.ok]);before=p.inputs(obj.ctx,obj.s)[0]
        env=dict(__name__='chappy_joint_maker.double_joint',__package__='chappy_joint_maker',candidates=p,trials=NS(select=t.select,proxies=t.proxies,attempt=attempt),adoption=NS(passing_item=a.passing_item,verify=a.verify,commit=a.commit,commit_many=a.commit_many,source_signature=Mock(return_value=1)),FIELDS=pair_tests.Pairs.fields(obj),bpy=NS(),plans=None,build=None,fh=NS(_make_collection=None,_destroy_collection=None),restore_selection=None,cj=NS(cm=NS(inspection_angles=None)),ui=NS(redraw=Mock()))
        fn=extract('double_joint.py','execute',env,'CJM_OT_double_apply_candidate');res=fn(NS(poll=lambda _:True,report=Mock(),index=1),obj.ctx)
        self.assertEqual(res,{'FINISHED'},obj.s.status);self.assertEqual(p.inputs(obj.ctx,obj.s)[0],{**before,**{ch['side'].lower()+'.'+ch['key']:ch['after'] for ch in items[1]['changes']}});self.assertEqual(attempt.call_count,2);self.assertEqual(obj.s.last_shape_candidates,'')
