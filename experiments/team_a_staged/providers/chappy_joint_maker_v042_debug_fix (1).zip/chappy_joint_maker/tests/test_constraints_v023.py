"""Numerical and RNA-adapter regressions for mechanical safety; no Blender."""
import unittest
from test_constraints_v021 import c,cm,ctx,rotary,ball,hinge
from test_constraints_v022 import lock,free

class Safety(unittest.TestCase):
    def test_retention_locked(self):
        s=ball(opening_diameter=12.);lock(s,'opening_diameter','ball_diameter');free(s,'clearance')
        self.assertFalse(c.run(ctx('BALL',s),s,'ball'));self.assertEqual(s.clearance,.4)
        self.assertIn('抜け止め',s['_cjm_constraint_status'])
    def test_retention_repair(self):
        s=ball(opening_diameter=12.);lock(s,'ball_diameter');free(s,'clearance')
        self.assertTrue(c.run(ctx('BALL',s),s,'ball','opening_diameter'));self.assertLess(s.opening_diameter,10.);self.assertEqual(s.clearance,.4)
    def test_retention_opt_out(self):
        s=ball(opening_diameter=12.);lock(s,'opening_diameter','ball_diameter');free(s,'clearance');cc=ctx('BALL',s);cc.scene.cjm_settings.constraint_ball_retention=False
        self.assertTrue(c.run(cc,s,'ball'));self.assertGreater(s.clearance,1.)
    def test_no_socket(self):
        s=ball(opening_diameter=12.,make_socket=False);self.assertTrue(c.run(ctx('BALL',s),s,'ball'));self.assertEqual(s.opening_diameter,12.)
    def test_rotary_zero_locked(self):
        s=rotary(shoulder_enabled=False,radial_clearance=0.,axial_gap=0.)
        self.assertFalse(c.run(ctx('ROTARY',s),s,'rotary'));self.assertEqual(s.axial_gap,0.)
    def test_rotary_zero_unlocked(self):
        s=rotary(shoulder_enabled=False,radial_clearance=0.,axial_gap=0.,tip_clearance=0.)
        free(s,'radial_clearance','axial_gap','tip_clearance');cc=ctx('ROTARY',s);cc.scene.cjm_settings.constraint_clearance_floor=.4
        self.assertTrue(c.run(cc,s,'rotary'));self.assertGreaterEqual(min(s.radial_clearance,s.axial_gap,s.tip_clearance),.399999)
    def test_floor_prevents_shrink(self):
        s=hinge(pin_diameter=2.8);lock(s,'outer_diameter');free(s,'pin_clearance');cc=ctx('HINGE',s);cc.scene.cjm_settings.constraint_clearance_floor=.4
        self.assertTrue(c.run(cc,s,'hinge','pin_diameter'));self.assertEqual(s.pin_clearance,.4);self.assertLess(s.pin_diameter,2.8)
    def test_floor_custom(self):
        s=hinge(pin_diameter=2.8);lock(s,'outer_diameter');free(s,'pin_clearance');cc=ctx('HINGE',s);cc.scene.cjm_settings.constraint_clearance_floor=.15
        self.assertTrue(c.run(cc,s,'hinge','pin_diameter'));self.assertEqual(s.pin_diameter,2.8);self.assertGreater(s.pin_clearance,.15)
    def test_existing_small_positive_not_increased(self):
        s=hinge(pin_clearance=.1);cc=ctx('HINGE',s);cc.scene.cjm_settings.constraint_clearance_floor=.4;free(s,'pin_clearance')
        self.assertTrue(c.run(cc,s,'hinge'));self.assertEqual(s.pin_clearance,.1)
    def test_existing_small_positive_not_shrunk(self):
        s=hinge(pin_clearance=.1,pin_diameter=3.1);cc=ctx('HINGE',s);cc.scene.cjm_settings.constraint_clearance_floor=.4;free(s,'pin_clearance');lock(s,'outer_diameter')
        self.assertTrue(c.run(cc,s,'hinge','pin_diameter'));self.assertEqual(s.pin_clearance,.1);self.assertLess(s.pin_diameter,3.1)
    def test_central_swing(self):
        s=rotary(swing_clearance=0.);cc=ctx('DOUBLE',s,rotary());cc.scene.cjm_settings.constraint_clearance_floor=.4
        self.assertFalse(c.run(cc,s,'central'));free(s,'swing_clearance');self.assertTrue(c.run(cc,s,'central'));self.assertGreaterEqual(s.swing_clearance,.399999)
    def pair(self,d=6.,outer=8.,axis='X',delta=None):
        a=rotary(outer_diameter=outer,pivot_set=True,pivot=(0.,0.,0.));b=rotary(pivot_set=True,pivot=delta or (0.,0.,d));cc=ctx('DOUBLE',a,b);cc.scene.cjm_double.axis=axis
        return a,b,cc
    def test_central_overlap_repair(self):
        a,b,cc=self.pair();self.assertTrue(c.run(cc,a,'central','outer_diameter'));self.assertLess(a.outer_diameter,5.4);self.assertEqual(b.outer_diameter,5.)
        x,y,remaining=c.central_separation(cc,a);self.assertGreater(remaining-(a.outer_diameter/2+a.swing_clearance),0.)
    def test_central_overlap_locked(self):
        a,b,cc=self.pair();lock(a,'outer_diameter');self.assertFalse(c.run(cc,a,'central'));self.assertEqual(a.outer_diameter,8.);self.assertEqual(b.outer_diameter,5.)
    def test_central_axial_projection(self):
        a,b,cc=self.pair(outer=5.,delta=(10.,0.,0.));lock(a,'b_width','axial_gap');self.assertTrue(c.run(cc,a,'central','a_width'));self.assertLess(a.a_width,3.5)
    def test_central_same_pivot(self):
        a,b,cc=self.pair(delta=(0.,0.,0.));self.assertFalse(c.run(cc,a,'central'));self.assertIn('軸中心',a['_cjm_constraint_status'])
    def test_repair_operator_failure(self):
        s=ball(opening_diameter=12.);lock(s,'opening_diameter','ball_diameter');op=c.CJM_OT_constraint_repair();self.assertEqual(op.execute(ctx('BALL',s)),{'CANCELLED'})
    def test_repair_operator_success(self):
        s=ball();self.assertEqual(c.CJM_OT_constraint_repair().execute(ctx('BALL',s)),{'FINISHED'})
    def test_repair_operator_double_rollback(self):
        a=rotary(outer_diameter=1.);b=rotary(outer_diameter=1.);lock(b,'outer_diameter','axle_diameter');cc=ctx('DOUBLE',a,b)
        self.assertEqual(c.CJM_OT_constraint_repair().execute(cc),{'CANCELLED'});self.assertEqual(a.outer_diameter,1.);self.assertEqual(b.outer_diameter,1.)
    def test_trunnion_incomplete_fixture(self):
        self.assertEqual(c.CJM_OT_constraint_repair().execute(ctx('TRUNNION',rotary())),{'CANCELLED'})
if __name__=='__main__':unittest.main()
