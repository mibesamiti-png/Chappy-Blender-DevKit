"""Bounded single-dimension continuation; mocked geometry, not Blender."""
import json,unittest
from types import SimpleNamespace as NS
from unittest.mock import Mock
from test_shape_candidates_v030 import fixture,detail
from test_shape_diagnostics_v029 import extract
from test_constraints_v022 import lock
from chappy_joint_maker import shape_candidates as p,shape_comparison as c,shape_trials as t,shape_apply as a,shape_diagnostics as d

class Expansion(unittest.TestCase):
    def setUp(self):
        self.u,self.l,self.ctx,self.s=fixture();self.u.preview_angle=self.l.preview_angle=0.
        self.e=detail(unit='volume');self.s.last_generation_diagnostic=self.e.encode()
        self.data=p.inputs(self.ctx,self.s);self.advice=p.capture(self.ctx,self.s,self.e);self.s.last_shape_candidates=self.advice
        self.initial=p.display(self.ctx,self.s,self.e)
        self.record={'status':'DONE','rows':[{'item':i,'result':{'status':'IMPROVED'}} for i in self.initial]}
    def expand(self):return p.expansion(self.advice,self.record,self.e,self.data,self.s)
    def test_stronger_single_field(self):
        out=json.loads(self.expand())['candidates'];self.assertEqual(len(out),len(self.initial))
        for old,new in zip(self.initial,out):
            self.assertEqual(old['key'],new['key']);self.assertEqual(old['before'],new['before']);self.assertLess(new['after'],old['after']);self.assertLessEqual(abs(new['after']/new['before']-1),.200001)
        self.assertEqual(p.inputs(self.ctx,self.s),self.data)
    def test_only_improved(self):
        self.record['rows'][0]['result']['status']='DIFFERENT';out=json.loads(self.expand())['candidates'];self.assertEqual([i['key'] for i in out],[self.initial[1]['key']])
    def test_no_pass(self):self.record['rows'][0]['result']['status']='PASS';self.assertEqual(self.expand(),'')
    def test_no_improvement(self):
        for row in self.record['rows']:row['result']['status']='UNCHANGED'
        self.assertEqual(self.expand(),'')
    def test_incomplete(self):self.record['status']='ERROR';self.assertEqual(self.expand(),'')
    def test_mismatch(self):self.record['rows'].reverse();self.assertEqual(self.expand(),'')
    def test_no_repeated_expansion(self):
        payload=self.expand();self.assertEqual(p.expansion(payload,self.record,self.e,self.data,self.s),'')
    def test_locked_after_comparison(self):
        payload=self.expand();self.s.last_shape_candidates=payload;lock(self.u,self.initial[0]['key']);self.assertRaises(ValueError,t.select,self.ctx,self.s,0)
    def test_expanded_select_and_pass_adoption(self):
        payload=self.expand();self.s.last_shape_candidates=payload;items=p.display(self.ctx,self.s,self.e)
        self.assertEqual(t.select(self.ctx,self.s,0),(self.e,items[0]))
        result={'status':'DONE','rows':[{'item':i,'result':{'status':'PASS'}} for i in items]}
        self.assertEqual(a.passing_item(c.encode(payload,result),payload,items,0),items[0])
    def test_tampered_candidate_rejected(self):
        payload=json.loads(self.expand());payload['candidates'][0]['after']*=.8;self.s.last_shape_candidates=json.dumps(payload);self.assertRaises(ValueError,t.select,self.ctx,self.s,0)
    def test_fixed_bounds_no_extra(self):
        orig,opt,bounds,pol,extra=self.data;bounds=dict(bounds)
        for i in self.initial:bounds['upper.'+i['key']]=(i['after'],bounds['upper.'+i['key']][1])
        self.assertEqual(p.expanded_propose(self.e,(orig,opt,bounds,pol,extra),[i['key'] for i in self.initial]),[])
    def run_op(self,drift=False,stale=False):
        self.s.last_shape_comparison=c.encode(self.advice,self.record)
        fields=tuple(k for k in vars(self.u) if k in ('outer_diameter','support_width','a_width','b_width','axle_diameter','radial_clearance','axial_gap','cap_wall','radial_wall','tip_clearance','shoulder_diameter','shoulder_thickness','shoulder_radial_clearance','shoulder_axial_clearance','support_thickness','embed_depth','swing_clearance','angle_step'))
        ok=t.Outcome('PASS','pass');fail=t.Outcome('FAILED','fail',self.e)
        attempt=Mock(side_effect=[ok if stale else fail,ok,ok]);sig=Mock(side_effect=[1,1,1,2] if drift else None,return_value=1)
        env=dict(diag=d,candidates=p,trials=NS(select=t.select,proxies=t.proxies,attempt=attempt),comparison=c,adoption=NS(source_signature=sig),FIELDS=fields,bpy=NS(),plans=None,build=None,fh=NS(_make_collection=None,_destroy_collection=None),restore_selection=None,cj=NS(cm=NS(inspection_angles=None)),ui=NS(redraw=Mock()))
        fn=extract('double_joint.py','execute',env,'CJM_OT_double_compare');result=fn(NS(poll=lambda x:True,report=Mock(),expand=True),self.ctx)
        self.assertEqual(p.inputs(self.ctx,self.s),self.data)
        if drift:
            self.assertEqual(result,{'CANCELLED'});self.assertEqual(self.s.last_shape_comparison,'');self.assertEqual(self.s.last_shape_candidates,self.advice);self.assertEqual(attempt.call_count,1)
        else:
            self.assertEqual(result,{'FINISHED'});rec=c.display(self.s.last_shape_comparison,self.s.last_shape_candidates);self.assertEqual(rec['status'],'STALE' if stale else 'DONE');self.assertEqual(attempt.call_count,1 if stale else 3)
            if not stale:self.assertEqual(rec['rows'][0]['result']['status'],'PASS')
    def test_operator_success(self):self.run_op()
    def test_operator_drift(self):self.run_op(drift=True)
    def test_operator_stale(self):self.run_op(stale=True)
