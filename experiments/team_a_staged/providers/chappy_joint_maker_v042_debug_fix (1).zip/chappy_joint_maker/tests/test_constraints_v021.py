import sys,types,importlib,unittest, pathlib, ast, math, random, struct
from types import SimpleNamespace as NS
from pathlib import Path
root=Path(__file__).resolve().parent.parent
pkg=types.ModuleType('chappy_joint_maker');pkg.__path__=[str(root)];sys.modules[pkg.__name__]=pkg
hp=types.ModuleType(pkg.__name__+'.hinge_maker');hp.__path__=[str(root/'hinge_maker')];sys.modules[hp.__name__]=hp;pkg.hinge_maker=hp
for mod in ('dimension_math','axle_math','end_geometry'):
 m=importlib.import_module(hp.__name__+'.'+mod)
 for k in dir(m):
  if not k.startswith('_'):setattr(hp,k,getattr(m,k))
parsed=ast.parse((root/'hinge_maker/__init__.py').read_text());selected={'knuckle_lengths','knuckle_specs','resolved_hinge_geometry','_blind_bore_plan'}
exec(compile(ast.Module(body=[n for n in parsed.body if isinstance(n,ast.FunctionDef) and n.name in selected],type_ignores=[]),str(root/'hinge_maker/__init__.py'),'exec'),hp.__dict__)
bpy=types.ModuleType('bpy');bt=types.ModuleType('bpy.types');bp=types.ModuleType('bpy.props');bt.Operator=object;bp.StringProperty=lambda **k:None;bpy.types=bt;bpy.props=bp;sys.modules.update({'bpy':bpy,'bpy.types':bt,'bpy.props':bp})
from chappy_joint_maker import constraint_math as cm, constraints as c,central_math,swap_math
from chappy_joint_maker.hinge_maker import face_hinge_math as fm

class Settings(dict):
 def __init__(self,**kwargs):
  super().__init__();self.__dict__.update(kwargs);self.bl_rna=NS(properties={k:NS(hard_min=.01,hard_max=1000.,name=k) for k,v in kwargs.items() if type(v) in (int,float)})
 def as_pointer(self):return id(self)
 def __setattr__(self,k,v):
  if isinstance(v,float):v=struct.unpack('f',struct.pack('f',v))[0]
  object.__setattr__(self,k,v)

def rotary(**kwargs):
 return Settings(**{**dict(outer_diameter=5.,axle_diameter=2.,a_width=3.5,b_width=3.5,radial_clearance=.4,axial_gap=.4,cap_wall=.8,radial_wall=.35,tip_clearance=.4,shoulder_enabled=True,shoulder_diameter=3.4,shoulder_thickness=.5,shoulder_radial_clearance=.4,shoulder_axial_clearance=.35,support_width=1.8,swing_clearance=.4,support_thickness=2.2,embed_depth=.5),**kwargs})
def swap(**kwargs):return Settings(**{**dict(vars(swap_math.Spec())),**kwargs})
def ball(**kwargs):return Settings(**{**dict(ball_diameter=10.,opening_diameter=7.5,shaft_diameter=3.2,clearance=.4,make_socket=True,make_shaft=True,make_motion_cut=False),**kwargs})
def hinge(**kwargs):return Settings(**{**dict(outer_diameter=4.,pin_diameter=2.,total_length=10.,knuckle_gap=.4,pin_clearance=.4,minimum_radial_wall=.4,minimum_cap_wall=.8,axle_tip_clearance=.4,axle_follow_side_centers=True,axle_prevent_overrun=True,hinge_style='INTEGRATED_AXLE',axle_end_mode='BLIND',length_mode='CENTER_LONG',center_ratio=1.4,layout_mode='ABA',pin_end_extra=.4,make_support_bridges=True,bridge_max_reach=40.,make_body_relief=True,face_clearance_follow_gap=True,face_clearance=.4),**kwargs})
def ctx(mode,s,other=None,design='CENTRAL',enabled=True):
 st=NS(mode=mode,auto_constraints=enabled,ball_section='GENERATE');sc=NS(cjm_settings=st)
 key={'BALL':'ball_joint_settings','ROTARY':'face_hinge_settings','HINGE':'hinge_maker_settings','SWAP':'cjm_swap','TRUNNION':'face_hinge_settings','DOUBLE':'cjm_double'}[mode];setattr(sc,key,NS(upper=s,lower=other,design=design) if mode=='DOUBLE' else s);return NS(scene=sc)

class Test(unittest.TestCase):
 def test_hinge_edited_pin_grows_outer(self):
  s=hinge(pin_diameter=5.);self.assertTrue(c.run(ctx('HINGE',s),s,'hinge','pin_diameter'));self.assertEqual(s.pin_diameter,5);self.assertGreater(s.outer_diameter,6.6);self.assertEqual(s.pin_clearance,.4)
 def test_hinge_locked_outer_shrinks_pin(self):
  s=hinge(pin_diameter=5.);s['_cjm_lock_outer_diameter']=True;self.assertTrue(c.run(ctx('HINGE',s),s,'hinge','pin_diameter'));self.assertEqual(s.outer_diameter,4.);self.assertLess(s.pin_diameter,2.4)
 def test_hinge_blind_cap_length(self):
  s=hinge(total_length=3.);self.assertTrue(c.run(ctx('HINGE',s),s,'hinge','total_length'));self.assertGreater(s.total_length,8.9)
 def test_hinge_alternate_candidate(self):
  s=hinge(pin_diameter=5.,bridge_max_reach=2.1);self.assertTrue(c.run(ctx('HINGE',s),s,'hinge','pin_diameter'));self.assertLess(s.outer_diameter,4.2);self.assertLess(s.pin_diameter,3.)
 def test_hinge_locked_conflict(self):
  s=hinge(pin_diameter=5.);s['_cjm_lock_outer_diameter']=s['_cjm_lock_pin_diameter']=True;self.assertFalse(c.run(ctx('HINGE',s),s,'hinge'));self.assertEqual(s.pin_diameter,5.)
 def test_ball_opening(self):
  s=ball(opening_diameter=14.);self.assertTrue(c.run(ctx('BALL',s),s,'ball','opening_diameter'));self.assertEqual(s.opening_diameter,14.);self.assertGreater(s.ball_diameter,13.2)
 def test_ball_two_locks(self):
  s=ball(shaft_diameter=12.);s['_cjm_lock_ball_diameter']=s['_cjm_lock_opening_diameter']=True;self.assertTrue(c.run(ctx('BALL',s),s,'ball','shaft_diameter'));self.assertLess(s.shaft_diameter,7.5)
 def test_ball_motion_excluded(self):
  s=ball(shaft_diameter=12.,make_motion_cut=True);self.assertTrue(c.run(ctx('BALL',s),s,'ball','shaft_diameter'));self.assertEqual(s.shaft_diameter,12.)
 def test_rotary_head(self):
  s=rotary(shoulder_diameter=5.);self.assertTrue(c.run(ctx('ROTARY',s),s,'rotary','shoulder_diameter'));self.assertGreater(s.outer_diameter,6.5)
 def test_rotary_head_locked_outer(self):
  s=rotary(shoulder_diameter=6.);s['_cjm_lock_outer_diameter']=True;self.assertTrue(c.run(ctx('ROTARY',s),s,'rotary','shoulder_diameter'));self.assertEqual(s.outer_diameter,5.);self.assertLess(s.shoulder_diameter,3.5)
 def test_rotary_fixed_total(self):
  s=rotary(shoulder_enabled=False,b_width=5.);s['_cjm_length_rotary']=7.4;self.assertTrue(c.run(ctx('ROTARY',s),s,'rotary','b_width'));self.assertAlmostEqual(c.length(s,'rotary'),7.4,places=5);self.assertEqual(s.b_width,5.)
 def test_central_fixed_total(self):
  s=rotary(b_width=5.);s['_cjm_length_central']=11.3;self.assertTrue(c.run(ctx('DOUBLE',s,rotary()),s,'central','b_width'));self.assertAlmostEqual(c.length(s,'central'),11.3,places=5);self.assertEqual(s.b_width,5.)
 def test_central_width_lock(self):
  s=rotary(support_width=5.);s['_cjm_lock_b_width']=True;self.assertTrue(c.run(ctx('DOUBLE',s,rotary()),s,'central','support_width'));self.assertEqual(s.support_width,3.5)
 def test_central_min_cap(self):
  s=rotary(a_width=.5);self.assertTrue(c.run(ctx('DOUBLE',s,rotary()),s,'central','a_width'));self.assertGreater(s.a_width,1.2)
 def test_central_independent_sides(self):
  a,b=rotary(),rotary();cc=ctx('DOUBLE',a,b);c.capture(cc);a.axle_diameter=4.;c.changed(a,cc,'double','axle_diameter','UPPER');self.assertEqual(b.outer_diameter,5.);self.assertGreater(a.outer_diameter,5.)
 def test_swap_depth(self):
  s=swap(lug_height=5.);self.assertTrue(c.run(ctx('SWAP',s),s,'swap','lug_height'));self.assertEqual(s.lug_height,5.);self.assertGreater(s.depth,7.3)
 def test_swap_depth_lock(self):
  s=swap(lug_height=8.);s['_cjm_lock_depth']=True;self.assertTrue(c.run(ctx('SWAP',s),s,'swap','lug_height'));self.assertEqual(s.depth,6.);self.assertLess(s.lug_height,3.7)
 def test_swap_angle(self):
  s=swap(lock_angle=15.);self.assertTrue(c.run(ctx('SWAP',s),s,'swap','lock_angle'));swap_math.plan(swap_math.spec_from(s));self.assertAlmostEqual(s.lock_angle,15.)
 def test_swap_4_lugs(self):
  s=swap(lug_count=4,lock_angle=85.);self.assertTrue(c.run(ctx('SWAP',s),s,'swap','lock_angle'));swap_math.plan(swap_math.spec_from(s))
 def test_swap_protected_clearance(self):
  s=swap(lug_projection=.1);self.assertTrue(c.run(ctx('SWAP',s),s,'swap','lug_projection'));self.assertEqual(s.radial_clearance,.4);self.assertGreater(s.lug_projection,.4)
 def test_off(self):
  s=ball(opening_diameter=20.);c.changed(s,ctx('BALL',s,enabled=False),'ball','opening_diameter');self.assertEqual(s.ball_diameter,10.);self.assertNotIn('_cjm_constraint_status',s)
 def test_suspended(self):
  s=ball(opening_diameter=20.);cc=ctx('BALL',s)
  with c.suspended():c.changed(s,cc,'ball','opening_diameter')
  self.assertEqual(s.ball_diameter,10.)
 def test_impossible_edit_rejected(self):
  s=ball();cc=ctx('BALL',s);c.capture(cc);s['_cjm_lock_ball_diameter']=s['_cjm_lock_opening_diameter']=True;s.opening_diameter=20.;c.changed(s,cc,'ball','opening_diameter');self.assertEqual(s.opening_diameter,7.5);self.assertIn('元に戻しました',s['_cjm_constraint_status'])
 def test_impossible_stale_snapshot_not_restored(self):
  s=ball();cc=ctx('BALL',s);c.capture(cc);s['_cjm_lock_ball_diameter']=s['_cjm_lock_opening_diameter']=True;s.ball_diameter=9.;s.opening_diameter=20.;c.changed(s,cc,'ball','opening_diameter');self.assertEqual(s.opening_diameter,20.);self.assertEqual(s.ball_diameter,9.)
 def test_no_partial_change_when_infeasible(self):
  s=rotary(a_width=.1,axle_diameter=20.);cc=ctx('ROTARY',s);s['_cjm_lock_a_width']=True;original=s.outer_diameter;self.assertFalse(c.run(cc,s,'rotary'));self.assertEqual(s.outer_diameter,original)
 def test_trunnion_unrelated_rotary_outer_diameter(self):
  s=rotary(outer_diameter=.1);c.changed(s,ctx('TRUNNION',s),'face','outer_diameter');self.assertEqual(s.outer_diameter,.1)
 def test_bound_search(self):
  v=dict(outer_diameter=3.,pin_diameter=5.,pin_clearance=.4,minimum_radial_wall=.4,knuckle_gap=.4,total_length=10.)
  r=cm.repair('hinge',v,{},dict(outer_diameter=(.1,4.),pin_diameter=(.05,8.),total_length=(.1,100.)),edited='pin_diameter');self.assertTrue(r.ok);self.assertLessEqual(r.values['outer_diameter'],4.)
 def test_nonfinite(self):
  r=cm.repair('hinge',{'bad':float('nan')},{},{},());self.assertFalse(r.ok)
 def test_limit(self):
  s=ball(opening_diameter=20.);v={k:getattr(s,k) for k in ('ball_diameter','opening_diameter','shaft_diameter','clearance')};r=cm.repair('ball',v,dict(socket=True,shaft=True,motion=False),{k:(.2,100.) for k in v if k!='clearance'},limit=1);self.assertFalse(r.ok);self.assertEqual(r.values,v)

if __name__=='__main__':unittest.main()
