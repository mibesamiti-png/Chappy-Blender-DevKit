"""Search refinement and transactional RNA regressions (no Blender required)."""
import unittest
from test_constraints_v021 import c,cm,ctx,rotary,ball
from test_constraints_v024 import pair
from test_constraints_v022 import lock

class Refinement(unittest.TestCase):
    def example(self):
        v=dict(outer_diameter=4.66,axle_diameter=1.84,a_width=5.91,b_width=4.33,support_width=6.72,radial_clearance=.4,tip_clearance=.4,axial_gap=.4,swing_clearance=.4,radial_wall=.35,cap_wall=.8)
        opt=dict(length=6.4,separation=(.6,.8,3.944995596215781))
        bounds={k:(.2,10) for k in c.CONFIG['central'][0]}
        locked={'tip_clearance','swing_clearance','radial_clearance','axial_gap'}
        return v,opt,bounds,locked
    def test_reproduced_unnecessary_support_shrink(self):
        v,opt,bounds,locked=self.example();r=cm.repair('central',v,opt,bounds,locked)
        self.assertTrue(r.ok);self.assertAlmostEqual(r.values['support_width'],3.1998,places=5)
        self.assertAlmostEqual(2*(r.values['a_width']+.4)+r.values['b_width'],6.4,places=6)
        self.assertTrue(all(x.deficit(r.values)<1e-6 for x in cm.rules('central',r.values,opt)))
        self.assertTrue(all(r.values[k]==v[k] for k in locked))
    def test_deterministic(self):
        v,opt,bounds,locked=self.example();self.assertEqual(cm.repair('central',v,opt,bounds,locked),cm.repair('central',v,opt,bounds,locked))
    def test_validator_rejects_refinement(self):
        v,opt,bounds,locked=self.example()
        def validator(x):
            if x['support_width']>2.7:raise ValueError('additional constraint')
        r=cm.repair('central',v,opt,bounds,locked,validator=validator)
        self.assertTrue(r.ok);self.assertLessEqual(r.values['support_width'],2.7)
    def test_locked_support_is_unchanged(self):
        v,opt,bounds,locked=self.example();v['support_width']=2.5;locked.add('support_width')
        r=cm.repair('central',v,opt,bounds,locked);self.assertTrue(r.ok);self.assertEqual(r.values['support_width'],2.5)
    def test_search_failure_not_proof(self):
        v,opt,bounds,locked=self.example();r=cm.repair('central',v,opt,bounds,set(bounds));self.assertFalse(r.ok);self.assertIn('成立不能の証明ではありません',r.reason);self.assertEqual(r.values,v)
    def test_swap_not_linearly_polished(self):
        from test_constraints_v021 import swap
        s=swap(lock_angle=15.);cc=ctx('SWAP',s);self.assertTrue(c.run(cc,s,'swap','lock_angle'));self.assertEqual(s.lock_angle,15.)

class Transaction(unittest.TestCase):
    def test_single_unexpected_locked_mutation_rollback(self):
        s=ball(ball_diameter=10.,opening_diameter=12.,clearance=.5);lock(s,'clearance');base=type(s)
        class Callback(base):
            def __setattr__(self,k,v):
                super().__setattr__(k,v)
                if k=='ball_diameter' and v>10.:self.clearance=.25
        s.__class__=Callback
        self.assertFalse(c.run(ctx('BALL',s),s,'ball','opening_diameter'));self.assertEqual((s.ball_diameter,s.clearance),(10.,.5));self.assertIn('固定値',s['_cjm_constraint_status'])
    def test_single_unplanned_free_mutation(self):
        s=ball(ball_diameter=10.,opening_diameter=12.,shaft_diameter=3.);base=type(s)
        class Callback(base):
            def __setattr__(self,k,v):
                super().__setattr__(k,v)
                if k=='ball_diameter' and v>10.:self.shaft_diameter=2.
        s.__class__=Callback
        self.assertFalse(c.run(ctx('BALL',s),s,'ball','opening_diameter'));self.assertEqual((s.ball_diameter,s.shaft_diameter),(10.,3.));self.assertIn('予定外',s['_cjm_constraint_status'])
    def test_single_out_of_range_write(self):
        s=ball(ball_diameter=10.,opening_diameter=12.);s.bl_rna.properties['ball_diameter'].hard_max=15.;base=type(s)
        class Callback(base):
            def __setattr__(self,k,v):
                if k=='ball_diameter' and v>10.:v=16.
                super().__setattr__(k,v)
        s.__class__=Callback
        self.assertFalse(c.run(ctx('BALL',s),s,'ball','opening_diameter'));self.assertEqual(s.ball_diameter,10.);self.assertIn('補正範囲外',s['_cjm_constraint_status'])
    def test_single_focus_restore(self):
        s=ball(ball_diameter=10.,opening_diameter=12.);s.live_focus='opening_diameter';base=type(s)
        class Callback(base):
            def __setattr__(self,k,v):
                super().__setattr__(k,v)
                if k=='ball_diameter':self.live_focus=k
        s.__class__=Callback
        self.assertTrue(c.run(ctx('BALL',s),s,'ball','opening_diameter'));self.assertEqual(s.live_focus,'opening_diameter')
    def test_pair_unplanned_free_mutation(self):
        a,b,cc=pair();base=type(b)
        class Callback(base):
            def __setattr__(self,k,v):
                super().__setattr__(k,v)
                if k=='outer_diameter' and v<5.:self.support_width=1.5
        b.support_width=2.;b.__class__=Callback
        self.assertFalse(c.run_pair(cc,'UPPER','outer_diameter'));self.assertEqual((a.outer_diameter,b.outer_diameter,b.support_width),(8.,5.,2.));self.assertIn('予定外',b['_cjm_constraint_status'])
    def test_restore_reports_unrecoverable_value(self):
        v={'a':2.,'b':3.}
        def write(k,x):
            if k=='a':raise ValueError('simulated unavailable property')
            v[k]=x
        self.assertEqual(c.restore_dimensions(lambda:dict(v),write,{'a':1.,'b':1.}),['a']);self.assertEqual(v['b'],1.)

if __name__=='__main__':unittest.main()
