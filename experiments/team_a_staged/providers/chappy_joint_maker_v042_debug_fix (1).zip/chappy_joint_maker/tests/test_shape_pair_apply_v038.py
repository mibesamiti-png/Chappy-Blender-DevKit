"""Atomic paired dimension adoption; simulated writes and generation only."""
import unittest, json
from unittest.mock import Mock, patch
from types import SimpleNamespace as NS
import test_shape_pairs_v037 as pair_tests
from test_shape_diagnostics_v029 import extract
from test_constraints_v022 import lock
from chappy_joint_maker import shape_apply as a, shape_candidates as p, shape_trials as t, shape_comparison as c

class Transaction(unittest.TestCase):
    def setUp(self):
        self.old={'upper.a':2.,'upper.b':3.,'lower.a':5.};self.v=self.old.copy();self.changes={'upper.a':1.9,'upper.b':2.8}
    def restore(self,old):self.v=old.copy();return []
    def run_commit(self,write=None,finish=lambda:None,restore=None,changes=None):
        a.commit_many(lambda:self.v.copy(),write or self.v.__setitem__,restore or self.restore,finish,self.old,self.changes if changes is None else changes)
    def test_success(self):self.run_commit();self.assertEqual(self.v,{**self.old,**self.changes})
    def test_second_write_failure(self):
        def write(k,v):
            self.v[k]=v
            if k=='upper.b':raise RuntimeError('second write')
        with self.assertRaisesRegex(RuntimeError,'second write'):self.run_commit(write)
        self.assertEqual(self.v,self.old)
    def test_first_write_side_effect(self):
        def write(k,v):self.v.update({k:v,'lower.a':1.})
        with self.assertRaises(ValueError):self.run_commit(write)
        self.assertEqual(self.v,self.old)
    def test_second_rounding(self):
        def write(k,v):self.v[k]=v if k=='upper.a' else 2.7
        with self.assertRaises(ValueError):self.run_commit(write)
        self.assertEqual(self.v,self.old)
    def test_finish_failure(self):
        with self.assertRaises(RuntimeError):self.run_commit(finish=Mock(side_effect=RuntimeError('finish')))
        self.assertEqual(self.v,self.old)
    def test_finish_side_effect(self):
        with self.assertRaises(ValueError):self.run_commit(finish=lambda:self.v.update({'lower.a':6.}))
        self.assertEqual(self.v,self.old)
    def test_incomplete_restore(self):
        with self.assertRaisesRegex(RuntimeError,'復元未完了'):self.run_commit(finish=Mock(side_effect=RuntimeError()),restore=lambda _:['upper.b'])
    def test_restore_raises(self):
        with self.assertRaisesRegex(RuntimeError,'復元未完了'):self.run_commit(finish=Mock(side_effect=RuntimeError()),restore=Mock(side_effect=ValueError('rollback')))
    def test_invalid_changes(self):
        for changes in ({},{'x':2.},{'upper.a':float('nan')},{'upper.a':2.},{'upper.a':1.,'upper.b':2.,'lower.a':3.}):
            write=Mock()
            with self.assertRaises(ValueError):self.run_commit(write,changes=changes)
            write.assert_not_called()
    def test_stale(self):
        self.v['lower.a']=6.;write=Mock()
        with self.assertRaises(RuntimeError):self.run_commit(write)
        write.assert_not_called()

class PairAdoption(unittest.TestCase):
    def setUp(self):
        # Reuse the same fixture setup without inheriting its tests.
        pair_tests.Pairs.setUp(self);self.failure=self.fail;del self.fail;self.s.active_joint='LOWER';self.u.live_focus=self.l.live_focus='axle_diameter'
        for j in (self.u,self.l):
            for k,v in vars(j).copy().items():
                if isinstance(v,float):setattr(j,k,v)
        self.data=p.inputs(self.ctx,self.s);self.advice=p.capture(self.ctx,self.s,self.e)
        self.s.last_shape_candidates=self.advice;self.initial=p.display(self.ctx,self.s,self.e)
        self.record={'status':'DONE','rows':[{'item':i,'result':{'status':'UNCHANGED'}} for i in self.initial]}
        self.payload=pair_tests.Pairs.pair(self);self.items=json.loads(self.payload)['candidates'];self.s.last_shape_candidates=self.payload
        self.result={'status':'DONE','rows':[{'item':i,'result':{'status':'PASS'}} for i in self.items]}
        self.s.last_shape_comparison=c.encode(self.payload,self.result)
    def passing(self):return a.passing_item(self.s.last_shape_comparison,self.payload,self.items,0,allow_pair=True)
    def test_pair_pass(self):self.assertEqual(self.passing(),self.items[0])
    def test_pair_nonpass(self):
        self.result['rows'][0]['result']['status']='IMPROVED';self.s.last_shape_comparison=c.encode(self.payload,self.result)
        with self.assertRaises(ValueError):self.passing()
    def test_pair_duplicate(self):
        self.items[0]['changes'][1]=self.items[0]['changes'][0].copy();self.s.last_shape_comparison=c.encode(self.payload,self.result)
        with self.assertRaises(ValueError):self.passing()
    def test_pair_cross_side(self):
        self.items[0]['changes'][1]['side']='LOWER';self.s.last_shape_comparison=c.encode(self.payload,self.result)
        with self.assertRaises(ValueError):self.passing()
    def operator(self,mode):
        if mode=='lock':lock(self.u,self.items[0]['changes'][0]['key'])
        before=p.inputs(self.ctx,self.s);attempt=Mock(side_effect=[self.failure,self.failure if mode=='fail' else self.ok]);signature=Mock(side_effect=[1,1,1,2] if mode=='drift' else None,return_value=1)
        adopt=NS(passing_item=a.passing_item,verify=a.verify,commit=a.commit,commit_many=a.commit_many,source_signature=signature)
        env=dict(__name__='chappy_joint_maker.double_joint',__package__='chappy_joint_maker',candidates=p,trials=NS(select=t.select,proxies=t.proxies,attempt=attempt),adoption=adopt,FIELDS=pair_tests.Pairs.fields(self),bpy=NS(),plans=None,build=None,fh=NS(_make_collection=None,_destroy_collection=None),restore_selection=None,cj=NS(cm=NS(inspection_angles=None)),ui=NS(redraw=Mock()))
        fn=extract('double_joint.py','execute',env,'CJM_OT_double_apply_candidate')
        def run():return fn(NS(poll=lambda _:True,report=Mock(),index=0),self.ctx)
        if mode=='numeric':
            real=p.numerically_valid
            def validate(v,opt,extras):
                if any(getattr(self.u,i['key'])!=i['before'] for i in self.items[0]['changes']):return False
                return real(v,opt,extras)
            with patch.object(p,'numerically_valid',side_effect=validate):res=run()
        else:res=run()
        if mode=='success':
            self.assertEqual(res,{'FINISHED'},self.s.status);self.assertEqual(p.inputs(self.ctx,self.s)[0],{**before[0],**{'upper.'+i['key']:i['after'] for i in self.items[0]['changes']}})
            self.assertEqual(self.s.last_shape_candidates,'');self.assertEqual(run(),{'CANCELLED'});self.assertEqual(attempt.call_count,2)
        else:self.assertEqual(res,{'CANCELLED'},self.s.status);self.assertEqual(p.inputs(self.ctx,self.s),before)
        self.assertEqual((self.s.active_joint,self.u.live_focus,self.l.live_focus),('LOWER','axle_diameter','axle_diameter'))
        if mode=='lock':attempt.assert_not_called()
    def test_operator_success(self):self.operator('success')
    def test_operator_fail(self):self.operator('fail')
    def test_operator_drift(self):self.operator('drift')
    def test_operator_lock(self):self.operator('lock')
    def test_operator_numeric_rollback(self):self.operator('numeric')
