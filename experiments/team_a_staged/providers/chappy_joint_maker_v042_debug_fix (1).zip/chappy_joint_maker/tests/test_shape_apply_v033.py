import unittest
from unittest.mock import Mock
from types import SimpleNamespace as NS
from test_shape_candidates_v030 import fixture,detail
from test_shape_diagnostics_v029 import extract
from chappy_joint_maker import shape_apply as a, shape_candidates as p, shape_trials as t,shape_comparison as c,shape_diagnostics as d

class Apply(unittest.TestCase):
    def setUp(self):
        self.item={'side':'UPPER','key':'support_width','before':2.,'after':1.9,'policy':'FREE'}
        self.items=[self.item];self.record={'status':'DONE','rows':[{'item':self.item,'result':{'status':'PASS'}}]}
        self.e=detail();self.fail=t.Outcome('FAILED','fail',self.e);self.ok=t.Outcome('PASS','ok')
        self.values={'upper.a':2.,'lower.a':5.};self.before=dict(self.values)
    def passing(self):return a.passing_item(c.encode('advice',self.record),'advice',self.items,0)
    def test_pass(self):self.assertEqual(self.passing(),self.item)
    def test_failed_candidate(self):
        self.record['rows'][0]['result']['status']='IMPROVED';self.assertRaises(ValueError,self.passing)
    def test_incomplete(self):
        self.record['status']='ERROR';self.assertRaises(ValueError,self.passing)
    def test_item_mismatch(self):
        self.record['rows'][0]['item']={**self.item,'after':1.8};self.assertRaises(ValueError,self.passing)
    def test_stale_advice(self):self.assertRaises(ValueError,a.passing_item,c.encode('old',self.record),'new',self.items,0)
    def test_verify(self):
        fn=Mock(side_effect=[self.fail,self.ok]);check=Mock();a.verify(self.e,1,2,fn,check);self.assertEqual(fn.call_count,2);self.assertEqual(check.call_count,3)
    def test_baseline_no_longer_fails(self):
        fn=Mock(return_value=self.ok);self.assertRaises(ValueError,a.verify,self.e,1,2,fn,Mock());fn.assert_called_once()
    def test_candidate_no_longer_passes(self):self.assertRaises(ValueError,a.verify,self.e,1,2,Mock(return_value=self.fail),Mock())
    def test_drift(self):
        fn=Mock(return_value=self.fail);self.assertRaises(RuntimeError,a.verify,self.e,1,2,fn,Mock(side_effect=[None,RuntimeError()]));fn.assert_called_once()
    def read(self):return dict(self.values)
    def restore(self,v):self.values=dict(v);return []
    def commit(self,write=None,finish=lambda:None,restore=None):a.commit(self.read,write or self.values.__setitem__,restore or self.restore,finish,self.before,'upper.a',1.9)
    def test_commit(self):self.commit();self.assertEqual(self.values,{'upper.a':1.9,'lower.a':5.})
    def test_clamp(self):
        self.assertRaises(ValueError,self.commit,lambda k,v:self.values.update({k:1.8}));self.assertEqual(self.values,self.before)
    def test_other_side(self):
        self.assertRaises(ValueError,self.commit,lambda k,v:self.values.update({k:v,'lower.a':4.}));self.assertEqual(self.values,self.before)
    def test_finish_failure(self):
        self.assertRaises(RuntimeError,self.commit,finish=Mock(side_effect=RuntimeError('finish')));self.assertEqual(self.values,self.before)
    def test_rollback_failure(self):
        self.assertRaisesRegex(RuntimeError,'復元未完了',self.commit,finish=Mock(side_effect=RuntimeError()),restore=lambda v:['upper.a'])
    def test_stale_before_write(self):
        self.values['lower.a']=4.;write=Mock();self.assertRaises(RuntimeError,self.commit,write);write.assert_not_called()
    def test_digest(self):
        mesh=NS(vertices=[NS(co=(0.,0.,0.)),NS(co=(1.,0.,0.)),NS(co=(0.,1.,0.))],edges=[NS(vertices=(0,1))],polygons=[NS(vertices=(0,1,2))]);old=a.mesh_digest(mesh);self.assertEqual(old,a.mesh_digest(mesh));mesh.vertices[0].co=(.1,0.,0.);self.assertNotEqual(old,a.mesh_digest(mesh));mesh.vertices[0].co=(0.,0.,0.);mesh.polygons[0].vertices=(2,1,0);self.assertNotEqual(old,a.mesh_digest(mesh))

class Integration(unittest.TestCase):
    def run_operator(self,pass_candidate=True,drift=False):
        u,l,ctx,s=fixture();s.active_joint='LOWER';u.live_focus=l.live_focus='axle_diameter';u.preview_angle=l.preview_angle=0.
        e=detail();s.last_generation_diagnostic=e.encode();s.last_shape_candidates=p.capture(ctx,s,e);items=p.display(ctx,s,e);item=items[0]
        s.last_shape_comparison=c.encode(s.last_shape_candidates,{'status':'DONE','rows':[{'item':i,'result':{'status':'PASS'}} for i in items]})
        before=p.inputs(ctx,s);fields=tuple(k for k in vars(u) if k in ('outer_diameter','support_width','a_width','b_width','axle_diameter','radial_clearance','axial_gap','cap_wall','radial_wall','tip_clearance','shoulder_diameter','shoulder_thickness','shoulder_radial_clearance','shoulder_axial_clearance','support_thickness','embed_depth','swing_clearance','angle_step'))
        attempt=Mock(side_effect=[t.Outcome('FAILED','fail',e),t.Outcome('PASS','pass') if pass_candidate else t.Outcome('FAILED','fail',e)])
        signature=Mock(side_effect=[1,1,2] if drift else None,return_value=1)
        adopt=NS(passing_item=a.passing_item,verify=a.verify,commit=a.commit,source_signature=signature)
        env=dict(__name__='chappy_joint_maker.double_joint',__package__='chappy_joint_maker',candidates=p,trials=NS(select=t.select,proxies=t.proxies,attempt=attempt),adoption=adopt,FIELDS=fields,bpy=NS(),plans=None,build=None,fh=NS(_make_collection=None,_destroy_collection=None),restore_selection=None,cj=NS(cm=NS(inspection_angles=None)),ui=NS(redraw=Mock()))
        fn=extract('double_joint.py','execute',env,'CJM_OT_double_apply_candidate');res=fn(NS(poll=lambda x:True,report=Mock(),index=0),ctx)
        if pass_candidate and not drift:
            self.assertEqual(res,{'FINISHED'},s.status);self.assertEqual(p.inputs(ctx,s)[0],{**before[0],'upper.'+item['key']:item['after']});self.assertEqual(s.last_shape_candidates,'');self.assertIn('_cjm_snapshot_central',u)
        else:self.assertEqual(res,{'CANCELLED'});self.assertEqual(p.inputs(ctx,s),before)
        self.assertEqual((s.active_joint,u.live_focus,l.live_focus),('LOWER','axle_diameter','axle_diameter'))
        self.assertEqual(attempt.call_count,1 if drift else 2)
    def test_success(self):self.run_operator()
    def test_failed(self):self.run_operator(False)
    def test_drift(self):self.run_operator(drift=True)
