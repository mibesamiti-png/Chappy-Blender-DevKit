"""Independent LP comparison for fixed length, cap and support constraints. Requires SciPy only offline."""
import sys,random,json
from audit_linear_v026 import reference,score,cm
rng=random.Random(2711); cases=[]
for i in range(160):
 v=dict(outer_diameter=rng.uniform(2,8),axle_diameter=rng.uniform(.5,4),a_width=rng.uniform(.2,5),b_width=rng.uniform(.2,6),support_width=rng.uniform(.2,6),radial_clearance=.4,tip_clearance=rng.uniform(.1,1.4),axial_gap=rng.uniform(.1,1),swing_clearance=.4,radial_wall=.35,cap_wall=rng.uniform(.3,2))
 keys=('a_width','b_width','support_width','tip_clearance','axial_gap')
 bounds={k:(.1,8) if k not in ('tip_clearance','axial_gap') else (.1,1.5) for k in keys}
 for k in keys:
  if rng.random()<.5: bounds[k]=(max(.1,v[k]-rng.uniform(.05,1.5)),v[k]+rng.uniform(.05,1.5))
 locked={k for k in keys if rng.random()<.15};edited=rng.choice(keys);preferred={k for k in keys if rng.random()<.25}
 opt=dict(length=rng.uniform(3,14),separation=(.6,.8,20))
 v['outer_diameter']=max(v['outer_diameter'],v['axle_diameter']+1.6)
 ref=reference(v,opt,bounds,locked,edited,preferred)
 r=cm.repair('central',v,opt,bounds,locked,edited=edited,preferred=preferred)
 sr=score(ref,v,bounds,edited,preferred) if ref else None; sc=score(r.values,v,bounds,edited,preferred)
 typ='infeasible' if ref is None and not r.ok else 'unexpected' if ref is None else 'missed' if not r.ok else 'suboptimal' if sc[:3]>sr[:3] or sc[:3]==sr[:3] and sc[3]>sr[3]+1e-6 else 'matched'
 cases.append(dict(i=i,type=typ,values=v,options=opt,bounds=bounds,locked=sorted(locked),edited=edited,preferred=sorted(preferred),reference=ref,result=r.values,reference_score=sr,score=sc,explored=r.explored))
from collections import Counter
print(Counter(e['type'] for e in cases));
if len(sys.argv)>1:
 with open(sys.argv[1],'w',encoding='utf-8') as f:json.dump(cases,f,indent=2,ensure_ascii=False)
