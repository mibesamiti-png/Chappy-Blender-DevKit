"""Independent box-feasibility oracle for swap constraints (SciPy, audit only).
Eliminate lug angle and lock angle analytically, solve remaining linear rows.
"""
import random, math, json
from scipy.optimize import linprog
from test_constraints_v021 import cm,swap_math
KEYS=tuple(k for k in vars(swap_math.Spec()) if k not in ('flange','lug_count','direction'))
RANGES=dict(zip(KEYS,[(.5,30),(.5,20),(.1,8),(.1,5),(4,90),(5,150),(.01,3),(.01,3),(.2,5)]))
def valid(v,n):
    swap_math.plan(swap_math.Spec(**v,lug_count=n))
def oracle(v,n,bounds,locked):
    box={k:(v[k],v[k]) if k in locked else bounds[k] for k in KEYS}
    a=box['lug_angle'][0];lo,hi=box['lock_angle'];pitch=360/n
    pad=min(hi-a-cm.EPS,(pitch-2-a-lo-cm.EPS)/2,(pitch-2-2*a-2*cm.EPS)/3)
    if pad<=1:return None
    ratio=math.sin(math.radians(min(90.,pad-1)))/2
    keys=[k for k in KEYS if k not in ('lug_angle','lock_angle')]
    # Independent derivation, not calls to cm.rules.
    rows=[]
    def add(rhs,**terms):rows.append(([-terms.get(k,0) for k in keys],-rhs))
    e=cm.EPS
    add(e,lug_projection=1,radial_clearance=-1)
    add(e,diameter=1,radial_clearance=-4)
    for ac,ak in ((2,.5),(3,0)):
        for wc,wk in ((0,.5),(.5,0)):
            add(ak+wk+e,depth=1,lug_height=-1,axial_clearance=-ac,wall=-wc)
    sag=1-math.cos(math.radians(1))
    add(e,diameter=-.5,lug_projection=-1,radial_clearance=1/sag-1)
    add(0,diameter=ratio,radial_clearance=-1)
    r=linprog([0]*len(keys),A_ub=[x for x,y in rows],b_ub=[y for x,y in rows],bounds=[box[k] for k in keys],method='highs')
    if r.status==2:return None
    if not r.success:raise RuntimeError(r.message)
    w=dict(zip(keys,map(float,r.x)));p=math.degrees(math.asin(2*w['radial_clearance']/w['diameter']))+1
    w['lug_angle']=a;w['lock_angle']=max(lo,a+p+e)
    assert w['lock_angle']<=hi+1e-6
    valid(w,n)
    return w

def cases(count=240):
    rng=random.Random(2811)
    for i in range(count):
        n=rng.choice([2,3,4]);v={k:rng.uniform(*b) for k,b in RANGES.items()}
        bounds={k:(max(lo,x-rng.uniform(.1,.7)*(hi-lo)),min(hi,x+rng.uniform(.1,.7)*(hi-lo))) for k,(lo,hi) in RANGES.items() for x in [v[k]]}
        locked={k for k in KEYS if rng.random()<.42};edited=rng.choice(KEYS);preferred={k for k in KEYS if rng.random()<.2}
        yield v,n,bounds,locked,edited,preferred

def audit(count=240):
    counts=dict(feasible=0,infeasible=0,miss=0,false=0,states=0,miss_examples=[])
    for v,n,b,l,e,p in cases(count):
        w=oracle(v,n,b,l);r=cm.repair('swap',v,{'lug_count':n},b,l,e,validator=lambda x:valid(x,n),preferred=p)
        counts['states']+=r.explored;counts['feasible' if w is not None else 'infeasible']+=1
        if w is not None and not r.ok:
            counts['miss']+=1;counts['miss_examples'].append(dict(v=v,n=n,b=b,l=sorted(l),e=e,p=sorted(p),w=w,reason=r.reason))
        if w is None and r.ok:counts['false']+=1
    return counts
if __name__=='__main__':print(json.dumps(audit(),indent=2,ensure_ascii=False))
