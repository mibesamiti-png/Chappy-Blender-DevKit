"""Mock orchestration only. No Blender geometry claims."""
import unittest
from types import SimpleNamespace as NS
from unittest.mock import Mock
from test_shape_candidates_v030 import fixture,detail
from chappy_joint_maker import shape_trials as t, shape_candidates as p, shape_diagnostics as d

class Trial(unittest.TestCase):
    def setUp(self):
        self.e=detail();self.base=object();self.trial=object()
        self.fail=t.Outcome('FAILED','test',self.e);self.ok=t.Outcome('PASS','test')
    def test_baseline_then_candidate(self):
        fn=Mock(side_effect=[self.fail,self.ok]);self.assertEqual(t.run(self.e,self.base,self.trial,fn).status,'PASS');self.assertEqual([a.args[0] for a in fn.call_args_list],[self.base,self.trial])
    def test_baseline_pass_stale(self):
        fn=Mock(return_value=self.ok);self.assertEqual(t.run(self.e,self.base,self.trial,fn).status,'STALE');fn.assert_called_once_with(self.base)
    def test_wrong_side_stale(self):
        fn=Mock(return_value=t.Outcome('FAILED','test',detail(side='LOWER')));self.assertEqual(t.run(self.e,self.base,self.trial,fn).status,'STALE');fn.assert_called_once()
    def test_baseline_error_no_retry(self):
        fn=Mock(return_value=t.Outcome('ERROR','bad'));self.assertEqual(t.run(self.e,self.base,self.trial,fn).status,'ERROR');fn.assert_called_once()
    def test_candidate_failure_no_retry(self):
        fn=Mock(side_effect=[self.fail,self.fail]);self.assertEqual(t.run(self.e,self.base,self.trial,fn),self.fail);self.assertEqual(fn.call_count,2)
    def test_cleanup_failure_no_retry(self):
        fn=Mock(side_effect=RuntimeError('cleanup'));self.assertRaises(RuntimeError,t.run,self.e,self.base,self.trial,fn);fn.assert_called_once()
    def test_select_revalidates(self):
        a,b,ctx,s=fixture();s.last_generation_diagnostic=self.e.encode();s.last_shape_candidates=p.capture(ctx,s,self.e)
        _,item=t.select(ctx,s,0);self.assertIn(item['key'],('outer_diameter','support_width'));a.outer_diameter=6.;self.assertRaises(ValueError,t.select,ctx,s,0)
    def test_proxies_only_one_change(self):
        a,b,ctx,s=fixture();a.preview_angle=b.preview_angle=0.;before=a.outer_diameter
        item=dict(side='UPPER',key='outer_diameter',before=before,after=4.75)
        fields=('outer_diameter','support_width','a_width','b_width','axle_diameter')
        base,trial=t.proxies(s,fields,item);self.assertEqual(a.outer_diameter,before);self.assertEqual(base.upper.outer_diameter,before);self.assertEqual(trial.upper.outer_diameter,4.75);self.assertEqual(vars(base.lower),vars(trial.lower));self.assertEqual({k for k in vars(base.upper) if getattr(base.upper,k)!=getattr(trial.upper,k)},{'outer_diameter'})
    def test_proxy_stale_value(self):
        a,b,ctx,s=fixture();a.preview_angle=b.preview_angle=0.
        self.assertRaises(ValueError,t.proxies,s,('outer_diameter',),dict(side='UPPER',key='outer_diameter',before=99,after=4.75))

class Isolation(unittest.TestCase):
    def setUp(self):
        self.active=object();self.ctx=NS(scene=object(),selected_objects=[self.active],view_layer=NS(objects=NS(active=self.active)))
        self.j=NS(minimum_angle=0,maximum_angle=45,angle_step=5)
        self.pairs=[(self.j,{'angles':range(10)})]*2;self.col=object();self.s=object()
        self.plan=Mock(return_value=self.pairs);self.build=Mock(return_value=(1,2,3));self.create=Mock(return_value=self.col);self.destroy=Mock();self.restore=Mock();self.inv=Mock(return_value=(1,2,3));self.angles=Mock(return_value=range(19))
    def run_attempt(self):
        return t.attempt(self.ctx,self.s,plans=self.plan,build=self.build,create=self.create,destroy=self.destroy,restore=self.restore,inventory=self.inv,inspection_angles=self.angles)
    def check_cleanup(self):
        self.destroy.assert_called_once_with(self.col);self.restore.assert_called_once_with(self.ctx,(self.active,),self.active)
    def test_pass_discard(self):
        self.assertEqual(self.run_attempt().status,'PASS');self.check_cleanup();self.build.assert_called_once_with(self.ctx,self.s,self.col,self.pairs)
    def test_shape_failure_discard(self):
        e=detail();self.build.side_effect=d.ShapeFailure(e);self.assertEqual(self.run_attempt().diagnostic,e);self.check_cleanup()
    def test_unknown_failure_discard(self):
        self.build.side_effect=RuntimeError('Boolean');self.assertEqual(self.run_attempt().status,'ERROR');self.check_cleanup()
    def test_invalid_result_discard(self):
        self.build.return_value=(1,2);self.assertEqual(self.run_attempt().status,'ERROR');self.check_cleanup()
    def test_budget_no_build(self):
        self.angles.return_value=range(201);self.assertEqual(self.run_attempt().status,'ERROR');self.create.assert_not_called();self.build.assert_not_called();self.restore.assert_called_once()
    def test_inventory_leak_stops(self):
        self.inv.side_effect=[(1,2,3),(1,2,4)];self.assertRaisesRegex(RuntimeError,'データブロック差分',self.run_attempt);self.check_cleanup()
    def test_selection_leak_stops(self):
        self.build.side_effect=lambda *a:(self.ctx.selected_objects.clear() or (1,2,3));self.assertRaisesRegex(RuntimeError,'選択状態',self.run_attempt);self.check_cleanup()
    def test_destroy_failure_restores_selection(self):
        self.destroy.side_effect=RuntimeError('cleanup');self.assertRaisesRegex(RuntimeError,'cleanup',self.run_attempt);self.restore.assert_called_once()

if __name__=='__main__':unittest.main()
