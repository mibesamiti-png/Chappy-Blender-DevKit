"""One midpoint probe with independently replayed passing parent; no Blender runtime."""
import unittest,json
from unittest.mock import Mock
from types import SimpleNamespace as NS
from test_shape_candidates_v030 import fixture,detail
from test_shape_diagnostics_v029 import extract
from test_constraints_v022 import lock,free
from chappy_joint_maker import shape_candidates as p,shape_comparison as c,shape_trials as t,shape_apply as a,shape_diagnostics as d

class Refinement(unittest.TestCase):
    def setUp(self):
        self.u,self.l,self.ctx,self.s=fixture();self.u.preview_angle=self.l.preview_angle=0.
        self.e=detail(unit='volume');self.s.last_generation_diagnostic=self.e.encode()
        self.data=p.inputs(self.ctx,self.s);self.advice=p.capture(self.ctx,self.s,self.e);self.s.last_shape_candidates=self.advice
        self.initial=p.display(self.ctx,self.s,self.e)
        self.record={'status':'DONE','rows':[{'item':i,'result':{'status':'PASS'}} for i in self.initial]}
        self.fail=t.Outcome('FAILED','failure',self.e);self.ok=t.Outcome('PASS','pass')
    def refine(self):return p.refinement(self.advice,self.record,self.e,self.data,self.s)
    def test_midpoint_and_recompute(self):
        payload=self.refine();items=json.loads(payload)['candidates'];parent,mid=items
        self.assertEqual(parent,self.initial[0]);self.assertEqual(mid['key'],parent['key']);self.assertAlmostEqual(mid['after'],(parent['before']+parent['after'])/2,places=5)
        self.assertEqual(items,p.recompute(payload,self.e,self.data));self.assertEqual(p.inputs(self.ctx,self.s),self.data)
    def test_only_pass(self):
        self.record['rows'][0]['result']['status']='IMPROVED';self.assertEqual(json.loads(self.refine())['candidates'][0],self.initial[1])
    def test_no_pass_or_incomplete(self):
        self.record['status']='ERROR';self.assertEqual(self.refine(),'');self.record['status']='DONE'
        for row in self.record['rows']:row['result']['status']='IMPROVED'
        self.assertEqual(self.refine(),'')
    def test_reordered_rows(self):
        self.record['rows'].reverse();self.assertEqual(self.refine(),'')
    def test_no_repeat(self):
        payload=self.refine();items=json.loads(payload)['candidates'];record={'status':'DONE','rows':[{'item':i,'result':{'status':'PASS'}} for i in items]}
        self.assertEqual(p.refinement(payload,record,self.e,self.data,self.s),'');self.assertEqual(p.expansion(payload,record,self.e,self.data,self.s),'')
    def test_expanded_parent(self):
        for r in self.record['rows']:r['result']['status']='IMPROVED'
        self.advice=p.expansion(self.advice,self.record,self.e,self.data,self.s);items=json.loads(self.advice)['candidates']
        self.record={'status':'DONE','rows':[{'item':i,'result':{'status':'PASS'}} for i in items]}
        self.assertEqual(json.loads(self.refine())['candidates'][0],items[0])
    def test_increasing_direction(self):
        free(self.u,'swing_clearance');e=detail('POSE_INTERFERENCE',unit='volume');data=p.inputs(self.ctx,self.s);initial=p.propose(e,*data);self.assertTrue(initial)
        parent,mid=p.refined_propose(e,data,'INITIAL',[],initial[0]['key']);self.assertLess(parent['before'],mid['after']);self.assertLess(mid['after'],parent['after'])
    def test_lock_and_tampering(self):
        payload=self.refine();self.s.last_shape_candidates=payload;self.assertEqual(t.select(self.ctx,self.s,1)[1],json.loads(payload)['candidates'][1]);bad=json.loads(payload);bad['candidates'][1]['after']+=.01;self.s.last_shape_candidates=json.dumps(bad)
        self.assertRaises(ValueError,t.select,self.ctx,self.s,1);self.s.last_shape_candidates=payload;lock(self.u,self.initial[0]['key']);self.assertRaises(ValueError,t.select,self.ctx,self.s,1)
    def test_clamped_midpoint_no_duplicate(self):
        orig,opt,bounds,pol,extra=self.data;bounds=dict(bounds);key=self.initial[0]['key'];k='upper.'+key;old=orig[k];bounds[k]=(old-.00000001,bounds[k][1]);self.assertEqual(p.refined_propose(self.e,(orig,opt,bounds,pol,extra),'INITIAL',[],key),[])
    def run_compare(self,outcomes):
        payload=self.refine();items=json.loads(payload)['candidates'];fn=Mock(side_effect=outcomes);rec=c.run(self.e,None,[(i,i) for i in items],fn,require_first_pass=True);return payload,items,rec,fn
    def test_midpoint_pass(self):
        payload,items,r,fn=self.run_compare([self.fail,self.ok,self.ok]);self.assertEqual(r['preferred'],1);self.assertEqual(fn.call_count,3);self.assertEqual(a.passing_item(c.encode(payload,r),payload,items,1),items[1])
    def test_midpoint_failure_retains_parent(self):
        payload,items,r,fn=self.run_compare([self.fail,self.ok,self.fail]);self.assertEqual(r['preferred'],0);self.assertEqual(a.passing_item(c.encode(payload,r),payload,items,0),items[0]);self.assertRaises(ValueError,a.passing_item,c.encode(payload,r),payload,items,1)
    def test_parent_failure_stops(self):
        _,_,r,fn=self.run_compare([self.fail,self.fail]);self.assertEqual(r['status'],'STALE');self.assertIsNone(r['preferred']);self.assertEqual(fn.call_count,2)
    def test_midpoint_error_no_recommendation(self):
        _,_,r,fn=self.run_compare([self.fail,self.ok,t.Outcome('ERROR','oops')]);self.assertEqual(r['status'],'ERROR');self.assertIsNone(r['preferred'])
    def test_baseline_stale(self):
        _,_,r,fn=self.run_compare([self.ok]);self.assertEqual(r['status'],'STALE');fn.assert_called_once()
    def test_operator(self):
        self.s.last_shape_comparison=c.encode(self.advice,self.record)
        fields=tuple(k for k in vars(self.u) if k in ('outer_diameter','support_width','a_width','b_width','axle_diameter','radial_clearance','axial_gap','cap_wall','radial_wall','tip_clearance','shoulder_diameter','shoulder_thickness','shoulder_radial_clearance','shoulder_axial_clearance','support_thickness','embed_depth','swing_clearance','angle_step'))
        attempt=Mock(side_effect=[self.fail,self.ok,self.ok]);sig=Mock(return_value=1)
        env=dict(diag=d,candidates=p,trials=NS(select=t.select,proxies=t.proxies,attempt=attempt),comparison=c,adoption=NS(source_signature=sig),FIELDS=fields,bpy=NS(),plans=None,build=None,fh=NS(_make_collection=None,_destroy_collection=None),restore_selection=None,cj=NS(cm=NS(inspection_angles=None)),ui=NS(redraw=Mock()))
        fn=extract('double_joint.py','execute',env,'CJM_OT_double_compare');self.assertEqual(fn(NS(poll=lambda x:True,report=Mock(),refine=True),self.ctx),{'FINISHED'});self.assertEqual(p.inputs(self.ctx,self.s),self.data);self.assertEqual(attempt.call_count,3);self.assertEqual(c.display(self.s.last_shape_comparison,self.s.last_shape_candidates)['preferred'],1)
