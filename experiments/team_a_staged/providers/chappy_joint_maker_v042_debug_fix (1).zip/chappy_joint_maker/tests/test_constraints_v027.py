"""Conservative interval proof and preservation of existing repair behavior."""
import unittest
from test_constraints_v021 import cm
import test_constraints_v025 as prior

class IntervalProof(unittest.TestCase):
    def case(self):
        v,opt,bounds,locked=prior.Refinement().example()
        return v,opt,bounds,locked
    def test_linked_length_conflict(self):
        v,opt,bounds,locked=self.case()
        # Each local rule can be satisfied alone, but fixed length, the cap
        # and the locked support width cannot all be satisfied together.
        v['support_width']=4.;locked.add('support_width')
        opt['separation']=None
        self.assertIsNotNone(cm._linear_interval_conflict('central',v,opt,bounds,locked))
        r=cm.repair('central',v,opt,bounds,locked)
        self.assertFalse(r.ok);self.assertEqual(r.explored,0);self.assertEqual(r.values,v)
        self.assertIn('数値制約が成立しません',r.reason)
    def test_feasible_same_example(self):
        v,opt,bounds,locked=self.case()
        self.assertIsNone(cm._linear_interval_conflict('central',v,opt,bounds,locked))
        r=cm.repair('central',v,opt,bounds,locked);self.assertTrue(r.ok)
        self.assertAlmostEqual(r.values['support_width'],3.1998,places=5)
    def test_manual_outside_bounds_not_rejected(self):
        v=dict(ball_diameter=10.,opening_diameter=8.,shaft_diameter=3.,clearance=.2)
        opt=dict(socket=True,retain=True,shaft=True)
        b={'ball_diameter':(1.,5.),'opening_diameter':(1.,4.)}
        self.assertIsNone(cm._linear_interval_conflict('ball',v,opt,b,()))
        r=cm.repair('ball',v,opt,b);self.assertTrue(r.ok);self.assertEqual(r.values,v)
    def test_locked_values_outside_bounds(self):
        v=dict(ball_diameter=10.,opening_diameter=12.,shaft_diameter=3.,clearance=.4)
        opt=dict(socket=True,retain=True,shaft=True)
        b={'ball_diameter':(1.,5.),'opening_diameter':(1.,9.)}
        self.assertIsNone(cm._linear_interval_conflict('ball',v,opt,b,{'ball_diameter'}))
        r=cm.repair('ball',v,opt,b,{'ball_diameter'});self.assertTrue(r.ok);self.assertEqual(r.values['ball_diameter'],10.)
    def test_tolerance_boundary(self):
        v=dict(ball_diameter=10.,opening_diameter=10.-cm.EPS+5e-8,shaft_diameter=3.,clearance=.4)
        opt=dict(socket=True,retain=True,shaft=True);b={'ball_diameter':(1.,10.)}
        self.assertIsNone(cm._linear_interval_conflict('ball',v,opt,b,()))
        self.assertTrue(cm.repair('ball',v,opt,b).ok)
    def test_nonlinear_excluded(self):
        self.assertIsNone(cm._linear_interval_conflict('swap',{}, {}, {'diameter':(1.,2.)},()))
    def test_adjustable_rule_constant_excluded(self):
        v,opt,bounds,locked=self.case();bounds['cap_wall']=(.1,2.)
        self.assertIsNone(cm._linear_interval_conflict('central',v,opt,bounds,locked))
    def test_validator_failure_not_proof(self):
        v=dict(ball_diameter=10.,opening_diameter=8.,shaft_diameter=3.,clearance=.4)
        def reject(_):raise ValueError('external validation')
        r=cm.repair('ball',v,dict(socket=True,retain=True,shaft=True),{'ball_diameter':(1.,15.)},validator=reject)
        self.assertFalse(r.ok);self.assertGreater(r.explored,0);self.assertIn('成立不能の証明ではありません',r.reason)
    def test_pair_fixed_length_conflict(self):
        v0,opt,b,locked=self.case();v={s+'.'+k:x for s in ('upper','lower') for k,x in v0.items()}
        bounds={s+'.'+k:x for s in ('upper','lower') for k,x in b.items()}
        options={'projection':(1.,0.,5.),'upper':{'length':6.4},'lower':{'length':6.4}}
        r=cm.repair('central_pair',v,options,bounds)
        self.assertFalse(r.ok);self.assertEqual(r.explored,0);self.assertEqual(r.values,v)

if __name__=='__main__':unittest.main()
