"""Fixed-length substitution regressions; standard library only."""
import json, unittest, random
from pathlib import Path
from test_constraints_v021 import cm

EXAMPLES=json.loads(Path(__file__).with_name('linear_regression_v026.json').read_text())

def score(v,o,keys,edited,preferred):
    diff=[k for k in keys if abs(v[k]-o[k])>1e-7]
    return (int(edited in diff),len(set(preferred)&set(diff)),len(diff),sum(abs(v[k]-o[k])/max(abs(o[k]),1) for k in diff))

def check_example(test,i):
    e=EXAMPLES[i];v=e['values'];opt=e['options'];bounds=e['bounds'];locked=e['locked']
    r=cm.repair('central',v,opt,bounds,locked,edited=e['edited'],preferred=e['preferred']);test.assertTrue(r.ok,r.reason)
    x=r.values;sc=score(x,v,bounds,e['edited'],e['preferred']);ref=e['reference_score']
    test.assertEqual(sc[:3],tuple(ref[:3]));test.assertAlmostEqual(sc[3],ref[3],places=6)
    for k in v:
        if k not in bounds or k in locked:test.assertEqual(x[k],v[k])
        elif x[k]!=v[k]:test.assertTrue(bounds[k][0]-1e-8<=x[k]<=bounds[k][1]+1e-8)
    test.assertAlmostEqual(2*(x['a_width']+x['axial_gap'])+x['b_width'],opt['length'],places=6)
    a,b,d=opt['separation'];extent=a*(x['a_width']+x['b_width']/2+x['axial_gap'])+b*max(x['outer_diameter']/2+x['swing_clearance'],x['axle_diameter']/2+x['radial_clearance']+x['radial_wall'])
    test.assertLessEqual(extent,d-cm.EPS+1e-7)
    test.assertTrue(all(z.deficit(x)<=1e-6 for z in cm.rules('central',x,opt)))

class Reduced(unittest.TestCase):
    def test_missed_case_128(self):check_example(self,0)
    def test_missed_case_134(self):check_example(self,1)
    def test_excessive_change_163(self):check_example(self,2)
    def test_local_equivalence(self):
        rng=random.Random(2603); v=EXAMPLES[0]['values'].copy()
        for _ in range(100):
            v.update(a_width=rng.uniform(1,5),b_width=rng.uniform(1,5),axial_gap=rng.uniform(.1,.6))
            opt=dict(length=2*(v['a_width']+v['axial_gap'])+v['b_width'],separation=(rng.random(),rng.random(),rng.uniform(3,10)))
            r=[z.deficit(v) for z in cm.rules('central',v,opt) if z.name=='上下の加工領域の離隔']
            raw=[z.deficit(v) for z in cm.rules('central',v,{**opt,'length':None}) if z.name=='上下の加工領域の離隔']
            for x,y in zip(r,raw):self.assertAlmostEqual(x,y,places=11)
    def test_pair_equivalence_mixed_locks(self):
        rng=random.Random(2604)
        for i in range(120):
            v={};opt={'projection':(rng.random(),rng.random(),rng.uniform(4,18))}
            for j,side in enumerate(('upper','lower')):
                local=EXAMPLES[0]['values'].copy();local.update(a_width=rng.uniform(1,5),b_width=rng.uniform(1,5),outer_diameter=rng.uniform(2,8))
                v.update({side+'.'+k:x for k,x in local.items()});opt[side]={'length':2*(local['a_width']+local['axial_gap'])+local['b_width'] if i&(1<<j) else None}
            r=[z.deficit(v) for z in cm.rules('central_pair',v,opt) if z.name=='上下の加工領域の離隔']
            raw=[z.deficit(v) for z in cm.rules('central_pair',v,{**opt,'upper':{},'lower':{}}) if z.name=='上下の加工領域の離隔']
            self.assertEqual(len(r),4)
            for x,y in zip(r,raw):self.assertAlmostEqual(x,y,places=11)
    def test_fixed_length_not_silently_relaxed(self):
        e=EXAMPLES[0];v=e['values'];r=cm.repair('central',v,e['options'],e['bounds'],locked=tuple(e['bounds']))
        self.assertFalse(r.ok);self.assertEqual(r.values,v)
    def test_pair_zero_axial_projection(self):
        v={s+'.'+k:x for s in ('upper','lower') for k,x in EXAMPLES[0]['values'].items()};opt={'projection':(0.,1.,10.),'upper':{'length':6.},'lower':{'length':7.}}
        r=[z.deficit(v) for z in cm.rules('central_pair',v,opt) if z.name=='上下の加工領域の離隔'];raw=[z.deficit(v) for z in cm.rules('central_pair',v,{**opt,'upper':{},'lower':{}}) if z.name=='上下の加工領域の離隔'];self.assertEqual(r,raw)
