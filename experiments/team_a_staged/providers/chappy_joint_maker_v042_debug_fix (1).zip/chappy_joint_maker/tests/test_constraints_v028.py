"""Regression of nonlinear angular coupling; no SciPy dependency."""
import json,math,random,unittest
from pathlib import Path
from test_constraints_v021 import cm,swap_math

class SwapCoupling(unittest.TestCase):
 def test_saved_counterexamples(self):
  for case in json.loads(Path(__file__).with_name('swap_regression_v028.json').read_text()):
   with self.subTest(count=case['n']):
    v,n,b,l,e,p=(case[k] for k in ('v','n','b','l','e','p'))
    validator=lambda w:swap_math.plan(swap_math.Spec(**w,lug_count=n))
    validator(case['w'])
    r=cm.repair('swap',v,{'lug_count':n},b,l,e,validator=validator,preferred=p)
    self.assertTrue(r.ok,r.reason);validator(r.values)
    for k in l:self.assertEqual(r.values[k],v[k])
    for k,x in r.values.items():self.assertTrue(x==v[k] or b[k][0]-1e-9<=x<=b[k][1]+1e-9)
 def test_angular_elimination_identity(self):
  rng=random.Random(283)
  for _ in range(300):
   n=rng.choice((2,3,4));v=dict(vars(swap_math.Spec()))
   v['diameter']=rng.uniform(2,30);v['radial_clearance']=rng.uniform(.001,v['diameter']/4-.001);v['lug_angle']=rng.uniform(4,90);v['lock_angle']=rng.uniform(5,150)
   rows={r.name:r for r in cm.rules('swap',v,{'lug_count':n})}
   a=rows['固定角と爪の保持代'].deficit(v);b=rows['隣接する爪溝との離隔'].deficit(v)
   self.assertAlmostEqual(a+b,rows['爪角幅と固定角の成立範囲'].deficit(v),places=10)
 def test_impossible_locked_angle_and_ratio(self):
  v={k:x for k,x in vars(swap_math.Spec(lug_angle=44,lock_angle=45)).items() if k not in ('flange','lug_count','direction')}
  r=cm.repair('swap',v,{'lug_count':4},{'lock_angle':(5,150)},validator=lambda w:swap_math.plan(swap_math.Spec(**w,lug_count=4)))
  self.assertFalse(r.ok);self.assertEqual(r.values,v)
 def test_valid_default_unchanged(self):
  v={k:x for k,x in vars(swap_math.Spec()).items() if k not in ('flange','lug_count','direction')}
  r=cm.repair('swap',v,{'lug_count':2},{k:(.01,1000) for k in v},validator=lambda w:swap_math.plan(swap_math.Spec(**w)))
  self.assertTrue(r.ok);self.assertEqual(r.values,v)
 def test_ratio_inverse_candidate(self):
  v={k:x for k,x in vars(swap_math.Spec(diameter=6.,radial_clearance=.5,lug_angle=40.,lock_angle=45.)).items() if k not in ('flange','lug_count','direction')}
  r=cm.repair('swap',v,{'lug_count':4},{'diameter':(6.,100.),'lock_angle':(5,150)},validator=lambda w:swap_math.plan(swap_math.Spec(**w,lug_count=4)))
  self.assertTrue(r.ok,r.reason);self.assertGreater(r.values['diameter'],6);self.assertEqual(r.values['lug_angle'],40.)
if __name__=='__main__':unittest.main()
