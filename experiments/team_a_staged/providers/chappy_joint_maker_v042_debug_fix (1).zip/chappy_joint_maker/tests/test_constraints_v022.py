"""Regression and new policy tests, Blender not required."""
import unittest
from test_constraints_v021 import c,cm,ctx,rotary,ball,hinge,swap,swap_math

def free(s,*keys):
    for k in keys:s['_cjm_policy_'+k]='FREE'
def lock(s,*keys):
    for k in keys:s['_cjm_policy_'+k]='LOCKED'
def prefer(s,*keys):
    for k in keys:s['_cjm_policy_'+k]='PREFERRED'

class Layout:
    def __init__(self):self.ops=[];self.labels=[]
    def operator(self,id,**kw):
        from types import SimpleNamespace
        op=SimpleNamespace(id=id,**kw);self.ops.append(op);return op
    def label(self,**kw):self.labels.append(kw)

class TestPolicy(unittest.TestCase):
    def test_default_and_migration(self):
        s=hinge();self.assertEqual(c.lock_state(s,'pin_clearance'),'LOCKED');self.assertEqual(c.lock_state(s,'outer_diameter'),'FREE')
        s['_cjm_lock_outer_diameter']=True;self.assertEqual(c.lock_state(s,'outer_diameter'),'LOCKED')
        self.assertEqual(c.cycle_lock(s,'pin_clearance'),'FREE');self.assertEqual(c.cycle_lock(s,'pin_clearance'),'PREFERRED');self.assertEqual(c.cycle_lock(s,'pin_clearance'),'LOCKED')
    def test_buttons(self):
        s=hinge();cc=ctx('HINGE',s);l=Layout()
        c.lock_button(l,cc,'hinge','','pin_clearance',s);self.assertEqual(l.ops[-1].icon,'LOCKED')
        free(s,'pin_clearance');c.lock_button(l,cc,'hinge','','pin_clearance',s);self.assertEqual(l.ops[-1].icon,'UNLOCKED')
        prefer(s,'pin_clearance');c.lock_button(l,cc,'hinge','','pin_clearance',s);self.assertEqual(l.ops[-1].icon,'SHIELD')
        c.lock_button(l,cc,'hinge','','minimum_radial_wall',s);self.assertEqual(l.labels[-1]['icon'],'INFO');self.assertEqual(len(l.ops),3)
    def test_operator_unlock_and_safety(self):
        s=hinge();cc=ctx('HINGE',s);op=c.CJM_OT_constraint_lock();op.engine='hinge';op.side='';op.prop='pin_clearance'
        self.assertEqual(op.execute(cc),{'FINISHED'});self.assertEqual(c.lock_state(s,'pin_clearance'),'FREE')
        op.prop='minimum_radial_wall';self.assertEqual(op.execute(cc),{'CANCELLED'})
    def test_hinge_unlocked_clearance(self):
        s=hinge(pin_diameter=2.8);lock(s,'outer_diameter');free(s,'pin_clearance')
        self.assertTrue(c.run(ctx('HINGE',s),s,'hinge','pin_diameter'));self.assertEqual(s.pin_diameter,2.8);self.assertAlmostEqual(s.pin_clearance,.19995,places=5);self.assertEqual(s.minimum_radial_wall,.4)
    def test_clearance_locked_by_default(self):
        s=hinge(pin_diameter=2.8);lock(s,'outer_diameter');self.assertTrue(c.run(ctx('HINGE',s),s,'hinge','pin_diameter'));self.assertEqual(s.pin_clearance,.4);self.assertLess(s.pin_diameter,2.8)
    def test_priority_before_free(self):
        s=hinge(pin_diameter=2.8);prefer(s,'outer_diameter');free(s,'pin_clearance');self.assertTrue(c.run(ctx('HINGE',s),s,'hinge','pin_diameter'));self.assertEqual(s.outer_diameter,4.);self.assertLess(s.pin_clearance,.4)
    def test_priority_fallback(self):
        s=hinge(pin_diameter=2.8);lock(s,'outer_diameter');prefer(s,'pin_clearance');self.assertTrue(c.run(ctx('HINGE',s),s,'hinge','pin_diameter'));self.assertLess(s.pin_clearance,.4);self.assertEqual(s.pin_diameter,2.8)
    def test_tip_clearance(self):
        s=hinge(total_length=8.);lock(s,'total_length','center_ratio');free(s,'axle_tip_clearance');self.assertTrue(c.run(ctx('HINGE',s),s,'hinge','total_length'));self.assertLess(s.axle_tip_clearance,.4);self.assertEqual(s.minimum_cap_wall,.8)
    def test_knuckle_gap(self):
        s=hinge(total_length=8.7,knuckle_gap=.5);lock(s,'total_length','center_ratio');free(s,'knuckle_gap');self.assertTrue(c.run(ctx('HINGE',s),s,'hinge','total_length'));self.assertLess(s.knuckle_gap,.5)
    def test_face_clearance_limit(self):
        s=hinge(total_length=8.7,knuckle_gap=.5,face_clearance_follow_gap=False,face_clearance=.45);lock(s,'total_length','center_ratio');free(s,'knuckle_gap');self.assertFalse(c.run(ctx('HINGE',s),s,'hinge'));self.assertEqual(s.knuckle_gap,.5)
    def test_ball_clearance_grows(self):
        s=ball(opening_diameter=12.);lock(s,'ball_diameter','opening_diameter');free(s,'clearance');cc=ctx('BALL',s);cc.scene.cjm_settings.constraint_ball_retention=False;self.assertTrue(c.run(cc,s,'ball'));self.assertGreater(s.clearance,1.)
    def test_fixed_length_gap(self):
        s=rotary(b_width=3.8,shoulder_enabled=False);s['_cjm_length_rotary']=7.4;lock(s,'a_width','b_width');free(s,'axial_gap');self.assertTrue(c.run(ctx('ROTARY',s),s,'rotary'));self.assertAlmostEqual(s.axial_gap,.1,places=5);self.assertAlmostEqual(c.length(s,'rotary'),7.4,places=5)
    def test_central_fixed_length_gap(self):
        s=rotary(b_width=4.);s['_cjm_length_central']=11.3;lock(s,'a_width','b_width');free(s,'axial_gap');self.assertTrue(c.run(ctx('DOUBLE',s,rotary()),s,'central'));self.assertAlmostEqual(s.axial_gap,.15,places=5)
    def test_shoulder_clearance(self):
        s=rotary(shoulder_diameter=4.);lock(s,'outer_diameter','shoulder_diameter');free(s,'shoulder_radial_clearance');self.assertTrue(c.run(ctx('ROTARY',s),s,'rotary'));self.assertLess(s.shoulder_radial_clearance,.151);self.assertEqual(s.radial_wall,.35)
    def test_swap_clearance(self):
        s=swap(lug_projection=.2);lock(s,'lug_projection');free(s,'radial_clearance');self.assertTrue(c.run(ctx('SWAP',s),s,'swap'));self.assertLess(s.radial_clearance,.2);swap_math.plan(swap_math.spec_from(s))
    def test_swap_angular_clearance(self):
        s=swap(lock_angle=28.);lock(s,'lock_angle','lug_angle','diameter');free(s,'radial_clearance');self.assertTrue(c.run(ctx('SWAP',s),s,'swap'));self.assertLess(s.radial_clearance,.4);swap_math.plan(swap_math.spec_from(s))
    def test_swap_axial_clearance(self):
        s=swap(depth=3.5);lock(s,'depth','lug_height');free(s,'axial_clearance');self.assertTrue(c.run(ctx('SWAP',s),s,'swap'));self.assertLess(s.axial_clearance,.4)
    def test_swap_wall_adjustable(self):
        s=swap(depth=3.5);lock(s,'depth','lug_height');free(s,'wall');self.assertTrue(c.run(ctx('SWAP',s),s,'swap'));self.assertLess(s.wall,2.);self.assertGreaterEqual(s.wall,.2)
    def test_no_zero_clearance_or_unsafe_wall(self):
        s=hinge(pin_diameter=3.2);lock(s,'outer_diameter','pin_diameter');free(s,'pin_clearance');self.assertFalse(c.run(ctx('HINGE',s),s,'hinge'));self.assertEqual(s.pin_clearance,.4);self.assertEqual(s.minimum_radial_wall,.4)
    def test_policy_independent_upper_lower(self):
        a,b=rotary(),rotary();free(a,'axial_gap');self.assertEqual(c.lock_state(b,'axial_gap'),'LOCKED')
    def test_no_solver_change_on_off(self):
        s=hinge(pin_diameter=2.8);free(s,'pin_clearance');c.changed(s,ctx('HINGE',s,enabled=False),'hinge','pin_diameter');self.assertEqual(s.pin_clearance,.4)

if __name__=='__main__':unittest.main()
