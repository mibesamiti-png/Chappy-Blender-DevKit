"""Explicit, disposable shape trials. Never write the live RNA dimensions.
Baseline is replayed because advisory signatures do not track mesh edits.
A pass is only a pass of the existing generator's sampled checks.
"""
from dataclasses import dataclass
from types import SimpleNamespace as NS
from . import shape_candidates as candidates, shape_diagnostics as diag

MAX_POSES = 200  # total sweep + fine inspection poses per build, both joints

@dataclass(frozen=True)
class Outcome:
    status: str
    message: str
    diagnostic: diag.Diagnostic | None = None


def select(context,s,index):
    detail=diag.Diagnostic.decode(s.last_generation_diagnostic)
    items=candidates.display(context,s,detail)
    data=candidates.inputs(context,s)
    if items is None or data is None or items!=candidates.recompute(s.last_shape_candidates,detail,data):
        raise ValueError('補正候補が古いか無効です。再生成してください')
    if not 0<=index<len(items):raise ValueError('候補がありません')
    return detail,items[index]


def proxies(s,fields,item):
    """Plain Python copies of all generator inputs; source objects are read-only references."""
    root={k:getattr(s,k) for k in ('design','axis','object_a','object_b','object_c',*(f'face_{k}' for k in ('a','bu','bl','c')),*(f'signature_{k}' for k in ('a','bu','bl','c')))}
    def spec(j):
        v={k:getattr(j,k) for k in (*fields,'shoulder_enabled','reverse_axis','minimum_angle','maximum_angle','preview_angle','pivot_set')}
        v['pivot']=tuple(j.pivot)
        return NS(**v)
    base=NS(**root,upper=spec(s.upper),lower=spec(s.lower))
    trial=NS(**root,upper=NS(**vars(base.upper)),lower=NS(**vars(base.lower)))
    for change in candidates.components(item):
        j=trial.upper if change['side']=='UPPER' else trial.lower
        if getattr(j,change['key'])!=change['before']:raise ValueError('候補の元寸法が変化しました')
        setattr(j,change['key'],change['after'])
    return base,trial


def matches(expected,actual):
    return (expected.code,expected.phase,expected.side,expected.component,expected.bearing_sign,expected.angle)==(actual.code,actual.phase,actual.side,actual.component,actual.bearing_sign,actual.angle)


def run(expected,base,trial,attempt):
    """Exactly one baseline, then at most one candidate. Cleanup failures propagate."""
    result=attempt(base)
    if result.status=='ERROR':return Outcome('ERROR','元条件の再検証中止：'+result.message)
    if result.status!='FAILED' or result.diagnostic is None or not matches(expected,result.diagnostic):
        return Outcome('STALE','現在の形状で同じ失敗を再現できません。再生成してください',result.diagnostic)
    result=attempt(trial)
    if result.status=='PASS':return Outcome('PASS','候補が生成時検査を通過しました（未適用）')
    return result


def budget(pairs,inspection_angles):
    count=sum(len(p['angles'])+len(inspection_angles(j.minimum_angle,j.maximum_angle,j.angle_step)) for j,p in pairs)
    if count>MAX_POSES:raise ValueError(f'試行対象の姿勢数 {count} が上限 {MAX_POSES} を超えます')
    return count


def attempt(context,s,*,plans,build,create,destroy,restore,inventory,inspection_angles):
    """Reuse the production generator in a disposable collection. Never commit.
    Inventory verifies cleanup; never delete unrelated datablocks by name.
    """
    selected=tuple(context.selected_objects);active=context.view_layer.objects.active
    before=inventory();col=None
    try:
        pairs=plans(context,s);budget(pairs,inspection_angles)
        col=create('CJM_Double_Trial',context.scene)
        out=build(context,s,col,pairs)
        if len(out)!=3:raise RuntimeError('試行結果が3部品ではありません')
        result=Outcome('PASS','生成時検査を通過')
    except diag.ShapeFailure as e:result=Outcome('FAILED',str(e),e.diagnostic)
    except Exception as e:result=Outcome('ERROR',str(e) or type(e).__name__)
    finally:
        try:
            if col is not None:destroy(col)
        finally:
            restore(context,selected,active)
            if inventory()!=before:raise RuntimeError('試行後のデータブロック差分を検出。再試行を中止してください')
            if set(context.selected_objects)!=set(selected) or context.view_layer.objects.active!=active:
                raise RuntimeError('試行後の選択状態を復元できませんでした')
    return result
