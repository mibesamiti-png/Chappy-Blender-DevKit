"""JOINT-SWAP-001 — independent detachable twist-lock generator."""
import math
import bpy
from bpy.types import Operator,Panel,PropertyGroup
from bpy.props import EnumProperty,FloatProperty,StringProperty,BoolProperty
from mathutils import Vector,Matrix
from . import swap_math as sm,ui,swap_preview as pv
from .hinge_maker import face_hinge as fh
from .geometry_ops import solid,stage,cut_checked,union_checked,intersect_volume
from .common_tools import restore_selection,selected_meshes

def _insertion_changed(self,context):
    if self.live_insertion<100 and self.live_rotation!=0:self.live_rotation=0
    ui.redraw(context)


class CJM_SwapSettings(PropertyGroup):
    axis: EnumProperty(name='着脱軸（+方向に抜く）',items=[(x,x,'') for x in 'XYZ'],default='Z',update=ui.swap_changed('axis'))
    diameter: FloatProperty(name='差込軸径',default=10,min=.5,max=1000,update=ui.constraint_update('swap','diameter',ui.swap_changed('diameter')))
    depth: FloatProperty(name='差込穴の深さ',default=6,min=.5,max=1000,update=ui.constraint_update('swap','depth',ui.swap_changed('depth')))
    lug_height: FloatProperty(name='爪の高さ',default=1.5,min=.1,max=100,update=ui.constraint_update('swap','lug_height',ui.swap_changed('lug_height')))
    lug_projection: FloatProperty(name='爪の突出量',default=1.5,min=.1,max=100,update=ui.constraint_update('swap','lug_projection',ui.swap_changed('lug_projection')))
    lug_angle: FloatProperty(name='爪の角幅（°）',default=24,min=4,max=90,update=ui.constraint_update('swap','lug_angle',ui.swap_changed('lug_angle')))
    lock_angle: FloatProperty(name='固定角度（°）',default=45,min=5,max=150,update=ui.constraint_update('swap','lock_angle',ui.swap_changed('lock_angle')))
    radial_clearance: FloatProperty(name='半径方向隙間（片側）',default=.4,min=.01,max=10,update=ui.constraint_update('swap','radial_clearance',ui.swap_changed('radial_clearance')))
    axial_clearance: FloatProperty(name='軸方向隙間（片側）',default=.4,min=.01,max=10,update=ui.constraint_update('swap','axial_clearance',ui.swap_changed('axial_clearance')))
    wall: FloatProperty(name='受けの外壁・底厚',default=2,min=.2,max=100,update=ui.constraint_update('swap','wall',ui.swap_changed('wall')))
    flange: FloatProperty(name='取付台座厚',default=2,min=.2,max=100,update=ui.swap_changed('flange'))
    lug_count: EnumProperty(name='爪数',items=[(str(x),str(x),'') for x in (2,3,4)],default='2',update=ui.constraint_update('swap','lug_count',ui.swap_changed('lug_count')))
    direction: EnumProperty(name='固定方向（抜く側から見て）',items=[('1','反時計回り',''),('-1','時計回り','')],default='1',update=ui.swap_changed('direction'))
    pose: EnumProperty(name='一式生成時の姿勢',items=[('SEPARATE','分離','印刷・形状確認用'),('INSERT','差込完了','爪と入口溝が一致'),('LOCK','回転固定','爪が保持壁の下')],default='SEPARATE')
    status: StringProperty(default='')
    live_enabled: BoolProperty(name='3D LIVE',default=False,options={'SKIP_SAVE'},update=lambda self,c:ui.redraw(c))
    live_focus: StringProperty(default='diameter',options={'SKIP_SAVE'})
    live_insertion: FloatProperty(name='差し込み量 (%)',default=100,min=0,max=100,options={'SKIP_SAVE'},update=_insertion_changed)
    live_rotation: FloatProperty(name='固定角度まで (%)',default=0,min=0,max=100,options={'SKIP_SAVE'},update=lambda self,c:ui.redraw(c))


def frame(axis):
    # Preserve a right-handed frame (local Z -> positive chosen world axis).
    return {'Z':Matrix.Identity(3),'X':Matrix(((0,0,1),(1,0,0),(0,1,0))),'Y':Matrix(((0,1,0),(0,0,1),(1,0,0)))}[axis]


def add_mesh(col,name,geo,origin,rot,role):
    v,f=geo;mesh=bpy.data.meshes.new(name);obj=None
    try:
        mesh.from_pydata(v,[],f);mesh.update()
        obj=bpy.data.objects.new(name,mesh);col.objects.link(obj)
        obj.matrix_world=Matrix.Translation(origin)@rot.to_4x4()
        obj['cjm_mechanism']='SWAP';obj['cjm_swap_role']=role
        return obj
    except Exception:
        if obj is not None:bpy.data.objects.remove(obj,do_unlink=True)
        if mesh.users==0:bpy.data.meshes.remove(mesh)
        raise

def attach_to_bodies(context,col,p,origin,rot):
    """Conservative direct mount: original bodies remain untouched.
    Require enough body stock to contain the entire nominal receiver wall.
    Head must overlap flange. Check the two complete parts at sampled angles.
    """
    src_a,src_b=selected_meshes(context,2)
    a=stage(context,src_a,col,'CJM_Swap_Body');b=stage(context,src_b,col,'CJM_Swap_Head')
    wall=add_mesh(col,'CJM_Swap_WallCheck',sm.female_mesh(p),origin,rot,'TEMP')
    context.view_layer.update();wv=solid(wall)
    if intersect_volume(context,wall,a,col)<wv*(1-1e-5):
        raise ValueError('本体に必要な受け壁・底厚を確保できません。カーソルと寸法を確認')
    fh._remove(wall)
    cutter=add_mesh(col,'CJM_Swap_Cutter',sm.female_mesh(p,True),origin,rot,'TEMP')
    plug=add_mesh(col,'CJM_Swap_Plug',sm.male_mesh(p),origin,rot,'TEMP')
    context.view_layer.update();cut_checked(a,cutter);union_checked(b,plug)
    # Check complete assemblies in insertion and discrete rotation poses.
    old=b.matrix_world.copy();to=Matrix.Translation(origin);back=Matrix.Translation(-origin)
    tol=max(1e-12,min(solid(a),solid(b))*1e-8)
    axis=rot@Vector((0,0,1))
    try:
        for i in range(7):
            angle=p.spec.direction*p.spec.lock_angle*i/6
            b.matrix_world=to@Matrix.Rotation(math.radians(angle),4,axis)@back@old
            context.view_layer.update()
            if intersect_volume(context,a,b,col)>tol:raise ValueError(f'本体と頭部が{angle:.1f}°で干渉します')
    finally:
        b.matrix_world=old;context.view_layer.update()
    return a,b

class CJM_OT_swap_generate(Operator):
    bl_idname='cjm.swap_generate';bl_label='着脱ジョイント生成';bl_options={'REGISTER','UNDO'}
    kind: EnumProperty(items=[('PAIR','ジョイント一式',''),('CUTTER','軸＋受け加工カッター',''),('ATTACH','本体へ直接取付','')],default='PAIR')
    @classmethod
    def poll(cls,context):return context.mode=='OBJECT' and ui.visible(context,'SWAP')
    def execute(self,context):
        if not self.poll(context):return {'CANCELLED'}
        s=context.scene.cjm_swap;col=None;selected=tuple(context.selected_objects);active=context.view_layer.objects.active
        try:
            p=sm.plan(sm.spec_from(s));origin=context.scene.cursor.location.copy();rot=frame(s.axis)
            col=fh._make_collection('CJM_Swap_Result',context.scene)
            if self.kind=='ATTACH':
                a,b=attach_to_bodies(context,col,p,origin,rot)
                for o,role in ((a,'RECEIVER'),(b,'PLUG')):
                    o['cjm_mechanism']='SWAP';o['cjm_swap_role']=role
            else:
                a=add_mesh(col,'CJM_Swap_Receiver' if self.kind=='PAIR' else 'CJM_Swap_Cutter',sm.female_mesh(p,self.kind=='CUTTER'),origin,rot,'RECEIVER' if self.kind=='PAIR' else 'CUTTER')
                # Cutter is always at the mouth; the male in CUTTER mode uses assembled insertion pose.
                offset=rot@Vector((2*p.outer+2,0,-p.tip)) if self.kind=='PAIR' and s.pose=='SEPARATE' else Vector((0,0,0))
                angle=p.spec.direction*p.spec.lock_angle if self.kind=='PAIR' and s.pose=='LOCK' else 0.
                b=add_mesh(col,'CJM_Swap_Plug',sm.male_mesh(p),origin+offset,rot@Matrix.Rotation(math.radians(angle),3,'Z'),'PLUG')
            context.view_layer.update();solid(a);solid(b)
            for o in (a,b):
                o['cjm_swap_mouth']=tuple(origin);o['cjm_swap_axis']=s.axis;o['cjm_swap_lock_angle']=p.spec.direction*p.spec.lock_angle
            restore_selection(context,(a,b),b)
            s.status={'CUTTER':'生成完了（カッターは印刷しない）','PAIR':'生成完了：2部品','ATTACH':'取付完了：原本は保持'}[self.kind];self.report({'INFO'},s.status);return {'FINISHED'}
        except Exception as e:
            if col:fh._destroy_collection(col)
            restore_selection(context,selected,active);s.status=str(e);self.report({'ERROR'},str(e));return {'CANCELLED'}

class VIEW3D_PT_cjm_swap(Panel):
    bl_idname='VIEW3D_PT_cjm_swap';bl_label='頭部交換・着脱ジョイント'
    bl_space_type='VIEW_3D';bl_region_type='UI';bl_category=ui.CATEGORY;bl_parent_id=ui.ROOT
    @classmethod
    def poll(cls,context):return ui.visible(context,'SWAP')
    def draw(self,context):
        l=self.layout;s=context.scene.cjm_swap
        l.label(text='差し込み → ひねり固定（JOINT-SWAP-001）');l.label(text='3Dカーソル＝受けの入口中心');ui.focus_row(l,s,'axis','swap','axis',expand=True)
        for title,props in [('軸・爪',('diameter','depth','lug_count','lug_height','lug_projection','lug_angle')),('固定・隙間',('lock_angle','direction','radial_clearance','axial_clearance')),('受け・取付台座',('wall','flange'))]:
            box=l.box();box.label(text=title)
            for prop in props:
                ui.focus_row(box,s,prop,'swap',prop)
        try:
            p=sm.plan(sm.spec_from(s));l.label(text=f'受け外径 {2*p.outer:.3g} / 寸法条件OK',icon='CHECKMARK');ok=True
        except ValueError as e:l.label(text=str(e),icon='ERROR');ok=False
        if s.live_enabled:
            v=l.box();v.label(text='3D LIVE：形状・着脱姿勢',icon='HIDE_OFF')
            row=v.row();row.enabled=s.live_rotation==0 or s.live_insertion<100;row.prop(s,'live_insertion',slider=True)
            row=v.row();row.enabled=s.live_insertion>=100;row.prop(s,'live_rotation',slider=True)
            if ok:
                dz,angle=pv.pose(p,s.live_insertion,s.live_rotation)
                v.label(text=f'現在の回転 {angle:+.1f}° / 抜き方向 {dz:.3g}')
            if s.live_insertion<100:v.label(text='奥まで差し込むと回転可能')
            elif s.live_rotation>0:v.label(text='抜く前に回転を0%へ戻す')
            v.label(text='青=受け / 橙=軸 / 水色=溝 / 黄=注目')
            v.label(text='表示専用：生成姿勢・原本は変更しません')
            v.label(text='本体との干渉は未検査',icon='INFO')
        b=l.column();b.enabled=ok and context.mode=='OBJECT';b.prop(s,'pose',expand=True)
        b.operator('cjm.swap_generate',text='ジョイント一式を生成',icon='MESH_CYLINDER').kind='PAIR'
        b.operator('cjm.swap_generate',text='差込軸＋受け加工カッター',icon='MOD_BOOLEAN').kind='CUTTER'
        b.operator('cjm.swap_generate',text='選択中の本体・頭部へ直接取付',icon='MOD_BOOLEAN').kind='ATTACH'
        l.label(text='直接取付：2体選択 / アクティブ=頭部')
        l.label(text='受け面をカーソルに、頭部を台座に重ねる')
        l.label(text='加工は複製 / 原本を手動で非表示')
        l.label(text='直接取付は差込姿勢・7角度を検査')
        l.label(text='取付はUnion / Differenceを使用');l.label(text='試作寸法：保持力・印刷は未検証',icon='INFO')
        if s.status:l.label(text=s.status[:64])

CLASSES=(CJM_SwapSettings,CJM_OT_swap_generate,VIEW3D_PT_cjm_swap)
