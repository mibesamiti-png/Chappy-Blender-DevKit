"""Viewport overlay for SWAP: GPU lines only, no Blender mesh creation."""
import bpy
from mathutils import Vector
from . import ui,swap_math as sm,swap_preview as pv
_HANDLE=None

def active(context):
    scene=getattr(context,'scene',None)
    s=getattr(scene,'cjm_swap',None)
    return s if s is not None and s.live_enabled and ui.visible(context,'SWAP') else None

def draw():
    c=bpy.context;s=active(c)
    if s is None:return
    import gpu
    from gpu_extras.batch import batch_for_shader
    from .swap_joint import frame
    origin=c.scene.cursor.location.copy();rot=frame(s.axis)
    try:
        groups=pv.groups(sm.spec_from(s),s.live_focus,s.live_insertion,s.live_rotation,c.scene.cjm_settings.face_view)
    except ValueError:
        r=max(.25,min(20.,s.diameter/2))
        groups=[(pv.arc(r,0)+pv.line((-r,-r,0),(r,r,0))+pv.line((-r,r,0),(r,-r,0)),pv.WARN)]
    shader=gpu.shader.from_builtin('UNIFORM_COLOR')
    saved={name:getattr(gpu.state,name+'_get')() for name in ('blend','depth_test','line_width','depth_mask') if hasattr(gpu.state,name+'_get')}
    gpu.state.blend_set('ALPHA')
    try:
        gpu.state.depth_test_set('NONE')
        if 'depth_mask' in saved:gpu.state.depth_mask_set(False)
        for edges,color in groups:
            if not edges:continue
            gpu.state.line_width_set(2.5 if color in (pv.FOCUS,pv.WARN) else 1.4)
            coords=[tuple(origin+rot@Vector(p)) for edge in edges for p in edge]
            batch=batch_for_shader(shader,'LINES',{'pos':coords});shader.bind();shader.uniform_float('color',color);batch.draw(shader)
    finally:
        if 'depth_mask' in saved:gpu.state.depth_mask_set(saved['depth_mask'])
        gpu.state.line_width_set(saved.get('line_width',1.0));gpu.state.depth_test_set(saved.get('depth_test','NONE'));gpu.state.blend_set(saved.get('blend','NONE'))
def install():
    global _HANDLE
    if _HANDLE is None:_HANDLE=bpy.types.SpaceView3D.draw_handler_add(draw,(),'WINDOW','POST_VIEW')
def uninstall():
    global _HANDLE
    try:
        if _HANDLE is not None:bpy.types.SpaceView3D.draw_handler_remove(_HANDLE,'WINDOW')
    finally:
        _HANDLE=None;pv.cached.cache_clear()
